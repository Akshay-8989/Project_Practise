"""
app.py
=======
Feature Engineering Layer — CLI entry point.

Modes:
  python app.py --consumer                  Kafka consumer (production)
  python app.py --file sample.json          Single payload file
  python app.py --folder sample_inputs/     Batch from folder
  python app.py --fit-tfidf corpus.txt      Fit TF-IDF on text corpus
  python app.py --training                  Batch + save to training store
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Dict, List

from config import CONFIG
from logger import get_logger
from pipeline import run_pipeline

log = get_logger("app")


def process_payload(payload: Dict) -> Dict:
    """Process one payload dict. Returns EngineeredFeatureSet dict."""
    result = run_pipeline(payload)
    if result.feature_set:
        return result.feature_set.model_dump()
    return {"status": "failed", "failure_reason": result.failure_reason,
            "failure_detail": result.failure_detail}


def process_file(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    return process_payload(payload)


def process_folder(folder: str) -> List[Dict]:
    results = []
    for fname in sorted(os.listdir(folder)):
        if not fname.endswith(".json"): continue
        fpath = os.path.join(folder, fname)
        log.info("Processing: %s", fname)
        try:
            out = process_file(fpath)
            results.append(out)
            status = out.get("status", "?")
            dim    = out.get("serving_features", {}).get("combined_dim", 0)
            emb    = out.get("serving_features", {}).get("embedding_dim", 0)
            log.info("  → status=%s combined_dim=%d emb_dim=%d", status, dim, emb)
        except Exception as exc:
            log.error("  FAILED: %s — %s", fname, exc)
    return results


def fit_tfidf_on_corpus(corpus_path: str):
    """Fit TF-IDF vectorizer from a plain text corpus file (one doc per line)."""
    from tfidf_engine import get_engine
    with open(corpus_path, "r", encoding="utf-8") as f:
        texts = [line.strip() for line in f if line.strip()]
    log.info("Fitting TF-IDF on %d texts from %s", len(texts), corpus_path)
    get_engine().fit(texts)
    log.info("TF-IDF fitted and saved.")


def main():
    parser = argparse.ArgumentParser(
        description="Enterprise Feature Engineering Layer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--consumer",    action="store_true", help="Start Kafka consumer loop")
    parser.add_argument("--file",        type=str, help="Process a single JSON payload file")
    parser.add_argument("--folder",      type=str, help="Batch process a folder of JSON files")
    parser.add_argument("--fit-tfidf",   type=str, help="Fit TF-IDF on a text corpus file")
    parser.add_argument("--output",      type=str, help="Write output JSON to this path")
    parser.add_argument("--training",    action="store_true", help="Enable training mode")
    parser.add_argument("--log-level",   default=CONFIG.log_level,
                        choices=["DEBUG","INFO","WARNING","ERROR"])
    args = parser.parse_args()

    CONFIG.log_level = args.log_level.upper()
    if args.training:
        CONFIG.mode = "training"

    if args.consumer:
        from consumer import FeatureEngineeringConsumer
        FeatureEngineeringConsumer().run()

    elif args.fit_tfidf:
        fit_tfidf_on_corpus(args.fit_tfidf)

    elif args.file:
        result = process_file(args.file)
        out = json.dumps(result, indent=2, default=str)
        if args.output:
            with open(args.output, "w") as f: f.write(out)
            print(f"Output written to {args.output}")
        else:
            print(out)

    elif args.folder:
        results = process_folder(args.folder or "sample_inputs/")
        out = json.dumps(results, indent=2, default=str)
        if args.output:
            with open(args.output, "w") as f: f.write(out)
            print(f"{len(results)} documents processed → {args.output}")
        else:
            print(f"{len(results)} documents processed")
            ok = sum(1 for r in results if r.get("status") in ("success","partial"))
            print(f"Success: {ok} / {len(results)}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
