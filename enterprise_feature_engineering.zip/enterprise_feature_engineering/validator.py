"""
validator.py
=============
Validates PreprocessedDocument payloads arriving from the Preprocessing Layer.
"""

from typing import Any, Dict, Tuple
from pydantic import ValidationError
from schema import PreprocessedDocument, ValidationResult
from logger import get_logger

log = get_logger("validator")


def validate_preprocessed_payload(
    raw: Dict[str, Any],
) -> Tuple[ValidationResult, PreprocessedDocument | None]:
    """
    Parse and validate a raw Kafka message dict from the Preprocessing Layer.
    Returns (ValidationResult, PreprocessedDocument | None).
    """
    try:
        doc = PreprocessedDocument(**raw)
    except ValidationError as exc:
        errors = "; ".join(f"{e['loc']}: {e['msg']}" for e in exc.errors())
        return ValidationResult.fail("SCHEMA_ERROR", errors), None
    except Exception as exc:
        return ValidationResult.fail("PARSE_ERROR", str(exc)), None

    if not doc.doc_id or not doc.doc_id.strip():
        return ValidationResult.fail("EMPTY_DOC_ID", "doc_id is empty"), None

    text = (doc.masked_text or doc.clean_text or "").strip()
    if not text:
        return ValidationResult.fail("EMPTY_TEXT", "Both masked_text and clean_text are empty"), None

    if doc.status == "failed":
        return ValidationResult.fail(
            "UPSTREAM_FAILED",
            "Preprocessing layer reported failure — skipping feature engineering",
        ), None

    if doc.business_metadata.source_system == "UNKNOWN":
        log.warning("[%s] source_system is UNKNOWN", doc.doc_id)
    if doc.business_metadata.department == "UNKNOWN":
        log.warning("[%s] department is UNKNOWN", doc.doc_id)

    return ValidationResult.ok(), doc
