"""
chunk_aggregator.py
====================
Aggregates embeddings across multiple chunks of a long document.

When a document was split into N chunks by the Preprocessing Layer,
the Classification Layer needs ONE embedding per document (or one per segment).
This module aggregates N chunk embeddings into a single vector.

Aggregation strategies:
  mean  — element-wise mean (default; works well for most tasks)
  max   — element-wise max pooling (captures peak signal per dimension)
  both  — concatenate mean and max (double dimension; richer representation)

For BERT/RoBERTa inference on chunked documents, the standard approach is
mean pooling — this is consistent with how sentence-transformers are trained.

Parent-child lineage:
  The chunk_aggregator only runs when chunk_info.total_chunks > 1.
  It returns aggregated features tagged with the parent_doc_id so the
  Classification Layer can associate the aggregate with the source document.

If only one chunk: pass-through (no aggregation needed).
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np

from schema import EmbeddingFeatures
from config import CONFIG
from logger import get_logger

log = get_logger("chunk_aggregator")


def aggregate_chunk_embeddings(
    chunk_vectors: List[List[float]],
    model_name:    str,
    model_alias:   str,
    doc_id:        str = "",
) -> EmbeddingFeatures:
    """
    Aggregate multiple chunk embedding vectors into one document-level vector.

    Args:
        chunk_vectors: List of per-chunk embedding vectors.
        model_name:    Name of the embedding model used.
        model_alias:   Short alias for the model.
        doc_id:        For logging.

    Returns:
        Single EmbeddingFeatures representing the full document.
    """
    if not chunk_vectors:
        return EmbeddingFeatures(model_name=model_name, model_alias=model_alias)

    if len(chunk_vectors) == 1:
        vec = np.array(chunk_vectors[0], dtype=np.float32)
        return EmbeddingFeatures(
            model_name  = model_name,
            model_alias = model_alias,
            dimension   = len(vec),
            vector      = vec.tolist(),
            vector_norm = float(np.linalg.norm(vec)),
            aggregation = "passthrough",
            chunk_count = 1,
        )

    strategy = CONFIG.chunk_aggregation.lower()
    matrix   = np.array(chunk_vectors, dtype=np.float32)   # (N, dim)

    if strategy == "mean":
        agg = matrix.mean(axis=0)
    elif strategy == "max":
        agg = matrix.max(axis=0)
    elif strategy == "both":
        # Concatenate mean and max → doubles the dimension
        agg = np.concatenate([matrix.mean(axis=0), matrix.max(axis=0)])
    else:
        log.warning("[%s] Unknown aggregation '%s' — using mean", doc_id, strategy)
        agg = matrix.mean(axis=0)

    # Re-normalise aggregate to unit vector
    norm = float(np.linalg.norm(agg))
    if norm > 0:
        agg = agg / norm

    log.debug(
        "[%s] Aggregated %d chunks → dim=%d strategy=%s",
        doc_id, len(chunk_vectors), len(agg), strategy,
    )

    return EmbeddingFeatures(
        model_name  = model_name,
        model_alias = model_alias,
        dimension   = len(agg),
        vector      = agg.tolist(),
        vector_norm = norm,
        aggregation = strategy,
        chunk_count = len(chunk_vectors),
    )


def compute_chunk_variance(chunk_vectors: List[List[float]]) -> float:
    """
    Compute variance across chunk embeddings.
    High variance → document has diverse content across chunks (may need
    segment-level classification rather than document-level).
    Low variance → homogeneous document (single classification is reliable).
    """
    if len(chunk_vectors) < 2:
        return 0.0
    matrix = np.array(chunk_vectors, dtype=np.float32)
    return float(np.mean(np.var(matrix, axis=0)))
