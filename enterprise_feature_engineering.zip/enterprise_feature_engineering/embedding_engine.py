"""
embedding_engine.py
====================
Pluggable transformer embedding engine.

Supports:
  minilm  — sentence-transformers/all-MiniLM-L6-v2  (384-dim, fast, default)
  bert    — bert-base-uncased                        (768-dim)
  roberta — roberta-base                             (768-dim)
  deberta — microsoft/deberta-v3-small               (768-dim)
  mpnet   — sentence-transformers/all-mpnet-base-v2  (768-dim, high quality)

Architecture:
  - SentenceTransformer models: encode() directly → mean pooled embedding
  - Raw HuggingFace models: extract [CLS] token embedding from last hidden state
  - Both paths normalised to L2 unit vector for cosine similarity compatibility

Performance:
  - Model loaded ONCE at startup (lazy, on first call)
  - SHA-256 content hash used as cache key
  - Embedding cache stored as .npy files in artifacts/embedding_cache/
  - Cache hit: ~0.1ms; Cache miss: model inference
  - Batch encoding for training mode

CPU / GPU:
  - Default: CPU (Windows compatible, no CUDA required)
  - Set EMBEDDING_DEVICE=cuda for GPU acceleration

Fallback:
  If sentence-transformers is not installed and embedding is enabled,
  returns a zero vector and logs a warning.
  This ensures the rest of the pipeline continues — Classification Layer
  will use classical features only.
"""

from __future__ import annotations

import hashlib
import os
from typing import List, Optional, Tuple

import numpy as np

from schema import EmbeddingFeatures
from config import CONFIG
from logger import get_logger

log = get_logger("embedding_engine")


class EmbeddingEngine:
    """
    Lazy-loaded transformer embedding engine.
    Thread-safe for concurrent inference (read-only after model load).
    """

    def __init__(self):
        self._model      = None
        self._model_name = ""
        self._dim        = 0
        self._alias      = CONFIG.embedding.model_alias
        self._is_st      = False    # True if sentence-transformers model

    def encode(
        self,
        text:    str,
        doc_id:  str = "",
    ) -> EmbeddingFeatures:
        """
        Encode a single text → EmbeddingFeatures.
        Returns cached result if available.
        """
        if not CONFIG.embedding.enabled:
            return EmbeddingFeatures(model_name=self._model_name or "disabled")

        # Check cache first
        if CONFIG.embedding.cache_enabled:
            cached = self._load_cache(text)
            if cached is not None:
                log.debug("[%s] Embedding cache hit", doc_id)
                return EmbeddingFeatures(
                    model_name  = self._model_name,
                    model_alias = self._alias,
                    dimension   = len(cached),
                    vector      = cached.tolist(),
                    vector_norm = float(np.linalg.norm(cached)),
                    from_cache  = True,
                    aggregation = "mean",
                    chunk_count = 1,
                )

        # Load model on first call
        model, model_name, dim = self._get_model()
        if model is None:
            return EmbeddingFeatures(model_name="unavailable")

        try:
            vector = self._encode_text(model, text)
            vector_norm = float(np.linalg.norm(vector))

            # Normalise to unit vector
            if vector_norm > 0:
                vector_normalised = vector / vector_norm
            else:
                vector_normalised = vector

            # Cache
            if CONFIG.embedding.cache_enabled:
                self._save_cache(text, vector_normalised)

            log.debug("[%s] Embedding generated: dim=%d norm=%.4f", doc_id, dim, vector_norm)

            return EmbeddingFeatures(
                model_name  = model_name,
                model_alias = self._alias,
                dimension   = dim,
                vector      = vector_normalised.tolist(),
                vector_norm = vector_norm,
                from_cache  = False,
                aggregation = "mean",
                chunk_count = 1,
            )

        except Exception as exc:
            log.error("[%s] Embedding encode failed: %s", doc_id, exc)
            return EmbeddingFeatures(model_name=model_name or "error")

    def encode_batch(self, texts: List[str]) -> np.ndarray:
        """
        Batch encode for training mode.
        Returns (N, dim) numpy array.
        """
        model, model_name, dim = self._get_model()
        if model is None:
            return np.zeros((len(texts), 384))

        try:
            if self._is_st:
                vecs = model.encode(
                    texts,
                    batch_size       = CONFIG.embedding.batch_size,
                    show_progress_bar= False,
                    normalize_embeddings = True,
                )
                return np.array(vecs)
            else:
                return np.vstack([self._encode_text(model, t) for t in texts])
        except Exception as exc:
            log.error("Batch encode failed: %s", exc)
            return np.zeros((len(texts), dim or 384))

    # ── Model loading ────────────────────────────────────────────────────

    def _get_model(self) -> Tuple:
        """Lazy load model on first call. Returns (model, name, dim)."""
        if self._model is not None:
            return self._model, self._model_name, self._dim

        model_name, dim = CONFIG.embedding.resolve()
        log.info("Loading embedding model: %s", model_name)

        # Try sentence-transformers first (preferred — handles pooling automatically)
        try:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer(
                model_name,
                device = CONFIG.embedding.device,
            )
            # Detect actual dimension from a test encode
            test = model.encode(["test"], normalize_embeddings=True)
            actual_dim = test.shape[1]
            self._model      = model
            self._model_name = model_name
            self._dim        = actual_dim
            self._is_st      = True
            log.info("SentenceTransformer loaded: %s (dim=%d)", model_name, actual_dim)
            return model, model_name, actual_dim

        except ImportError:
            log.warning("sentence-transformers not installed — trying HuggingFace transformers")
        except Exception as exc:
            log.warning("SentenceTransformer load failed: %s — trying HuggingFace", exc)

        # Fallback: raw HuggingFace transformers
        try:
            from transformers import AutoModel, AutoTokenizer
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            model     = AutoModel.from_pretrained(model_name)
            model.eval()
            self._model      = (tokenizer, model)
            self._model_name = model_name
            self._dim        = dim or 768
            self._is_st      = False
            log.info("HuggingFace model loaded: %s (dim=%d)", model_name, self._dim)
            return (tokenizer, model), model_name, self._dim

        except ImportError:
            log.error(
                "Neither sentence-transformers nor transformers is installed. "
                "Embeddings disabled. Run: pip install sentence-transformers"
            )
        except Exception as exc:
            log.error("HuggingFace model load failed: %s", exc)

        return None, model_name, dim or 384

    def _encode_text(self, model, text: str) -> np.ndarray:
        """Encode one text. Handles both ST and raw HF model."""
        if self._is_st:
            vec = model.encode(
                [text[:CONFIG.embedding.max_length * 4]],
                normalize_embeddings=True,
                show_progress_bar=False,
            )
            return vec[0]
        else:
            import torch
            tokenizer, hf_model = model
            inputs = tokenizer(
                text,
                return_tensors = "pt",
                truncation     = True,
                max_length     = CONFIG.embedding.max_length,
                padding        = True,
            )
            with torch.no_grad():
                outputs = hf_model(**inputs)
            # Mean pool last hidden state
            vec = outputs.last_hidden_state.mean(dim=1).squeeze().numpy()
            return vec / (np.linalg.norm(vec) + 1e-8)

    # ── Cache ─────────────────────────────────────────────────────────────

    @staticmethod
    def _cache_key(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def _cache_path(self, text: str) -> str:
        os.makedirs(CONFIG.embedding_cache, exist_ok=True)
        return os.path.join(
            CONFIG.embedding_cache,
            f"{self._alias}_{self._cache_key(text)[:16]}.npy",
        )

    def _load_cache(self, text: str) -> Optional[np.ndarray]:
        path = self._cache_path(text)
        if os.path.isfile(path):
            try:
                return np.load(path)
            except Exception:
                pass
        return None

    def _save_cache(self, text: str, vec: np.ndarray):
        try:
            np.save(self._cache_path(text), vec)
        except Exception as exc:
            log.debug("Embedding cache write failed: %s", exc)


# Module-level singleton
_engine: Optional[EmbeddingEngine] = None


def get_engine() -> EmbeddingEngine:
    global _engine
    if _engine is None:
        _engine = EmbeddingEngine()
    return _engine


def encode_text(text: str, doc_id: str = "") -> EmbeddingFeatures:
    return get_engine().encode(text, doc_id=doc_id)
