"""
consumer.py
============
Kafka Consumer for the Feature Engineering Layer.
Consumes from preprocessed_documents and drives the pipeline.
"""

from __future__ import annotations

import json
import signal
from typing import Dict

from kafka import KafkaConsumer
from kafka.errors import NoBrokersAvailable

from config import CONFIG
from logger import get_logger
from producer import FeatureProducer
from pipeline import run_pipeline
from schema import ProcessingStatus

log = get_logger("consumer")


def _deser(data: bytes) -> Dict:
    try:   return json.loads(data.decode("utf-8")) if data else {}
    except: return {}


class FeatureEngineeringConsumer:
    """Consumes preprocessed_documents and publishes engineered_features."""

    def __init__(self):
        self._running  = True
        self._producer = None
        self._consumer = None
        self._stats    = {"received": 0, "success": 0, "failed": 0}
        signal.signal(signal.SIGINT,  self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

    def run(self):
        try:
            self._producer = FeatureProducer()
            self._consumer = KafkaConsumer(
                CONFIG.topics.preprocessed,
                value_deserializer = _deser,
                key_deserializer   = lambda k: k.decode("utf-8") if k else None,
                **CONFIG.kafka.consumer_kwargs(),
            )
        except NoBrokersAvailable as exc:
            log.critical("Kafka unavailable: %s", exc); raise

        log.info(
            "Feature Engineering consumer started | topic=%s | group=%s | mode=%s",
            CONFIG.topics.preprocessed, CONFIG.kafka.group_id, CONFIG.mode,
        )

        try:
            for msg in self._consumer:
                if not self._running: break
                self._handle(msg)
        finally:
            self._consumer.close()
            self._producer.close()
            log.info("Shutdown | recv=%d ok=%d fail=%d",
                     self._stats["received"], self._stats["success"], self._stats["failed"])

    def _handle(self, msg):
        self._stats["received"] += 1
        raw = msg.value

        result = run_pipeline(raw, source_topic=msg.topic)

        if result.status in (ProcessingStatus.SUCCESS.value, ProcessingStatus.PARTIAL.value):
            self._stats["success"] += 1
            payload = result.feature_set.model_dump()
            self._producer.send_features(payload)

            # In training mode, also publish to training store
            if CONFIG.is_training_mode:
                self._producer.send_training(payload)

            if result.audit:
                self._producer.send_audit(result.audit.model_dump())
            log.info("Engineered: %s", result)

        else:
            self._stats["failed"] += 1
            if result.dlr:
                self._producer.send_dlq(result.dlr.model_dump())
            if result.audit:
                self._producer.send_audit(result.audit.model_dump())
            log.warning("Failed: %s", result)

        self._consumer.commit()

        if self._stats["received"] % 100 == 0:
            log.info("Stats | recv=%d ok=%d fail=%d",
                     self._stats["received"], self._stats["success"], self._stats["failed"])

    def _shutdown(self, *_):
        log.info("Shutdown signal received.")
        self._running = False
