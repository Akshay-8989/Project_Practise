"""
feature_registry.py
====================
Feature name registry, version management, and drift detection.

Responsibilities:
  1. Maintain a canonical mapping of feature_index → feature_name
     Used by SHAP, LIME, and Feature Importance charts in the
     Classification Layer and Governance Dashboard.

  2. Version feature schemas so downstream models know what they're getting.
     Schema change → version bump → Classification Layer knows to retrain.

  3. Feature drift detection:
     - Track distribution statistics of numerical features over a rolling window
     - Alert when mean or variance shifts beyond threshold
     - Hooks for the Governance Dashboard to trigger retraining workflows

  4. Null / missing feature fallback registry:
     - Each feature type has a defined fallback value
     - Ensures Classification Layer never receives NaN inputs

SHAP Compatibility:
  The Classification Layer calls:
    registry.get_feature_names(feature_type)
  to get the exact feature names to pass to shap.Explainer or LIME.
  Feature names must exactly match the columns of the numpy array
  passed to the model.
"""

from __future__ import annotations

import json
import os
import time
from collections import deque
from datetime import datetime
from typing import Any, Deque, Dict, List, Optional, Tuple

import numpy as np

from config import CONFIG
from logger import get_logger

log = get_logger("feature_registry")


# ─────────────────────────────────────────────────────────────────────────────
# Feature schema version
# Bump when feature vector structure changes
# ─────────────────────────────────────────────────────────────────────────────

FEATURE_SCHEMA_VERSION = "v1.0.0"

# Null fallback values per feature type
NULL_FALLBACKS: Dict[str, Any] = {
    "stat":      0.0,
    "metadata":  0.0,
    "risk":      0.0,
    "tfidf":     0.0,
    "embedding": 0.0,
}


# ─────────────────────────────────────────────────────────────────────────────
# Feature Registry
# ─────────────────────────────────────────────────────────────────────────────

class FeatureRegistry:
    """
    Singleton registry for feature names, versions, and drift tracking.
    Persisted to artifacts/feature_registry.json for cross-session continuity.
    """

    def __init__(self):
        self._registry:      Dict[str, List[str]] = {}
        self._drift_trackers:Dict[str, "DriftTracker"] = {}
        self._registry_path  = os.path.join(CONFIG.artifact_base, "feature_registry.json")
        self._load()

    # ── Feature name registry ─────────────────────────────────────────────

    def register(self, feature_type: str, names: List[str]):
        """Register feature names for a given type. Called after vectorizer fit."""
        if not names:
            return
        self._registry[feature_type] = names
        self._save()
        log.info("Registered %d feature names for type '%s'", len(names), feature_type)

    def get_feature_names(self, feature_type: str) -> List[str]:
        """Return SHAP-compatible feature names for a feature type."""
        return self._registry.get(feature_type, [])

    def get_all_feature_names(self) -> Dict[str, List[str]]:
        return dict(self._registry)

    def get_combined_feature_names(self, include: List[str] = None) -> List[str]:
        """
        Return combined feature name list for a concatenated vector.
        Order: stat → metadata → risk  (same as pipeline.py build_combined_vector)
        """
        types  = include or ["stat", "metadata", "risk"]
        result = []
        for t in types:
            result.extend(self._registry.get(t, []))
        return result

    # ── Drift tracking ────────────────────────────────────────────────────

    def update_drift(self, feature_type: str, vector: List[float]):
        """Update drift statistics for a feature vector."""
        if not CONFIG.drift.enabled:
            return
        if feature_type not in self._drift_trackers:
            self._drift_trackers[feature_type] = DriftTracker(
                window_size     = CONFIG.drift.window_size,
                alert_threshold = CONFIG.drift.alert_threshold,
            )
        self._drift_trackers[feature_type].update(vector, feature_type)

    def get_drift_report(self) -> Dict[str, Dict]:
        return {
            k: t.report()
            for k, t in self._drift_trackers.items()
        }

    # ── Schema version ────────────────────────────────────────────────────

    @property
    def schema_version(self) -> str:
        return FEATURE_SCHEMA_VERSION

    # ── Null fallback ─────────────────────────────────────────────────────

    @staticmethod
    def fill_nulls(vector: List[float], feature_type: str) -> List[float]:
        """Replace NaN/None values with type-specific fallback."""
        fallback = NULL_FALLBACKS.get(feature_type, 0.0)
        return [fallback if (v is None or (isinstance(v, float) and np.isnan(v))) else v
                for v in vector]

    # ── Persistence ───────────────────────────────────────────────────────

    def _load(self):
        if os.path.isfile(self._registry_path):
            try:
                with open(self._registry_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self._registry = data.get("feature_names", {})
                log.info("Feature registry loaded from %s", self._registry_path)
            except Exception as exc:
                log.warning("Could not load feature registry: %s", exc)

    def _save(self):
        os.makedirs(os.path.dirname(self._registry_path) or ".", exist_ok=True)
        try:
            existing = {}
            if os.path.isfile(self._registry_path):
                with open(self._registry_path, "r", encoding="utf-8") as f:
                    existing = json.load(f)
            existing["feature_names"]   = self._registry
            existing["schema_version"]  = FEATURE_SCHEMA_VERSION
            existing["last_updated"]    = datetime.utcnow().isoformat()
            with open(self._registry_path, "w", encoding="utf-8") as f:
                json.dump(existing, f, indent=2)
        except Exception as exc:
            log.error("Could not save feature registry: %s", exc)


# ─────────────────────────────────────────────────────────────────────────────
# Drift Tracker
# ─────────────────────────────────────────────────────────────────────────────

class DriftTracker:
    """
    Rolling-window feature distribution drift detector.

    Tracks mean and standard deviation of each feature over a window.
    When current mean deviates from baseline by > threshold, raises alert.

    This is a lightweight KS-inspired heuristic.
    For production: replace with Evidently AI or River (as mentioned in PS MLOps section).
    """

    def __init__(self, window_size: int = 1000, alert_threshold: float = 0.15):
        self._window:     Deque[List[float]] = deque(maxlen=window_size)
        self._baseline_mean: Optional[np.ndarray] = None
        self._baseline_std:  Optional[np.ndarray] = None
        self._window_size    = window_size
        self._threshold      = alert_threshold
        self._alert_count    = 0
        self._total_count    = 0

    def update(self, vector: List[float], feature_type: str = ""):
        if not vector:
            return
        self._window.append(vector)
        self._total_count += 1

        # Set baseline from first window_size/2 observations
        if self._total_count == self._window_size // 2:
            data = np.array(list(self._window), dtype=np.float32)
            self._baseline_mean = data.mean(axis=0)
            self._baseline_std  = data.std(axis=0) + 1e-8
            log.info("[%s] Drift baseline established (%d samples)", feature_type, self._total_count)

        # Check drift after baseline is set
        if self._baseline_mean is not None and self._total_count % 100 == 0:
            current = np.array(list(self._window)[-100:], dtype=np.float32).mean(axis=0)
            drift   = np.abs((current - self._baseline_mean) / self._baseline_std).mean()
            if drift > self._threshold:
                self._alert_count += 1
                log.warning(
                    "[%s] Feature drift detected: normalised_delta=%.4f > threshold=%.3f "
                    "(alert #%d)",
                    feature_type, drift, self._threshold, self._alert_count,
                )

    def report(self) -> Dict:
        return {
            "total_samples":   self._total_count,
            "window_size":     self._window_size,
            "alert_count":     self._alert_count,
            "has_baseline":    self._baseline_mean is not None,
        }


# Module-level singleton
_registry: Optional[FeatureRegistry] = None


def get_registry() -> FeatureRegistry:
    global _registry
    if _registry is None:
        _registry = FeatureRegistry()
    return _registry
