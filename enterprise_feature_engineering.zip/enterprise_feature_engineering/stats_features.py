"""
stats_features.py
==================
Statistical text feature extraction.

Produces a dense numerical vector from text properties:
  token_count, avg_word_length, sentence_count, uppercase_ratio,
  digit_ratio, special_char_ratio, entropy, repeated_term_ratio,
  type_token_ratio, punctuation_ratio, etc.

These features capture document structure signals that complement TF-IDF.
High uppercase_ratio → possible legal/compliance document.
High digit_ratio → financial report.
Low type_token_ratio → repetitive form/template.
High entropy → information-dense confidential content.

All values are normalised to [0, 1] range where possible to avoid
scale issues with linear models.
"""

from __future__ import annotations

import math
import re
import string
from collections import Counter
from typing import List

from schema import StatisticalFeatures, TextStats
from logger import get_logger

log = get_logger("stats_features")

_PUNCT = set(string.punctuation)
_SPECIAL = re.compile(r"[^a-zA-Z0-9\s]")
_UPPER   = re.compile(r"[A-Z]")
_DIGIT   = re.compile(r"\d")


def extract_stat_features(
    text:   str,
    tokens: List[str],
    stats:  TextStats,
    doc_id: str = "",
) -> StatisticalFeatures:
    """
    Compute statistical text features from masked_text and token list.

    Args:
        text:   Masked text (PII already replaced with tags).
        tokens: Tokenised word list from Preprocessing Layer.
        stats:  TextStats object from Preprocessing Layer.
        doc_id: For logging.

    Returns:
        StatisticalFeatures with all fields populated.
    """
    if not text:
        log.warning("[%s] Empty text for stat features", doc_id)
        return StatisticalFeatures()

    total_chars = max(len(text), 1)
    words       = tokens if tokens else text.split()
    n_words     = max(len(words), 1)
    n_unique    = len(set(words))

    # ── Token-level features ──────────────────────────────────────────────
    word_lengths    = [len(w) for w in words] if words else [0]
    avg_word_len    = sum(word_lengths) / n_words
    max_word_len    = float(max(word_lengths)) if word_lengths else 0.0

    # Type-token ratio (lexical diversity)
    ttr = n_unique / n_words

    # Repeated term ratio (terms that appear more than once)
    freq            = Counter(words)
    repeated_count  = sum(1 for c in freq.values() if c > 1)
    repeated_ratio  = repeated_count / n_unique if n_unique else 0.0

    # ── Character-level features ──────────────────────────────────────────
    uppercase_chars = len(_UPPER.findall(text))
    digit_chars     = len(_DIGIT.findall(text))
    punct_chars     = sum(1 for c in text if c in _PUNCT)
    special_chars   = len(_SPECIAL.findall(text))
    space_chars     = text.count(" ") + text.count("\n") + text.count("\t")

    uppercase_ratio  = uppercase_chars  / total_chars
    digit_ratio      = digit_chars      / total_chars
    punct_ratio      = punct_chars      / total_chars
    special_ratio    = special_chars    / total_chars
    whitespace_ratio = space_chars      / total_chars

    # ── Shannon entropy (character-level) ─────────────────────────────────
    entropy = _shannon_entropy(text)

    # ── Sentence-level ────────────────────────────────────────────────────
    sentence_count     = float(stats.sentence_count) if stats.sentence_count else 1.0
    avg_sent_length    = n_words / sentence_count

    log.debug(
        "[%s] StatFeatures: tokens=%d ttr=%.3f entropy=%.3f upper=%.3f digit=%.3f",
        doc_id, n_words, ttr, entropy, uppercase_ratio, digit_ratio,
    )

    return StatisticalFeatures(
        token_count         = float(n_words),
        unique_token_count  = float(n_unique),
        type_token_ratio    = round(ttr, 6),
        avg_word_length     = round(avg_word_len, 4),
        max_word_length     = max_word_len,
        sentence_count      = sentence_count,
        avg_sentence_length = round(avg_sent_length, 4),
        uppercase_ratio     = round(uppercase_ratio, 6),
        digit_ratio         = round(digit_ratio, 6),
        special_char_ratio  = round(special_ratio, 6),
        punctuation_ratio   = round(punct_ratio, 6),
        whitespace_ratio    = round(whitespace_ratio, 6),
        entropy             = round(entropy, 6),
        repeated_term_ratio = round(repeated_ratio, 6),
        char_count          = float(total_chars),
        reduction_pct       = stats.reduction_pct,
    )


def _shannon_entropy(text: str) -> float:
    """Compute Shannon entropy of character frequency distribution."""
    if not text:
        return 0.0
    freq = Counter(text)
    n    = len(text)
    return -sum((c / n) * math.log2(c / n) for c in freq.values() if c > 0)
