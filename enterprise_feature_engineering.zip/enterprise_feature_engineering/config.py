"""
config.py
==========
Environment-driven configuration for the Enterprise Feature Engineering Layer.
"""

import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def _e(k: str, d: str = "") -> str:        return os.environ.get(k, d)
def _eb(k: str, d: bool = False) -> bool:  return _e(k, str(d)).lower() in ("true","1","yes")
def _ei(k: str, d: int = 0) -> int:
    try: return int(_e(k, str(d)))
    except: return d
def _ef(k: str, d: float = 0.0) -> float:
    try: return float(_e(k, str(d)))
    except: return d
def _el(k: str, d: str = "") -> List[str]:
    raw = _e(k, d); return [x.strip() for x in raw.split(",") if x.strip()] if raw else []


@dataclass
class KafkaConfig:
    bootstrap_servers:  str  = field(default_factory=lambda: _e("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"))
    security_protocol:  str  = field(default_factory=lambda: _e("KAFKA_SECURITY_PROTOCOL", "PLAINTEXT"))
    ssl_cafile:   Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_CAFILE") or None)
    ssl_certfile: Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_CERTFILE") or None)
    ssl_keyfile:  Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_KEYFILE") or None)
    group_id:           str  = field(default_factory=lambda: _e("KAFKA_CONSUMER_GROUP", "feature_engineering_service_v1"))
    auto_offset_reset:  str  = field(default_factory=lambda: _e("KAFKA_AUTO_OFFSET_RESET", "earliest"))
    enable_auto_commit: bool = False
    max_poll_records:   int  = field(default_factory=lambda: _ei("KAFKA_MAX_POLL_RECORDS", 10))
    session_timeout_ms: int  = field(default_factory=lambda: _ei("KAFKA_SESSION_TIMEOUT_MS", 60000))
    acks:               str  = field(default_factory=lambda: _e("KAFKA_ACKS", "all"))
    retries:            int  = field(default_factory=lambda: _ei("KAFKA_RETRIES", 3))
    compression_type:   str  = field(default_factory=lambda: _e("KAFKA_COMPRESSION", "gzip"))
    enable_idempotence: bool = field(default_factory=lambda: _eb("KAFKA_ENABLE_IDEMPOTENCE", True))

    def _ssl(self) -> dict:
        if self.security_protocol != "SSL": return {}
        return dict(ssl_cafile=self.ssl_cafile, ssl_certfile=self.ssl_certfile, ssl_keyfile=self.ssl_keyfile)

    def producer_kwargs(self) -> dict:
        return dict(bootstrap_servers=self.bootstrap_servers, security_protocol=self.security_protocol,
                    acks=self.acks, retries=self.retries, compression_type=self.compression_type,
                    enable_idempotence=self.enable_idempotence, **self._ssl())

    def consumer_kwargs(self) -> dict:
        return dict(bootstrap_servers=self.bootstrap_servers, security_protocol=self.security_protocol,
                    group_id=self.group_id, auto_offset_reset=self.auto_offset_reset,
                    enable_auto_commit=self.enable_auto_commit, max_poll_records=self.max_poll_records,
                    session_timeout_ms=self.session_timeout_ms, **self._ssl())


@dataclass
class TopicsConfig:
    preprocessed:     str = field(default_factory=lambda: _e("TOPIC_PREPROCESSED_DOCS",  "preprocessed_documents"))
    engineered:       str = field(default_factory=lambda: _e("TOPIC_ENGINEERED_FEATURES","engineered_features"))
    audit_logs:       str = field(default_factory=lambda: _e("TOPIC_AUDIT_LOGS",         "feature_audit_logs"))
    retry_queue:      str = field(default_factory=lambda: _e("TOPIC_RETRY_QUEUE",        "feature_retry_queue"))
    dlq:              str = field(default_factory=lambda: _e("TOPIC_DLQ",                "feature_dead_letter_queue"))
    training_store:   str = field(default_factory=lambda: _e("TOPIC_TRAINING_STORE",     "training_feature_store"))
    realtime_store:   str = field(default_factory=lambda: _e("TOPIC_REALTIME_STORE",     "realtime_feature_store"))


@dataclass
class TFIDFConfig:
    max_features:  int   = field(default_factory=lambda: _ei("TFIDF_MAX_FEATURES", 10000))
    ngram_min:     int   = field(default_factory=lambda: _ei("TFIDF_NGRAM_MIN", 1))
    ngram_max:     int   = field(default_factory=lambda: _ei("TFIDF_NGRAM_MAX", 2))
    min_df:        int   = field(default_factory=lambda: _ei("TFIDF_MIN_DF", 2))
    max_df:        float = field(default_factory=lambda: _ef("TFIDF_MAX_DF", 0.95))
    sublinear_tf:  bool  = field(default_factory=lambda: _eb("TFIDF_SUBLINEAR_TF", True))


@dataclass
class EmbeddingConfig:
    enabled:       bool  = field(default_factory=lambda: _eb("EMBEDDING_ENABLED", True))
    model_alias:   str   = field(default_factory=lambda: _e("EMBEDDING_MODEL", "minilm"))
    batch_size:    int   = field(default_factory=lambda: _ei("EMBEDDING_BATCH_SIZE", 32))
    max_length:    int   = field(default_factory=lambda: _ei("EMBEDDING_MAX_LENGTH", 512))
    cache_enabled: bool  = field(default_factory=lambda: _eb("EMBEDDING_CACHE_ENABLED", True))
    device:        str   = field(default_factory=lambda: _e("EMBEDDING_DEVICE", "cpu"))
    model_name_override: str = field(default_factory=lambda: _e("EMBEDDING_MODEL_NAME", ""))

    # Alias → HuggingFace model name
    _MODEL_MAP: Dict[str, tuple] = field(default_factory=lambda: {
        "minilm":  ("sentence-transformers/all-MiniLM-L6-v2",   384),
        "bert":    ("bert-base-uncased",                          768),
        "roberta": ("roberta-base",                               768),
        "deberta": ("microsoft/deberta-v3-small",                768),
        "mpnet":   ("sentence-transformers/all-mpnet-base-v2",   768),
    })

    def resolve(self) -> tuple:
        """Returns (model_name, dimension)."""
        if self.model_name_override:
            return self.model_name_override, None   # caller must detect dim
        alias = self.model_alias.lower()
        return self._MODEL_MAP.get(alias, self._MODEL_MAP["minilm"])


@dataclass
class DriftConfig:
    enabled:         bool  = field(default_factory=lambda: _eb("DRIFT_DETECTION_ENABLED", True))
    window_size:     int   = field(default_factory=lambda: _ei("DRIFT_WINDOW_SIZE", 1000))
    alert_threshold: float = field(default_factory=lambda: _ef("DRIFT_ALERT_THRESHOLD", 0.15))


@dataclass
class RetryConfig:
    max_attempts:       int   = field(default_factory=lambda: _ei("RETRY_MAX_ATTEMPTS", 3))
    backoff_seconds:    float = field(default_factory=lambda: _ef("RETRY_BACKOFF_SECONDS", 2.0))
    backoff_multiplier: float = field(default_factory=lambda: _ef("RETRY_BACKOFF_MULTIPLIER", 2.0))


@dataclass
class AppConfig:
    env:              str = field(default_factory=lambda: _e("APP_ENV", "development"))
    log_level:        str = field(default_factory=lambda: _e("LOG_LEVEL", "INFO"))
    log_file:         str = field(default_factory=lambda: _e("LOG_FILE", "logs/feature_engineering.log"))
    version:          str = field(default_factory=lambda: _e("FEATURE_PIPELINE_VERSION", "v1"))
    mode:             str = field(default_factory=lambda: _e("PIPELINE_MODE", "inference"))

    artifact_base:    str = field(default_factory=lambda: _e("ARTIFACT_BASE_PATH",      "artifacts"))
    vectorizer_path:  str = field(default_factory=lambda: _e("VECTORIZER_PATH",         "artifacts/vectorizers"))
    encoder_path:     str = field(default_factory=lambda: _e("ENCODER_PATH",            "artifacts/encoders"))
    embedding_cache:  str = field(default_factory=lambda: _e("EMBEDDING_CACHE_PATH",    "artifacts/embedding_cache"))

    metadata_encoding:str = field(default_factory=lambda: _e("METADATA_ENCODING", "onehot"))
    chunk_aggregation:str = field(default_factory=lambda: _e("CHUNK_AGGREGATION", "mean"))

    kafka:     KafkaConfig     = field(default_factory=KafkaConfig)
    topics:    TopicsConfig    = field(default_factory=TopicsConfig)
    tfidf:     TFIDFConfig     = field(default_factory=TFIDFConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    drift:     DriftConfig     = field(default_factory=DriftConfig)
    retry:     RetryConfig     = field(default_factory=RetryConfig)

    @property
    def is_training_mode(self) -> bool:
        return self.mode.lower() == "training"


CONFIG = AppConfig()
