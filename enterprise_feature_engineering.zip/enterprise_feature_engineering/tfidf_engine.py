"""
tfidf_engine.py
================
Enterprise TF-IDF feature extraction engine.

Features:
  - Configurable n-gram range (unigrams + bigrams by default)
  - Sublinear TF scaling (reduces dominance of high-frequency terms)
  - Vocabulary persistence via joblib (fast inference — no refit needed)
  - Top-N feature inlining in Kafka payload (avoids sending full sparse matrix)
  - Full sparse matrix serialised to disk; path referenced in output schema
  - Feature names preserved for SHAP / LIME compatibility

Two modes:
  Training mode  — fits the vectoriser on a batch of documents, saves artifact
  Inference mode — loads pre-fitted vectoriser, transforms one document at a time

Vocabulary drift detection hook:
  After transform, checks if OOV (out-of-vocabulary) rate exceeds threshold.
  High OOV → model may need retraining (signals feature_drift_alert).
"""

from __future__ import annotations

import hashlib
import os
import re
import uuid
from typing import Dict, List, Optional, Tuple

import numpy as np
import scipy.sparse as sp

from schema import TFIDFRef
from config import CONFIG
from logger import get_logger

log = get_logger("tfidf_engine")

_VECTORIZER_FILENAME = "tfidf_vectorizer.joblib"


class TFIDFEngine:
    """
    Stateful TF-IDF engine.
    One instance per process — loaded at startup, used for all documents.
    """

    def __init__(self):
        self._vectorizer  = None
        self._version     = ""
        self._vocab_size  = 0
        self._oov_tracker = OOVTracker()
        self._load_or_init()

    # ── Public API ───────────────────────────────────────────────────────

    def transform(
        self,
        text:   str,
        doc_id: str = "",
        top_n:  int = 20,
    ) -> TFIDFRef:
        """
        Transform a single document text → TFIDFRef.

        Returns a TFIDFRef with:
          - Path to serialised sparse vector (for Classification Layer batch loading)
          - Top-N non-zero features inlined (for real-time inference)
          - Feature count and vocab size
        """
        if self._vectorizer is None:
            log.warning("[%s] TF-IDF vectorizer not fitted — returning empty ref", doc_id)
            return TFIDFRef(vectorizer_version=self._version)

        try:
            vec = self._vectorizer.transform([text])   # (1, vocab_size) sparse

            # Track OOV
            self._oov_tracker.update(text, self._vectorizer)

            # Serialise sparse vector to disk
            artifact_path = self._save_vector(vec, doc_id)

            # Inline top-N non-zero features for real-time inference
            top_features = self._top_features(vec, top_n)

            return TFIDFRef(
                artifact_path      = artifact_path,
                feature_count      = int(vec.nnz),
                vocab_size         = self._vocab_size,
                vectorizer_version = self._version,
                top_features       = top_features,
            )

        except Exception as exc:
            log.error("[%s] TF-IDF transform failed: %s", doc_id, exc)
            return TFIDFRef(vectorizer_version=self._version)

    def fit(self, texts: List[str]):
        """
        Fit the TF-IDF vectoriser on a corpus.
        Called during training mode batch processing.
        """
        from sklearn.feature_extraction.text import TfidfVectorizer
        cfg = CONFIG.tfidf
        self._vectorizer = TfidfVectorizer(
            max_features = cfg.max_features,
            ngram_range  = (cfg.ngram_min, cfg.ngram_max),
            min_df       = cfg.min_df,
            max_df       = cfg.max_df,
            sublinear_tf = cfg.sublinear_tf,
            strip_accents= "unicode",
            analyzer     = "word",
            token_pattern= r"(?u)\b\w\w+\b",
        )
        self._vectorizer.fit(texts)
        self._vocab_size = len(self._vectorizer.vocabulary_)
        self._version    = self._compute_version(texts)
        self._save_vectorizer()
        log.info(
            "TF-IDF fitted: vocab=%d ngrams=(%d,%d) max_features=%d",
            self._vocab_size, cfg.ngram_min, cfg.ngram_max, cfg.max_features,
        )

    @property
    def feature_names(self) -> List[str]:
        """SHAP-compatible feature names: ["tfidf_salary", "tfidf_payroll_report", ...]"""
        if self._vectorizer is None:
            return []
        return [f"tfidf_{t}" for t in self._vectorizer.get_feature_names_out()]

    @property
    def vocab_size(self) -> int:
        return self._vocab_size

    @property
    def version(self) -> str:
        return self._version

    # ── Internal ─────────────────────────────────────────────────────────

    def _load_or_init(self):
        path = os.path.join(CONFIG.vectorizer_path, _VECTORIZER_FILENAME)
        if os.path.isfile(path):
            try:
                import joblib
                data = joblib.load(path)
                self._vectorizer = data["vectorizer"]
                self._version    = data.get("version", "unknown")
                self._vocab_size = len(self._vectorizer.vocabulary_)
                log.info("TF-IDF vectorizer loaded from %s (vocab=%d)", path, self._vocab_size)
                return
            except Exception as exc:
                log.warning("Could not load vectorizer: %s — will fit on demand", exc)

        # Cold start: create a minimal vectorizer for inference
        # Real vocabulary built during training mode
        log.warning(
            "No pre-fitted TF-IDF vectorizer found at %s. "
            "Run in training mode first, or place a fitted vectorizer artifact there. "
            "Inference will return empty TF-IDF refs until fitted.",
            path,
        )

    def _save_vectorizer(self):
        os.makedirs(CONFIG.vectorizer_path, exist_ok=True)
        path = os.path.join(CONFIG.vectorizer_path, _VECTORIZER_FILENAME)
        try:
            import joblib
            joblib.dump({"vectorizer": self._vectorizer, "version": self._version}, path)
            log.info("TF-IDF vectorizer saved to %s", path)
        except Exception as exc:
            log.error("Could not save vectorizer: %s", exc)

    def _save_vector(self, vec: sp.spmatrix, doc_id: str) -> str:
        """Serialise the sparse vector for this document. Returns the file path."""
        os.makedirs(CONFIG.vectorizer_path, exist_ok=True)
        safe_id  = re.sub(r"[^a-zA-Z0-9_\-]", "_", doc_id)[:64]
        filename = f"tfidf_{safe_id}_{uuid.uuid4().hex[:8]}.npz"
        path     = os.path.join(CONFIG.vectorizer_path, filename)
        try:
            sp.save_npz(path, vec)
        except Exception as exc:
            log.debug("Could not save sparse vector: %s", exc)
            path = ""
        return path

    def _top_features(self, vec: sp.spmatrix, top_n: int) -> Dict[str, float]:
        """Extract top-N non-zero TF-IDF features as {term: score}."""
        if self._vectorizer is None or vec.nnz == 0:
            return {}
        try:
            names   = self._vectorizer.get_feature_names_out()
            row     = vec.toarray()[0]
            nonzero = np.nonzero(row)[0]
            top_idx = nonzero[np.argsort(row[nonzero])[-top_n:][::-1]]
            return {names[i]: round(float(row[i]), 6) for i in top_idx}
        except Exception:
            return {}

    @staticmethod
    def _compute_version(texts: List[str]) -> str:
        sample = " ".join(texts[:100])
        return hashlib.md5(sample.encode()).hexdigest()[:8]


# ─────────────────────────────────────────────────────────────────────────────
# OOV (Out-of-Vocabulary) Drift Tracker
# ─────────────────────────────────────────────────────────────────────────────

class OOVTracker:
    """
    Tracks the rate of out-of-vocabulary tokens in recent documents.
    High OOV rate signals vocabulary drift → model may need retraining.
    Compatible with the drift detection framework in feature_registry.py.
    """

    def __init__(self):
        self._window:    List[float] = []
        self._max_size   = CONFIG.drift.window_size
        self._threshold  = CONFIG.drift.alert_threshold

    def update(self, text: str, vectorizer) -> Optional[float]:
        """Compute OOV rate for this document and update the window."""
        try:
            tokens  = text.lower().split()
            vocab   = vectorizer.vocabulary_
            oov     = sum(1 for t in tokens if t not in vocab)
            rate    = oov / max(len(tokens), 1)
            self._window.append(rate)
            if len(self._window) > self._max_size:
                self._window.pop(0)

            avg = self.average_oov_rate
            if avg > self._threshold and len(self._window) >= 50:
                log.warning(
                    "TF-IDF OOV rate %.3f exceeds threshold %.3f — "
                    "vocabulary drift detected, consider retraining",
                    avg, self._threshold,
                )
            return rate
        except Exception:
            return None

    @property
    def average_oov_rate(self) -> float:
        return sum(self._window) / max(len(self._window), 1)


# Module-level singleton
_engine: Optional[TFIDFEngine] = None


def get_engine() -> TFIDFEngine:
    global _engine
    if _engine is None:
        _engine = TFIDFEngine()
    return _engine


def transform_document(text: str, doc_id: str = "", top_n: int = 20) -> TFIDFRef:
    return get_engine().transform(text, doc_id=doc_id, top_n=top_n)
