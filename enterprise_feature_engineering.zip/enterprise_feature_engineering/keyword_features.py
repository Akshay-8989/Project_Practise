"""
keyword_features.py
====================
Domain-specific keyword and phrase dictionaries aligned with the
sensitivity taxonomy (Restricted / Confidential / Internal / Financial / Legal).

These lexicons are derived from the Problem Statement's sensitivity level
definitions and enterprise document knowledge. They produce strong signal
features for the Classification Layer — particularly for the rule-overlay
Policy Engine (which must override to Restricted if a Restricted token is found).

Features produced per document:
  - Count of Restricted keywords matched
  - Count of Confidential keywords matched
  - Count of Internal keywords matched
  - Count of Financial keywords matched
  - Count of Legal keywords matched
  - Binary flag for each tier (0/1)

These are deliberately pattern-based (not ML) so the system is:
  - Fully auditable (PS Constraint C2)
  - Interpretable for SHAP feature importance
  - Compatible with the Policy Engine rule overlay

Dictionary extensibility:
  - Add terms directly to the lists below
  - Or load from a JSON file at artifacts/keyword_dicts/ for runtime updates
  - Dictionary versions are tracked for audit
"""

from __future__ import annotations

import json
import os
import re
from typing import Dict, List, Tuple

from schema import RiskFeatures, PIIEntities
from config import CONFIG
from logger import get_logger

log = get_logger("keyword_features")

# ─────────────────────────────────────────────────────────────────────────────
# Keyword dictionaries
# ─────────────────────────────────────────────────────────────────────────────

RESTRICTED_TERMS: List[str] = [
    "top secret", "restricted", "classified", "for official use only",
    "do not distribute", "do not forward", "do not share outside",
    "trade secret", "attorney.client privilege", "privileged and confidential",
    "pci.?dss", "hipaa", "gdpr", "ccpa", "legal hold",
    "merger", "acquisition", "takeover bid",
    "inside information", "material non.?public",
    "password", "private key", "secret key", "api key", "access token",
    "customer data", "personal data", "personal information",
    "passport number", "national id", "biometric",
    "account number", "routing number", "swift code",
    "salary structure", "compensation structure", "executive compensation",
]

CONFIDENTIAL_TERMS: List[str] = [
    "confidential", "proprietary", "not for public release",
    "internal use only", "company confidential",
    "contract", "agreement", "nda", "non.?disclosure",
    "pricing", "price list", "quotation", "proposal",
    "invoice", "purchase order", "vendor agreement",
    "negotiation", "term sheet", "letter of intent",
    "litigation", "lawsuit", "legal proceedings", "settlement",
    "audit report", "compliance report", "risk assessment",
    "business strategy", "strategic plan", "competitive analysis",
    "financial forecast", "budget", "projection",
    "employee performance", "performance review", "appraisal",
    "medical", "health record", "diagnosis", "treatment",
]

INTERNAL_TERMS: List[str] = [
    "internal", "internal use", "not for external distribution",
    "company policy", "hr policy", "employee handbook",
    "org chart", "organisation chart", "headcount",
    "internal memo", "internal communication",
    "team meeting", "board minutes", "management report",
    "onboarding", "offboarding", "exit interview",
    "vendor list", "supplier", "procurement",
    "it policy", "security policy", "access control",
    "change management", "release notes", "deployment plan",
]

FINANCIAL_TERMS: List[str] = [
    "revenue", "profit", "loss", "net income", "gross margin",
    "balance sheet", "income statement", "cash flow",
    "quarterly results", "annual report", "fiscal year",
    "ebitda", "roi", "p&l", "profit and loss",
    "investment", "portfolio", "asset", "liability",
    "tax", "payroll", "salary", "compensation", "bonus",
    "dividend", "equity", "stock option", "shares",
    "loan", "credit facility", "debt", "interest rate",
]

LEGAL_TERMS: List[str] = [
    "whereas", "hereby", "indemnify", "indemnification",
    "liability", "limitation of liability", "warranty",
    "intellectual property", "copyright", "trademark", "patent",
    "force majeure", "governing law", "jurisdiction",
    "arbitration", "dispute resolution", "mediation",
    "termination clause", "breach", "remedy",
    "schedule", "exhibit", "appendix", "annex",
    "executed by", "duly authorized", "in witness whereof",
]

# ─────────────────────────────────────────────────────────────────────────────
# Compile patterns at import time
# ─────────────────────────────────────────────────────────────────────────────

def _compile(terms: List[str]) -> re.Pattern:
    escaped = [re.escape(t) if "." not in t else t for t in terms]
    return re.compile(r"\b(?:" + "|".join(escaped) + r")\b", re.IGNORECASE)


_RESTRICTED_PAT    = _compile(RESTRICTED_TERMS)
_CONFIDENTIAL_PAT  = _compile(CONFIDENTIAL_TERMS)
_INTERNAL_PAT      = _compile(INTERNAL_TERMS)
_FINANCIAL_PAT     = _compile(FINANCIAL_TERMS)
_LEGAL_PAT         = _compile(LEGAL_TERMS)

_POLICY_HINT_MAP = {"Allow": 0, "Encrypt": 1, "Restrict": 2, "Quarantine": 3}

_DICT_VERSION = "v1.0"


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def extract_risk_features(
    masked_text:  str,
    pii_entities: PIIEntities,
    policy_hint:  str,
    token_count:  int,
    doc_id:       str = "",
) -> RiskFeatures:
    """
    Compute PII + keyword risk features from preprocessed document data.

    Args:
        masked_text:  Masked text (PII already replaced — keyword patterns still match).
        pii_entities: PII entity counts from Preprocessing Layer.
        policy_hint:  "Allow" | "Encrypt" | "Restrict" | "Quarantine"
        token_count:  Total token count (for PII density normalisation).
        doc_id:       For logging.

    Returns:
        RiskFeatures with all fields populated.
    """
    # ── PII features ─────────────────────────────────────────────────────
    total_pii = pii_entities.total if hasattr(pii_entities, 'total') else sum(
        v for v in pii_entities.model_dump().values() if isinstance(v, int)
    )

    restricted_pii  = sum([
        pii_entities.PAN, pii_entities.AADHAAR, pii_entities.SSN,
        pii_entities.IBAN, pii_entities.CREDIT_CARD, pii_entities.BANK_ACCOUNT,
    ])
    confidential_pii = sum([
        pii_entities.EMAIL, pii_entities.PHONE,
        pii_entities.DOB, pii_entities.EMPLOYEE_ID,
    ])

    pii_density = total_pii / max(token_count, 1)

    # ── Keyword features ─────────────────────────────────────────────────
    restricted_count   = len(_RESTRICTED_PAT.findall(masked_text))
    confidential_count = len(_CONFIDENTIAL_PAT.findall(masked_text))
    internal_count     = len(_INTERNAL_PAT.findall(masked_text))
    financial_count    = len(_FINANCIAL_PAT.findall(masked_text))
    legal_count        = len(_LEGAL_PAT.findall(masked_text))

    log.debug(
        "[%s] Risk: pii_total=%d restricted_kw=%d confidential_kw=%d",
        doc_id, total_pii, restricted_count, confidential_count,
    )

    return RiskFeatures(
        # PII raw counts
        pii_email       = pii_entities.EMAIL,
        pii_phone       = pii_entities.PHONE,
        pii_pan         = pii_entities.PAN,
        pii_aadhaar     = pii_entities.AADHAAR,
        pii_ssn         = pii_entities.SSN,
        pii_iban        = pii_entities.IBAN,
        pii_credit_card = pii_entities.CREDIT_CARD,
        pii_dob         = pii_entities.DOB,
        pii_employee_id = pii_entities.EMPLOYEE_ID,
        pii_bank_account= pii_entities.BANK_ACCOUNT,
        # Derived PII
        total_pii_count      = total_pii,
        high_risk_pii_flag   = int(restricted_pii > 0),
        medium_risk_pii_flag = int(confidential_pii > 0 and restricted_pii == 0),
        pii_density          = round(pii_density, 6),
        # Keyword counts
        restricted_kw_count  = restricted_count,
        confidential_kw_count= confidential_count,
        internal_kw_count    = internal_count,
        financial_kw_count   = financial_count,
        legal_kw_count       = legal_count,
        # Keyword flags
        has_restricted_kw    = int(restricted_count > 0),
        has_confidential_kw  = int(confidential_count > 0),
        # Policy hint
        policy_hint_encoded  = _POLICY_HINT_MAP.get(policy_hint, 0),
    )


def get_dict_version() -> str:
    return _DICT_VERSION


def load_custom_dict(path: str) -> bool:
    """
    Runtime keyword dictionary extension.
    Load additional terms from a JSON file.
    Expected format: {"restricted": [...], "confidential": [...], ...}
    """
    global _RESTRICTED_PAT, _CONFIDENTIAL_PAT, _INTERNAL_PAT
    try:
        with open(path, "r", encoding="utf-8") as f:
            custom = json.load(f)
        if "restricted"   in custom:
            RESTRICTED_TERMS.extend(custom["restricted"])
            _RESTRICTED_PAT = _compile(RESTRICTED_TERMS)
        if "confidential" in custom:
            CONFIDENTIAL_TERMS.extend(custom["confidential"])
            _CONFIDENTIAL_PAT = _compile(CONFIDENTIAL_TERMS)
        if "internal"     in custom:
            INTERNAL_TERMS.extend(custom["internal"])
            _INTERNAL_PAT = _compile(INTERNAL_TERMS)
        log.info("Custom keyword dictionary loaded from %s", path)
        return True
    except Exception as exc:
        log.error("Failed to load custom keyword dict from %s: %s", path, exc)
        return False
