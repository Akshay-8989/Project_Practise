import logging, os, sys
from logging.handlers import RotatingFileHandler
_done: set = set()

def get_logger(name: str = "fe") -> logging.Logger:
    log = logging.getLogger(name)
    if name in _done: return log
    _done.add(name)
    try:
        from config import CONFIG
        level = getattr(logging, CONFIG.log_level.upper(), logging.INFO)
        lf    = CONFIG.log_file
    except Exception:
        level, lf = logging.INFO, "logs/feature_engineering.log"
    log.setLevel(level); log.propagate = False
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)-30s | %(message)s", "%Y-%m-%d %H:%M:%S")
    ch = logging.StreamHandler(sys.stdout); ch.setFormatter(fmt); log.addHandler(ch)
    try:
        os.makedirs(os.path.dirname(lf) or ".", exist_ok=True)
        fh = RotatingFileHandler(lf, maxBytes=10*1024*1024, backupCount=5, encoding="utf-8")
        fh.setFormatter(fmt); log.addHandler(fh)
    except Exception: pass
    return log
