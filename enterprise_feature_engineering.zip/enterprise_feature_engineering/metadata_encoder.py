"""
metadata_encoder.py
====================
Categorical metadata feature encoding.

Encodes business metadata signals as numerical features:
  source_system, department, business_unit, region,
  document_type, source_channel, language, data_category

Supports three encoding strategies (config-driven):
  onehot     — scikit-learn OneHotEncoder; preserves feature interpretability
                (best for SHAP explainability — feature names are readable)
  frequency  — replace category with its training-set frequency
                (compact; handles high-cardinality fields like client_name)
  hash       — MurmurHash; fixed-dimension; handles unseen categories

Unknown category handling:
  OneHot: OHE handles unknown with all-zeros vector
  Frequency: unknown categories get frequency=0.0
  Hash: unknown categories hash normally (no special case needed)

SHAP Compatibility:
  feature_names list maps each vector dimension to a human-readable name
  e.g. ["meta_source_system_HRMS", "meta_dept_HR", "meta_region_India", ...]
  The Classification Layer passes this to shap.Explainer.

Encoder persistence:
  Fitted encoders are saved to artifacts/encoders/ via joblib.
  Loaded at startup for inference — zero fit latency on live traffic.
"""

from __future__ import annotations

import hashlib
import os
from typing import Dict, List, Optional, Tuple

import numpy as np

from schema import BusinessMetadata, MetadataFeatures
from config import CONFIG
from logger import get_logger

log = get_logger("metadata_encoder")

# Canonical metadata fields to encode (order matters — fixed feature index)
METADATA_FIELDS = [
    "source_system",
    "department",
    "business_unit",
    "region",
    "document_type",
    "source_channel",
]

# Known category vocabularies (from PS domain knowledge + config validation)
KNOWN_CATEGORIES: Dict[str, List[str]] = {
    "source_system":  ["HRMS", "ERP", "CRM", "DMS", "EMAIL", "SHAREPOINT",
                       "S3", "DRIVE", "API", "MANUAL", "UNKNOWN"],
    "department":     ["Finance", "HR", "Legal", "IT", "Sales", "Support",
                       "Operations", "Compliance", "Engineering", "UNKNOWN"],
    "business_unit":  ["UNKNOWN"],          # open-ended; use frequency encoding
    "region":         ["India", "US", "EU", "APAC", "UK", "LATAM", "MEA",
                       "Global", "UNKNOWN"],
    "document_type":  ["contract", "invoice", "report", "email", "ticket",
                       "hr_record", "policy", "payroll", "log", "general", "UNKNOWN"],
    "source_channel": ["direct_upload", "email_export", "api_upload",
                       "hrms_export", "erp_export", "crm_export", "UNKNOWN"],
}


class MetadataEncoder:
    """
    Encodes BusinessMetadata into a fixed-dimension numerical vector.
    Thread-safe for concurrent inference (read-only after fit).
    """

    def __init__(self, encoding: str = None):
        self._encoding   = encoding or CONFIG.metadata_encoding
        self._fitted     = False
        self._freq_tables: Dict[str, Dict[str, float]] = {}
        self._ohe        = None          # sklearn OHE instance (lazy import)
        self._feature_names: List[str]   = []
        self._dim        = 0

        self._load_or_init()

    # ── Public API ───────────────────────────────────────────────────────

    def encode(self, meta: BusinessMetadata, doc_id: str = "") -> MetadataFeatures:
        """Encode metadata → MetadataFeatures with vector + feature_names."""
        raw = self._extract_raw(meta)
        unknown_flags = {k: (v == "UNKNOWN" or v == "unknown") for k, v in raw.items()}

        try:
            if self._encoding == "onehot":
                vector, names = self._encode_onehot(raw)
            elif self._encoding == "frequency":
                vector, names = self._encode_frequency(raw)
            else:
                vector, names = self._encode_hash(raw)
        except Exception as exc:
            log.warning("[%s] Metadata encoding failed: %s — using zeros", doc_id, exc)
            vector = [0.0] * max(self._dim, len(METADATA_FIELDS))
            names  = [f"meta_{f}_UNKNOWN" for f in METADATA_FIELDS]

        return MetadataFeatures(
            encoding_type   = self._encoding,
            vector          = vector,
            feature_names   = names,
            raw_categories  = raw,
            unknown_flags   = unknown_flags,
        )

    def fit(self, records: List[BusinessMetadata]):
        """
        Fit encoder on a batch of metadata records (training mode).
        For OneHot: builds vocabulary from all observed categories.
        For Frequency: computes category frequencies.
        """
        if self._encoding == "onehot":
            self._fit_onehot(records)
        elif self._encoding == "frequency":
            self._fit_frequency(records)
        # Hash: no fitting needed
        self._fitted = True
        self._save()
        log.info("MetadataEncoder fitted on %d records (mode=%s)", len(records), self._encoding)

    @property
    def feature_names(self) -> List[str]:
        return self._feature_names

    @property
    def dimension(self) -> int:
        return self._dim

    # ── OneHot encoding ──────────────────────────────────────────────────

    def _fit_onehot(self, records: List[BusinessMetadata]):
        """Build OHE vocabulary from known categories (augmented with observed)."""
        from sklearn.preprocessing import OneHotEncoder
        # Build training matrix from known categories
        data = []
        for f in METADATA_FIELDS:
            cats = KNOWN_CATEGORIES.get(f, ["UNKNOWN"])
            for cat in cats:
                row = {field: "UNKNOWN" for field in METADATA_FIELDS}
                row[f] = cat
                data.append(row)
        X = [[r[f] for f in METADATA_FIELDS] for r in data]
        self._ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        self._ohe.fit(X)
        self._feature_names = [
            f"meta_{field}_{cat}"
            for field, cats in zip(METADATA_FIELDS, self._ohe.categories_)
            for cat in cats
        ]
        self._dim = len(self._feature_names)

    def _encode_onehot(self, raw: Dict[str, str]) -> Tuple[List[float], List[str]]:
        if self._ohe is None:
            self._fit_onehot([])
        X = [[raw.get(f, "UNKNOWN") for f in METADATA_FIELDS]]
        vec = self._ohe.transform(X)[0].tolist()
        return vec, self._feature_names

    # ── Frequency encoding ───────────────────────────────────────────────

    def _fit_frequency(self, records: List[BusinessMetadata]):
        from collections import Counter
        for field in METADATA_FIELDS:
            vals = [getattr(r, field, "UNKNOWN") for r in records]
            total = max(len(vals), 1)
            counts = Counter(vals)
            self._freq_tables[field] = {k: v / total for k, v in counts.items()}
        self._feature_names = [f"meta_freq_{f}" for f in METADATA_FIELDS]
        self._dim = len(METADATA_FIELDS)

    def _encode_frequency(self, raw: Dict[str, str]) -> Tuple[List[float], List[str]]:
        vec = []
        for f in METADATA_FIELDS:
            val   = raw.get(f, "UNKNOWN")
            freq  = self._freq_tables.get(f, {}).get(val, 0.0)
            vec.append(freq)
        return vec, [f"meta_freq_{f}" for f in METADATA_FIELDS]

    # ── Hash encoding ────────────────────────────────────────────────────

    def _encode_hash(
        self, raw: Dict[str, str], n_bits: int = 8
    ) -> Tuple[List[float], List[str]]:
        """MurmurHash-based feature hashing — fixed dim, handles unknown."""
        dim   = 2 ** n_bits
        vec   = [0.0] * dim
        names = [f"meta_hash_{i}" for i in range(dim)]
        for field, val in raw.items():
            key  = f"{field}:{val}"
            idx  = int(hashlib.md5(key.encode()).hexdigest(), 16) % dim
            vec[idx] += 1.0
        self._dim = dim
        self._feature_names = names
        return vec, names

    # ── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _extract_raw(meta: BusinessMetadata) -> Dict[str, str]:
        return {f: str(getattr(meta, f, "UNKNOWN")) for f in METADATA_FIELDS}

    def _load_or_init(self):
        """Load encoder from disk if available, otherwise init from known categories."""
        path = os.path.join(CONFIG.encoder_path, f"metadata_encoder_{self._encoding}.joblib")
        if os.path.isfile(path):
            try:
                import joblib
                state = joblib.load(path)
                self._ohe           = state.get("ohe")
                self._freq_tables   = state.get("freq_tables", {})
                self._feature_names = state.get("feature_names", [])
                self._dim           = state.get("dim", 0)
                self._fitted        = True
                log.info("MetadataEncoder loaded from %s (dim=%d)", path, self._dim)
                return
            except Exception as exc:
                log.warning("Could not load encoder from %s: %s — fitting fresh", path, exc)

        # Cold start: fit on known categories so inference works without training data
        if self._encoding == "onehot":
            self._fit_onehot([])
        elif self._encoding == "frequency":
            # Build synthetic frequencies from known categories
            self._freq_tables = {
                f: {cat: 1.0 / max(len(cats), 1) for cat in cats}
                for f, cats in KNOWN_CATEGORIES.items()
            }
            self._feature_names = [f"meta_freq_{f}" for f in METADATA_FIELDS]
            self._dim = len(METADATA_FIELDS)
        else:
            self._dim = 256
            self._feature_names = [f"meta_hash_{i}" for i in range(256)]
        self._fitted = True

    def _save(self):
        os.makedirs(CONFIG.encoder_path, exist_ok=True)
        path = os.path.join(CONFIG.encoder_path, f"metadata_encoder_{self._encoding}.joblib")
        try:
            import joblib
            joblib.dump({
                "ohe":           self._ohe,
                "freq_tables":   self._freq_tables,
                "feature_names": self._feature_names,
                "dim":           self._dim,
            }, path)
            log.info("MetadataEncoder saved to %s", path)
        except Exception as exc:
            log.error("Could not save encoder: %s", exc)


# Module-level singleton (loaded once at startup)
_encoder: Optional[MetadataEncoder] = None


def get_encoder() -> MetadataEncoder:
    global _encoder
    if _encoder is None:
        _encoder = MetadataEncoder()
    return _encoder


def encode_metadata(meta: BusinessMetadata, doc_id: str = "") -> MetadataFeatures:
    return get_encoder().encode(meta, doc_id=doc_id)
