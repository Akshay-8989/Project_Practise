"""
producer.py
============
Kafka producer for the Feature Engineering Layer.
"""

import json
from typing import Any, Dict, Optional

from kafka import KafkaProducer
from kafka.errors import KafkaError, NoBrokersAvailable

from config import CONFIG
from logger import get_logger

log = get_logger("producer")


def _ser(obj: Any) -> bytes:
    return json.dumps(obj, default=str, ensure_ascii=False).encode("utf-8")

def _key(k: Optional[str]) -> Optional[bytes]:
    return k.encode("utf-8") if k else None


class FeatureProducer:
    def __init__(self):
        try:
            self._p = KafkaProducer(
                value_serializer = _ser,
                key_serializer   = _key,
                **CONFIG.kafka.producer_kwargs(),
            )
            log.info("Producer connected | broker=%s", CONFIG.kafka.bootstrap_servers)
        except NoBrokersAvailable:
            log.critical("Kafka broker not reachable at %s", CONFIG.kafka.bootstrap_servers)
            raise

    def __enter__(self):  return self
    def __exit__(self, *_): self.close()

    def send_features(self, payload: Dict):
        self._send(CONFIG.topics.engineered, payload.get("doc_id"), payload)

    def send_training(self, payload: Dict):
        self._send(CONFIG.topics.training_store, payload.get("doc_id"), payload)

    def send_realtime(self, payload: Dict):
        self._send(CONFIG.topics.realtime_store, payload.get("doc_id"), payload)

    def send_audit(self, entry: Dict):
        self._send(CONFIG.topics.audit_logs, entry.get("feature_run_id"), entry)

    def send_retry(self, entry: Dict):
        self._send(CONFIG.topics.retry_queue, entry.get("retry_id"), entry)

    def send_dlq(self, record: Dict):
        self._send(CONFIG.topics.dlq, record.get("doc_id", "unknown"), record)

    def flush(self, timeout: int = 30): self._p.flush(timeout=timeout)
    def close(self):
        self.flush(); self._p.close()
        log.info("Producer closed.")

    def _send(self, topic: str, key: Optional[str], data: Dict):
        try:
            (self._p.send(topic, key=key, value=data)
             .add_callback(lambda m: log.debug("→ %s part=%d off=%d", m.topic, m.partition, m.offset))
             .add_errback(lambda e: log.error("Kafka error: %s", e)))
        except KafkaError as exc:
            log.error("Send failed → %s: %s", topic, exc)
