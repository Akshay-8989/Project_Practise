"""
schema.py
==========
Canonical data models for the Feature Engineering Layer.

Input:  PreprocessedDocument  (from Preprocessing Layer)
Output: EngineeredFeatureSet  (consumed by Classification Model Layer)

Design contract for downstream Classification Layer:
  classical_features.stat_vector     → np.ndarray  (statistical features)
  classical_features.metadata_vector → np.ndarray  (encoded metadata)
  classical_features.risk_vector     → np.ndarray  (PII + keyword signals)
  embedding_features.vector          → np.ndarray  (dense embedding)
  tfidf_ref                          → serialized sparse matrix path
  feature_names                      → SHAP / LIME explainability map
"""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ProcessingStatus(str, Enum):
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED  = "failed"
    SKIPPED = "skipped"


class PipelineMode(str, Enum):
    INFERENCE = "inference"
    TRAINING  = "training"


# ─────────────────────────────────────────────────────────────────────────────
# Input schema (mirrors PreprocessedDocument from Preprocessing Layer)
# ─────────────────────────────────────────────────────────────────────────────

class PIIEntities(BaseModel):
    EMAIL: int = 0; PHONE: int = 0; PAN: int = 0; AADHAAR: int = 0
    SSN: int = 0; IBAN: int = 0; CREDIT_CARD: int = 0; DOB: int = 0
    EMPLOYEE_ID: int = 0; BANK_ACCOUNT: int = 0
    class Config: extra = "allow"

class LanguageInfo(BaseModel):
    code: str = "en"; name: str = "English"; confidence: float = 0.0
    recommended_model: str = "english_classifier_v1"; detection_method: str = "unknown"
    class Config: extra = "allow"

class ChunkInfo(BaseModel):
    is_chunked: bool = False; chunk_id: int = 0; total_chunks: int = 1
    chunk_token_count: int = 0
    class Config: extra = "allow"

class TextStats(BaseModel):
    raw_chars: int = 0; clean_chars: int = 0; masked_chars: int = 0
    raw_words: int = 0; clean_words: int = 0; token_count: int = 0
    sentence_count: int = 0; reduction_pct: float = 0.0
    class Config: extra = "allow"

class BusinessMetadata(BaseModel):
    source_system: str = "UNKNOWN"; department: str = "UNKNOWN"
    business_unit: str = "UNKNOWN"; region: str = "UNKNOWN"
    owner: str = "UNKNOWN"; document_type: str = "general"
    client_name: str = "UNKNOWN"; source_channel: str = "UNKNOWN"
    created_at: Optional[str] = None; tags: List[str] = Field(default_factory=list)
    class Config: extra = "allow"

class PreprocessedDocument(BaseModel):
    """Input from Preprocessing Layer Kafka topic."""
    doc_id:           str
    parent_doc_id:    Optional[str] = None
    event_id:         str = ""
    ingest_id:        str = ""
    clean_text:       str = ""
    masked_text:      str = ""
    tokens:           List[str] = Field(default_factory=list)
    sentence_chunks:  List[str] = Field(default_factory=list)
    language:         LanguageInfo  = Field(default_factory=LanguageInfo)
    recommended_model:str = "english_classifier_v1"
    pii_entities:     PIIEntities   = Field(default_factory=PIIEntities)
    pii_policy_hint:  str = "Allow"
    stats:            TextStats     = Field(default_factory=TextStats)
    structure_type:   str = "single"
    data_category:    str = "unstructured"
    segment_index:    Optional[int] = None
    total_segments:   Optional[int] = None
    segment_type:     Optional[str] = None
    chunk_info:       ChunkInfo     = Field(default_factory=ChunkInfo)
    business_metadata:BusinessMetadata = Field(default_factory=BusinessMetadata)
    status:           str = "success"
    class Config: extra = "allow"


# ─────────────────────────────────────────────────────────────────────────────
# Feature sub-models
# ─────────────────────────────────────────────────────────────────────────────

class StatisticalFeatures(BaseModel):
    """
    Numerical statistical features computed from text.
    These are directly usable as input to classical ML models.
    """
    token_count:         float = 0.0
    unique_token_count:  float = 0.0
    type_token_ratio:    float = 0.0    # unique/total — lexical diversity
    avg_word_length:     float = 0.0
    max_word_length:     float = 0.0
    sentence_count:      float = 0.0
    avg_sentence_length: float = 0.0
    uppercase_ratio:     float = 0.0
    digit_ratio:         float = 0.0
    special_char_ratio:  float = 0.0
    punctuation_ratio:   float = 0.0
    whitespace_ratio:    float = 0.0
    entropy:             float = 0.0    # Shannon entropy of char distribution
    repeated_term_ratio: float = 0.0   # tokens that appear >1 / total tokens
    char_count:          float = 0.0
    reduction_pct:       float = 0.0   # clean/raw reduction from preprocessing

    def to_vector(self) -> List[float]:
        return list(self.model_dump().values())

    @classmethod
    def feature_names(cls) -> List[str]:
        return [f"stat_{k}" for k in cls.model_fields.keys()]


class MetadataFeatures(BaseModel):
    """
    Encoded categorical metadata features.
    Vector representation of source_system, department, region, doc_type, language.
    """
    encoding_type:   str  = "onehot"
    vector:          List[float] = Field(default_factory=list)
    feature_names:   List[str]   = Field(default_factory=list)
    raw_categories:  Dict[str, str] = Field(default_factory=dict)
    unknown_flags:   Dict[str, bool] = Field(default_factory=dict)  # which fields had UNKNOWN


class RiskFeatures(BaseModel):
    """
    PII counts, keyword flags, and derived risk signals.
    High signal-to-noise features for sensitivity classification.
    """
    # PII counts (raw)
    pii_email:        int = 0
    pii_phone:        int = 0
    pii_pan:          int = 0
    pii_aadhaar:      int = 0
    pii_ssn:          int = 0
    pii_iban:         int = 0
    pii_credit_card:  int = 0
    pii_dob:          int = 0
    pii_employee_id:  int = 0
    pii_bank_account: int = 0
    # Derived PII features
    total_pii_count:      int  = 0
    high_risk_pii_flag:   int  = 0   # 1 if any Restricted-level PII present
    medium_risk_pii_flag: int  = 0   # 1 if only Confidential-level PII
    pii_density:          float= 0.0 # total_pii / token_count
    # Keyword features
    restricted_kw_count:  int  = 0
    confidential_kw_count:int  = 0
    internal_kw_count:    int  = 0
    financial_kw_count:   int  = 0
    legal_kw_count:       int  = 0
    # Derived keyword flags
    has_restricted_kw:    int  = 0
    has_confidential_kw:  int  = 0
    # Policy hint encoding
    policy_hint_encoded:  int  = 0   # Allow=0, Encrypt=1, Restrict=2, Quarantine=3

    def to_vector(self) -> List[float]:
        return [float(v) for v in self.model_dump().values()
                if isinstance(v, (int, float))]

    @classmethod
    def feature_names(cls) -> List[str]:
        return [f"risk_{k}" for k, v in cls.model_fields.items()
                if v.annotation in (int, float)]


class EmbeddingFeatures(BaseModel):
    """Dense vector representation from a transformer model."""
    model_name:    str   = ""
    model_alias:   str   = ""
    dimension:     int   = 0
    vector:        List[float] = Field(default_factory=list)
    vector_norm:   float = 0.0
    from_cache:    bool  = False
    aggregation:   str   = "mean"   # mean | max | cls
    chunk_count:   int   = 1


class TFIDFRef(BaseModel):
    """
    Reference to a serialised TF-IDF sparse matrix.
    The sparse vector itself is not inlined in Kafka — too large.
    The Classification Layer loads it from the artifact path.
    """
    artifact_path: str  = ""   # path to joblib-serialised sparse vector
    feature_count: int  = 0
    vocab_size:    int  = 0
    vectorizer_version: str = ""
    # For real-time inference: top-N non-zero features are inlined
    top_features:  Dict[str, float] = Field(default_factory=dict)   # term → tfidf_score


class ClassicalFeatures(BaseModel):
    tfidf:           TFIDFRef         = Field(default_factory=TFIDFRef)
    stat_features:   StatisticalFeatures = Field(default_factory=StatisticalFeatures)
    metadata_features: MetadataFeatures  = Field(default_factory=MetadataFeatures)
    risk_features:   RiskFeatures     = Field(default_factory=RiskFeatures)
    # Combined dense vector (stat + metadata + risk concatenated) for direct model input
    combined_vector: List[float]      = Field(default_factory=list)
    combined_feature_names: List[str] = Field(default_factory=list)


class ServingFeatures(BaseModel):
    """Flags indicating which feature types are ready for serving."""
    dense_vector_ready:  bool = False
    sparse_vector_ready: bool = False
    embedding_ready:     bool = False
    combined_dim:        int  = 0
    embedding_dim:       int  = 0
    tfidf_features:      int  = 0


# ─────────────────────────────────────────────────────────────────────────────
# Feature Engineering metadata (provenance)
# ─────────────────────────────────────────────────────────────────────────────

class FeatureEngineeringMetadata(BaseModel):
    feature_run_id:      str   = Field(default_factory=lambda: str(uuid.uuid4()))
    feature_timestamp:   str   = Field(default_factory=lambda: datetime.utcnow().isoformat())
    feature_version:     str   = "v1"
    pipeline_mode:       str   = PipelineMode.INFERENCE.value
    pipeline_steps:      List[str] = Field(default_factory=list)
    step_warnings:       Dict[str, str] = Field(default_factory=dict)
    processing_time_ms:  float = 0.0
    vectorizer_version:  str   = ""


# ─────────────────────────────────────────────────────────────────────────────
# OUTPUT: EngineeredFeatureSet — what Classification Layer consumes
# ─────────────────────────────────────────────────────────────────────────────

class EngineeredFeatureSet(BaseModel):
    """
    Canonical output of the Feature Engineering Layer.
    Published to: engineered_features topic.

    Classification Layer reads:
      classical_features.combined_vector     → LR, XGBoost, LightGBM input
      classical_features.combined_feature_names → SHAP feature names
      embedding_features.vector              → BERT classifier head input
      classical_features.risk_features       → direct signals for ensemble
      lineage                                → provenance tracing
    """
    # Identity
    doc_id:          str
    parent_doc_id:   Optional[str] = None
    event_id:        str = ""
    ingest_id:       str = ""

    # Features
    classical_features:  ClassicalFeatures  = Field(default_factory=ClassicalFeatures)
    embedding_features:  EmbeddingFeatures  = Field(default_factory=EmbeddingFeatures)
    serving_features:    ServingFeatures    = Field(default_factory=ServingFeatures)

    # Forwarded signals (so classifier doesn't need to re-read preprocessing output)
    language:            str = "en"
    recommended_model:   str = "english_classifier_v1"
    structure_type:      str = "single"
    segment_index:       Optional[int] = None
    total_segments:      Optional[int] = None
    pii_policy_hint:     str = "Allow"

    # Metadata forwarded from ingestion (prior signals for the model)
    source_system:       str = "UNKNOWN"
    department:          str = "UNKNOWN"
    document_type:       str = "general"
    region:              str = "UNKNOWN"

    # Lineage
    lineage: Dict[str, str] = Field(default_factory=lambda: {
        "source_topic":   "preprocessed_documents",
        "pipeline_stage": "feature_engineering",
    })

    # Provenance
    feature_engineering: FeatureEngineeringMetadata = Field(
        default_factory=FeatureEngineeringMetadata
    )
    status:       str = ProcessingStatus.SUCCESS.value
    status_detail:Optional[str] = None

    class Config:
        use_enum_values = True


# ─────────────────────────────────────────────────────────────────────────────
# Audit + DLR
# ─────────────────────────────────────────────────────────────────────────────

class FeatureAudit(BaseModel):
    audit_id:           str   = Field(default_factory=lambda: str(uuid.uuid4()))
    doc_id:             str   = ""
    ingest_id:          str   = ""
    feature_run_id:     str   = ""
    source_topic:       str   = ""
    source_system:      str   = ""
    department:         str   = ""
    pipeline_mode:      str   = ""
    status:             str   = ""
    language:           str   = "en"
    recommended_model:  str   = ""
    tfidf_features:     int   = 0
    stat_features:      int   = 0
    metadata_features:  int   = 0
    risk_features:      int   = 0
    embedding_dim:      int   = 0
    combined_dim:       int   = 0
    pipeline_steps:     List[str] = Field(default_factory=list)
    step_warnings:      Dict[str, str] = Field(default_factory=dict)
    processing_time_ms: float = 0.0
    failure_reason:     Optional[str] = None
    failure_detail:     Optional[str] = None
    timestamp:          str   = Field(default_factory=lambda: datetime.utcnow().isoformat())


class FeatureDLR(BaseModel):
    dlr_id:          str = Field(default_factory=lambda: str(uuid.uuid4()))
    doc_id:          str = ""
    ingest_id:       str = ""
    source_topic:    str = ""
    failure_stage:   str = ""
    failure_reason:  str = ""
    failure_detail:  str = ""
    retry_count:     int = 0
    original_payload:Optional[Dict[str, Any]] = None
    failed_at:       str = Field(default_factory=lambda: datetime.utcnow().isoformat())


class ValidationResult(BaseModel):
    success:        bool
    failure_reason: Optional[str] = None
    failure_detail: Optional[str] = None

    @classmethod
    def ok(cls): return cls(success=True)

    @classmethod
    def fail(cls, reason: str, detail: str = ""):
        return cls(success=False, failure_reason=reason, failure_detail=detail)
