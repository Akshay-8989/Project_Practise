# Enterprise Feature Engineering Layer
## Automated Sensitivity Classification Platform — v1.0

---

## Where This Layer Sits

```
Source Systems → Ingestion → Preprocessing → [FEATURE ENGINEERING] → Classification → Policy Engine → Output
```

Converts preprocessed, cleaned, PII-masked documents into ML-ready numerical representations.
Downstream Classification Layer reads directly from the `engineered_features` Kafka topic.

---

## Full Pipeline Per Document

```
Kafka Message (from Preprocessing Layer: preprocessed_documents)
            │
            ▼
  [1]  Schema Validation          Pydantic parse of PreprocessedDocument
            │
            ▼
  [2]  Statistical Features       16 numerical signals from text structure
       token_count | avg_word_length | entropy | uppercase_ratio
       digit_ratio | TTR | repeated_term_ratio | sentence_count ...
            │
            ▼
  [3]  Metadata Encoding          Categorical → numerical
       source_system | department | region | document_type
       OneHot / Frequency / Hash (config-driven)
            │
            ▼
  [4]  Risk + Keyword Features    PII counts + domain keyword signals
       10 PII type counts | total_pii | high_risk_flag | pii_density
       restricted_kw_count | confidential_kw_count | financial_kw_count ...
            │
            ▼
  [5]  TF-IDF Transform           Sparse vector (unigrams + bigrams)
       Top-25 features inlined in Kafka | full sparse saved to disk
            │
            ▼
  [6]  Embedding Encode           Dense vector via SentenceTransformer
       MiniLM-L6 (384-dim) | BERT/RoBERTa/DeBERTa (768-dim)
       Chunk aggregation for long docs (mean/max pooling)
       Content-hash cache for repeat documents
            │
            ▼
  [7]  Combined Vector            stat + metadata + risk concatenated
       Fixed-dim dense vector for direct classifier input
       Feature names registered for SHAP/LIME explainability
            │
            ▼
  [8]  Drift Detection            Rolling window mean/variance tracking
       Alerts on distribution shift → signals model retraining need
            │
            ▼
  [9]  Publish EngineeredFeatureSet
       engineered_features topic (Classification Layer reads this)
       training_feature_store (training mode only)
       feature_audit_logs
```

---

## Output Schema (what Classification Layer consumes)

```json
{
  "doc_id": "DOC-HRMS-2026-00441",
  "language": "en",
  "recommended_model": "english_classifier_v1",
  "pii_policy_hint": "Quarantine",

  "classical_features": {
    "tfidf": {
      "artifact_path": "artifacts/vectorizers/tfidf_DOC-HRMS_abc12345.npz",
      "feature_count": 47,
      "vocab_size": 10000,
      "vectorizer_version": "a3f9e2b1",
      "top_features": {
        "confidential": 0.421, "salary": 0.389, "employee": 0.312,
        "hr": 0.298, "payroll": 0.276
      }
    },
    "stat_features": {
      "token_count": 29.0, "type_token_ratio": 0.827, "entropy": 4.312,
      "uppercase_ratio": 0.031, "digit_ratio": 0.018, ...
    },
    "metadata_features": {
      "encoding_type": "onehot",
      "vector": [1,0,0,0,0, 0,1,0,0,0, ...],
      "feature_names": ["meta_source_system_HRMS", "meta_dept_HR", ...]
    },
    "risk_features": {
      "pii_pan": 1, "pii_aadhaar": 1, "total_pii_count": 6,
      "high_risk_pii_flag": 1, "pii_density": 0.207,
      "restricted_kw_count": 2, "confidential_kw_count": 1,
      "policy_hint_encoded": 3
    },
    "combined_vector": [29.0, 0.827, 4.312, ...],
    "combined_feature_names": ["stat_token_count", "stat_type_token_ratio", ...,
                               "meta_source_system_HRMS", ..., "risk_total_pii_count", ...]
  },

  "embedding_features": {
    "model_name": "sentence-transformers/all-MiniLM-L6-v2",
    "model_alias": "minilm",
    "dimension": 384,
    "vector": [0.0412, -0.0831, 0.1204, ...],
    "vector_norm": 1.0,
    "aggregation": "mean",
    "chunk_count": 1
  },

  "serving_features": {
    "dense_vector_ready": true,
    "sparse_vector_ready": true,
    "embedding_ready": true,
    "combined_dim": 52,
    "embedding_dim": 384,
    "tfidf_features": 47
  },

  "lineage": {
    "source_topic": "preprocessed_documents",
    "pipeline_stage": "feature_engineering",
    "ingest_id": "ingest-001-uuid"
  },

  "feature_engineering": {
    "feature_version": "v1",
    "pipeline_mode": "inference",
    "pipeline_steps": ["schema_validation", "stat_features", "metadata_encoding",
                       "risk_keyword_features", "tfidf_transform", "embedding_encode",
                       "combined_vector_build"],
    "processing_time_ms": 42.3
  },
  "status": "success"
}
```

---

## Feature Types Reference

### Statistical Features (16 dimensions)
| Feature | Description | Sensitivity Signal |
|---|---|---|
| `token_count` | Total word tokens | Document length |
| `type_token_ratio` | Unique/total tokens | Lexical diversity |
| `entropy` | Shannon entropy | Information density |
| `uppercase_ratio` | CAPS proportion | Legal/formal docs |
| `digit_ratio` | Numeric proportion | Financial documents |
| `special_char_ratio` | Special chars | Code/technical docs |
| `avg_word_length` | Mean word length | Domain specificity |
| `repeated_term_ratio` | Repeated terms | Template documents |
| `sentence_count` | Sentence count | Document structure |
| `reduction_pct` | Clean/raw reduction | HTML/OCR noise level |

### Risk Features (21 dimensions)
| Feature | Description | Signal |
|---|---|---|
| `pii_pan`, `pii_aadhaar`, `pii_ssn`, `pii_iban`, `pii_credit_card`, `pii_bank_account` | High-severity PII counts | → Restricted |
| `pii_email`, `pii_phone`, `pii_dob`, `pii_employee_id` | Medium-severity PII | → Confidential |
| `total_pii_count` | Sum of all PII | Overall PII load |
| `high_risk_pii_flag` | 1 if any Restricted PII | Hard signal |
| `pii_density` | PII per token | Relative PII concentration |
| `restricted_kw_count` | Restricted keyword hits | Rule-overlay signal |
| `confidential_kw_count` | Confidential keyword hits | Soft signal |
| `financial_kw_count` | Financial keyword hits | Domain signal |
| `policy_hint_encoded` | 0=Allow 1=Encrypt 2=Restrict 3=Quarantine | Pre-classification hint |

---

## Project Structure

```
enterprise_feature_engineering/
│
├── app.py                 CLI entry point (all modes)
├── consumer.py            Kafka consumer loop (production)
├── pipeline.py            Pipeline orchestrator (wires all steps)
│
├── stats_features.py      Statistical text features (16 dims)
├── metadata_encoder.py    Categorical metadata encoding (OneHot/Freq/Hash)
├── keyword_features.py    Domain keyword dictionaries + risk flags (21 dims)
├── tfidf_engine.py        TF-IDF with artifact persistence + SHAP names
├── embedding_engine.py    Pluggable transformer embeddings + cache
├── chunk_aggregator.py    Multi-chunk mean/max pooling
├── feature_registry.py    Feature name registry + drift detection
├── serializer.py          Artifact save/load + training batch writer
│
├── validator.py           Schema + business rule validation
├── producer.py            Kafka producer wrapper
├── retry_handler.py       Exponential backoff + DLQ
├── schema.py              All Pydantic models
├── config.py              Environment-driven config
├── logger.py              Structured rotating logger
│
├── .env.example           Environment config template
├── requirements.txt
│
├── sample_inputs/         Preprocessed document payloads for testing
├── sample_outputs/        Generated outputs
├── logs/                  feature_engineering.log
└── artifacts/
    ├── vectorizers/       TF-IDF vectorizer + sparse vectors (.joblib, .npz)
    ├── encoders/          Metadata encoders (.joblib)
    ├── embedding_cache/   Embedding cache (.npy per content hash)
    ├── training_store/    Training feature batches (.parquet)
    └── feature_registry.json
```

---

## Windows Kafka Setup

If Kafka from previous layers is already running, only create the new topics.

**Start Zookeeper (Terminal 1):**
```cmd
cd C:\kafka
.\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties
```

**Start Kafka Broker (Terminal 2):**
```cmd
cd C:\kafka
.\bin\windows\kafka-server-start.bat .\config\server.properties
```

**Create Feature Engineering Topics (Terminal 3):**
```cmd
cd C:\kafka

.\bin\windows\kafka-topics.bat --create --topic engineered_features --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic feature_audit_logs --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic feature_retry_queue --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic feature_dead_letter_queue --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic training_feature_store --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic realtime_feature_store --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1
```

**Verify:**
```cmd
.\bin\windows\kafka-topics.bat --list --bootstrap-server localhost:9092
```

---

## Install Dependencies

```bash
pip install -r requirements.txt
```

For embeddings (required for `embedding_engine.py`):
```bash
pip install sentence-transformers
```
On first run, MiniLM model (~90 MB) downloads automatically from HuggingFace.

---

## How to Run

### Mode 1 — Test without Kafka
```bash
# Single payload
python app.py --file sample_inputs/hr_record_preprocessed.json

# All samples with output
python app.py --folder sample_inputs/ --output sample_outputs/all_features.json
```

### Mode 2 — Fit TF-IDF on your corpus (do this before inference)
```bash
# Create a corpus file: one document text per line
python app.py --fit-tfidf my_corpus.txt
# Saves vectorizer to artifacts/vectorizers/tfidf_vectorizer.joblib
```

### Mode 3 — Kafka consumer (production mode)
```bash
python app.py --consumer
```

### Mode 4 — Training mode (batch + save to feature store)
```bash
python app.py --consumer --training
# Also publishes to training_feature_store topic
```

### Monitor output
```cmd
cd C:\kafka
.\bin\windows\kafka-console-consumer.bat --topic engineered_features --from-beginning --bootstrap-server localhost:9092
```

---

## Integration: Preprocessing → Feature Engineering

The Feature Engineering Layer consumes directly from `preprocessed_documents`.
`PreprocessedDocument` in `schema.py` mirrors `PreprocessedDocument` from the Preprocessing Layer.
**No adapter needed — Kafka topic is the integration contract.**

---

## Integration: Feature Engineering → Classification Layer

The Classification Layer reads from `engineered_features`.
Key fields it uses:

| Field | Used for |
|---|---|
| `classical_features.combined_vector` | LR, XGBoost, LightGBM input array |
| `classical_features.combined_feature_names` | SHAP explainer feature names |
| `embedding_features.vector` | BERT classifier head input |
| `classical_features.tfidf.top_features` | Real-time LIME token attribution |
| `classical_features.risk_features` | Policy Engine rule overlay signals |
| `recommended_model` | Which model variant to load |
| `pii_policy_hint` | Pre-classification risk signal |
| `serving_features.combined_dim` | Validates expected input dimension |

Classification Layer pseudo-code:
```python
# Load pre-fitted models
lr_model   = joblib.load("models/lr_classifier.joblib")
xgb_model  = joblib.load("models/xgb_classifier.joblib")
emb_model  = load_bert_head("models/bert_head.pt")

# Read from Kafka
features = EngineeredFeatureSet(**kafka_message)

# Classical path
X_classical = np.array(features.classical_features.combined_vector)
lr_proba    = lr_model.predict_proba([X_classical])
xgb_proba   = xgb_model.predict_proba([X_classical])

# Embedding path
X_emb       = np.array(features.embedding_features.vector)
bert_proba  = emb_model.predict([X_emb])

# Ensemble
final_proba = 0.3*lr_proba + 0.4*xgb_proba + 0.3*bert_proba
label       = ["Public","Internal","Confidential","Restricted"][final_proba.argmax()]

# SHAP explainability
explainer   = shap.LinearExplainer(lr_model, background_data)
shap_values = explainer(X_classical)
# feature_names = features.classical_features.combined_feature_names
# → "stat_entropy", "risk_pii_pan", "meta_dept_HR" etc.
```

---

## Configuration Reference

| Variable | Default | Description |
|---|---|---|
| `PIPELINE_MODE` | `inference` | `inference` or `training` |
| `TFIDF_MAX_FEATURES` | `10000` | Vocabulary size |
| `TFIDF_NGRAM_MIN/MAX` | `1` / `2` | Unigrams + bigrams |
| `EMBEDDING_MODEL` | `minilm` | `minilm`, `bert`, `roberta`, `deberta` |
| `EMBEDDING_CACHE_ENABLED` | `true` | Cache embeddings by content hash |
| `METADATA_ENCODING` | `onehot` | `onehot`, `frequency`, `hash` |
| `CHUNK_AGGREGATION` | `mean` | `mean`, `max`, `both` |
| `DRIFT_DETECTION_ENABLED` | `true` | Rolling drift alerts |
| `DRIFT_ALERT_THRESHOLD` | `0.15` | Normalised delta before alert |

---

## Future Extensibility

| Enhancement | How |
|---|---|
| **Presidio PII features** | Add Presidio entity type counts to `RiskFeatures` |
| **Custom embedding model** | Set `EMBEDDING_MODEL_NAME=company/model` in `.env` |
| **Incremental TF-IDF refit** | Use scikit-learn `HashingVectorizer` + warm-start SGD |
| **Evidently AI drift** | Replace `DriftTracker` in `feature_registry.py` with Evidently monitor |
| **River online learning** | Replace batch TF-IDF with `river.feature_extraction.TFIDF` |
| **Feature store (Feast)** | Replace `serializer.save_training_batch` with Feast push |
| **GPU embeddings** | Set `EMBEDDING_DEVICE=cuda` in `.env` |
| **New keyword domains** | Add terms to lists in `keyword_features.py` or load from JSON |
| **Additional languages** | Add entries to `LanguageConfig.model_routing` in `config.py` |
