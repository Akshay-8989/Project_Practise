"""
pipeline.py
============
Feature Engineering Pipeline Orchestrator.

Executes all feature engineering steps in order:

  [1]  Validate schema           validator.validate_preprocessed_payload()
  [2]  Statistical features      stats_features.extract_stat_features()
  [3]  Metadata encoding         metadata_encoder.encode_metadata()
  [4]  Risk + keyword features   keyword_features.extract_risk_features()
  [5]  TF-IDF transform          tfidf_engine.transform_document()
  [6]  Embedding encode          embedding_engine.encode_text()
                                  (with chunk aggregation if needed)
  [7]  Build combined vector     concat(stat + metadata + risk)
  [8]  Register feature names    feature_registry.register()
  [9]  Drift tracking            feature_registry.update_drift()
  [10] Build EngineeredFeatureSet
  [11] Build audit record

Two pipeline modes:
  inference — fast path; uses preloaded artifacts; minimal I/O
  training  — full path; builds training feature batches for model fitting

Null handling:
  Every feature extraction step is wrapped in try/except.
  Failed steps return zero vectors and are recorded in step_warnings.
  The pipeline never crashes — partial features are better than no features.
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import numpy as np

from schema import (
    ClassicalFeatures, EngineeredFeatureSet, EmbeddingFeatures,
    FeatureAudit, FeatureDLR, FeatureEngineeringMetadata,
    PreprocessedDocument, ProcessingStatus, ServingFeatures,
    ValidationResult,
)
from config import CONFIG
from logger import get_logger
from validator import validate_preprocessed_payload
from stats_features import extract_stat_features
from metadata_encoder import encode_metadata
from keyword_features import extract_risk_features
from tfidf_engine import transform_document, get_engine as get_tfidf_engine
from embedding_engine import encode_text, get_engine as get_emb_engine
from chunk_aggregator import aggregate_chunk_embeddings
from feature_registry import get_registry, FeatureRegistry

log = get_logger("pipeline")


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline result
# ─────────────────────────────────────────────────────────────────────────────

class PipelineResult:
    __slots__ = [
        "doc_id", "feature_run_id", "status", "feature_set",
        "audit", "dlr", "failure_reason", "failure_detail",
        "processing_time_ms",
    ]

    def __init__(self, doc_id: str = ""):
        self.doc_id              = doc_id
        self.feature_run_id      = str(uuid.uuid4())
        self.status              = ProcessingStatus.FAILED.value
        self.feature_set:        Optional[EngineeredFeatureSet] = None
        self.audit:              Optional[FeatureAudit] = None
        self.dlr:                Optional[FeatureDLR]   = None
        self.failure_reason:     Optional[str] = None
        self.failure_detail:     Optional[str] = None
        self.processing_time_ms: float = 0.0

    def __repr__(self):
        if self.status == ProcessingStatus.SUCCESS.value:
            fs = self.feature_set
            return (
                f"<OK  doc_id={self.doc_id} "
                f"combined_dim={fs.serving_features.combined_dim if fs else 0} "
                f"emb_dim={fs.serving_features.embedding_dim if fs else 0} "
                f"time={self.processing_time_ms:.0f}ms>"
            )
        return f"<FAIL doc_id={self.doc_id} {self.failure_reason}: {self.failure_detail}>"


# ─────────────────────────────────────────────────────────────────────────────
# Main pipeline function
# ─────────────────────────────────────────────────────────────────────────────

def run_pipeline(
    raw_payload:  Dict,
    source_topic: str = "preprocessed_documents",
) -> PipelineResult:
    """
    Execute the full feature engineering pipeline for one Kafka message.

    Args:
        raw_payload:  Deserialised Kafka message dict from Preprocessing Layer.
        source_topic: Source Kafka topic (for audit lineage).

    Returns:
        PipelineResult with EngineeredFeatureSet and audit record.
    """
    start_time      = time.monotonic()
    result          = PipelineResult()
    pipeline_steps: List[str] = []
    step_warnings:  Dict[str, str] = {}
    registry        = get_registry()

    # ─────────────────────────────────────────────────────────────────────
    # [1] Schema validation
    # ─────────────────────────────────────────────────────────────────────
    val_result, doc = validate_preprocessed_payload(raw_payload)
    if not val_result.success:
        return _fail(result, raw_payload, source_topic,
                     "SCHEMA_VALIDATION", val_result.failure_reason,
                     val_result.failure_detail, start_time)

    result.doc_id = doc.doc_id
    text          = doc.masked_text or doc.clean_text
    tokens        = doc.tokens or text.split()
    pipeline_steps.append("schema_validation")

    log.info(
        "[%s] Pipeline start | source=%s | dept=%s | lang=%s | tokens=%d",
        doc.doc_id, doc.business_metadata.source_system,
        doc.business_metadata.department, doc.language.code, len(tokens),
    )

    # ─────────────────────────────────────────────────────────────────────
    # [2] Statistical features
    # ─────────────────────────────────────────────────────────────────────
    try:
        stat_feats = extract_stat_features(text, tokens, doc.stats, doc_id=doc.doc_id)
        pipeline_steps.append("stat_features")
    except Exception as exc:
        log.warning("[%s] Stat features failed: %s", doc.doc_id, exc)
        from schema import StatisticalFeatures
        stat_feats = StatisticalFeatures()
        step_warnings["stat"] = str(exc)

    stat_vector = registry.fill_nulls(stat_feats.to_vector(), "stat")
    stat_names  = stat_feats.feature_names()
    registry.register("stat", stat_names)
    if CONFIG.drift.enabled:
        registry.update_drift("stat", stat_vector)

    # ─────────────────────────────────────────────────────────────────────
    # [3] Metadata encoding
    # ─────────────────────────────────────────────────────────────────────
    try:
        meta_feats = encode_metadata(doc.business_metadata, doc_id=doc.doc_id)
        pipeline_steps.append("metadata_encoding")
    except Exception as exc:
        log.warning("[%s] Metadata encoding failed: %s", doc.doc_id, exc)
        from schema import MetadataFeatures
        meta_feats = MetadataFeatures()
        step_warnings["metadata"] = str(exc)

    meta_vector = registry.fill_nulls(meta_feats.vector, "metadata")
    if meta_feats.feature_names:
        registry.register("metadata", meta_feats.feature_names)

    # ─────────────────────────────────────────────────────────────────────
    # [4] Risk + keyword features
    # ─────────────────────────────────────────────────────────────────────
    try:
        risk_feats = extract_risk_features(
            masked_text  = text,
            pii_entities = doc.pii_entities,
            policy_hint  = doc.pii_policy_hint,
            token_count  = len(tokens),
            doc_id       = doc.doc_id,
        )
        pipeline_steps.append("risk_keyword_features")
    except Exception as exc:
        log.warning("[%s] Risk features failed: %s", doc.doc_id, exc)
        from schema import RiskFeatures
        risk_feats = RiskFeatures()
        step_warnings["risk"] = str(exc)

    risk_vector = registry.fill_nulls(risk_feats.to_vector(), "risk")
    risk_names  = risk_feats.feature_names()
    registry.register("risk", risk_names)
    if CONFIG.drift.enabled:
        registry.update_drift("risk", risk_vector)

    # ─────────────────────────────────────────────────────────────────────
    # [5] TF-IDF transform
    # ─────────────────────────────────────────────────────────────────────
    try:
        tfidf_ref = transform_document(text, doc_id=doc.doc_id, top_n=25)
        pipeline_steps.append("tfidf_transform")
        # Register TF-IDF feature names if vectorizer is fitted
        tfidf_names = get_tfidf_engine().feature_names
        if tfidf_names:
            registry.register("tfidf", tfidf_names)
    except Exception as exc:
        log.warning("[%s] TF-IDF failed: %s", doc.doc_id, exc)
        from schema import TFIDFRef
        tfidf_ref = TFIDFRef()
        step_warnings["tfidf"] = str(exc)

    # ─────────────────────────────────────────────────────────────────────
    # [6] Embedding (with chunk aggregation)
    # ─────────────────────────────────────────────────────────────────────
    embedding_feats = _encode_with_aggregation(doc, text, step_warnings, pipeline_steps)

    # ─────────────────────────────────────────────────────────────────────
    # [7] Build combined dense vector (stat + metadata + risk)
    # ─────────────────────────────────────────────────────────────────────
    combined_vector = stat_vector + meta_vector + risk_vector
    combined_names  = stat_names + meta_feats.feature_names + risk_names
    combined_vector = registry.fill_nulls(combined_vector, "combined")

    if CONFIG.drift.enabled:
        registry.update_drift("combined", combined_vector)

    pipeline_steps.append("combined_vector_build")

    # ─────────────────────────────────────────────────────────────────────
    # [8] Build EngineeredFeatureSet
    # ─────────────────────────────────────────────────────────────────────
    elapsed_ms = (time.monotonic() - start_time) * 1000

    classical = ClassicalFeatures(
        tfidf             = tfidf_ref,
        stat_features     = stat_feats,
        metadata_features = meta_feats,
        risk_features     = risk_feats,
        combined_vector   = combined_vector,
        combined_feature_names = combined_names,
    )

    serving = ServingFeatures(
        dense_vector_ready  = len(combined_vector) > 0,
        sparse_vector_ready = bool(tfidf_ref.artifact_path),
        embedding_ready     = len(embedding_feats.vector) > 0,
        combined_dim        = len(combined_vector),
        embedding_dim       = embedding_feats.dimension,
        tfidf_features      = tfidf_ref.feature_count,
    )

    fe_meta = FeatureEngineeringMetadata(
        feature_run_id     = result.feature_run_id,
        feature_version    = CONFIG.version,
        pipeline_mode      = CONFIG.mode,
        pipeline_steps     = pipeline_steps,
        step_warnings      = step_warnings,
        processing_time_ms = elapsed_ms,
        vectorizer_version = tfidf_ref.vectorizer_version,
    )

    status = (ProcessingStatus.PARTIAL.value if step_warnings
              else ProcessingStatus.SUCCESS.value)

    feature_set = EngineeredFeatureSet(
        doc_id           = doc.doc_id,
        parent_doc_id    = doc.parent_doc_id,
        event_id         = doc.event_id,
        ingest_id        = doc.ingest_id,
        classical_features  = classical,
        embedding_features  = embedding_feats,
        serving_features    = serving,
        language         = doc.language.code,
        recommended_model= doc.recommended_model,
        structure_type   = doc.structure_type,
        segment_index    = doc.segment_index,
        total_segments   = doc.total_segments,
        pii_policy_hint  = doc.pii_policy_hint,
        source_system    = doc.business_metadata.source_system,
        department       = doc.business_metadata.department,
        document_type    = doc.business_metadata.document_type,
        region           = doc.business_metadata.region,
        lineage          = {
            "source_topic":   source_topic,
            "pipeline_stage": "feature_engineering",
            "ingest_id":      doc.ingest_id,
        },
        feature_engineering = fe_meta,
        status           = status,
        status_detail    = "; ".join(step_warnings.values()) if step_warnings else None,
    )

    result.feature_set       = feature_set
    result.status            = status
    result.processing_time_ms = elapsed_ms

    # ─────────────────────────────────────────────────────────────────────
    # [9] Build audit record
    # ─────────────────────────────────────────────────────────────────────
    result.audit = FeatureAudit(
        doc_id             = doc.doc_id,
        ingest_id          = doc.ingest_id,
        feature_run_id     = result.feature_run_id,
        source_topic       = source_topic,
        source_system      = doc.business_metadata.source_system,
        department         = doc.business_metadata.department,
        pipeline_mode      = CONFIG.mode,
        status             = status,
        language           = doc.language.code,
        recommended_model  = doc.recommended_model,
        tfidf_features     = tfidf_ref.feature_count,
        stat_features      = len(stat_vector),
        metadata_features  = len(meta_vector),
        risk_features      = len(risk_vector),
        embedding_dim      = embedding_feats.dimension,
        combined_dim       = len(combined_vector),
        pipeline_steps     = pipeline_steps,
        step_warnings      = step_warnings,
        processing_time_ms = elapsed_ms,
    )

    log.info(
        "[%s] Pipeline complete | combined_dim=%d emb_dim=%d tfidf=%d "
        "time=%.0fms status=%s",
        doc.doc_id, len(combined_vector), embedding_feats.dimension,
        tfidf_ref.feature_count, elapsed_ms, status,
    )
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Embedding + chunk aggregation helper
# ─────────────────────────────────────────────────────────────────────────────

def _encode_with_aggregation(
    doc:           PreprocessedDocument,
    text:          str,
    step_warnings: Dict,
    pipeline_steps:List,
) -> EmbeddingFeatures:
    """Encode embedding with optional chunk aggregation for long documents."""
    try:
        chunk_info  = doc.chunk_info
        if chunk_info.total_chunks > 1 and doc.sentence_chunks:
            # Encode each chunk independently, then aggregate
            chunk_vecs = []
            for chunk in doc.sentence_chunks:
                ef = encode_text(chunk, doc_id=doc.doc_id)
                if ef.vector:
                    chunk_vecs.append(ef.vector)

            emb_engine   = get_emb_engine()
            model_name, _ = CONFIG.embedding.resolve()
            embedding_feats = aggregate_chunk_embeddings(
                chunk_vectors = chunk_vecs,
                model_name    = emb_engine._model_name or model_name,
                model_alias   = CONFIG.embedding.model_alias,
                doc_id        = doc.doc_id,
            )
        else:
            embedding_feats = encode_text(text, doc_id=doc.doc_id)

        pipeline_steps.append("embedding_encode")
        return embedding_feats

    except Exception as exc:
        log.warning("[%s] Embedding failed: %s", doc.doc_id, exc)
        step_warnings["embedding"] = str(exc)
        return EmbeddingFeatures()


# ─────────────────────────────────────────────────────────────────────────────
# Failure helper
# ─────────────────────────────────────────────────────────────────────────────

def _fail(
    result:      PipelineResult,
    raw_payload: Dict,
    source_topic:str,
    stage:       str,
    reason:      str,
    detail:      str,
    start_time:  float,
) -> PipelineResult:
    elapsed = (time.monotonic() - start_time) * 1000
    result.failure_reason    = reason
    result.failure_detail    = detail
    result.processing_time_ms = elapsed

    doc_id   = raw_payload.get("doc_id", "")
    ingest_id= raw_payload.get("ingest_id", "")

    result.dlr = FeatureDLR(
        doc_id          = doc_id,
        ingest_id       = ingest_id,
        source_topic    = source_topic,
        failure_stage   = stage,
        failure_reason  = reason,
        failure_detail  = detail,
        original_payload= raw_payload,
    )
    result.audit = FeatureAudit(
        doc_id         = doc_id,
        ingest_id      = ingest_id,
        feature_run_id = result.feature_run_id,
        source_topic   = source_topic,
        status         = ProcessingStatus.FAILED.value,
        failure_reason = reason,
        failure_detail = detail,
        processing_time_ms = elapsed,
    )
    log.error("[%s] FAILED | stage=%s | reason=%s | %s", doc_id, stage, reason, detail)
    return result
