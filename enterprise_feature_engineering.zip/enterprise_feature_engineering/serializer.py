"""
serializer.py
==============
Artifact serialisation for the Feature Engineering Layer.

Two output modes:

  Streaming (inference):
    - Features inlined in Kafka message as JSON-serialisable lists
    - TF-IDF sparse vector saved to disk, path referenced in payload
    - Embedding vector inlined (384-768 floats — manageable in Kafka)

  Batch (training feature store):
    - All features serialised to disk as joblib/npz/parquet
    - Training manifest written (doc_ids, labels, artifact paths)
    - Used by the Classification Layer for model training

Serialisation formats:
  joblib  — sklearn/scipy objects (vectorizers, encoders, sparse matrices)
  .npy    — numpy arrays (dense embedding vectors)
  .npz    — scipy sparse matrices (TF-IDF vectors)
  .parquet— pandas DataFrames (training feature batches)
  .json   — metadata, registries, manifests
"""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

import numpy as np

from config import CONFIG
from logger import get_logger

log = get_logger("serializer")


def save_artifact(obj: Any, path: str, use_joblib: bool = True) -> bool:
    """Save any object to disk using joblib (default) or pickle."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    try:
        if use_joblib:
            import joblib
            joblib.dump(obj, path)
        else:
            import pickle
            with open(path, "wb") as f:
                pickle.dump(obj, f)
        log.debug("Saved artifact: %s", path)
        return True
    except Exception as exc:
        log.error("Could not save artifact %s: %s", path, exc)
        return False


def load_artifact(path: str, use_joblib: bool = True) -> Optional[Any]:
    """Load an artifact from disk."""
    if not os.path.isfile(path):
        return None
    try:
        if use_joblib:
            import joblib
            return joblib.load(path)
        else:
            import pickle
            with open(path, "rb") as f:
                return pickle.load(f)
    except Exception as exc:
        log.error("Could not load artifact %s: %s", path, exc)
        return None


def save_training_batch(
    doc_ids:          List[str],
    combined_vectors: List[List[float]],
    embedding_vectors:List[List[float]],
    feature_names:    List[str],
    labels:           Optional[List[str]] = None,
    batch_id:         str = "",
) -> str:
    """
    Serialise a batch of feature vectors to the training feature store.
    Returns the path to the saved batch file.

    Output: parquet file with columns matching feature_names + doc_id + label
    """
    try:
        import pandas as pd

        bid  = batch_id or uuid.uuid4().hex[:8]
        ts   = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(CONFIG.artifact_base, "training_store", f"batch_{ts}_{bid}.parquet")
        os.makedirs(os.path.dirname(path), exist_ok=True)

        # Classical features
        df = pd.DataFrame(combined_vectors, columns=feature_names[:len(combined_vectors[0])])
        df.insert(0, "doc_id", doc_ids)

        # Embedding features (as separate columns emb_0, emb_1, ...)
        if embedding_vectors and any(embedding_vectors):
            emb_dim = max(len(v) for v in embedding_vectors if v)
            emb_df  = pd.DataFrame(
                [v if v else [0.0] * emb_dim for v in embedding_vectors],
                columns=[f"emb_{i}" for i in range(emb_dim)],
            )
            df = pd.concat([df, emb_df], axis=1)

        if labels:
            df["label"] = labels

        df.to_parquet(path, index=False, engine="pyarrow")
        log.info("Training batch saved: %s (%d docs)", path, len(doc_ids))
        return path

    except ImportError:
        log.error("pandas/pyarrow not available for parquet serialisation")
    except Exception as exc:
        log.error("Training batch save failed: %s", exc)
    return ""


def write_manifest(manifest: Dict, name: str = "feature_manifest") -> str:
    """Write a JSON manifest describing the training feature store."""
    path = os.path.join(CONFIG.artifact_base, f"{name}.json")
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, default=str)
        log.info("Manifest written: %s", path)
        return path
    except Exception as exc:
        log.error("Manifest write failed: %s", exc)
        return ""
