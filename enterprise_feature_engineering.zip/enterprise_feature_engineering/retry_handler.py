"""retry_handler.py — Exponential backoff retry for Feature Engineering Layer."""
from __future__ import annotations
import time
from typing import Any, Callable, Dict, Optional, Tuple, TypeVar
from config import CONFIG
from logger import get_logger
log = get_logger("retry_handler")
T = TypeVar("T")

def with_retry(func: Callable[[], T], context: Dict[str, Any], producer: Any, stage: str = "") -> Tuple[bool, Optional[T], Optional[str]]:
    max_att, backoff, mult = CONFIG.retry.max_attempts, CONFIG.retry.backoff_seconds, CONFIG.retry.backoff_multiplier
    last_err = ""
    for attempt in range(1, max_att + 1):
        try:
            return True, func(), None
        except Exception as exc:
            last_err = str(exc)
            log.warning("[%s] Attempt %d/%d FAILED | stage=%s | %s", context.get("doc_id","?"), attempt, max_att, stage, exc)
            if attempt < max_att:
                sleep = backoff * (mult ** (attempt - 1))
                time.sleep(sleep)
    try:
        from schema import FeatureDLR
        dlr = FeatureDLR(doc_id=context.get("doc_id",""), ingest_id=context.get("ingest_id",""),
                         source_topic=context.get("source_topic",""), failure_stage=stage,
                         failure_reason="MAX_RETRIES_EXCEEDED", failure_detail=last_err, retry_count=max_att)
        producer.send_dlq(dlr.model_dump())
    except Exception as e:
        log.error("DLQ write failed: %s", e)
    return False, None, last_err
