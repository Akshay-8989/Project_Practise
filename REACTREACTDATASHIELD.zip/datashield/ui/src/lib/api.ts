// Centralised API client. The Vite dev server proxies /api/* to http://127.0.0.1:8000.
// In production we'd point this at the same host or a configured URL.

const API_BASE = '/api';

export interface ClassifyResponse {
  doc_id: string;
  label: string;
  confidence: number;
  class_probabilities: Record<string, number>;
  evidence: Array<{ token: string; weight: number; source: string }>;
  policy_action: string;
  policy_trace: any;
  model_contributions: Record<string, any>;
  language: { detected: string; routed_to: string };
  audit: any;
  preprocessing: any;
  features: any;
  latency_ms: { preprocessing: number; features: number; classification: number; total: number };
  timestamp_utc: string;
  source_file?: string;
  extracted_text_preview?: string;
  webhooks_delivered?: number;
}

export interface MetricsResponse {
  total_classified: number;
  total_overrides: number;
  total_confirmations?: number;
  human_override_rate: number;
  override_rate_compliant: boolean;
  label_distribution: Record<string, number>;
  avg_confidence: number;
  target_override_rate: string;
}

export interface HistoryEntry {
  doc_id: string;
  label: string;
  confidence: number;
  timestamp_utc: string;
  policy_trace?: any;
  input_snippet_masked?: string;
  evidence_count?: number;
  human_override?: any;
  class_probabilities?: Record<string, number>;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(API_BASE + path, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`API ${path} → HTTP ${res.status}: ${body}`);
  }
  return res.json();
}

async function requestFormData<T>(path: string, formData: FormData): Promise<T> {
  const res = await fetch(API_BASE + path, { method: 'POST', body: formData });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`API ${path} → HTTP ${res.status}: ${body}`);
  }
  return res.json();
}

export const api = {
  // Health
  health: () => request<{ status: string; pipeline_loaded: boolean; timestamp_utc: string }>('/health'),

  // Classification
  classifyText: (text: string, opts: { doc_id?: string; source_system?: string; department?: string }) =>
    request<ClassifyResponse>('/classify', {
      method: 'POST',
      body: JSON.stringify({ text, ...opts, file_type: 'txt' }),
    }),

  classifyFile: (file: File, opts: { doc_id?: string; source_system?: string; department?: string }) => {
    const fd = new FormData();
    fd.append('file', file);
    if (opts.doc_id) fd.append('doc_id', opts.doc_id);
    if (opts.source_system) fd.append('source_system', opts.source_system);
    if (opts.department) fd.append('department', opts.department);
    return requestFormData<ClassifyResponse>('/classify/file', fd);
  },

  classifyBatch: (files: File[]) => {
    const fd = new FormData();
    files.forEach(f => fd.append('files', f));
    return requestFormData<{ job_id: string; status: string; item_count: number }>('/classify/batch', fd);
  },

  jobStatus: (jobId: string) =>
    request<{ job_id: string; status: string; progress: { completed: number; total: number }; results: any[] }>(`/classify/status/${jobId}`),

  // History
  history: (params: { limit?: number; offset?: number; label?: string; only_overrides?: boolean } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && v !== '' && qs.append(k, String(v)));
    return request<{ total: number; offset: number; limit: number; entries: HistoryEntry[] }>(`/history?${qs}`);
  },

  document: (docId: string) =>
    request<{ audit: any; overrides: any[]; approvals: any[] }>(`/document/${docId}`),

  // HITL
  override: (body: { doc_id: string; original_label: string; corrected_label: string; reviewer: string; reason?: string }) =>
    request<{ status: string; is_correction: boolean; entry: any }>('/override', { method: 'POST', body: JSON.stringify(body) }),

  reviewQueue: () => request<{ pending_count: number; entries: any[] }>('/review-queue'),

  // Approvals
  approve: (body: { doc_id: string; approver: string; decision: string; notes?: string }) =>
    request<{ status: string; entry: any; gate_status: any }>('/approval/sign-off', { method: 'POST', body: JSON.stringify(body) }),

  approvalStatus: (docId: string) => request<any>(`/approval/status/${docId}`),

  // Metrics & MLOps
  metrics: () => request<MetricsResponse>('/metrics'),
  mlopsRegistry: () => request<any>('/mlops/registry'),
  mlopsRetraining: () => request<any>('/mlops/retraining'),
  exportTrainingBatch: () => request<{ exported: boolean; path?: string; pending_count?: number; reason?: string }>('/mlops/export-batch', { method: 'POST' }),
};

// Sensitivity label color helper
export function labelClass(label: string | undefined): string {
  switch (label) {
    case 'Public': return 'label-public';
    case 'Internal': return 'label-internal';
    case 'Confidential': return 'label-confidential';
    case 'Restricted': return 'label-restricted';
    default: return 'bg-slate-100 text-slate-700 border-slate-200';
  }
}

export function actionClass(action: string | undefined): string {
  switch (action) {
    case 'Allow': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'Encrypt': return 'bg-amber-50 text-amber-700 border-amber-200';
    case 'Restrict': return 'bg-orange-50 text-orange-700 border-orange-200';
    case 'Quarantine': return 'bg-rose-50 text-rose-700 border-rose-200';
    case 'HumanReview': return 'bg-violet-50 text-violet-700 border-violet-200';
    default: return 'bg-slate-50 text-slate-700 border-slate-200';
  }
}

export function actionIcon(action: string | undefined): string {
  switch (action) {
    case 'Allow': return '✓';
    case 'Encrypt': return '🔒';
    case 'Restrict': return '⊘';
    case 'Quarantine': return '⛔';
    case 'HumanReview': return '👤';
    default: return '?';
  }
}
