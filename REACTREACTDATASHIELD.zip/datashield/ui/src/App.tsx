import { useEffect, useState } from 'react';
import { Routes, Route, NavLink, Navigate } from 'react-router-dom';
import {
  Shield, FileText, History, CheckSquare, BarChart3,
} from 'lucide-react';
import ClassifyPage from './pages/ClassifyPage';
import HistoryPage from './pages/HistoryPage';
import ApprovalsPage from './pages/ApprovalsPage';
import MetricsPage from './pages/MetricsPage';
import { api } from './lib/api';

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}

const NAV: NavItem[] = [
  { to: '/classify', label: 'Classify', icon: FileText, description: 'Single, multi, batch upload' },
  { to: '/history', label: 'History', icon: History, description: 'Audit trail & corrections' },
  { to: '/approvals', label: 'Approvals', icon: CheckSquare, description: 'Legal + DataGov sign-off' },
  { to: '/metrics', label: 'Metrics & MLOps', icon: BarChart3, description: 'KPIs and compliance' },
];

export default function App() {
  const [apiOnline, setApiOnline] = useState<boolean | null>(null);

  // Poll health every 5s
  useEffect(() => {
    const check = async () => {
      try {
        await api.health();
        setApiOnline(true);
      } catch {
        setApiOnline(false);
      }
    };
    check();
    const id = setInterval(check, 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-72 bg-slate-900 text-slate-100 flex flex-col">
        <div className="px-6 py-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-brand-600 flex items-center justify-center">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <div className="text-lg font-bold tracking-tight">DataShield</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-start gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  isActive ? 'bg-brand-600 text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`
              }
            >
              <item.icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <div className="font-medium">{item.label}</div>
                <div className="text-xs opacity-70 mt-0.5">{item.description}</div>
              </div>
            </NavLink>
          ))}
        </nav>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-x-auto">
        {apiOnline === false && (
          <div className="bg-rose-50 border-b border-rose-200 text-rose-800 px-6 py-3 text-sm">
            <strong>API offline.</strong> Start the backend with <code className="px-1.5 py-0.5 bg-rose-100 rounded font-mono">python api.py</code> or <code className="px-1.5 py-0.5 bg-rose-100 rounded font-mono">python run.py</code>.
          </div>
        )}
        <div className="px-8 py-6 max-w-screen-2xl">
          <Routes>
            <Route path="/" element={<Navigate to="/classify" replace />} />
            <Route path="/classify" element={<ClassifyPage />} />
            <Route path="/history" element={<HistoryPage />} />
            <Route path="/approvals" element={<ApprovalsPage />} />
            <Route path="/metrics" element={<MetricsPage />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}
