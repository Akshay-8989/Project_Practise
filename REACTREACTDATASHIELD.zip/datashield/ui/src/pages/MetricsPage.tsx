import { useEffect, useState } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Cell } from 'recharts';
import { PageHeader, Card, KpiCard, SectionTitle, Spinner } from '../components/UI';
import { api } from '../lib/api';

const LABEL_COLORS: Record<string, string> = {
  Public: '#10b981', Internal: '#3b82f6', Confidential: '#f59e0b', Restricted: '#ef4444',
};

export default function MetricsPage() {
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const m = await api.metrics();
      setMetrics(m);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  if (loading || !metrics) {
    return (
      <div>
        <PageHeader title="Metrics & MLOps" />
        <Card><div className="flex items-center justify-center py-8"><Spinner className="w-8 h-8" /></div></Card>
      </div>
    );
  }

  const overrideRate = metrics.human_override_rate;
  const compliant = metrics.override_rate_compliant;
  const dist = metrics.label_distribution || {};
  const distData = Object.entries(dist).map(([k, v]) => ({ name: k, value: v as number }));

  return (
    <div>
      <PageHeader
        title="Metrics & MLOps"
        subtitle="Live key performance indicators across classifications, overrides, and label distribution."
        action={
          <button onClick={load} className="btn-secondary">
            <RefreshCw className="w-4 h-4" /> Refresh
          </button>
        }
      />

      {/* KPI cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <KpiCard label="Total Classified" value={metrics.total_classified} />
        <KpiCard label="Avg Confidence" value={`${(metrics.avg_confidence * 100).toFixed(1)}%`} />
        <KpiCard
          label="Override Rate"
          value={`${overrideRate.toFixed(2)}%`}
          delta={compliant ? 'Within 5% target' : 'KPI BREACH'}
          deltaTone={compliant ? 'good' : 'bad'}
        />
        <KpiCard label="Corrections" value={metrics.total_overrides} />
      </div>

      {/* Override rate alert */}
      {!compliant && (
        <Card className="mb-6 !border-rose-200 !bg-rose-50">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-rose-900">Override KPI Breach</div>
              <div className="text-sm text-rose-700 mt-1">
                Human override rate exceeds the 5% threshold. Investigate recent corrections on the History page.
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Label distribution */}
      <Card className="mb-6">
        <SectionTitle>Label Distribution</SectionTitle>
        {distData.length > 0 ? (
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={distData}>
                <XAxis dataKey="name" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: '1px solid #e2e8f0' }} />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {distData.map(d => <Cell key={d.name} fill={LABEL_COLORS[d.name] || '#6b7280'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="text-sm text-slate-500 py-8 text-center">No classifications yet.</div>
        )}
      </Card>
    </div>
  );
}
