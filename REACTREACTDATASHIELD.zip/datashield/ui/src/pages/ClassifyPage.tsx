import { useState } from 'react';
import { Upload, FileText, Zap, Sparkles, X } from 'lucide-react';
import { PageHeader, Card, SectionTitle, Spinner } from '../components/UI';
import ResultCard from '../components/ResultCard';
import { api, ClassifyResponse } from '../lib/api';

type Mode = 'upload' | 'paste' | 'batch';

const SAMPLES: Record<string, string> = {
  Public: 'Our Q1 product roadmap is published on the company website and open to all stakeholders. View it at https://example.com/roadmap.',
  Internal: 'All employees: please join the all-hands meeting Tuesday at 3pm in Conference Room A. Agenda attached.',
  Confidential: 'Employee ID 10293 — salary band L5 ($142,000). Performance review scheduled with HR next week.',
  Restricted: 'Customer SSN 123-45-6789, credit card 4111-1111-1111-1111 on file. GDPR data subject access request pending.',
};

const SOURCES = ['', 'JIRA', 'ServiceNow', 'Confluence', 'Workday', 'Salesforce', 'Gmail', 'SharePoint'];
const DEPTS = ['', 'Engineering', 'HR', 'Finance', 'Legal', 'Sales', 'Marketing', 'Operations'];

export default function ClassifyPage() {
  const [mode, setMode] = useState<Mode>('upload');

  return (
    <div>
      <PageHeader
        title="Classify Documents"
        subtitle="Upload one or many documents in any format, paste text, or submit asynchronously."
      />

      {/* Mode tabs */}
      <div className="flex items-center gap-2 mb-6 border-b border-slate-200">
        <TabButton active={mode === 'upload'} onClick={() => setMode('upload')} icon={Upload}>Upload Files</TabButton>
        <TabButton active={mode === 'paste'} onClick={() => setMode('paste')} icon={FileText}>Paste Text</TabButton>
        <TabButton active={mode === 'batch'} onClick={() => setMode('batch')} icon={Zap}>Async Batch</TabButton>
      </div>

      {mode === 'upload' && <UploadMode />}
      {mode === 'paste' && <PasteMode />}
      {mode === 'batch' && <BatchMode />}
    </div>
  );
}

function TabButton({ active, onClick, icon: Icon, children }: { active: boolean; onClick: () => void; icon: any; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2.5 -mb-px text-sm font-medium border-b-2 transition-colors ${
        active ? 'border-brand-600 text-brand-700' : 'border-transparent text-slate-600 hover:text-slate-900'
      }`}
    >
      <Icon className="w-4 h-4" />
      {children}
    </button>
  );
}

// ──────────────────────────────────────────────────────────
// Upload mode (single + multi file)
// ──────────────────────────────────────────────────────────
function UploadMode() {
  const [files, setFiles] = useState<File[]>([]);
  const [docId, setDocId] = useState('');
  const [source, setSource] = useState('');
  const [dept, setDept] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ClassifyResponse[]>([]);
  const [errors, setErrors] = useState<string[]>([]);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files);
    setFiles(prev => [...prev, ...dropped]);
  };

  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) setFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    e.target.value = '';
  };

  const remove = (i: number) => setFiles(files.filter((_, idx) => idx !== i));

  const classify = async () => {
    if (!files.length) return;
    setLoading(true);
    setResults([]);
    setErrors([]);
    const out: ClassifyResponse[] = [];
    const errs: string[] = [];
    for (const f of files) {
      try {
        const opts: any = { source_system: source || undefined, department: dept || undefined };
        if (files.length === 1 && docId) opts.doc_id = docId;
        const r = await api.classifyFile(f, opts);
        out.push(r);
      } catch (e: any) {
        errs.push(`${f.name}: ${e.message}`);
      }
    }
    setResults(out);
    setErrors(errs);
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <Card>
        <SectionTitle>Upload Documents</SectionTitle>

        {/* Drop zone */}
        <div
          onDragOver={e => e.preventDefault()}
          onDrop={onDrop}
          className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center bg-slate-50/50 hover:bg-slate-50 transition-colors"
        >
          <Upload className="w-10 h-10 mx-auto text-slate-400 mb-2" />
          <div className="text-sm text-slate-700 mb-2 font-medium">Drag files here, or pick from your computer</div>
          <div className="text-xs text-slate-500 mb-4">Supported: PDF · DOCX · TXT · CSV · JSON · HTML · MD · LOG</div>
          <label className="btn-secondary cursor-pointer">
            Browse files
            <input
              type="file"
              multiple
              className="hidden"
              accept=".pdf,.docx,.txt,.csv,.json,.jsonl,.md,.html,.htm,.log"
              onChange={onPick}
            />
          </label>
        </div>

        {/* File list */}
        {files.length > 0 && (
          <div className="mt-4 space-y-2">
            <div className="text-xs font-semibold text-slate-600 uppercase tracking-wide">{files.length} file(s) staged</div>
            {files.map((f, i) => (
              <div key={i} className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                <div className="flex items-center gap-2 min-w-0">
                  <FileText className="w-4 h-4 text-slate-500 flex-shrink-0" />
                  <span className="text-sm font-mono truncate">{f.name}</span>
                  <span className="text-xs text-slate-500 flex-shrink-0">{(f.size / 1024).toFixed(1)} KB</span>
                </div>
                <button onClick={() => remove(i)} className="text-slate-400 hover:text-rose-600">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Metadata */}
        <div className="grid grid-cols-3 gap-4 mt-5">
          <div>
            <label className="label-text">Custom Doc ID (single file only)</label>
            <input className="input" placeholder="e.g. TICKET-2025-001" value={docId} onChange={e => setDocId(e.target.value)} disabled={files.length > 1} />
          </div>
          <div>
            <label className="label-text">Source System</label>
            <select className="input" value={source} onChange={e => setSource(e.target.value)}>
              {SOURCES.map(s => <option key={s} value={s}>{s || '— optional —'}</option>)}
            </select>
          </div>
          <div>
            <label className="label-text">Department</label>
            <select className="input" value={dept} onChange={e => setDept(e.target.value)}>
              {DEPTS.map(s => <option key={s} value={s}>{s || '— optional —'}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-5 flex justify-end">
          <button onClick={classify} disabled={loading || !files.length} className="btn-primary">
            {loading ? <Spinner /> : <Sparkles className="w-4 h-4" />}
            Classify {files.length > 1 ? `All (${files.length})` : 'Document'}
          </button>
        </div>
      </Card>

      {errors.length > 0 && (
        <Card className="border-rose-200 bg-rose-50">
          <div className="font-semibold text-rose-800 mb-2">Errors</div>
          {errors.map((e, i) => <div key={i} className="text-sm text-rose-700">{e}</div>)}
        </Card>
      )}

      {results.length > 0 && (
        <div className="space-y-4">
          <div className="text-sm font-semibold text-slate-700">
            {results.length} classification result(s)
          </div>
          {results.map((r, i) => <ResultCard key={i} result={r} />)}
        </div>
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────
// Paste mode
// ──────────────────────────────────────────────────────────
function PasteMode() {
  const [text, setText] = useState('');
  const [docId, setDocId] = useState('');
  const [source, setSource] = useState('');
  const [dept, setDept] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ClassifyResponse | null>(null);

  const classify = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const r = await api.classifyText(text, {
        doc_id: docId || undefined,
        source_system: source || undefined,
        department: dept || undefined,
      });
      setResult(r);
    } catch (e: any) {
      alert('Classify failed: ' + e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <SectionTitle>Paste Text</SectionTitle>

        <div className="grid grid-cols-[2fr_1fr] gap-4">
          <div>
            <label className="label-text">Document content</label>
            <textarea
              className="input font-mono text-sm"
              rows={10}
              value={text}
              onChange={e => setText(e.target.value)}
              placeholder="Paste an email, ticket, contract, HR note…"
            />
          </div>
          <div className="space-y-3">
            <div>
              <label className="label-text">Doc ID</label>
              <input className="input" placeholder="e.g. TICKET-001" value={docId} onChange={e => setDocId(e.target.value)} />
            </div>
            <div>
              <label className="label-text">Source</label>
              <select className="input" value={source} onChange={e => setSource(e.target.value)}>
                {SOURCES.map(s => <option key={s} value={s}>{s || '— optional —'}</option>)}
              </select>
            </div>
            <div>
              <label className="label-text">Department</label>
              <select className="input" value={dept} onChange={e => setDept(e.target.value)}>
                {DEPTS.map(s => <option key={s} value={s}>{s || '— optional —'}</option>)}
              </select>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <div className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-2">Try a sample:</div>
          <div className="flex flex-wrap gap-2">
            {Object.entries(SAMPLES).map(([label, txt]) => (
              <button
                key={label}
                onClick={() => setText(txt)}
                className="text-xs px-3 py-1.5 border border-slate-300 rounded-lg hover:bg-slate-50 font-medium"
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-5 flex justify-end">
          <button onClick={classify} disabled={loading || !text.trim()} className="btn-primary">
            {loading ? <Spinner /> : <Sparkles className="w-4 h-4" />}
            Classify
          </button>
        </div>
      </Card>

      {result && <ResultCard result={result} />}
    </div>
  );
}

// ──────────────────────────────────────────────────────────
// Async batch mode
// ──────────────────────────────────────────────────────────
function BatchMode() {
  const [files, setFiles] = useState<File[]>([]);
  const [jobId, setJobId] = useState<string | null>(null);
  const [status, setStatus] = useState<any>(null);
  const [polling, setPolling] = useState(false);

  const submit = async () => {
    if (!files.length) return;
    try {
      const r = await api.classifyBatch(files);
      setJobId(r.job_id);
      setStatus(null);
    } catch (e: any) {
      alert('Submit failed: ' + e.message);
    }
  };

  const refresh = async () => {
    if (!jobId) return;
    setPolling(true);
    try {
      const s = await api.jobStatus(jobId);
      setStatus(s);
    } catch (e: any) {
      alert('Poll failed: ' + e.message);
    } finally {
      setPolling(false);
    }
  };

  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) setFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    e.target.value = '';
  };
  const remove = (i: number) => setFiles(files.filter((_, idx) => idx !== i));

  return (
    <div className="space-y-6">
      <Card>
        <SectionTitle>Async Batch Processing</SectionTitle>
        <p className="text-sm text-slate-600 mb-4">
          Submit many files for non-blocking processing. Decouples bulk ingestion from real-time API (PS-01 throughput requirement).
        </p>

        <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center bg-slate-50/50">
          <label className="btn-secondary cursor-pointer">
            Add files
            <input
              type="file"
              multiple
              className="hidden"
              accept=".pdf,.docx,.txt,.csv,.json,.md,.html"
              onChange={onPick}
            />
          </label>
          <div className="text-xs text-slate-500 mt-2">{files.length} file(s) staged</div>
        </div>

        {files.length > 0 && (
          <div className="mt-4 grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
            {files.map((f, i) => (
              <div key={i} className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded px-2 py-1.5 text-xs">
                <span className="truncate">{f.name}</span>
                <button onClick={() => remove(i)} className="text-slate-400 hover:text-rose-600"><X className="w-3 h-3" /></button>
              </div>
            ))}
          </div>
        )}

        <div className="mt-5 flex justify-end">
          <button onClick={submit} disabled={!files.length} className="btn-primary">
            <Zap className="w-4 h-4" /> Submit Batch
          </button>
        </div>
      </Card>

      {jobId && (
        <Card>
          <div className="flex items-center justify-between mb-3">
            <SectionTitle>Job Status</SectionTitle>
            <button onClick={refresh} disabled={polling} className="btn-secondary text-xs">
              {polling ? <Spinner /> : null} Refresh
            </button>
          </div>
          <div className="text-xs font-mono text-slate-600 mb-3">Job ID: {jobId}</div>

          {status && (
            <>
              <div className="flex items-center gap-3 mb-3">
                <span className={`pill ${status.status === 'completed' ? 'label-public' : 'label-internal'}`}>
                  {status.status}
                </span>
                <span className="text-sm text-slate-700">
                  {status.progress?.completed || 0} / {status.progress?.total || 0}
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2 mb-4">
                <div
                  className="bg-brand-500 h-2 rounded-full transition-all"
                  style={{ width: `${((status.progress?.completed || 0) / Math.max(status.progress?.total || 1, 1)) * 100}%` }}
                />
              </div>

              {status.results?.length > 0 && (
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-600">
                      <tr>
                        <th className="px-3 py-2 text-left">File</th>
                        <th className="px-3 py-2 text-left">Doc ID</th>
                        <th className="px-3 py-2 text-left">Label</th>
                        <th className="px-3 py-2 text-left">Confidence</th>
                        <th className="px-3 py-2 text-left">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {status.results.map((r: any, i: number) => (
                        <tr key={i}>
                          <td className="px-3 py-2 font-mono text-xs">{r.source_file || '—'}</td>
                          <td className="px-3 py-2 font-mono text-xs">{r.doc_id?.slice(0, 16) || '—'}</td>
                          <td className="px-3 py-2"><span className={`pill ${r.label ? `label-${r.label.toLowerCase()}` : ''}`}>{r.label || 'error'}</span></td>
                          <td className="px-3 py-2 text-xs">{r.confidence ? `${(r.confidence * 100).toFixed(1)}%` : '—'}</td>
                          <td className="px-3 py-2 text-xs">{r.policy_action || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </Card>
      )}
    </div>
  );
}
