import { labelClass, actionClass, actionIcon } from '../lib/api';

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h1>
        {subtitle && <p className="text-sm text-slate-600 mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`card p-5 ${className}`}>{children}</div>;
}

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="text-base font-semibold text-slate-900 mb-3">{children}</h2>;
}

export function LabelBadge({ label }: { label: string | undefined }) {
  return <span className={`pill ${labelClass(label)}`}>{label || '—'}</span>;
}

export function ActionBadge({ action }: { action: string | undefined }) {
  return (
    <span className={`pill ${actionClass(action)}`}>
      <span className="mr-1">{actionIcon(action)}</span>
      {action || '—'}
    </span>
  );
}

export function KpiCard({ label, value, delta, deltaTone }: {
  label: string;
  value: React.ReactNode;
  delta?: string;
  deltaTone?: 'good' | 'bad' | 'neutral';
}) {
  const tone = deltaTone === 'good' ? 'text-emerald-600' : deltaTone === 'bad' ? 'text-rose-600' : 'text-slate-500';
  return (
    <div className="card p-5">
      <div className="text-xs font-medium text-slate-500 uppercase tracking-wide">{label}</div>
      <div className="text-3xl font-bold text-slate-900 mt-2">{value}</div>
      {delta && <div className={`text-xs mt-1 font-medium ${tone}`}>{delta}</div>}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, hint }: { icon: React.ComponentType<{ className?: string }>; title: string; hint?: string }) {
  return (
    <div className="text-center py-16 text-slate-500">
      <Icon className="w-12 h-12 mx-auto text-slate-300 mb-3" />
      <div className="font-medium text-slate-700">{title}</div>
      {hint && <div className="text-sm mt-1">{hint}</div>}
    </div>
  );
}

export function Spinner({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={`animate-spin ${className}`} fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.4 0 0 5.4 0 12h4zm2 5.3A8 8 0 014 12H0c0 3 1.1 5.8 3 7.9l3-2.6z" />
    </svg>
  );
}
