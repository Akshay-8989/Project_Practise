# 🔐 DataShield — PS-01 Sensitivity Classification Engine

**Enterprise-grade prototype** for automated data-sensitivity classification.
Per **PS-01** (Opus Technologies, Team #01: Akshay / Aditi / Shikha).
Runs entirely on a laptop — no Kafka, no Docker, no S3, no cloud calls.

> Classifies any unstructured document into one of **Public / Internal /
> Confidential / Restricted**, returns confidence + evidence + policy
> action, masks PII before audit, logs everything, exposes a
> human-in-the-loop correction path, and explicitly answers every
> MECE-gap question from the mentor review.

---

## ⚡ Quick start

**Prerequisites:** Python 3.10+ and Node.js 18+ (for the React UI).

```bash
# 1. Install Python deps
pip install -r requirements.txt

# 2. Start both API + UI with one command (auto-installs UI deps on first run)
python run.py
```

Then open: **http://localhost:8501** (React UI)
API docs: **http://localhost:8000/docs** (Swagger UI)

To stop: `Ctrl+C` in the terminal.

> **PyCharm users**: open the project folder, right-click `run.py`, choose
> *Run 'run'*. On first run it auto-installs UI dependencies (`npm install`
> inside `ui/`). Subsequent runs are instant.

> **No Node.js?** `run.py` falls back to serving the prebuilt static
> `ui/dist/` via Python's http.server. The bundled zip includes the
> built dist, so the UI works even without Node.

---

## 🖥️ Tech stack

| Layer | Technology |
|------|------|
| Backend | FastAPI + Uvicorn (Python) |
| Frontend | React 18 + TypeScript + Vite + Tailwind CSS + Recharts + Lucide icons |
| ML models | scikit-learn (Logistic Regression) + XGBoost + optional DistilBERT |
| Explainability | SHAP + LIME + Integrated Gradients |
| PII masking | Presidio (primary) + regex (defensive fallback) |
| Config | YAML (editable by Legal + Data Governance) |
| Audit log | Append-only JSONL (Filebeat-friendly) |
| MLOps | MLflow + custom PSI drift + active-learning loop |

The UI is a real React SPA. Vite dev server runs on port 8501 and proxies
`/api/*` to the FastAPI backend on port 8000. In production you'd build
once (`npm run build`) and serve `ui/dist/` behind nginx with the API on
the same host.

---

## 🏛️ Architecture

The system implements all 8 PS-01 layers:

```
┌──────────────────────────────────────────────────────────────┐
│ 1. INGESTION         ingestion.py                            │
│    pdfplumber + python-docx + json/csv/html parsers          │
├──────────────────────────────────────────────────────────────┤
│ 2. PRE-PROCESSING    preprocessing.py + utils/               │
│    Unicode NFKC → boilerplate strip → language detect →      │
│    Presidio + regex PII masking → tokenize → chunk → enrich  │
├──────────────────────────────────────────────────────────────┤
│ 3. FEATURE ENGINEERING   feature_engineering.py              │
│    TF-IDF (1-2 grams) + n-gram counts + numeric features +   │
│    optional transformer embedding hook                       │
├──────────────────────────────────────────────────────────────┤
│ 4. CLASSIFICATION    models/ + ensemble/                     │
│    Logistic Regression (baseline) + XGBoost +                │
│    optional DistilBERT → Stacking meta-learner               │
├──────────────────────────────────────────────────────────────┤
│ 5. EXPLAINABILITY    explainability/                         │
│    SHAP (XGB) + LIME (LR) + IG (Transformer)                 │
│    Every prediction returns ≥ 3 evidence tokens              │
├──────────────────────────────────────────────────────────────┤
│ 6. POLICY ENGINE     policy_engine/                          │
│    8 PII regex rules (SSN with Luhn-validated card, IBAN,    │
│    PAN, Aadhaar, email, phone, DOB) — override to Restricted │
│    on match. Dual-approval gate (Legal + DataGov).           │
├──────────────────────────────────────────────────────────────┤
│ 7. OUTPUT / API      api.py (FastAPI)                        │
│    REST endpoints + outbound webhooks (HMAC-signed)          │
├──────────────────────────────────────────────────────────────┤
│ 8. MLOPS             mlops.py + active_learning.py           │
│    Model registry + drift detection + active-learning loop   │
│    + automated retraining trigger                            │
└──────────────────────────────────────────────────────────────┘
           ↓
       UI: React + TypeScript SPA (5 pages)
```

---

## 🎨 The React UI

Four pages in the sidebar:

| Page | What it does |
|------|---|
| **📄 Classify** | Three modes: File Upload (single + multi, drag-and-drop, custom Doc ID, source/department tagging), Paste Text (with one-click sample buttons), Async Batch (submit many, poll job progress). Inline result card with label, confidence, action, evidence tokens, probabilities bar chart, and HITL form. Click **View Insights** for a detailed, business-readable modal showing document overview, content statistics, sensitive-data findings, top keywords, per-class confidence bars, latency breakdown, and the full policy engine trace (JSON). |
| **📜 History** | Master-detail layout. List on the left (filter by label or override-only), detail on the right. Drill into any document to see masked snippet, probabilities chart, policy trace, override history, approval signatures, and submit a retrospective correction. |
| **✅ Approvals** | Constraint C4 dual-approval queue. Confidential needs Legal; Restricted needs Legal + DataGov. Inline sign-off with role selector and notes. Gate status pill updates live. |
| **📊 Metrics & MLOps** | KPI cards (Total / Avg Confidence / Override Rate vs 5% target / Corrections), label distribution bar chart, and a live system compliance checklist. |

---

## 🛡️ Mentor MECE-gap coverage

Every question from the mentor's review diagrams is addressed in code. Quick summary:

**Decision Intelligence Gap**
- Class imbalance handled (LR `class_weight=balanced` + policy override safety net)
- Policy actions correctly triggered (`_label_to_action` + verified in history)
- Policy decisions logged with reasoning (`policy_trace` in every audit line, visible via View Insights)
- Training data dual-approved (Constraint C4 — `/approval/sign-off`)

**Input Acquisition Gap**
- REST connectors live (Kafka/S3 are pluggable, scoped out per laptop-first)
- Real-time ingestion meets the 200 ms p95 SLA (~70 ms warm)
- PII detected before classification (8 regex patterns + Presidio NER)
- PII masked before storage (two-layer defence, C1 compliant)
- Every masking action logged (`preprocessing.pii_entities` in response)
- Metadata used as classification signal (XGBoost gets 6 one-hot features)

**Operationalization Gap**
- Batch decoupled from real-time (`/classify/batch` BackgroundTasks)
- Model registry available (`mlops.py` · `/mlops/registry` endpoint)
- mTLS path documented (uvicorn `--ssl-keyfile/--ssl-certfile`)
- Webhooks signed (HMAC SHA-256 via `X-DataShield-Signature` header)

**Governance & Auditability Gap**
- Every prediction logged with timestamp + model version (`audit.jsonl`)
- Log format aligned with PCI DSS / GDPR (append-only JSONL, PII-masked)
- SHAP for trees, LIME for linear, IG for transformer (3 explainers wired)
- Auditors can replay any decision (full policy_trace + masked input)

---

## 🔌 API quick reference

Full Swagger UI: **http://localhost:8000/docs**

```bash
# Classify text
curl -X POST http://localhost:8000/classify \
  -H "Content-Type: application/json" \
  -d '{"text":"Customer SSN 123-45-6789","doc_id":"TICKET-001"}'

# Classify a file
curl -X POST http://localhost:8000/classify/file \
  -F "file=@./contract.pdf" \
  -F "doc_id=CONTRACT-99" \
  -F "department=Legal"

# Async batch
curl -X POST http://localhost:8000/classify/batch \
  -F "files=@doc1.txt" -F "files=@doc2.pdf"
# → {"job_id":"...", "status":"queued"}
curl http://localhost:8000/classify/status/{job_id}

# History
curl "http://localhost:8000/history?limit=50&label=Restricted"

# Human-in-the-loop override
curl -X POST http://localhost:8000/override \
  -H "Content-Type: application/json" \
  -d '{"doc_id":"TICKET-001","original_label":"Restricted",
       "corrected_label":"Confidential","reviewer":"alice@legal","reason":"…"}'

# Dual-approval sign-off (C4)
curl -X POST http://localhost:8000/approval/sign-off \
  -H "Content-Type: application/json" \
  -d '{"doc_id":"TICKET-001","approver":"Legal","decision":"approved"}'

# Webhook subscription
curl -X POST http://localhost:8000/webhooks \
  -H "Content-Type: application/json" \
  -d '{"url":"https://dlp.example.com/events",
       "events":["classification.completed"],
       "secret":"my-hmac-secret"}'

# MLOps — retraining trigger recommendation
curl http://localhost:8000/mlops/retraining
```

---

## 🎯 PS-01 evaluation criteria

| Metric | Target | Status |
|--------|--------|--------|
| Precision (Confidential) | ≥ 0.90 | ✅ 0.93 |
| Precision (Restricted)   | ≥ 0.95 | ✅ 0.96 (policy regex → ceiling) |
| Recall (Restricted)      | ≥ 0.97 | ✅ 0.98 (policy override safety net) |
| F1-Macro                 | ≥ 0.88 | ✅ 0.89 |
| Latency p95              | < 200 ms | ✅ ~70 ms warm |
| Evidence ≥ 3 tokens      | 100 % | ✅ Pipeline guarantees, padded from SHAP / LIME / policy |
| Override rate KPI        | < 5 % | ✅ Live-tracked on Metrics page |

Re-run the evaluator: `python scripts/evaluate_compliance.py`.

---

## 🔒 Constraints satisfied

| | Constraint | How |
|---|---|---|
| **C1** | No raw PII persisted | Two-layer masking — Presidio at preprocessing + regex at every audit-log write |
| **C2** | Auditable models | LR + XGBoost interpretable; SHAP + LIME + IG every prediction; full policy trace logged |
| **C3** | On-prem / air-gapped | Zero cloud calls at inference; all artifacts bundled; SQLite for MLflow |
| **C4** | Dual approval for Restricted | `/approval/sign-off` + Approvals UI page; never auto-trains |
| **C5** | mTLS for payments clients | uvicorn `--ssl-keyfile` / `--ssl-certfile` (out of scope for local demo, drop-in for prod) |

---

## 📁 Project structure

```
datashield/
├── api.py                    ← FastAPI service (port 8000)
├── run.py                    ← Launcher (starts API + React UI)
├── requirements.txt
├── README.md
│
├── ingestion.py              ← Layer 1 — file format parsers
├── preprocessing.py          ← Layer 2 — clean / mask / tokenize / chunk
├── feature_engineering.py    ← Layer 3 — TF-IDF + n-grams + embedding hook
├── pipeline.py               ← Layers 4–6 orchestration
├── webhooks.py               ← Layer 7 — DLP / CASB outbound (HMAC-signed)
├── active_learning.py        ← Layer 8 — HITL feedback → retraining trigger
├── mlops.py                  ← Layer 8 — model registry + drift
│
├── models/                   ← LR / XGBoost / Transformer
├── ensemble/                 ← Voting + Stacking meta-learner
├── explainability/           ← SHAP / LIME / IG
├── policy_engine/            ← Rules + dual approval (C4)
├── utils/                    ← audit_logger, pii_masker, presidio_masker, lang_detector
│
├── ui/                       ← React + TypeScript + Vite + Tailwind
│   ├── src/
│   │   ├── App.tsx           ← Layout + routing
│   │   ├── pages/            ← Classify / History / Approvals / Metrics
│   │   ├── components/       ← UI primitives + ResultCard
│   │   └── lib/api.ts        ← API client
│   ├── dist/                 ← Prebuilt static (fallback if no Node)
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   └── tsconfig.json
│
├── configs/
│   ├── model.yaml            ← Hyperparameters
│   └── policy.yaml           ← Editable by Legal + DataGov
│
├── artifacts/                ← Pre-trained model joblib files (en + hi)
├── data/                     ← Synthetic dataset + sample docs
├── scripts/                  ← train_all / evaluate_compliance / benchmark_latency
├── tests/                    ← pytest suite (92 tests)
└── logs/                     ← Runtime: audit.jsonl, overrides.jsonl, …
```

---

## 🛠️ Common tasks

| Task | Command |
|---|---|
| Install Python deps | `pip install -r requirements.txt` |
| Install UI deps (manual) | `cd ui && npm install` |
| Start everything | `python run.py` |
| Start API only | `python api.py` |
| Start UI only (dev) | `cd ui && npm run dev -- --port 8501` |
| Build UI for production | `cd ui && npm run build` |
| Train models from scratch | `python scripts/train_all.py` |
| Evaluate against PS-01 | `python scripts/evaluate_compliance.py` |
| Run test suite | `pytest tests/ -q` |
| Reset audit log | `rm -rf logs/*.jsonl logs/*.json` |

---

## ❓ Troubleshooting

**“API offline” banner shown.** Start the API first (`python api.py`) or run `python run.py`.

**First classify is slow (~3 s).** That's the pipeline loading joblib artifacts. Every subsequent call is < 100 ms.

**UI shows nothing / blank page.** Check the terminal — `npm install` may still be running on first launch. Subsequent runs are instant.

**Vite says “port in use”.** Kill the existing process or change `UI_PORT` in `run.py`.

**Node.js not installed.** `run.py` falls back to serving `ui/dist/` via Python. The bundled zip already contains a built dist, so the UI works without Node. To rebuild, install Node 18+ and run `cd ui && npm run build`.

---

*Built for PS-01 — Data Governance & Privacy Engineering. © Team #01.*
