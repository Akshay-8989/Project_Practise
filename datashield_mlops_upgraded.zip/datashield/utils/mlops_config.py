"""
utils/mlops_config.py
---------------------
Tiny, cached loader for the centralized MLOps config (configs/mlops.yaml).

Why a module instead of inlining yaml.safe_load everywhere:
  - one cached read per process
  - normalizes paths (so callers don't need to know about PROJECT_DIR)
  - graceful default if the file is missing (every key has a sensible
    fallback so older deployments keep working)

Public API:
    cfg = get_mlops_config()         # full dict
    cfg.drift.thresholds.psi_alert   # dot access via the namespace wrapper
    resolve_path('logs/audit.jsonl') # absolute path inside the project

Used by: mlops.py, webhooks.py, utils/audit_logger.py (extended fields),
api.py (registry endpoint), pipeline.py (auto-load champion).
"""
from __future__ import annotations
import os
import threading
from types import SimpleNamespace
from typing import Any, Dict, Optional

import yaml

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_CONFIG_PATH = os.path.join(PROJECT_DIR, 'configs', 'mlops.yaml')

_LOCK = threading.Lock()
_CACHED_DICT: Optional[Dict[str, Any]] = None
_CACHED_NS: Optional[SimpleNamespace] = None

# Defaults used when configs/mlops.yaml is missing or partial.
# Keeping these in code (not just YAML) guarantees the system still
# runs in an air-gapped deployment that has never seen the file.
_DEFAULTS: Dict[str, Any] = {
    'versions': {
        'model': 'v3.0.0-bilingual',
        'preprocessing': 'v1.2.0',
        'feature': 'v1.1.0',
    },
    'mlflow': {
        'experiment_name': 'sensitivity_classification',
        'tracking_uri': None,
        'artifact_subdir': 'mlruns_artifacts',
        'log_confusion_matrix': True,
        'log_class_metrics': True,
        'log_dataset_version': True,
        'log_vectorizer_version': True,
    },
    'registry': {
        'path': 'logs/model_registry.json',
        'promote_metric': 'f1_macro',
        'promote_min_delta': 0.005,
        'auto_load_champion': True,
    },
    'drift': {
        'reports_dir': 'mlops/drift_reports',
        'reference_window': 50,
        'current_window': 20,
        'thresholds': {
            'psi_warn': 0.10,
            'psi_alert': 0.20,
            'psi_critical': 0.25,
            'performance_drop_pct': 0.03,
            'confidence_drop': 0.05,
        },
        'dimensions': {
            'feature_drift': True,
            'prediction_drift': True,
            'confidence_drift': True,
            'class_distribution_drift': True,
        },
    },
    'retraining': {
        'monthly_trigger_days': 30,
        'schedule_log': 'logs/retraining_history.jsonl',
        'schedule_state': 'logs/retraining_state.json',
        'enable_lightweight_scheduler': True,
        'human_approval_required': True,
    },
    'audit': {
        'path': 'logs/audit.jsonl',
        'explanations_path': 'logs/explanations.jsonl',
        'retention_days': 365,
        'include_evidence_tokens': True,
        'evidence_top_k': 5,
    },
    'confidence': {
        'low_confidence': 0.55,
        'high_confidence': 0.90,
    },
    'webhooks': {
        'enabled': False,
        'config_path': 'configs/webhooks.yaml',
        'delivery_log': 'logs/webhook_deliveries.jsonl',
        'dead_letter_path': 'logs/webhook_dead_letter.jsonl',
        'defaults': {
            'timeout_seconds': 5,
            'max_retries': 3,
            'retry_backoff_seconds': 2,
            'hmac_header': 'X-DataShield-Signature',
            'api_key_header': 'X-API-Key',
            'request_id_header': 'X-DataShield-Request-Id',
        },
        'delivery_strategy': 'thread',
        'policy_action_routing': {
            'ALLOW': [],
            'ENCRYPT': [],
            'RESTRICT': [],
            'QUARANTINE': [],
        },
    },
}


def _deep_merge(base: Dict[str, Any], overlay: Dict[str, Any]) -> Dict[str, Any]:
    """Recursive dict merge — overlay wins, but missing keys fall back to base."""
    out = dict(base)
    for k, v in (overlay or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _to_namespace(obj: Any) -> Any:
    """Recursively convert dicts to SimpleNamespace for dot-access ergonomics."""
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: _to_namespace(v) for k, v in obj.items()})
    if isinstance(obj, list):
        return [_to_namespace(x) for x in obj]
    return obj


def load_mlops_config(path: Optional[str] = None, force_reload: bool = False) -> Dict[str, Any]:
    """Load (and cache) the MLOps config as a plain dict."""
    global _CACHED_DICT, _CACHED_NS
    if _CACHED_DICT is not None and not force_reload:
        return _CACHED_DICT
    with _LOCK:
        if _CACHED_DICT is not None and not force_reload:
            return _CACHED_DICT
        cfg_path = path or DEFAULT_CONFIG_PATH
        overlay: Dict[str, Any] = {}
        if os.path.exists(cfg_path):
            try:
                with open(cfg_path, 'r', encoding='utf-8') as f:
                    overlay = yaml.safe_load(f) or {}
            except Exception as e:
                print(f'[mlops_config] WARN: could not parse {cfg_path}: {e} — using defaults.')
                overlay = {}
        merged = _deep_merge(_DEFAULTS, overlay)
        _CACHED_DICT = merged
        _CACHED_NS = _to_namespace(merged)
        return _CACHED_DICT


def get_mlops_config() -> SimpleNamespace:
    """Get the cached config as a SimpleNamespace (dot-access)."""
    if _CACHED_NS is None:
        load_mlops_config()
    return _CACHED_NS  # type: ignore[return-value]


def resolve_path(rel_or_abs: str) -> str:
    """Resolve a project-relative path to absolute under PROJECT_DIR."""
    if not rel_or_abs:
        return rel_or_abs
    if os.path.isabs(rel_or_abs):
        return rel_or_abs
    return os.path.join(PROJECT_DIR, rel_or_abs)


def get_versions() -> Dict[str, str]:
    """Convenience: return the three version strings recorded on each audit line."""
    cfg = load_mlops_config()
    v = cfg.get('versions', {})
    return {
        'model_version': v.get('model', 'unknown'),
        'preprocessing_version': v.get('preprocessing', 'unknown'),
        'feature_version': v.get('feature', 'unknown'),
    }
