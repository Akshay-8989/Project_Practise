"""
audit_logger.py
---------------
Writes one JSON line per prediction to logs/audit.jsonl.

Guarantees:
  - Input snippet is masked before write (compliance C1).
  - Keys are sorted for deterministic output (reproducibility for audit).
  - Every entry has a UTC ISO timestamp and a monotonic doc_id.
  - Log rotation is ops-team responsibility (we just append).

MLOps extensions (additive, backward compatible):
  - Stamps model_version, preprocessing_version, feature_version
    on every entry (configurable via configs/mlops.yaml → versions).
  - When configs/mlops.yaml says include_evidence_tokens: true (default),
    also persists top-k evidence tokens with weight + source to a
    sibling stream (logs/explanations.jsonl). Evidence is never written
    inline to audit.jsonl — that file is treated as a tamper-evident
    governance log and we keep it minimal. Explanations go to their own
    file so they can be rotated / archived on a different schedule.
  - Recorded canonical policy_action (ALLOW/ENCRYPT/RESTRICT/QUARANTINE)
    alongside the original policy_trace.
"""
import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from utils.pii_masker import safe_snippet


# Canonical policy action mapping. Mirrors webhooks._canonical_action so the
# audit log + webhook payload always agree on the action name.
_CANONICAL_ACTION = {
    'allow': 'ALLOW',
    'encrypt': 'ENCRYPT',
    'restrict': 'RESTRICT',
    'quarantine': 'QUARANTINE',
}


def _canonicalize_action(action: Optional[str]) -> str:
    if not action:
        return 'ALLOW'
    return _CANONICAL_ACTION.get(action.strip().lower(), 'RESTRICT')


class AuditLogger:
    def __init__(
        self,
        log_dir: str = 'logs',
        filename: str = 'audit.jsonl',
        explanations_filename: str = 'explanations.jsonl',
    ):
        os.makedirs(log_dir, exist_ok=True)
        self.path = os.path.join(log_dir, filename)
        self.explanations_path = os.path.join(log_dir, explanations_filename)

        # Lazy-load versions / config flags. We intentionally fall back
        # silently if utils/mlops_config or configs/mlops.yaml isn't there
        # so the older smoke tests still pass.
        self._versions: Dict[str, str] = {
            'model_version': 'unknown',
            'preprocessing_version': 'unknown',
            'feature_version': 'unknown',
        }
        self._persist_evidence = True
        self._evidence_top_k = 5
        try:
            from utils.mlops_config import get_versions, get_mlops_config
            self._versions.update(get_versions())
            cfg = get_mlops_config()
            self._persist_evidence = bool(cfg.audit.include_evidence_tokens)
            self._evidence_top_k = int(cfg.audit.evidence_top_k)
            # Allow centralized override of where the explanations stream lives
            if getattr(cfg.audit, 'explanations_path', None):
                proj = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                explan_rel = cfg.audit.explanations_path
                self.explanations_path = (
                    explan_rel if os.path.isabs(explan_rel)
                    else os.path.join(proj, explan_rel)
                )
                os.makedirs(os.path.dirname(self.explanations_path), exist_ok=True)
        except Exception:
            pass

    def log(self, input_text: str, prediction: Dict[str, Any], model_version: Optional[str] = None) -> str:
        """Writes one audit entry. Returns the doc_id.

        Backwards compatible: callers passing only model_version=... keep
        working. When not given, we use the version stamped in configs/mlops.yaml.
        """
        doc_id = prediction.get('doc_id') or str(uuid.uuid4())

        # ── Versions ──
        mv = model_version or self._versions.get('model_version', 'unknown')

        # ── Canonical policy action (matches webhook payload) ──
        policy_trace = prediction.get('policy_trace') or {}
        canonical_action = _canonicalize_action(policy_trace.get('action'))

        entry = {
            'doc_id': doc_id,
            'timestamp_utc': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),

            # Versioning (new) ----
            'model_version': mv,
            'preprocessing_version': self._versions.get('preprocessing_version', 'unknown'),
            'feature_version': self._versions.get('feature_version', 'unknown'),

            # Classification record ----
            'input_snippet_masked': safe_snippet(input_text, max_len=160),
            'label': prediction.get('label'),
            'confidence': prediction.get('confidence'),
            'class_probabilities': prediction.get('class_probabilities'),
            'policy_trace': policy_trace,
            'policy_action': canonical_action,
            'model_contributions': prediction.get('model_contributions'),
            'evidence_count': len(prediction.get('evidence', [])),
        }
        with open(self.path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry, sort_keys=True, ensure_ascii=False) + '\n')

        # ── Explainability persistence (new) ──
        # Streamed to a sibling file so audit.jsonl stays compact and
        # explanations can be rotated / archived on their own schedule.
        if self._persist_evidence:
            self._persist_explanation(doc_id, prediction, mv)

        return doc_id

    def _persist_explanation(self, doc_id: str, prediction: Dict[str, Any], model_version: str) -> None:
        """Write top-k evidence tokens + confidence summary for one prediction."""
        evidence = prediction.get('evidence') or []
        top = []
        for ev in evidence[: self._evidence_top_k]:
            top.append({
                'token': str(ev.get('token', ''))[:80],
                'weight': float(ev.get('weight', 0) or 0),
                'source': str(ev.get('source', 'unknown')),
            })

        confidence = prediction.get('confidence')
        try:
            confidence = float(confidence) if confidence is not None else None
        except Exception:
            confidence = None

        class_probs = prediction.get('class_probabilities') or {}
        explanation = {
            'doc_id': doc_id,
            'timestamp_utc': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            'model_version': model_version,
            'preprocessing_version': self._versions.get('preprocessing_version', 'unknown'),
            'feature_version': self._versions.get('feature_version', 'unknown'),
            'label': prediction.get('label'),
            'confidence': confidence,
            'class_probabilities': class_probs,
            'evidence_top_k': top,
            'confidence_explanation': self._build_confidence_explanation(confidence, class_probs),
        }
        with open(self.explanations_path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(explanation, sort_keys=True, ensure_ascii=False) + '\n')

    @staticmethod
    def _build_confidence_explanation(confidence: Optional[float], class_probs: Dict[str, Any]) -> Dict[str, Any]:
        """A small human-readable narrative on why this confidence is what it is."""
        if confidence is None:
            return {'narrative': 'confidence not available'}
        # Margin between top class and runner-up
        sorted_classes = sorted(
            ((k, float(v)) for k, v in class_probs.items()),
            key=lambda kv: -kv[1],
        )
        if len(sorted_classes) >= 2:
            margin = sorted_classes[0][1] - sorted_classes[1][1]
        else:
            margin = 1.0

        if confidence >= 0.90:
            level = 'high'
        elif confidence >= 0.65:
            level = 'medium'
        else:
            level = 'low'

        return {
            'level': level,
            'top_class': sorted_classes[0][0] if sorted_classes else None,
            'top_prob': sorted_classes[0][1] if sorted_classes else None,
            'runner_up_class': sorted_classes[1][0] if len(sorted_classes) > 1 else None,
            'runner_up_prob': sorted_classes[1][1] if len(sorted_classes) > 1 else None,
            'margin': round(margin, 4),
            'narrative': (
                f"{level.title()} confidence — winning class beat runner-up "
                f"by {margin:.2%}." if sorted_classes else f"{level} confidence"
            ),
        }
