"""
train_all.py
------------
Trains ONE MODEL SET PER LANGUAGE, including the DistilBERT transformer.

Input:  data/synthetic_dataset.csv (bilingual, has a `language` column)
Output: artifacts/
          en/
            logistic.joblib
            xgboost.joblib
            transformer.joblib     ← NEW (DistilBERT fine-tuned)
            stacker.joblib         ← NOW includes transformer OOF predictions
          hi/
            logistic.joblib
            xgboost.joblib
            transformer.joblib     ← NEW
            stacker.joblib         ← NOW includes transformer OOF predictions

For each language the process is identical — train LR + XGBoost on that
language's slice of the data, then (optionally) fine-tune the transformer,
generate OOF predictions and train a stacking meta-learner. Evaluation
metrics are printed per language so you can see which classes each
language model struggles with.

Transformer training:
  - Uses DistilBERT (distilbert-base-uncased) by default
  - Fine-tunes [CLS] pooling → dropout → linear head
  - Skipped automatically if torch/transformers not installed
  - Use --skip-transformer to force skip even when torch is available
  - OOF uses 3 folds (fewer than LR/XGB because transformer training is slow)

Usage:
    python -m scripts.train_all                    # full data (all models)
    python -m scripts.train_all --sample 500       # dev mode (fast)
    python -m scripts.train_all --skip-transformer # skip transformer
"""
import argparse
import os
import sys
import random
import time
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import yaml
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, precision_recall_fscore_support

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from models.logistic_model import LogisticModel
from models.xgboost_model import XGBoostModel
from ensemble.stacking import (
    StackingEnsemble,
    generate_oof_logistic,
    generate_oof_xgboost,
)

# MLOps experiment tracking (graceful fallback if mlops import fails)
try:
    import mlops as _mlops_module
    _MLOPS_AVAILABLE = True
except Exception as _e:
    _mlops_module = None
    _MLOPS_AVAILABLE = False

# Transformer + OOF: optional (graceful fallback if torch not installed)
try:
    from models.transformer_model import TORCH_AVAILABLE
    if TORCH_AVAILABLE:
        from models.transformer_model import TransformerModel
        from ensemble.stacking import generate_oof_transformer
    else:
        TransformerModel = None
except Exception:
    TORCH_AVAILABLE = False
    TransformerModel = None

SEED = 42
random.seed(SEED)
np.random.seed(SEED)


def _train_one_language(lang: str, df_lang: pd.DataFrame, cfg: dict,
                         artifacts_dir: str, test_size: float, sample: int = None,
                         skip_transformer: bool = False):
    print(f'\n{"="*60}\n[train:{lang}] training model set for language: {lang}\n{"="*60}')
    classes = cfg['classes']

    if sample:
        df_lang = df_lang.groupby('label', group_keys=False).apply(
            lambda g: g.sample(min(len(g), sample), random_state=SEED)
        ).reset_index(drop=True)
        print(f'[train:{lang}] subsampled to {len(df_lang)} rows')
    else:
        print(f'[train:{lang}] using all {len(df_lang)} rows')

    # Verify we have all 4 classes
    counts = df_lang['label'].value_counts()
    if len(counts) < 4:
        print(f'[train:{lang}] WARNING: only {len(counts)} classes present. Skipping.')
        return None

    texts = df_lang['text'].astype(str).tolist()
    labels = df_lang['label'].tolist()
    metadata = df_lang[['source_system', 'department', 'file_type', 'author']].to_dict('records')

    train_idx, test_idx = train_test_split(
        np.arange(len(texts)), test_size=test_size, random_state=SEED, stratify=labels,
    )

    def subset(idx):
        return [texts[i] for i in idx], [labels[i] for i in idx], [metadata[i] for i in idx]

    train_texts, train_labels, train_meta = subset(train_idx)
    test_texts, test_labels, test_meta = subset(test_idx)

    lang_dir = os.path.join(artifacts_dir, lang)
    os.makedirs(lang_dir, exist_ok=True)

    # Logistic Regression
    print(f'\n[train:{lang}] --- Logistic Regression ---')
    lr = LogisticModel(cfg['logistic'], classes)
    lr.fit(train_texts, train_labels)
    lr_preds = lr.predict(test_texts)
    print(classification_report(test_labels, lr_preds, digits=3, zero_division=0))
    lr.save(os.path.join(lang_dir, 'logistic.joblib'))

    # XGBoost
    print(f'\n[train:{lang}] --- XGBoost ---')
    xgbm = XGBoostModel(cfg['xgboost'], classes)
    xgbm.fit(train_texts, train_labels, train_meta)
    xgb_preds = xgbm.predict(test_texts, test_meta)
    print(classification_report(test_labels, xgb_preds, digits=3, zero_division=0))
    xgbm.save(os.path.join(lang_dir, 'xgboost.joblib'))

    # Transformer (DistilBERT)
    transformer = None
    transformer_preds = None
    if not skip_transformer and TORCH_AVAILABLE and TransformerModel is not None:
        print(f'\n[train:{lang}] --- DistilBERT Transformer ---')
        t0 = time.time()
        transformer_cfg = cfg.get('transformer', {})
        transformer = TransformerModel(transformer_cfg, classes)
        transformer.fit(train_texts, train_labels)
        transformer_preds = transformer.predict(test_texts)
        elapsed = time.time() - t0
        print(f'[train:{lang}] transformer trained in {elapsed:.1f}s')
        print(classification_report(test_labels, transformer_preds, digits=3, zero_division=0))
        transformer.save(os.path.join(lang_dir, 'transformer.joblib'))
    elif skip_transformer:
        print(f'\n[train:{lang}] --- Transformer SKIPPED (--skip-transformer) ---')
    else:
        print(f'\n[train:{lang}] --- Transformer SKIPPED (torch not installed) ---')
        print(f'[train:{lang}] To enable: pip install -r requirements-transformer.txt')

    # Stacker with OOF predictions from train set
    print(f'\n[train:{lang}] --- Stacking ---')
    print(f'[train:{lang}] generating OOF predictions...')
    n_folds = cfg['ensemble']['stacking']['cv_folds']
    oof_lr = generate_oof_logistic(LogisticModel, cfg['logistic'], classes,
                                   train_texts, train_labels, n_folds=n_folds)
    oof_xgb = generate_oof_xgboost(XGBoostModel, cfg['xgboost'], classes,
                                   train_texts, train_labels, train_meta, n_folds=n_folds)

    oof_dict = {'logistic': oof_lr, 'xgboost': oof_xgb}

    # Include transformer OOF if transformer was trained
    if transformer is not None:
        print(f'[train:{lang}] generating transformer OOF predictions (3 folds)...')
        t0 = time.time()
        oof_transformer = generate_oof_transformer(
            TransformerModel, cfg.get('transformer', {}), classes,
            train_texts, train_labels, n_folds=3,
        )
        oof_dict['transformer'] = oof_transformer
        elapsed = time.time() - t0
        print(f'[train:{lang}] transformer OOF done in {elapsed:.1f}s')

    label_to_idx = {c: i for i, c in enumerate(classes)}
    y_train_int = np.array([label_to_idx[l] for l in train_labels])

    stacker = StackingEnsemble(
        classes=classes,
        n_folds=n_folds,
        meta=cfg['ensemble']['stacking']['meta_learner'],
    )
    stacker.fit_meta(oof_dict, y_train_int)

    # Test stacker
    lr_test_probs = lr.predict_proba(test_texts)
    xgb_test_probs = xgbm.predict_proba(test_texts, test_meta)
    test_probs_dict = {'logistic': lr_test_probs, 'xgboost': xgb_test_probs}
    if transformer is not None:
        test_probs_dict['transformer'] = transformer.predict_proba(test_texts)

    stacker_probs = stacker.predict_proba(test_probs_dict)
    stacker_preds = [classes[i] for i in np.argmax(stacker_probs, axis=1)]
    print(classification_report(test_labels, stacker_preds, digits=3, zero_division=0))
    stacker.save(os.path.join(lang_dir, 'stacker.joblib'))

    # Summary
    def macro_f1(preds):
        _, _, f, _ = precision_recall_fscore_support(test_labels, preds, average='macro', zero_division=0)
        return f

    summary = {
        'lang': lang,
        'test_size': len(test_labels),
        'macro_f1_lr': macro_f1(lr_preds),
        'macro_f1_xgb': macro_f1(xgb_preds),
        'macro_f1_stacker': macro_f1(stacker_preds),
    }
    if transformer_preds is not None:
        summary['macro_f1_transformer'] = macro_f1(transformer_preds)

    # ── MLOps experiment tracking (MLflow if installed, JSONL otherwise) ──
    if _MLOPS_AVAILABLE and _mlops_module is not None:
        try:
            from sklearn.metrics import precision_recall_fscore_support, confusion_matrix
            # Per-class metrics for the final (stacker) prediction
            precision, recall, f1, _ = precision_recall_fscore_support(
                test_labels, stacker_preds, labels=classes,
                average=None, zero_division=0,
            )
            class_metrics = {
                cls: {
                    'precision': float(precision[i]),
                    'recall': float(recall[i]),
                    'f1': float(f1[i]),
                }
                for i, cls in enumerate(classes)
            }

            cm = confusion_matrix(test_labels, stacker_preds, labels=classes).tolist()

            dataset_csv = cfg['paths']['dataset_csv']
            vectorizer_path = os.path.join(lang_dir, 'logistic.joblib')

            mlflow_params = {
                'language': lang,
                'classes': ','.join(classes),
                'ensemble_strategy': cfg['ensemble']['strategy'],
                'logistic_C': cfg['logistic']['model']['C'],
                'xgb_n_estimators': cfg['xgboost']['n_estimators'],
                'xgb_max_depth': cfg['xgboost']['max_depth'],
                'transformer_used': transformer is not None,
                'train_size': len(train_labels),
                'test_size': len(test_labels),
                'sample_limit': sample or 'full',
            }
            mlflow_metrics = {
                'macro_f1_lr': float(summary['macro_f1_lr']),
                'macro_f1_xgb': float(summary['macro_f1_xgb']),
                'macro_f1_stacker': float(summary['macro_f1_stacker']),
            }
            if transformer_preds is not None:
                mlflow_metrics['macro_f1_transformer'] = float(summary['macro_f1_transformer'])

            _mlops_module.log_experiment(
                run_name=f'train_{lang}_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
                params=mlflow_params,
                metrics=mlflow_metrics,
                tags={'language': lang, 'env': 'train_all'},
                class_metrics=class_metrics,
                confusion_matrix=cm,
                classes=classes,
                dataset_path=dataset_csv,
                vectorizer_path=vectorizer_path,
            )

            # Register as challenger (humans promote via /mlops/promote)
            version_str = f'v3.0.x-{lang}-{datetime.now().strftime("%Y%m%d_%H%M%S")}'
            _mlops_module.register_model(
                version=version_str,
                metrics={'f1_macro': float(summary['macro_f1_stacker']), **{
                    f'f1_{cls}': class_metrics[cls]['f1'] for cls in classes
                }},
                mode='challenger',
                artifact_dir=lang_dir,
                tags={'language': lang, 'trained_at': datetime.now(timezone.utc).isoformat()},
            )
            # Mark a retraining run complete so the scheduler resets
            _mlops_module.mark_retraining_complete(
                model_version=version_str,
                metrics={'f1_macro': float(summary['macro_f1_stacker'])},
                notes=f'train_all language={lang}',
            )
        except Exception as e:
            print(f'[train:{lang}] MLOps logging skipped: {e}')

    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='configs/model.yaml')
    parser.add_argument('--sample', type=int, default=None,
                        help='Use only N samples per class per language (dev mode)')
    parser.add_argument('--test-size', type=float, default=0.2)
    parser.add_argument('--only-language', default=None,
                        help='Train only one language (e.g. en, hi)')
    parser.add_argument('--skip-transformer', action='store_true',
                        help='Skip transformer training (faster, LR+XGB only)')
    args = parser.parse_args()

    with open(args.config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    dataset_csv = cfg['paths']['dataset_csv']
    artifacts_dir = cfg['paths']['artifacts_dir']
    languages = cfg.get('languages', ['en'])
    if args.only_language:
        languages = [args.only_language]

    if not os.path.exists(dataset_csv):
        print(f'[train] dataset not found: {dataset_csv}')
        print('[train] run: python -m data.synthetic_generator')
        sys.exit(1)

    os.makedirs(artifacts_dir, exist_ok=True)
    df = pd.read_csv(dataset_csv)
    print(f'[train] loaded {len(df)} total rows')

    if 'language' not in df.columns:
        print('[train] ERROR: dataset has no `language` column. Regenerate with the bilingual generator.')
        sys.exit(1)

    print(f'[train] language distribution:\n{df["language"].value_counts().to_string()}')
    if TORCH_AVAILABLE and not args.skip_transformer:
        print(f'[train] Transformer: ENABLED (torch available)')
    elif args.skip_transformer:
        print(f'[train] Transformer: SKIPPED (--skip-transformer flag)')
    else:
        print(f'[train] Transformer: SKIPPED (torch not installed)')
        print(f'[train] To enable: pip install -r requirements-transformer.txt')

    summaries = []
    for lang in languages:
        df_lang = df[df['language'] == lang].reset_index(drop=True)
        if len(df_lang) == 0:
            print(f'[train] no rows for language `{lang}`, skipping.')
            continue
        summary = _train_one_language(
            lang, df_lang, cfg, artifacts_dir, args.test_size,
            args.sample, skip_transformer=args.skip_transformer,
        )
        if summary:
            summaries.append(summary)

    # Final cross-language comparison
    print('\n' + '='*60)
    print('[train] FINAL COMPARISON (macro-F1 by language)')
    print('='*60)
    has_transformer = any('macro_f1_transformer' in s for s in summaries)
    header = f'{"language":<10} {"test_n":<8} {"LR":<8} {"XGB":<8} {"Stacker":<8}'
    if has_transformer:
        header += f' {"Transformer":<12}'
    print(header)
    for s in summaries:
        line = (f"{s['lang']:<10} {s['test_size']:<8} "
                f"{s['macro_f1_lr']:<8.4f} {s['macro_f1_xgb']:<8.4f} {s['macro_f1_stacker']:<8.4f}")
        if has_transformer and 'macro_f1_transformer' in s:
            line += f" {s['macro_f1_transformer']:<12.4f}"
        print(line)

    print(f'\n[train] done. Artifacts written to {artifacts_dir}/<lang>/')
    if has_transformer:
        print(f'[train] Transformer artifacts saved (DistilBERT fine-tuned)')
        print(f'[train] Integrated Gradients explainability is now ACTIVE')


if __name__ == '__main__':
    main()
