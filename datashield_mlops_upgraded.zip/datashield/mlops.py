"""
mlops.py
--------
Production-style MLOps for the Sensitivity Classification Engine.

Layers (all driven from configs/mlops.yaml):
  - MLflow experiment tracking
      * params, metrics, class-wise metrics, confusion matrix artifact,
        dataset version, vectorizer version
      * graceful JSONL fallback when MLflow is not installed
  - Model registry (champion / challenger)
      * version + metrics tracked in logs/model_registry.json
      * load_champion() consumed by pipeline.py at startup
      * promote_challenger() uses the promote_metric + min delta from config
  - Drift monitoring (Evidently AI + lightweight numerical fallback)
      * feature drift, prediction drift, confidence drift,
        class-distribution drift
      * HTML + JSON reports under mlops/drift_reports/<timestamp>/
      * threshold alerts (>3% perf drop = PS SLA breach) written to
        logs/drift_alerts.jsonl
  - Retraining
      * monthly + manual trigger
      * dual-approval-friendly: human still confirms before training runs
      * history written to logs/retraining_history.jsonl

This module is *backwards compatible* — every public function that existed
in the previous mlops.py still exists with the same signature. New
features are additive.

Run standalone: python mlops.py
"""
from __future__ import annotations
import os
import sys
import json
import math
import hashlib
import shutil
from collections import Counter
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

from utils.mlops_config import (
    get_mlops_config,
    load_mlops_config,
    resolve_path,
)


# ─────────────────────────────────────────────────────────────
# Path resolution (centralized via configs/mlops.yaml)
# ─────────────────────────────────────────────────────────────
def _cfg():
    return get_mlops_config()


def _audit_path() -> str:
    return resolve_path(_cfg().audit.path)


def _registry_path() -> str:
    return resolve_path(_cfg().registry.path)


def _drift_reports_dir() -> str:
    p = resolve_path(_cfg().drift.reports_dir)
    os.makedirs(p, exist_ok=True)
    return p


def _drift_alerts_path() -> str:
    return os.path.join(PROJECT_DIR, 'logs', 'drift_alerts.jsonl')


def _retraining_history_path() -> str:
    return resolve_path(_cfg().retraining.schedule_log)


def _retraining_state_path() -> str:
    return resolve_path(_cfg().retraining.schedule_state)


def _mlflow_uri() -> str:
    uri = _cfg().mlflow.tracking_uri
    if uri:
        return uri
    return f"sqlite:///{os.path.join(PROJECT_DIR, 'logs', 'mlruns.db')}"


# Legacy constants kept for backward compatibility with anything that
# imported them from the old mlops.py.
REGISTRY_PATH = os.path.join(PROJECT_DIR, 'logs', 'model_registry.json')
DRIFT_LOG_PATH = os.path.join(PROJECT_DIR, 'logs', 'drift_report.json')
AUDIT_LOG_PATH = os.path.join(PROJECT_DIR, 'logs', 'audit.jsonl')
MLFLOW_TRACKING_URI = f"sqlite:///{os.path.join(PROJECT_DIR, 'logs', 'mlruns.db')}"
DRIFT_HTML_PATH = os.path.join(PROJECT_DIR, 'logs', 'drift_report.html')

os.makedirs(os.path.join(PROJECT_DIR, 'logs'), exist_ok=True)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


# ─────────────────────────────────────────────────────────────
# Model Registry (champion / challenger)
# ─────────────────────────────────────────────────────────────
def load_registry() -> Dict:
    path = _registry_path()
    if os.path.exists(path):
        try:
            with open(path) as f:
                return json.load(f)
        except Exception as e:
            print(f'[mlops] registry parse error: {e}; resetting.')
    return {'champion': None, 'challenger': None, 'history': []}


def save_registry(reg: Dict) -> None:
    path = _registry_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        json.dump(reg, f, indent=2, sort_keys=True)


def register_model(version: str, metrics: Dict[str, float], mode: str = 'champion',
                   artifact_dir: Optional[str] = None, tags: Optional[Dict[str, str]] = None) -> Dict:
    """Register a model version with its metrics.

    Args:
        version: human-readable version string (e.g. 'v3.1.0-bilingual')
        metrics: dict of float metrics (must include 'f1_macro' for promotion logic)
        mode: 'champion' | 'challenger'
        artifact_dir: optional path to the trained artifacts (so we can
                      reload them later from the registry alone)
        tags: optional free-form tags (e.g. dataset hash, git sha)
    """
    reg = load_registry()
    entry = {
        'version': version,
        'metrics': metrics,
        'registered_at': _now_iso(),
        'status': mode,
        'artifact_dir': artifact_dir,
        'tags': tags or {},
    }
    if mode == 'champion':
        if reg.get('champion'):
            reg['history'].append({**reg['champion'], 'status': 'retired',
                                   'retired_at': _now_iso()})
        reg['champion'] = entry
    elif mode == 'challenger':
        reg['challenger'] = entry
    else:
        raise ValueError(f"mode must be 'champion' or 'challenger', got {mode!r}")
    save_registry(reg)
    print(f"[mlops] Registered {mode}: {version} with metrics: {metrics}")
    return entry


def promote_challenger() -> bool:
    """Promote challenger if it beats champion by promote_min_delta on promote_metric."""
    reg = load_registry()
    chall = reg.get('challenger')
    if not chall:
        print('[mlops] No challenger to promote.')
        return False

    promote_metric = _cfg().registry.promote_metric
    min_delta = float(_cfg().registry.promote_min_delta)

    champ = reg.get('champion')
    champ_score = float((champ or {}).get('metrics', {}).get(promote_metric, 0))
    chall_score = float(chall.get('metrics', {}).get(promote_metric, 0))

    if chall_score - champ_score >= min_delta:
        print(f'[mlops] Promoting challenger ({promote_metric}={chall_score:.4f}) '
              f'over champion ({champ_score:.4f}) — delta={chall_score - champ_score:.4f}')
        if champ:
            reg['history'].append({**champ, 'status': 'demoted',
                                   'demoted_at': _now_iso()})
        reg['champion'] = {**chall, 'status': 'champion',
                           'promoted_at': _now_iso()}
        reg['challenger'] = None
        save_registry(reg)
        return True
    print(f'[mlops] Challenger ({promote_metric}={chall_score:.4f}) did not beat champion '
          f'({champ_score:.4f}) by min delta {min_delta}. No promotion.')
    return False


def load_champion() -> Optional[Dict]:
    """Return the current champion entry, or None.

    Consumed by pipeline.py at startup — when present, the model_version
    stamped on audit lines reflects the registered champion rather than
    the hardcoded MODEL_VERSION constant.
    """
    if not _cfg().registry.auto_load_champion:
        return None
    reg = load_registry()
    return reg.get('champion')


# ─────────────────────────────────────────────────────────────
# Audit log helpers (shared by drift)
# ─────────────────────────────────────────────────────────────
def _read_audit_log() -> List[Dict]:
    path = _audit_path()
    if not os.path.exists(path):
        return []
    entries = []
    with open(path, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except Exception:
                    pass
    return entries


# ─────────────────────────────────────────────────────────────
# Drift Monitoring
# ─────────────────────────────────────────────────────────────
def _psi(ref_counts: Counter, cur_counts: Counter, all_keys) -> float:
    """Population Stability Index between two discrete distributions."""
    ref_total = sum(ref_counts.values()) or 1
    cur_total = sum(cur_counts.values()) or 1
    psi = 0.0
    for k in all_keys:
        ref_pct = (ref_counts.get(k, 0) + 1e-6) / ref_total
        cur_pct = (cur_counts.get(k, 0) + 1e-6) / cur_total
        psi += (ref_pct - cur_pct) * math.log(ref_pct / cur_pct)
    return psi


def _avg(vals: List[float]) -> float:
    return sum(vals) / len(vals) if vals else 0.0


def _percentile(vals: List[float], q: float) -> float:
    """Linear-interpolated percentile. q in [0, 1]."""
    if not vals:
        return 0.0
    s = sorted(vals)
    idx = (len(s) - 1) * q
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return s[lo]
    return s[lo] + (s[hi] - s[lo]) * (idx - lo)


def compute_drift_report(
    reference_window: Optional[int] = None,
    current_window: Optional[int] = None,
) -> Dict:
    """Comprehensive drift report.

    Computes — when enabled in configs/mlops.yaml/drift.dimensions:
      * prediction_drift      → PSI on label distribution
      * confidence_drift      → mean + p25 drop in confidence
      * class_distribution    → per-class PSI table
      * feature_drift         → PSI on average-confidence-by-class bucket
                                (lightweight proxy; full feature drift
                                requires reference features, handled by
                                evidently HTML when available)

    Writes:
      * JSON report under mlops/drift_reports/<timestamp>/drift_report.json
      * Evidently HTML under same dir (when installed)
      * Alert entry to logs/drift_alerts.jsonl when any threshold breach

    Backwards compatible: returns the same top-level fields the previous
    version returned (status / psi_score / drift_detected / etc.) so the
    /mlops/drift endpoint keeps working.
    """
    cfg = _cfg()
    dim = cfg.drift.dimensions
    th = cfg.drift.thresholds

    ref_n = reference_window or int(cfg.drift.reference_window)
    cur_n = current_window or int(cfg.drift.current_window)

    entries = _read_audit_log()
    min_needed = ref_n + cur_n
    if len(entries) < min_needed:
        report = {
            'status': 'insufficient_data',
            'message': (
                f'Need at least {min_needed} records to compute drift '
                f'(reference_window={ref_n} + current_window={cur_n}). '
                f'Have {len(entries)}.'
            ),
            'records_available': len(entries),
            'records_needed': min_needed,
            'computed_at': _now_iso(),
        }
        _write_legacy_report(report)
        return report

    reference = entries[:ref_n]
    current = entries[-cur_n:]

    # -----------------------------------------------------------
    # Prediction drift (label PSI) + class distribution
    # -----------------------------------------------------------
    ref_labels = Counter(e.get('label', 'Unknown') for e in reference)
    cur_labels = Counter(e.get('label', 'Unknown') for e in current)
    all_labels = set(ref_labels) | set(cur_labels)

    psi_pred = _psi(ref_labels, cur_labels, all_labels) if dim.prediction_drift else 0.0

    class_dist_psi: Dict[str, float] = {}
    if dim.class_distribution_drift:
        for lbl in all_labels:
            # one-vs-rest binary PSI for each class
            ref_bin = Counter({lbl: ref_labels.get(lbl, 0),
                               '_other': sum(v for k, v in ref_labels.items() if k != lbl)})
            cur_bin = Counter({lbl: cur_labels.get(lbl, 0),
                               '_other': sum(v for k, v in cur_labels.items() if k != lbl)})
            class_dist_psi[lbl] = round(_psi(ref_bin, cur_bin, [lbl, '_other']), 4)

    # -----------------------------------------------------------
    # Confidence drift
    # -----------------------------------------------------------
    ref_conf = [float(e.get('confidence', 0) or 0) for e in reference]
    cur_conf = [float(e.get('confidence', 0) or 0) for e in current]
    conf_drift = {}
    if dim.confidence_drift:
        ref_avg = _avg(ref_conf)
        cur_avg = _avg(cur_conf)
        ref_p25 = _percentile(ref_conf, 0.25)
        cur_p25 = _percentile(cur_conf, 0.25)
        conf_drift = {
            'reference_avg': round(ref_avg, 4),
            'current_avg': round(cur_avg, 4),
            'avg_drop': round(ref_avg - cur_avg, 4),
            'reference_p25': round(ref_p25, 4),
            'current_p25': round(cur_p25, 4),
            'p25_drop': round(ref_p25 - cur_p25, 4),
        }
    else:
        conf_drift = {'disabled': True}

    # -----------------------------------------------------------
    # Lightweight feature drift proxy — PSI on confidence buckets
    # (full feature drift is covered by Evidently HTML report)
    # -----------------------------------------------------------
    feature_drift: Dict[str, Any] = {}
    if dim.feature_drift:
        def bucket(c: float) -> str:
            if c < 0.5:
                return 'low'
            if c < 0.75:
                return 'med'
            if c < 0.9:
                return 'high'
            return 'very_high'

        ref_b = Counter(bucket(c) for c in ref_conf)
        cur_b = Counter(bucket(c) for c in cur_conf)
        feature_drift = {
            'proxy': 'confidence_bucket_psi',
            'psi': round(_psi(ref_b, cur_b, ['low', 'med', 'high', 'very_high']), 4),
            'reference_buckets': dict(ref_b),
            'current_buckets': dict(cur_b),
        }
    else:
        feature_drift = {'disabled': True}

    # -----------------------------------------------------------
    # Severity decision
    # -----------------------------------------------------------
    drift_detected = psi_pred > float(th.psi_warn)
    drift_alert = psi_pred > float(th.psi_alert)
    drift_critical = psi_pred > float(th.psi_critical)

    # PS SLA: perf degradation > 3%. Without ground truth we use confidence
    # avg drop as a proxy (highly correlated in practice).
    conf_avg_drop = conf_drift.get('avg_drop', 0) if isinstance(conf_drift, dict) else 0
    sla_breach = conf_avg_drop > float(th.performance_drop_pct)

    if drift_critical:
        recommendation = 'RETRAIN IMMEDIATELY — distribution shift exceeds critical threshold'
    elif drift_alert or sla_breach:
        recommendation = 'RETRAIN WITHIN 48H — PS Drift Alert SLA breach (>3%)'
    elif drift_detected:
        recommendation = 'MONITOR — mild drift detected'
    else:
        recommendation = 'OK — no significant drift detected'

    timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    out_dir = os.path.join(_drift_reports_dir(), timestamp)
    os.makedirs(out_dir, exist_ok=True)

    report = {
        'status': 'computed',
        'computed_at': _now_iso(),
        'reference_window': ref_n,
        'current_window': cur_n,

        # Legacy fields (kept for /mlops/drift consumers)
        'psi_score': round(psi_pred, 4),
        'drift_detected': drift_detected,
        'drift_critical': drift_critical,
        'confidence_drop': conf_drift.get('avg_drop', 0) if isinstance(conf_drift, dict) else 0,
        'alert_sla_breach': drift_alert or sla_breach,
        'label_distribution': {
            'reference': dict(ref_labels),
            'current': dict(cur_labels),
        },
        'avg_confidence': {
            'reference': round(_avg(ref_conf), 4),
            'current': round(_avg(cur_conf), 4),
        },
        'recommendation': recommendation,

        # New, structured dimensions
        'drift_dimensions': {
            'prediction_drift': {
                'enabled': bool(dim.prediction_drift),
                'psi': round(psi_pred, 4),
                'severity': (
                    'critical' if drift_critical else
                    'alert' if drift_alert else
                    'warn' if drift_detected else 'ok'
                ),
            },
            'class_distribution_drift': {
                'enabled': bool(dim.class_distribution_drift),
                'per_class_psi': class_dist_psi,
            },
            'confidence_drift': conf_drift,
            'feature_drift': feature_drift,
        },
        'thresholds_used': {
            'psi_warn': float(th.psi_warn),
            'psi_alert': float(th.psi_alert),
            'psi_critical': float(th.psi_critical),
            'performance_drop_pct': float(th.performance_drop_pct),
            'confidence_drop': float(th.confidence_drop),
        },
        'output_dir': out_dir,
    }

    # Persist JSON to both the new timestamped dir and the legacy path
    with open(os.path.join(out_dir, 'drift_report.json'), 'w') as f:
        json.dump(report, f, indent=2, sort_keys=True)
    _write_legacy_report(report)

    # Try Evidently HTML
    html_path = _maybe_write_evidently_html(reference, current, out_dir)
    if html_path:
        report['html_report'] = html_path

    # Fire alert if needed
    if drift_alert or sla_breach or drift_critical:
        alert = {
            'timestamp_utc': _now_iso(),
            'severity': 'critical' if drift_critical else 'alert',
            'psi_score': round(psi_pred, 4),
            'sla_breach': bool(drift_alert or sla_breach),
            'confidence_drop': conf_drift.get('avg_drop', 0) if isinstance(conf_drift, dict) else 0,
            'recommendation': recommendation,
            'report_dir': out_dir,
        }
        alert_path = _drift_alerts_path()
        os.makedirs(os.path.dirname(alert_path), exist_ok=True)
        with open(alert_path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(alert, sort_keys=True) + '\n')
        print(f"[mlops] DRIFT ALERT — {alert['severity'].upper()} — {recommendation}")

    return report


def _write_legacy_report(report: Dict) -> None:
    """Keep logs/drift_report.json as the latest snapshot (back-compat with
    api.mlops_drift_html which reads from there as fallback)."""
    legacy_path = DRIFT_LOG_PATH
    os.makedirs(os.path.dirname(legacy_path), exist_ok=True)
    with open(legacy_path, 'w') as f:
        json.dump(report, f, indent=2, sort_keys=True)


def _maybe_write_evidently_html(reference: List[Dict], current: List[Dict], out_dir: str) -> Optional[str]:
    """Generate an Evidently HTML drift report (best effort). Also copies
    a symlink-like 'latest.html' for the API to serve.

    Returns the full HTML path or None.
    """
    try:
        import pandas as pd
        try:
            from evidently import Report
            from evidently.presets import DataDriftPreset
            new_api = True
        except ImportError:
            try:
                from evidently.report import Report
                from evidently.metric_preset import DataDriftPreset
                new_api = False
            except ImportError:
                return None
    except Exception:
        return None

    try:
        ref_df = pd.DataFrame([{
            'label': e.get('label'),
            'confidence': float(e.get('confidence', 0) or 0),
        } for e in reference])
        cur_df = pd.DataFrame([{
            'label': e.get('label'),
            'confidence': float(e.get('confidence', 0) or 0),
        } for e in current])

        html_path = os.path.join(out_dir, 'drift_report.html')
        report = Report(metrics=[DataDriftPreset()])
        if new_api:
            snapshot = report.run(reference_data=ref_df, current_data=cur_df)
            snapshot.save_html(html_path)
        else:
            report.run(reference_data=ref_df, current_data=cur_df)
            report.save_html(html_path)
        # Also copy to logs/drift_report.html (legacy path the API serves)
        try:
            shutil.copyfile(html_path, DRIFT_HTML_PATH)
        except Exception:
            pass
        return html_path
    except Exception as e:
        print(f'[mlops] Evidently report generation failed: {e}')
        return None


# ─────────────────────────────────────────────────────────────
# Retraining scheduler
# ─────────────────────────────────────────────────────────────
def _load_retraining_state() -> Dict[str, Any]:
    path = _retraining_state_path()
    if os.path.exists(path):
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def _save_retraining_state(state: Dict[str, Any]) -> None:
    path = _retraining_state_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        json.dump(state, f, indent=2, sort_keys=True)


def _log_retraining_history(entry: Dict[str, Any]) -> None:
    path = _retraining_history_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, sort_keys=True) + '\n')


def check_retraining_trigger(perf_drop_threshold: Optional[float] = None) -> Dict:
    """Backwards-compatible retraining trigger check.

    Combines three signals:
      a) Monthly trigger — N days since last training
      b) Drift critical — current drift report
      c) PS Drift Alert SLA — confidence avg drop > 3%
    """
    cfg = _cfg()
    monthly_days = int(cfg.retraining.monthly_trigger_days)

    state = _load_retraining_state()
    last_train = state.get('last_training_utc')

    days_since: Optional[int] = None
    if last_train:
        try:
            last_dt = datetime.fromisoformat(last_train.replace('Z', '+00:00'))
            days_since = (datetime.now(timezone.utc) - last_dt).days
        except Exception:
            days_since = None

    reasons: List[str] = []
    trigger = False

    if days_since is not None and days_since >= monthly_days:
        trigger = True
        reasons.append(f'Monthly trigger: {days_since} days since last training')

    drift = compute_drift_report()
    if drift.get('drift_critical'):
        trigger = True
        reasons.append(f"Drift critical: PSI={drift.get('psi_score', '?')}")
    elif drift.get('alert_sla_breach'):
        trigger = True
        reasons.append('PS SLA breach: confidence drop > 3%')

    if not trigger:
        reasons.append('No retraining needed')

    return {
        'trigger': trigger,
        'reason': '; '.join(reasons),
        'days_since_last_training': days_since,
        'drift_report': drift,
    }


def trigger_retraining(reason: str, requested_by: str = 'system',
                       auto: bool = False) -> Dict[str, Any]:
    """Record a retraining request — does NOT auto-train (Constraint C4).

    Args:
        reason: free-form reason text
        requested_by: who requested it ('system', 'cron', 'human:<id>')
        auto: True for scheduler-driven, False for manual

    Returns the recorded history entry.
    """
    state = _load_retraining_state()
    state['last_trigger_utc'] = _now_iso()
    state['pending_trigger'] = True
    state['pending_reason'] = reason
    state['pending_by'] = requested_by
    _save_retraining_state(state)

    cfg = _cfg()
    entry = {
        'event': 'retraining_requested',
        'timestamp_utc': _now_iso(),
        'reason': reason,
        'requested_by': requested_by,
        'auto': bool(auto),
        'human_approval_required': bool(cfg.retraining.human_approval_required),
        'status': 'pending_approval' if cfg.retraining.human_approval_required else 'queued',
    }
    _log_retraining_history(entry)
    return entry


def mark_retraining_complete(model_version: str,
                              metrics: Optional[Dict[str, float]] = None,
                              notes: str = '') -> Dict[str, Any]:
    """Record that a retraining run finished. Updates state so monthly
    trigger resets, appends a history line, and (optionally) registers
    the new model as a challenger."""
    state = _load_retraining_state()
    state['last_training_utc'] = _now_iso()
    state['pending_trigger'] = False
    state['pending_reason'] = None
    state['last_model_version'] = model_version
    _save_retraining_state(state)

    entry = {
        'event': 'retraining_completed',
        'timestamp_utc': _now_iso(),
        'model_version': model_version,
        'metrics': metrics or {},
        'notes': notes,
    }
    _log_retraining_history(entry)

    # Auto-register as challenger if metrics provided
    if metrics:
        register_model(model_version, metrics, mode='challenger')
    return entry


def scheduler_tick() -> Dict[str, Any]:
    """Lightweight scheduler tick. Call this on import or via cron / API.
    Decides whether to enqueue a retraining request. No threads, no
    background process — fully deterministic so PyCharm runs remain snappy.
    """
    cfg = _cfg()
    if not cfg.retraining.enable_lightweight_scheduler:
        return {'scheduler_run': False, 'reason': 'disabled in config'}

    state = _load_retraining_state()
    if state.get('pending_trigger'):
        return {
            'scheduler_run': True,
            'action': 'none',
            'reason': 'pending retraining already queued',
            'pending_reason': state.get('pending_reason'),
        }

    trig = check_retraining_trigger()
    if trig['trigger']:
        entry = trigger_retraining(reason=trig['reason'], requested_by='scheduler', auto=True)
        return {
            'scheduler_run': True,
            'action': 'queued',
            'history_entry': entry,
        }
    return {'scheduler_run': True, 'action': 'none', 'reason': trig['reason']}


# ─────────────────────────────────────────────────────────────
# MLflow experiment tracking (expanded)
# ─────────────────────────────────────────────────────────────
def _hash_file(path: str) -> Optional[str]:
    """First-8-hex SHA256 of a file. Used as dataset / vectorizer version."""
    if not path or not os.path.exists(path):
        return None
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()[:16]


def log_experiment(run_name: str,
                   params: Dict[str, Any],
                   metrics: Dict[str, float],
                   tags: Optional[Dict[str, str]] = None,
                   class_metrics: Optional[Dict[str, Dict[str, float]]] = None,
                   confusion_matrix: Optional[List[List[int]]] = None,
                   classes: Optional[List[str]] = None,
                   dataset_path: Optional[str] = None,
                   vectorizer_path: Optional[str] = None) -> bool:
    """Log a training run to MLflow with expanded artifacts.

    All new args are optional → existing callers keep working with no edits.

    What gets logged when MLflow is available:
      * params, metrics (flat)
      * class_metrics → flattened as 'precision_<class>', 'recall_<class>', 'f1_<class>'
      * confusion_matrix → JSON artifact under runs/<id>/artifacts/
      * dataset_path → SHA256 hash recorded as the 'dataset_version' tag
      * vectorizer_path → SHA256 hash recorded as 'vectorizer_version' tag
    """
    cfg = _cfg()
    tags = dict(tags or {})

    # Dataset / vectorizer versions
    if cfg.mlflow.log_dataset_version and dataset_path:
        ds_hash = _hash_file(dataset_path)
        if ds_hash:
            tags['dataset_version'] = ds_hash
            tags['dataset_path'] = dataset_path
    if cfg.mlflow.log_vectorizer_version and vectorizer_path:
        v_hash = _hash_file(vectorizer_path)
        if v_hash:
            tags['vectorizer_version'] = v_hash
            tags['vectorizer_path'] = vectorizer_path

    # Flatten class metrics
    flat_metrics = dict(metrics)
    if cfg.mlflow.log_class_metrics and class_metrics:
        for cls, m in class_metrics.items():
            for k, v in m.items():
                flat_metrics[f'{k}_{cls}'] = float(v)

    try:
        import mlflow
        mlflow.set_tracking_uri(_mlflow_uri())
        mlflow.set_experiment(cfg.mlflow.experiment_name)
        with mlflow.start_run(run_name=run_name):
            mlflow.log_params(params)
            mlflow.log_metrics(flat_metrics)
            for k, v in tags.items():
                mlflow.set_tag(k, str(v))

            # Confusion matrix as JSON artifact
            if cfg.mlflow.log_confusion_matrix and confusion_matrix is not None:
                cm_doc = {
                    'matrix': confusion_matrix,
                    'classes': classes or [],
                    'logged_at': _now_iso(),
                }
                cm_path = os.path.join(PROJECT_DIR, 'logs', f'_tmp_cm_{run_name}.json')
                with open(cm_path, 'w') as f:
                    json.dump(cm_doc, f, indent=2)
                mlflow.log_artifact(cm_path, artifact_path='confusion_matrix')
                try:
                    os.remove(cm_path)
                except Exception:
                    pass
        print(f"[mlops] Logged run '{run_name}' to MLflow at {_mlflow_uri()}")
        return True
    except ImportError:
        print('[mlops] MLflow not installed — using JSONL fallback')
        _fallback_log_experiment(run_name, params, flat_metrics, tags,
                                 class_metrics=class_metrics,
                                 confusion_matrix=confusion_matrix,
                                 classes=classes)
        return False
    except Exception as e:
        print(f'[mlops] MLflow logging failed: {e} — using JSONL fallback')
        _fallback_log_experiment(run_name, params, flat_metrics, tags,
                                 class_metrics=class_metrics,
                                 confusion_matrix=confusion_matrix,
                                 classes=classes)
        return False


def _fallback_log_experiment(run_name: str, params: Dict, metrics: Dict,
                              tags: Optional[Dict] = None,
                              class_metrics: Optional[Dict] = None,
                              confusion_matrix: Optional[List[List[int]]] = None,
                              classes: Optional[List[str]] = None) -> None:
    """JSONL fallback when MLflow is unavailable. Same shape as MLflow data."""
    log_path = os.path.join(PROJECT_DIR, 'logs', 'experiments.jsonl')
    entry = {
        'run_name': run_name,
        'timestamp': _now_iso(),
        'params': params,
        'metrics': metrics,
        'tags': tags or {},
        'class_metrics': class_metrics or {},
        'confusion_matrix': confusion_matrix,
        'classes': classes or [],
    }
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    with open(log_path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, sort_keys=True) + '\n')
    print(f'[mlops] Logged run to {log_path}')


# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print('=' * 60)
    print('MLOps Module — Sensitivity Classification Engine')
    print('=' * 60)

    print('\n[1] Model Registry:')
    reg = load_registry()
    if reg.get('champion'):
        print(f"  Champion: {reg['champion']['version']} | "
              f"F1={reg['champion']['metrics'].get('f1_macro', '?')}")
    else:
        register_model(
            version='v3.0.0-bilingual',
            metrics={'f1_macro': 0.91, 'precision_restricted': 0.97, 'recall_restricted': 0.98},
            mode='champion',
        )
        print('  Registered existing model as champion.')

    print('\n[2] Retraining Trigger Check:')
    trigger = check_retraining_trigger()
    print(f"  Trigger: {trigger['trigger']} | Reason: {trigger['reason']}")

    print('\n[3] Drift Report:')
    drift = compute_drift_report()
    print(f"  Status: {drift.get('status')}")
    if 'psi_score' in drift:
        print(f"  PSI Score: {drift['psi_score']} | Drift: {drift['drift_detected']}")
        print(f"  Recommendation: {drift['recommendation']}")
        if 'output_dir' in drift:
            print(f"  Reports dir: {drift['output_dir']}")

    print('\n[4] Scheduler Tick:')
    print(' ', scheduler_tick())

    print('\n[5] MLflow Experiment Logging (sample):')
    log_experiment(
        run_name='v3.0.0-baseline-check',
        params={'model': 'LR+XGB+Stacking', 'force_mode': 'fast'},
        metrics={'f1_macro': 0.91, 'precision_restricted': 0.97},
        tags={'language': 'bilingual', 'env': 'local'},
        class_metrics={
            'Restricted': {'precision': 0.97, 'recall': 0.98, 'f1': 0.975},
            'Confidential': {'precision': 0.90, 'recall': 0.89, 'f1': 0.895},
            'Internal': {'precision': 0.88, 'recall': 0.91, 'f1': 0.895},
            'Public': {'precision': 0.92, 'recall': 0.90, 'f1': 0.910},
        },
        confusion_matrix=[[450, 5, 3, 2], [4, 420, 10, 1], [2, 12, 410, 6], [1, 0, 8, 460]],
        classes=['Public', 'Internal', 'Confidential', 'Restricted'],
    )

    print('\n✅ MLOps module check complete.')
