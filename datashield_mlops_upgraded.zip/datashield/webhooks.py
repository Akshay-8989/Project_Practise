"""
webhooks.py
-----------
Enterprise webhook delivery for downstream DLP / CASB / data catalog
integrations. Triggered after every successful classification by the API
layer (api._classify → webhooks.dispatch_classification_event).

Design contract:
  1. Non-blocking. Dispatch happens on a background thread (or via FastAPI
     BackgroundTasks if the caller prefers) — the HTTP response to the
     classifying client is never delayed by webhook I/O.
  2. Configurable. Endpoints + secrets in configs/webhooks.yaml, behaviour
     (timeouts, retries, headers, routing) in configs/mlops.yaml. No
     hardcoded URLs.
  3. Resilient. Each endpoint has its own retry loop with exponential
     backoff. Permanent failures land in a dead-letter file
     (logs/webhook_dead_letter.jsonl) for ops replay.
  4. Auditable. Every attempt — success and failure — is appended to
     logs/webhook_deliveries.jsonl with timestamps and status codes.
  5. Tamper-evident. Optional HMAC-SHA256 signature over the body, plus
     X-API-Key header for caller authentication.
  6. PII-safe. The payload uses the same masked snippet as the audit log
     (Constraint C1). Raw text never leaves this process.

Public API:
    enabled() -> bool
    dispatch_classification_event(prediction: dict) -> str   # returns event_id
    dispatch_sync(endpoint_name: str, payload: dict) -> dict # for tests
    list_dead_letter() -> list[dict]
    replay_dead_letter(event_id: str | None = None) -> dict

Compatible policy actions (PS): ALLOW, ENCRYPT, RESTRICT, QUARANTINE.
The API maps 'Allow' / 'Encrypt' / 'Restrict' / 'Quarantine' → these
canonical uppercase tokens before lookup.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import yaml

from utils.mlops_config import (
    PROJECT_DIR,
    get_mlops_config,
    load_mlops_config,
    resolve_path,
)

# `requests` is already in requirements.txt — safe to import at module level.
import requests


# ─────────────────────────────────────────────────────────────
# Internal state
# ─────────────────────────────────────────────────────────────
_ENDPOINTS_CACHE: Optional[Dict[str, Dict[str, Any]]] = None
_EXECUTOR: Optional[ThreadPoolExecutor] = None
_EXECUTOR_LOCK = threading.Lock()


CANONICAL_POLICY_ACTIONS = {'ALLOW', 'ENCRYPT', 'RESTRICT', 'QUARANTINE'}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def _ensure_executor() -> ThreadPoolExecutor:
    """Lazy thread-pool — only created on first dispatch."""
    global _EXECUTOR
    if _EXECUTOR is None:
        with _EXECUTOR_LOCK:
            if _EXECUTOR is None:
                _EXECUTOR = ThreadPoolExecutor(
                    max_workers=4,
                    thread_name_prefix='datashield-webhook',
                )
    return _EXECUTOR


def _load_endpoints(force_reload: bool = False) -> Dict[str, Dict[str, Any]]:
    """Read configs/webhooks.yaml lazily."""
    global _ENDPOINTS_CACHE
    if _ENDPOINTS_CACHE is not None and not force_reload:
        return _ENDPOINTS_CACHE
    cfg = get_mlops_config()
    path = resolve_path(cfg.webhooks.config_path)
    endpoints: Dict[str, Dict[str, Any]] = {}
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                doc = yaml.safe_load(f) or {}
            endpoints = doc.get('endpoints') or {}
        except Exception as e:
            print(f'[webhooks] WARN: failed to parse {path}: {e}')
            endpoints = {}
    _ENDPOINTS_CACHE = endpoints
    return endpoints


def _ensure_log_files() -> None:
    cfg = get_mlops_config()
    for p in (cfg.webhooks.delivery_log, cfg.webhooks.dead_letter_path):
        full = resolve_path(p)
        os.makedirs(os.path.dirname(full), exist_ok=True)


def enabled() -> bool:
    """Master switch. Returns True iff webhooks are turned on AND at least
    one configured endpoint is enabled."""
    cfg = get_mlops_config()
    if not bool(cfg.webhooks.enabled):
        return False
    eps = _load_endpoints()
    return any(ep.get('enabled') for ep in eps.values())


# ─────────────────────────────────────────────────────────────
# Payload builder + canonicalization
# ─────────────────────────────────────────────────────────────
def _canonical_action(action: str) -> str:
    if not action:
        return 'ALLOW'
    upper = action.strip().upper()
    return upper if upper in CANONICAL_POLICY_ACTIONS else 'RESTRICT'


def build_payload(prediction: Dict[str, Any]) -> Dict[str, Any]:
    """Construct a webhook payload from a classification result.

    Compliant with Constraint C1 — only masked/safe fields are included.
    Raw or clean text is never forwarded; only the doc_id and the masked
    snippet that already lives in the audit log."""
    versions = prediction.get('audit', {}) or {}
    pre_audit = prediction.get('preprocessing', {}) or {}

    # Evidence tokens are derived in the policy engine + explainers and
    # are already masked (rule names + token strings only).
    evidence = []
    for ev in (prediction.get('evidence') or [])[:8]:
        evidence.append({
            'token': str(ev.get('token', ''))[:80],
            'weight': float(ev.get('weight', 0) or 0),
            'source': str(ev.get('source', 'unknown')),
        })

    policy_action = _canonical_action(prediction.get('policy_action', ''))

    return {
        'event_id': str(uuid.uuid4()),
        'event_type': 'classification.completed',
        'timestamp_utc': _now_iso(),
        'document': {
            'doc_id': prediction.get('doc_id'),
            'label': prediction.get('label'),
            'confidence': prediction.get('confidence'),
            'policy_action': policy_action,
            'evidence_tokens': evidence,
            'masked_snippet': (pre_audit.get('masked_text_preview') or '')[:240],
            'detected_language': (prediction.get('language') or {}).get('detected'),
        },
        'audit': {
            'model_version': versions.get('model_version'),
            'preprocessing_version': versions.get('preprocessing_version'),
            'feature_version': versions.get('feature_version'),
            'ensemble_used': versions.get('ensemble_used'),
            'runtime_mode': versions.get('runtime_mode'),
        },
        'producer': 'datashield-api',
    }


# ─────────────────────────────────────────────────────────────
# Signing
# ─────────────────────────────────────────────────────────────
def _sign_body(secret: str, body_bytes: bytes) -> str:
    """HMAC-SHA256 of the raw JSON body. Hex-encoded, prefixed with 'sha256='."""
    if not secret:
        return ''
    mac = hmac.new(secret.encode('utf-8'), body_bytes, hashlib.sha256)
    return f'sha256={mac.hexdigest()}'


# ─────────────────────────────────────────────────────────────
# Delivery — synchronous core with retry + DLQ
# ─────────────────────────────────────────────────────────────
def _append_jsonl(path: str, entry: Dict[str, Any]) -> None:
    full = resolve_path(path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, sort_keys=True, ensure_ascii=False) + '\n')


def _record_delivery(entry: Dict[str, Any]) -> None:
    cfg = get_mlops_config()
    _append_jsonl(cfg.webhooks.delivery_log, entry)


def _record_dead_letter(entry: Dict[str, Any]) -> None:
    cfg = get_mlops_config()
    _append_jsonl(cfg.webhooks.dead_letter_path, entry)


def _deliver_one(
    endpoint_name: str,
    endpoint_cfg: Dict[str, Any],
    payload: Dict[str, Any],
) -> Dict[str, Any]:
    """Single-endpoint delivery with retries. Returns the final status entry."""
    cfg = get_mlops_config()
    defaults = cfg.webhooks.defaults

    url = endpoint_cfg.get('url')
    if not endpoint_cfg.get('enabled') or not url:
        result = {
            'event_id': payload.get('event_id'),
            'endpoint': endpoint_name,
            'status': 'skipped',
            'reason': 'endpoint disabled or missing url',
            'timestamp_utc': _now_iso(),
        }
        _record_delivery(result)
        return result

    timeout = float(endpoint_cfg.get('timeout_seconds', defaults.timeout_seconds))
    max_retries = int(endpoint_cfg.get('max_retries', defaults.max_retries))
    backoff = float(endpoint_cfg.get('retry_backoff_seconds', defaults.retry_backoff_seconds))

    api_key = endpoint_cfg.get('api_key') or os.environ.get(
        f'DATASHIELD_WEBHOOK__{endpoint_name}__API_KEY', ''
    )
    hmac_secret = endpoint_cfg.get('hmac_secret') or os.environ.get(
        f'DATASHIELD_WEBHOOK__{endpoint_name}__HMAC_SECRET', ''
    )

    body_bytes = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode('utf-8')
    headers = {
        'Content-Type': 'application/json',
        defaults.request_id_header: payload.get('event_id', ''),
    }
    if api_key:
        headers[defaults.api_key_header] = api_key
    if hmac_secret:
        headers[defaults.hmac_header] = _sign_body(hmac_secret, body_bytes)

    attempts: List[Dict[str, Any]] = []
    success = False
    last_error: Optional[str] = None
    status_code: Optional[int] = None

    for attempt in range(1, max_retries + 1):
        t0 = time.time()
        try:
            resp = requests.post(url, data=body_bytes, headers=headers, timeout=timeout)
            status_code = resp.status_code
            ok = 200 <= status_code < 300
            elapsed_ms = int((time.time() - t0) * 1000)
            attempts.append({
                'attempt': attempt,
                'status_code': status_code,
                'ok': ok,
                'elapsed_ms': elapsed_ms,
                'timestamp_utc': _now_iso(),
            })
            if ok:
                success = True
                break
            last_error = f'HTTP {status_code}'
            # 4xx (except 408/429) is a permanent failure → no more retries
            if 400 <= status_code < 500 and status_code not in (408, 429):
                break
        except Exception as e:
            elapsed_ms = int((time.time() - t0) * 1000)
            last_error = str(e)
            attempts.append({
                'attempt': attempt,
                'status_code': None,
                'ok': False,
                'error': last_error,
                'elapsed_ms': elapsed_ms,
                'timestamp_utc': _now_iso(),
            })

        if attempt < max_retries:
            time.sleep(backoff * (2 ** (attempt - 1)))   # exponential backoff

    result = {
        'event_id': payload.get('event_id'),
        'endpoint': endpoint_name,
        'url': url,
        'status': 'delivered' if success else 'failed',
        'attempts': attempts,
        'last_status_code': status_code,
        'last_error': last_error,
        'doc_id': (payload.get('document') or {}).get('doc_id'),
        'policy_action': (payload.get('document') or {}).get('policy_action'),
        'timestamp_utc': _now_iso(),
    }
    _record_delivery(result)
    if not success:
        _record_dead_letter({
            **result,
            'payload': payload,
            'reason': last_error or 'unknown',
        })
    return result


# ─────────────────────────────────────────────────────────────
# Top-level dispatch (async-safe)
# ─────────────────────────────────────────────────────────────
def _route_endpoints(policy_action: str) -> List[str]:
    cfg = get_mlops_config()
    routing = getattr(cfg.webhooks, 'policy_action_routing', None)
    if routing is None:
        return []
    # SimpleNamespace doesn't expose .get; pull via __dict__
    routing_dict = routing.__dict__ if hasattr(routing, '__dict__') else {}
    return list(routing_dict.get(_canonical_action(policy_action), []) or [])


def _dispatch_payload(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Synchronous core — runs on a worker thread."""
    endpoints_cfg = _load_endpoints()
    policy_action = (payload.get('document') or {}).get('policy_action', 'ALLOW')
    target_names = _route_endpoints(policy_action)

    results: List[Dict[str, Any]] = []
    for name in target_names:
        ep = endpoints_cfg.get(name)
        if not ep:
            results.append({
                'event_id': payload.get('event_id'),
                'endpoint': name,
                'status': 'skipped',
                'reason': 'endpoint not defined in webhooks.yaml',
                'timestamp_utc': _now_iso(),
            })
            _record_delivery(results[-1])
            continue
        results.append(_deliver_one(name, ep, payload))
    return results


def dispatch_classification_event(prediction: Dict[str, Any]) -> Optional[str]:
    """Public entry point — call from api._classify after a successful
    prediction. Non-blocking; returns the event_id immediately."""
    if not enabled():
        return None
    _ensure_log_files()
    payload = build_payload(prediction)
    ex = _ensure_executor()
    ex.submit(_dispatch_payload, payload)
    return payload['event_id']


def dispatch_sync(endpoint_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Synchronous single-endpoint delivery — used by /webhooks/test and tests."""
    eps = _load_endpoints(force_reload=True)
    ep = eps.get(endpoint_name)
    if not ep:
        return {
            'event_id': payload.get('event_id'),
            'endpoint': endpoint_name,
            'status': 'skipped',
            'reason': 'endpoint not defined in webhooks.yaml',
            'timestamp_utc': _now_iso(),
        }
    return _deliver_one(endpoint_name, ep, payload)


# ─────────────────────────────────────────────────────────────
# Inspection + dead-letter replay
# ─────────────────────────────────────────────────────────────
def _read_jsonl(path: str) -> List[Dict[str, Any]]:
    full = resolve_path(path)
    if not os.path.exists(full):
        return []
    out: List[Dict[str, Any]] = []
    with open(full, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
    return out


def list_dead_letter(limit: int = 100) -> List[Dict[str, Any]]:
    cfg = get_mlops_config()
    entries = _read_jsonl(cfg.webhooks.dead_letter_path)
    return list(reversed(entries))[:limit]


def list_deliveries(limit: int = 100) -> List[Dict[str, Any]]:
    cfg = get_mlops_config()
    entries = _read_jsonl(cfg.webhooks.delivery_log)
    return list(reversed(entries))[:limit]


def replay_dead_letter(event_id: Optional[str] = None) -> Dict[str, Any]:
    """Re-deliver one (event_id) or all dead-letter items. Returns a
    summary; successful replays are removed from the DLQ file."""
    cfg = get_mlops_config()
    entries = _read_jsonl(cfg.webhooks.dead_letter_path)
    if not entries:
        return {'replayed': 0, 'remaining': 0, 'message': 'dead-letter is empty'}

    keep: List[Dict[str, Any]] = []
    replayed = 0
    failed_again = 0
    for entry in entries:
        target_id = entry.get('event_id')
        if event_id and target_id != event_id:
            keep.append(entry)
            continue
        endpoint_name = entry.get('endpoint')
        payload = entry.get('payload') or {}
        result = dispatch_sync(endpoint_name, payload)
        if result.get('status') == 'delivered':
            replayed += 1
        else:
            failed_again += 1
            keep.append({**entry, 'last_replay_attempt': _now_iso()})

    # Rewrite DLQ with the remaining unresolved items
    dlq_path = resolve_path(cfg.webhooks.dead_letter_path)
    with open(dlq_path, 'w', encoding='utf-8') as f:
        for k in keep:
            f.write(json.dumps(k, sort_keys=True, ensure_ascii=False) + '\n')

    return {
        'replayed': replayed,
        'failed_again': failed_again,
        'remaining': len(keep),
        'message': f'Replayed {replayed} event(s); {failed_again} still failing.',
    }


def shutdown() -> None:
    """Clean shutdown — drains the executor. Called from API shutdown hook."""
    global _EXECUTOR
    if _EXECUTOR is not None:
        _EXECUTOR.shutdown(wait=True)
        _EXECUTOR = None


# ─────────────────────────────────────────────────────────────
# CLI for quick verification
# ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print('webhooks.py — config check')
    cfg = get_mlops_config()
    print(f'  master enabled: {cfg.webhooks.enabled}')
    eps = _load_endpoints()
    for name, ep in eps.items():
        print(f'  - {name:24s} enabled={ep.get("enabled")} url={ep.get("url")}')
    print(f'  routing:')
    for action in ('ALLOW', 'ENCRYPT', 'RESTRICT', 'QUARANTINE'):
        print(f'    {action:10s} → {_route_endpoints(action)}')
