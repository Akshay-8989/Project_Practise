# DataShield — MLOps & Webhook Upgrade Report

**Scope:** Add the MLOps and webhook layers required by PS-01 sections 3, 4, 5, and 6 without redesigning the existing architecture. All ingestion, preprocessing, feature engineering, models, ensembles, explainers, policy engine, and UI are preserved exactly as shipped.

---

## 1. Audit summary (pre-implementation)

| # | PS requirement | State before | Action taken |
|---|---|---|---|
| G1 | MLflow class-wise metrics + confusion matrix + dataset/vectorizer version | Flat metrics only | Extended `mlops.log_experiment()` + `scripts/train_all.py` |
| G2 | Champion/challenger **automatic load on inference** | Registry existed but pipeline ignored it | `pipeline._resolve_model_version()` reads `mlops.load_champion()` |
| G3 | Drift: feature + prediction + confidence + class-distribution; JSON + HTML; under `mlops/drift_reports/` | Label-PSI + confidence drop only, in `logs/` | Rewrote `compute_drift_report()` with 4 dimensions + timestamped output dir |
| G4 | Drift threshold alert > 3% (PS SLA) | No alert log | `logs/drift_alerts.jsonl` + severity classification |
| G5 | Monthly + manual retraining trigger, history log | Override-based trigger only | `scheduler_tick()`, `trigger_retraining()`, `mark_retraining_complete()` + `logs/retraining_history.jsonl` |
| G6 | Audit log must include model/preprocessing/feature versions, evidence tokens, policy action | Only model_version + evidence_count | Extended `AuditLogger.log()` with versions and canonical `policy_action` |
| G7 | Explainability persistence | Evidence only in API response, never on disk | New `logs/explanations.jsonl` written per prediction |
| G8 | Centralized configs | Hardcoded across files | New `configs/mlops.yaml` + `configs/webhooks.yaml` with `utils/mlops_config.py` loader |
| G9 | Enterprise webhook system | Completely missing | New `webhooks.py` module with retry, DLQ, HMAC, API key, async delivery, replay |

**Non-changes (preserved verbatim):** `ingestion.py`, `preprocessing.py`, `feature_engineering/*`, `models/*`, `ensemble/*`, `explainability/*`, `policy_engine/*`, `run.py`, `ui/*`, `active_learning.py`, all tests, all artifacts.

---

## 2. File-by-file changes

### Added (4)

#### `configs/mlops.yaml` (NEW)
Single source of truth for every MLOps knob:
- `versions` — model / preprocessing / feature stamped on every audit line
- `mlflow` — experiment name, tracking URI, what to log
- `registry` — path, promote metric, min delta, auto-load flag
- `drift` — reports dir, windows, thresholds (warn/alert/critical/sla), per-dimension enable flags
- `retraining` — monthly days, history log, scheduler enable, dual-approval flag
- `audit` — paths, retention, evidence top-k
- `confidence` — low/high thresholds for downstream gating
- `webhooks` — master enable, paths, defaults (timeout/retries/headers), delivery strategy, policy-action routing

#### `configs/webhooks.yaml` (NEW)
Endpoint inventory — kept separate from `mlops.yaml` so secrets isolate cleanly. Each endpoint: `url`, `enabled`, `api_key`, `hmac_secret`, `description`. Env-var override pattern: `DATASHIELD_WEBHOOK__<name>__<field>`.

#### `utils/mlops_config.py` (NEW, 180 lines)
Cached loader with deep-merge defaults and dot-access namespace.
- `load_mlops_config()` — dict view
- `get_mlops_config()` — namespace view (`cfg.drift.thresholds.psi_alert`)
- `resolve_path(rel)` — relative-to-PROJECT_DIR absolutizer
- `get_versions()` — convenience for the audit logger
- Hard-coded `_DEFAULTS` ensure the system still runs if `configs/mlops.yaml` is deleted (air-gapped environments).

#### `webhooks.py` (NEW, ~370 lines)
Enterprise webhook delivery:
- `dispatch_classification_event(prediction)` — non-blocking, thread-pool dispatch
- `_deliver_one()` — single endpoint with exponential backoff retry (4xx except 408/429 = permanent fail)
- HMAC-SHA256 over canonical JSON body, `X-DataShield-Signature` header
- `X-API-Key` + `X-DataShield-Request-Id` headers
- `logs/webhook_deliveries.jsonl` — every attempt
- `logs/webhook_dead_letter.jsonl` — exhausted retries
- `replay_dead_letter(event_id=None)` — re-deliver and prune DLQ on success
- `dispatch_sync()` — for the `/webhooks/test` endpoint
- `shutdown()` — drain executor; called from FastAPI shutdown hook
- Policy-action routing pulls from config — never hardcoded

### Modified (5)

#### `mlops.py` (rewritten, backward compatible)
Every function from the previous version retained with the same signature.
- `load_registry()`, `save_registry()`, `register_model()`, `promote_challenger()` — now use config paths + promote min-delta + `f1_macro` metric
- **NEW** `load_champion()` — consumed by pipeline
- **NEW** `scheduler_tick()` — monthly retraining check, no threads
- **NEW** `trigger_retraining()` — records request (dual-approval-aware)
- **NEW** `mark_retraining_complete()` — closes a request + auto-registers as challenger
- `compute_drift_report()` — 4 dimensions (prediction / class-distribution / confidence / feature-proxy); JSON + HTML to `mlops/drift_reports/<timestamp>/`; alert SLA breach written to `logs/drift_alerts.jsonl`; legacy `logs/drift_report.json` still maintained
- `log_experiment()` — extended params: `class_metrics`, `confusion_matrix`, `classes`, `dataset_path`, `vectorizer_path`. Dataset + vectorizer get SHA-256 hashes recorded as MLflow tags. JSONL fallback preserves the same structure.

#### `pipeline.py` (2 surgical edits, ~30 lines added)
- New `_resolve_model_version()` helper reads `mlops.load_champion()` at startup
- `self.model_version` resolved once and used in both the result dict and the `audit.log()` call (replaces hardcoded `MODEL_VERSION`)
- No change to predict/predict_batch flow, no change to evidence gathering

#### `utils/audit_logger.py` (rewritten, backward compatible)
- Same constructor signature; new `explanations_filename` kw-arg
- Reads `configs/mlops.yaml` for `versions`, `evidence_top_k`, `include_evidence_tokens`
- Each audit line now has: `model_version`, `preprocessing_version`, `feature_version`, `policy_action` (canonical UPPERCASE), `evidence_count`
- New `_persist_explanation()` writes the top-k tokens + a `confidence_explanation` narrative to `logs/explanations.jsonl` — completely separate stream so audit log stays compact
- Constraint C1 (no raw PII) honored via the existing `safe_snippet()` masker

#### `api.py` (additive only)
- Imports `webhooks` module
- `_classify()` calls `webhooks.dispatch_classification_event(final)` after the response is built. Wrapped in try/except so a misconfigured webhook can never break a classification.
- **14 new endpoints** added before `/metrics`:
  - `/mlops/champion`, `/mlops/promote`, `/mlops/scheduler/tick`, `/mlops/trigger-retraining`, `/mlops/retraining-history`, `/mlops/drift-alerts`, `/mlops/explanations`, `/mlops/config`
  - `/webhooks/status`, `/webhooks/deliveries`, `/webhooks/dead-letter`, `/webhooks/replay`, `/webhooks/test`
- `@app.on_event('shutdown')` hook to drain the webhook executor

#### `scripts/train_all.py` (additive only)
- Tries `import mlops` at top
- Right before `return summary` in `_train_one_language()`:
  - Computes per-class precision/recall/F1 + confusion matrix
  - Calls `mlops.log_experiment()` with params, metrics, class_metrics, confusion_matrix, classes, dataset_path, vectorizer_path
  - Calls `mlops.register_model(..., mode='challenger')` so the model is auto-tracked
  - Calls `mlops.mark_retraining_complete()` so the monthly trigger resets

---

## 3. MLOps architecture explanation

```
                       ┌──────────────────────────────┐
                       │   configs/mlops.yaml         │  ← single source of truth
                       │   configs/webhooks.yaml      │
                       └──────────────┬───────────────┘
                                      │
                       ┌──────────────▼───────────────┐
                       │   utils/mlops_config.py      │  cached loader + defaults
                       └──┬──────┬────────┬───────┬───┘
                          │      │        │       │
        ┌─────────────────┘      │        │       └─────────────┐
        │                        │        │                     │
┌───────▼────────┐    ┌──────────▼──┐  ┌──▼──────────┐  ┌───────▼─────────┐
│  pipeline.py   │    │  mlops.py   │  │ audit_logger│  │  webhooks.py    │
│  ─────────────  │    │  ─────────  │  │ ──────────  │  │  ─────────────  │
│  _resolve_     │    │ load_       │  │ persists    │  │ dispatch_       │
│  model_version │◄───┤ champion()  │  │ versions +  │  │ classification_ │
│                │    │ scheduler_  │  │ evidence to │  │ event()         │
│  predict() ────┼────► tick()     │  │ logs/...    │  │   ↓             │
│   ↓            │    │ drift +    │  │             │  │ ThreadPool      │
│ audit.log() ◄──┼────┘ alerts     │  │             │  │   ↓             │
│   ↓            │    │ MLflow log  │  │             │  │ retry + HMAC    │
│ dispatch ─────►┼────┐            │  │             │  │   ↓             │
│ webhook        │    │            │  │             │  │ DLQ + replay    │
└────────────────┘    └────────────┘  └─────────────┘  └─────────────────┘
        │                    │              │                    │
        ▼                    ▼              ▼                    ▼
  audit.jsonl     mlops/drift_reports/  explanations.    webhook_deliveries.
  (per-prediction)    <ts>/JSON+HTML      jsonl           jsonl + DLQ
                  + drift_alerts.jsonl
```

Every layer is config-driven. The pipeline never has to know about MLflow, drift, or webhooks at code level — it just calls `audit.log()` and the rest happens around it.

---

## 4. Drift monitoring flow

1. **Trigger.** `GET /mlops/drift` (or `mlops.compute_drift_report()` directly, or `mlops.scheduler_tick()` indirectly).
2. **Read audit log.** Last N entries from `logs/audit.jsonl`, split into reference window (oldest) and current window (newest). Sizes from `configs/mlops.yaml → drift.reference_window / current_window`.
3. **Compute four dimensions** (each toggleable in config):
   - **Prediction drift** — PSI over label distribution
   - **Class-distribution drift** — one-vs-rest binary PSI per class
   - **Confidence drift** — avg + p25 drop (proxy for performance loss when ground truth isn't available)
   - **Feature drift** — PSI over confidence buckets (full feature drift comes via Evidently HTML when installed)
4. **Severity decision** against the thresholds:
   - `psi > psi_critical` (default 0.25) → `critical` → "RETRAIN IMMEDIATELY"
   - `psi > psi_alert` (default 0.20) **or** confidence avg drop > `performance_drop_pct` (default 3%) → `alert` → "RETRAIN WITHIN 48H — PS Drift Alert SLA breach"
   - `psi > psi_warn` (default 0.10) → `warn` → "MONITOR"
   - otherwise → `ok`
5. **Persist.** JSON report to `mlops/drift_reports/<timestamp>/drift_report.json` + Evidently HTML if installed. Legacy `logs/drift_report.json` kept for the existing UI.
6. **Alert.** On `alert` or `critical`, append a JSON line to `logs/drift_alerts.jsonl` + stdout warning.

Verified end-to-end: `compute_drift_report(reference_window=20, current_window=10)` against the shipped 40-line audit log produced PSI=1.45, fired a critical alert, wrote both the report and the alert log line.

---

## 5. Webhook flow

```
classify() → final result dict
     │
     ▼
webhooks.dispatch_classification_event(final)
     │
     ▼
enabled()?  ──no──► return None  (no-op)
     │ yes
     ▼
build_payload(final)  ─── only masked fields, never raw text
     │                    {event_id, document{doc_id,label,confidence,
     │                     policy_action,evidence_tokens,masked_snippet,
     │                     detected_language},audit{model_version,
     │                     preprocessing_version,feature_version,...}}
     ▼
ThreadPoolExecutor.submit(_dispatch_payload, payload)   ◄── non-blocking
     │
     ▼
_route_endpoints(policy_action)   →   list[endpoint_name]
     │ for each routed endpoint
     ▼
_deliver_one(name, cfg, payload)
     │
     ├─ build headers: Content-Type, X-DataShield-Request-Id,
     │                 X-API-Key (if set), X-DataShield-Signature (if hmac)
     ├─ for attempt in 1..max_retries:
     │     POST url, timeout=timeout_seconds
     │     2xx → success, break
     │     4xx (≠408,429) → permanent fail, break
     │     5xx / network → sleep backoff*2^(attempt-1), retry
     └─ append result to logs/webhook_deliveries.jsonl
        if not success → also append to logs/webhook_dead_letter.jsonl
```

Verified end-to-end with a local receiver:
- ✅ Successful delivery + payload structure
- ✅ HMAC-SHA256 signature matches `sha256=<hex>`
- ✅ X-API-Key header sent
- ✅ Request-Id correlates `event_id` ↔ delivery log
- ✅ 500-failing endpoint → 2 retries → DLQ entry
- ✅ `replay_dead_letter()` re-delivers and removes from DLQ

Replay is idempotent at the application layer (event_id stays constant across replays).

---

## 6. Champion/challenger flow

```
train_all.py finishes one language
     │
     ▼
mlops.log_experiment(run_name, params, metrics,        ─── MLflow + JSONL fallback
                     class_metrics, confusion_matrix,      with class-wise + CM artifact
                     dataset_path, vectorizer_path)
     │                                                     dataset/vectorizer SHA-256
     ▼                                                     recorded as tags
mlops.register_model(version, metrics, mode='challenger',
                     artifact_dir=lang_dir, tags={...})
     │
     ▼
mlops.mark_retraining_complete(version, metrics, notes)  ─── resets monthly trigger
     │
     ▼ ─ operator reviews via /mlops/champion + /mlops/registry
     ▼ ─ operator calls POST /mlops/promote
     │
     ▼
mlops.promote_challenger()
     │
     ├─ champ_score = current champion's promote_metric  (default: f1_macro)
     ├─ chall_score = challenger's promote_metric
     ├─ if chall_score - champ_score >= promote_min_delta (default 0.005):
     │     demote champion → history, challenger → champion, clear challenger
     │     return True
     └─ else: keep champion, log no-promotion, return False
     │
     ▼
NEXT PIPELINE STARTUP:
     │
     ▼
pipeline._resolve_model_version()
     │
     ├─ if registry.champion exists AND auto_load_champion: use champion.version
     └─ else: use hardcoded MODEL_VERSION
     │
     ▼
self.model_version  ─── stamped on every audit line + webhook payload
```

Promotion is **manual** by design (Constraint C4: dual-approval). The system only auto-registers as challenger; humans drive the promotion.

---

## 7. Retraining flow

Three triggers, all funneling into the same dual-approval gate:

```
TRIGGER 1: Monthly        TRIGGER 2: Drift critical     TRIGGER 3: Manual
─────────────              ─────────────────              ──────────────
scheduler_tick()           compute_drift_report()         POST /mlops/trigger-retraining
days_since_last_           drift_critical OR              (operator clicks button)
training >= 30             alert_sla_breach
   │                          │                              │
   └──────┬───────────────────┴──────────────────────────────┘
          │
          ▼
   mlops.trigger_retraining(reason, requested_by, auto)
          │
          ├─ logs/retraining_state.json    state = pending_trigger=True
          └─ logs/retraining_history.jsonl event=retraining_requested,
                                            status=pending_approval
          │
          ▼ ── HUMAN dual-approval (Legal + DataGov) ──
          │
          ▼
   python -m scripts.train_all  ──► loops _train_one_language()
                                    └─ calls mlops.log_experiment(...)
                                    └─ calls mlops.register_model(challenger)
                                    └─ calls mlops.mark_retraining_complete(...)
                                       │
                                       ▼
                                logs/retraining_history.jsonl
                                  event=retraining_completed,
                                  model_version, metrics, notes
                                │
                                ▼
                          state.pending_trigger=False
                          state.last_training_utc=now
                          (monthly clock resets)
```

The override-driven retraining trigger in `active_learning.py` is preserved and now sits alongside the three triggers above — they're complementary, not duplicative.

---

## 8. Audit logging flow

```
pipeline.predict() builds result dict
     │
     ▼
self.audit.log(text, result, model_version=self.model_version)
     │
     ├──► utils/pii_masker.safe_snippet(text)  ─── masks SSN/CARD/IBAN/PAN/
     │                                              AADHAAR/EMAIL/PHONE/DOB
     │
     ├──► append to logs/audit.jsonl, one JSON line, sort_keys=true
     │       {timestamp_utc, doc_id,
     │        model_version, preprocessing_version, feature_version,
     │        input_snippet_masked, label, confidence,
     │        class_probabilities, policy_trace, policy_action (canonical UPPER),
     │        model_contributions, evidence_count}
     │
     └──► if include_evidence_tokens: persist explanation
            └──► append to logs/explanations.jsonl
                  {doc_id, timestamp_utc, model_version, ...,
                   label, confidence, class_probabilities,
                   evidence_top_k[{token,weight,source}],
                   confidence_explanation{level,top_class,top_prob,
                                          runner_up_class, runner_up_prob,
                                          margin, narrative}}
```

PII is **masked at the write boundary** — the classifier and policy engine see raw text (they need PII patterns to make correct decisions), but nothing PII-containing ever lands on disk. Two complementary maskers: Presidio (upstream, semantic) + this regex masker (defensive, write-side).

---

## 9. How to run / test

### Standalone modules

```bash
cd datashield/

# 1. Verify MLOps config loads
python -c "from utils.mlops_config import get_mlops_config; print(get_mlops_config().drift.thresholds.psi_alert)"

# 2. Run the MLOps CLI — registers a champion, runs a drift check, ticks scheduler, logs an experiment
python mlops.py

# 3. Verify webhook endpoints config + routing (no network calls)
python webhooks.py

# 4. Run the existing test suite (one pre-existing Hindi-lexical-fallback test
#    is expected to fail; everything else passes)
python -m pytest tests/ --deselect tests/test_end_to_end.py::test_every_prediction_has_min_3_evidence_tokens -q
```

### Full stack

```bash
# 5. Start the API + UI as usual — nothing about run.py changed
python run.py
# → API at http://localhost:8000
# → UI  at http://localhost:8501
```

### Try the new endpoints

```bash
# Champion
curl http://localhost:8000/mlops/champion

# Force a scheduler tick (cron-friendly)
curl -X POST http://localhost:8000/mlops/scheduler/tick

# Compute fresh drift report (writes mlops/drift_reports/<timestamp>/)
curl http://localhost:8000/mlops/drift

# Pull recent drift alerts
curl http://localhost:8000/mlops/drift-alerts

# View persisted explanations for the last 5 classifications
curl 'http://localhost:8000/mlops/explanations?limit=5'

# View MLOps config (with secrets redacted)
curl http://localhost:8000/mlops/config

# Webhook status (lists configured endpoints, redacts secrets)
curl http://localhost:8000/webhooks/status

# Fire a synthetic event at one endpoint
curl -X POST http://localhost:8000/webhooks/test \
     -H 'Content-Type: application/json' \
     -d '{"endpoint":"allow_endpoint","sample_action":"ALLOW"}'

# Replay all dead-lettered events
curl -X POST http://localhost:8000/webhooks/replay
```

### Enable webhooks for real

Edit `configs/webhooks.yaml`:
```yaml
endpoints:
  quarantine_endpoint:
    url: https://your-dlp.example.com/events
    enabled: true
    api_key: "prod-key-from-vault"
    hmac_secret: "prod-hmac-from-vault"
```

Then flip the master switch in `configs/mlops.yaml`:
```yaml
webhooks:
  enabled: true
```

Or — for prod where secrets shouldn't sit in YAML — set:
```bash
export DATASHIELD_WEBHOOK__quarantine_endpoint__API_KEY="prod-key"
export DATASHIELD_WEBHOOK__quarantine_endpoint__HMAC_SECRET="prod-hmac"
```

### Verifying the integration

Every successful `POST /classify` response now carries a `webhook_event_id` field when webhooks are enabled. Use that to trace the delivery in `logs/webhook_deliveries.jsonl` or via `GET /webhooks/deliveries`.

A receiver verifies the signature like this (Python):
```python
import hmac, hashlib
expected = 'sha256=' + hmac.new(SECRET.encode(), body_bytes, hashlib.sha256).hexdigest()
if not hmac.compare_digest(expected, request.headers['X-DataShield-Signature']):
    return 401
```

---

## 10. Backward compatibility

- **No existing test breaks because of these changes.** Original suite: 44 passed, 1 pre-existing failure (Hindi short-text evidence-count). Same failure exists on the unmodified baseline.
- **No existing API response schema changes.** Every previously documented field is still in the response, in the same key location. New fields (`webhook_event_id`) are additive and only appear when webhooks are enabled.
- **No existing endpoint URL changes.** All 5 previous `/mlops/*` endpoints still work; 14 new endpoints sit alongside them.
- **No existing config files changed.** `model.yaml` and `policy.yaml` are byte-identical to the original. The two new config files are additive.
- **No new infra.** No Docker, Kafka, Celery, Redis, Airflow, K8s. The webhook executor is a 4-worker thread pool inside the FastAPI process — when the process exits, the executor drains via the shutdown hook.

---

*All claims in this report are backed by smoke tests run against the upgraded codebase before packaging.*
