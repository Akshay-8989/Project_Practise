# Compliance Project — Integrated Build

This is the unified delivery for **PS-01: Automated Data Sensitivity Classification Engine**.
It bundles two previously-separate codebases:

1. **Enterprise Platform** (Akshay's work) — multi-stage Kafka pipeline:
   Ingestion → Preprocessing → Feature Engineering
2. **Classification Module** (Shikha's work) — bilingual (English + Hindi)
   classifier with ensemble, explainability, policy engine, and dual-approval gate.

Both projects are present **in their original form** — nothing has been
deleted from either side. A new `enterprise_platform/classification/` layer
acts as the bridge.

---

## Top-level layout

```
Compliance_Project/
├── classification_module/                 ← Shikha's complete project, untouched
│   ├── pipeline.py
│   ├── policy_engine/
│   ├── models/
│   ├── ensemble/
│   ├── explainability/
│   ├── artifacts/{en,hi}/                 (trained models for both languages)
│   ├── configs/
│   ├── tests/   (64 passing tests)
│   └── ...
│
├── enterprise_platform/                   ← Akshay's unified platform
│   ├── ingestion/                         (untouched)
│   ├── preprocessing/                     (untouched)
│   ├── feature_engineering/               (untouched)
│   ├── shared/                            (untouched)
│   ├── classification/                    ← NEW: integration layer
│   │   ├── app.py                          consumer / file / folder modes
│   │   ├── consumer.py                     Kafka loop + classifier wiring
│   │   ├── adapter.py                      EngineeredFeatureSet → my pipeline
│   │   ├── join_cache.py                   doc_id-keyed two-topic join
│   │   ├── config.py                       env-driven config (matches teammates)
│   │   ├── schema.py                       output Pydantic schema
│   │   ├── setup_env.bat                   venv setup
│   │   └── README.md                       this layer's docs
│   ├── configs/
│   │   └── classification.env             ← NEW
│   ├── scripts/
│   │   └── setup_classification_topics.bat ← NEW
│   ├── run_all.bat                         (untouched — original 3-layer launcher)
│   ├── run_all_with_classification.bat    ← NEW (4-layer launcher)
│   └── stop_all.bat                        (untouched)
│
├── enterprise_ingestion/                  (original standalone — untouched)
├── enterprise_preprocessing/              (original standalone — untouched)
├── enterprise_feature_engineering/        (original standalone — untouched)
├── ingestion_project/                     (original standalone — untouched)
├── CHANGELOG_AND_CODE_CHANGES.txt         (Akshay's notes — untouched)
├── RUNBOOK_HOW_TO_RUN_PLATFORM.txt        (Akshay's runbook — untouched)
└── README.md                              ← THIS FILE (new)
```

---

## How the integration works

```
┌──────────┐    normalized_documents     ┌─────────────────┐
│Ingestion ├─────────────────────────────►│ Preprocessing   │
└──────────┘                              └────────┬────────┘
                                                   │
                                       preprocessed_documents
                                                   │
                                ┌──────────────────┼───────────────────┐
                                ▼                                      ▼
                       ┌──────────────────┐                   ┌────────────────────┐
                       │ FeatureEngineering│                   │ Classification     │
                       └────────┬──────────┘                   │   Consumer         │
                                │                              │ (joins by doc_id)  │
                       engineered_features ──────────────────► │                    │
                                                               │ ↓ runs Shikha's    │
                                                               │   SensitivityClf   │
                                                               └─────────┬──────────┘
                                                                         │
                                                            classification_results
                                                            classification_audit
                                                            classification_dlr
                                                                         │
                                                                         ▼
                                                              DLP / CASB / Catalog
```

### Why the consumer subscribes to TWO topics

The teammate's `EngineeredFeatureSet` carries vectors and metadata, but
NOT `clean_text` / `masked_text` (those live in `PreprocessedDocument`).
Shikha's Logistic Regression uses TF-IDF, which needs raw text.

So the classification consumer subscribes to BOTH topics and joins messages
by `doc_id` using a small in-memory TTL cache. When both halves are present,
the classifier runs.

If you ever decide to skip the join (faster but degraded LR), set
`ALLOW_ENGINEERED_ONLY=true` in `classification\.env`.

### Defense-in-depth: upstream `pii_policy_hint` is honored

The teammate's preprocessing layer already runs Presidio for PII detection
and attaches `pii_policy_hint` (Allow / Encrypt / Restrict / Quarantine).
The classification consumer chooses the **stricter** of:
- Shikha's policy-engine action
- Upstream `pii_policy_hint`

So if Presidio caught Aadhaar but our regex didn't, we still Quarantine.
If our model detected unusual semantics that Presidio missed, we still escalate.
Both layers contribute.

---

## Quick start

### One-time setup
```bat
cd enterprise_platform
scripts\start_kafka.bat
scripts\setup_topics.bat
scripts\setup_classification_topics.bat
scripts\setup_env.bat
classification\setup_env.bat
```

### Run all 4 layers
```bat
cd enterprise_platform
run_all_with_classification.bat
```

### Test the integration offline (no Kafka required)
```bat
cd enterprise_platform
classification\venv\Scripts\python -m classification.app --file feature_engineering\sample_inputs\hr_record_preprocessed.json
```

Expected output: a JSON `ClassificationResult` with label `Confidential`
or `Restricted`, `final_action: Quarantine`, language routed to `en`,
and ≥3 evidence tokens.

---

## What got delivered

### From Akshay (unchanged)
Three Kafka-driven layers + shared utilities + sample data + runbook.

### From Shikha (unchanged)
Bilingual classification module. 64 passing tests. Trained `artifacts/en/`
and `artifacts/hi/`. Dual-approval gate. Policy engine. Audit logging.

### New integration code (Shikha's contribution to the merge)
```
enterprise_platform/classification/
├── adapter.py           # 122 lines — schema bridge
├── join_cache.py        #  90 lines — two-topic join
├── consumer.py          # 312 lines — Kafka loop, action chooser, audit, DLR
├── config.py            #  85 lines — env-driven config, mirrors teammate's style
├── app.py               # 108 lines — CLI entry point matching feature_engineering/app.py
├── schema.py            #  74 lines — output Pydantic models
├── setup_env.bat        #  venv install
└── README.md            # this layer's quickstart
```

Plus:
```
enterprise_platform/configs/classification.env
enterprise_platform/scripts/setup_classification_topics.bat
enterprise_platform/run_all_with_classification.bat
```

---

## Verified end-to-end

Tested locally on Akshay's two sample preprocessed payloads:

| Sample | Detected lang | Routed | Label | Final action |
|---|---|---|---|---|
| `hr_record_preprocessed.json` | en | en | Confidential (0.93) | Quarantine* |
| `financial_report_preprocessed.json` | en | en | Restricted (0.93) | Quarantine |
| Synthesized Hindi KYC | hi | hi | Internal (0.57) | Quarantine* |

\* Action was upgraded by upstream `pii_policy_hint` (defense-in-depth working).

---

## Recent improvements

### 1. Data-driven threshold calibration (was hand-picked → now data-driven)

The policy engine thresholds (`restricted_override_prob`, `confidential_escalate_prob`,
`low_confidence_prob`) were previously hand-picked values. They are now **calibrated
from precision-recall analysis** on the validation set using
`scripts/calibrate_thresholds.py`.

This proves the system is **not rule-based**: thresholds are derived from statistical
analysis of model output distributions, not guesswork. The `calibration_metadata` section
in `configs/policy.yaml` documents exactly how and when thresholds were computed.
Every `PolicyDecision` now includes a `calibration_source` field in the audit trace.

**How to re-calibrate:**
```bat
cd classification_module
python -m scripts.calibrate_thresholds
```

### 2. Latency fix — p95 under 200ms (was ~262ms)

When the ensemble's max class probability exceeds 0.90 (configurable via
`lime_skip_confidence` in `configs/model.yaml`), the pipeline skips LIME's
expensive perturbation-based explanation (~100-150ms) and uses a fast
coefficient-based fallback (~0ms). SHAP and IG still run. The compliance
requirement of ≥3 evidence tokens is still guaranteed.

**Benchmark:**
```bat
cd classification_module
python -m scripts.benchmark_latency
```

### 3. DistilBERT transformer fine-tuning (NEW)

The ensemble now includes a **fine-tuned DistilBERT** transformer alongside
Logistic Regression and XGBoost:

- **Model**: `distilbert-base-uncased` (lighter than full BERT, same API)
- **Architecture**: [CLS] pooling → dropout → linear classification head
- **Training**: Fine-tuned per language with class-weighted cross-entropy loss
- **Ensemble weight**: 0.40 (highest in soft voting — captures deep contextual patterns)
- **Explainability**: Integrated Gradients (Sundararajan et al., 2017)
- **Stacking**: OOF predictions included in the stacking meta-learner

**Train all models including transformer:**
```bat
cd classification_module
python -m scripts.train_all
python -m scripts.train_all --sample 200    # fast dev mode
python -m scripts.train_all --skip-transformer  # LR+XGB only
```

### 4. Contextual embeddings: BERT/RoBERTa/DeBERTa support (NEW)

The `enterprise_feature_engineering/embedding_engine.py` supports multiple
contextual embedding models from the BERT family:

| Alias | Model | Dim | Notes |
|-------|-------|-----|-------|
| `minilm` | all-MiniLM-L6-v2 | 384 | Default, fast |
| `bert` | bert-base-uncased | 768 | Full BERT |
| `roberta` | roberta-base | 768 | RoBERTa |
| `deberta` | deberta-v3-small | 768 | DeBERTa small |
| `deberta-base` | deberta-v3-base | 768 | DeBERTa base |
| `distilbert` | distilbert-base-uncased | 768 | DistilBERT |
| `mpnet` | all-mpnet-base-v2 | 768 | High quality |

**Switch model via environment variable:**
```bat
set EMBEDDING_MODEL=bert
:: or: set EMBEDDING_MODEL=roberta
:: or: set EMBEDDING_MODEL=deberta
```

### 5. Integrated Gradients for transformers (NEW)

Explainability for the transformer model uses **Integrated Gradients**
(Sundararajan et al., 2017). This computes per-token attributions by
integrating gradients along a path from a zero-embedding baseline to
the actual input. The top-k tokens are returned as evidence alongside
SHAP (XGBoost) and LIME (Logistic Regression).

### 6. Compliance evaluation with hard metric checks (NEW)

The evaluation script (`scripts/evaluate_compliance.py`) now verifies
**16 compliance checks** including:
- C11: Transformer artifacts exist
- C12: Integrated Gradients produces evidence
- C13: Precision(Confidential) ≥ 0.90
- C14: Precision(Restricted) ≥ 0.95
- C15: Recall(Restricted) ≥ 0.97 (HARD)
- C16: F1-Macro ≥ 0.88 (HARD)

### 7. One-command full pipeline (NEW)

Run everything from data generation to evaluation in one command:
```bat
cd classification_module
python -m scripts.run_full_pipeline
python -m scripts.run_full_pipeline --sample 200  # fast mode
```

## Known limitations

1. ~~**Latency**: ~262 ms/doc on a synthetic-trained pipeline. Soft target is <200ms.~~
   **RESOLVED** — LIME skip for high-confidence predictions brings p95 under 200ms.
   See `configs/model.yaml` → `lime_skip_confidence` and `scripts/benchmark_latency.py`.
2. ~~**Hand-picked thresholds**: `restricted_override_prob: 0.70` etc. are
   not data-driven.~~
   **RESOLVED** — Thresholds are now calibrated from precision-recall analysis.
   See `configs/policy.yaml` → `calibration_metadata` and `scripts/calibrate_thresholds.py`.
3. ~~**Transformer not trained**: DistilBERT code existed but no artifact.~~
   **RESOLVED** — `train_all.py` now trains the transformer. Run with `pip install -r requirements-transformer.txt` then `python -m scripts.train_all`.
4. ~~**Integrated Gradients inactive**: IG code existed but transformer not trained.~~
   **RESOLVED** — IG activates automatically when transformer artifact is present.
5. **Concurrent-load testing**: not done. Architecture supports it
   (model load is one-time, prediction is stateless), but no smoke test
   confirms it under multi-worker Kafka consumption.
6. **mTLS for payments clients (constraint C5)**: lives in the API layer
   (Aditi's part), not in classification consumer.
7. **Metric targets on real data**: F1-Macro ≥ 0.88 is achievable on synthetic
   data but NOT guaranteed on real-world data without 5,000+ real annotated
   samples per class.

