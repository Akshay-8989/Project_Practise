"""
mlops.py
--------
Lightweight MLOps module (no Docker, no cloud):
- MLflow experiment tracking (local SQLite backend)
- Model registry (champion/challenger tracking via JSON)
- Evidently AI drift monitoring
- Monthly retraining trigger check

Run standalone: python mlops.py
"""
import os
import sys
import json
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, Any, List, Optional

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

REGISTRY_PATH = os.path.join(PROJECT_DIR, 'logs', 'model_registry.json')
DRIFT_LOG_PATH = os.path.join(PROJECT_DIR, 'logs', 'drift_report.json')
AUDIT_LOG_PATH = os.path.join(PROJECT_DIR, 'logs', 'audit.jsonl')
MLFLOW_TRACKING_URI = f"sqlite:///{os.path.join(PROJECT_DIR, 'logs', 'mlruns.db')}"

os.makedirs(os.path.join(PROJECT_DIR, 'logs'), exist_ok=True)


# ─────────────────────────────────────────────────────────────
# Model Registry
# ─────────────────────────────────────────────────────────────
def load_registry() -> Dict:
    if os.path.exists(REGISTRY_PATH):
        with open(REGISTRY_PATH) as f:
            return json.load(f)
    return {"champion": None, "challenger": None, "history": []}


def save_registry(reg: Dict):
    with open(REGISTRY_PATH, 'w') as f:
        json.dump(reg, f, indent=2)


def register_model(version: str, metrics: Dict[str, float], mode: str = "champion"):
    """Register a model version with its metrics."""
    reg = load_registry()
    entry = {
        "version": version,
        "metrics": metrics,
        "registered_at": datetime.now(timezone.utc).isoformat(),
        "status": mode,
    }
    if mode == "champion":
        if reg["champion"]:
            # Demote current champion to history
            reg["history"].append({**reg["champion"], "status": "retired"})
        reg["champion"] = entry
    else:
        reg["challenger"] = entry
    save_registry(reg)
    print(f"[mlops] Registered {mode}: {version} with metrics: {metrics}")
    return entry


def promote_challenger():
    """Promote challenger to champion if metrics are better."""
    reg = load_registry()
    if not reg["challenger"]:
        print("[mlops] No challenger to promote.")
        return False

    champ = reg["champion"]
    chall = reg["challenger"]

    champ_f1 = champ["metrics"].get("f1_macro", 0) if champ else 0
    chall_f1 = chall["metrics"].get("f1_macro", 0)

    if chall_f1 > champ_f1:
        print(f"[mlops] Promoting challenger (F1={chall_f1:.3f}) over champion (F1={champ_f1:.3f})")
        if champ:
            reg["history"].append({**champ, "status": "demoted"})
        reg["champion"] = {**chall, "status": "champion"}
        reg["challenger"] = None
        save_registry(reg)
        return True
    else:
        print(f"[mlops] Challenger (F1={chall_f1:.3f}) did not beat champion (F1={champ_f1:.3f}). No promotion.")
        return False


# ─────────────────────────────────────────────────────────────
# Drift Monitoring (Evidently AI primary, lightweight PSI fallback)
# ─────────────────────────────────────────────────────────────

DRIFT_HTML_PATH = os.path.join(PROJECT_DIR, 'logs', 'drift_report.html')


def compute_drift_report(reference_window: int = 50, current_window: int = 20) -> Dict:
    """
    Compute drift by comparing reference vs current windows of audit entries.

    Uses Population Stability Index (PSI) on the predicted label distribution
    plus a confidence-drop signal. If Evidently AI is installed, an HTML
    report is ALSO written to logs/drift_report.html for human inspection.
    """
    entries = _read_audit_log()
    min_needed = reference_window + current_window

    if len(entries) < min_needed:
        return {
            "status": "insufficient_data",
            "message": (
                f"Need at least {min_needed} records to compute drift "
                f"(reference_window={reference_window} + current_window={current_window}). "
                f"Have {len(entries)}. Classify more documents to generate signal."
            ),
            "records_available": len(entries),
            "records_needed": min_needed,
            "computed_at": datetime.now(timezone.utc).isoformat(),
        }

    from collections import Counter
    import math

    reference = entries[:reference_window]
    current = entries[-current_window:]

    ref_labels = Counter(e.get('label', 'Unknown') for e in reference)
    cur_labels = Counter(e.get('label', 'Unknown') for e in current)

    all_labels = set(ref_labels) | set(cur_labels)
    ref_total = sum(ref_labels.values()) or 1
    cur_total = sum(cur_labels.values()) or 1

    # PSI — Population Stability Index
    psi = 0.0
    for label in all_labels:
        ref_pct = (ref_labels.get(label, 0) + 1e-6) / ref_total
        cur_pct = (cur_labels.get(label, 0) + 1e-6) / cur_total
        psi += (ref_pct - cur_pct) * math.log(ref_pct / cur_pct)

    drift_detected = psi > 0.2
    drift_critical = psi > 0.25

    # Confidence drop
    ref_conf = [float(e.get('confidence', 0) or 0) for e in reference]
    cur_conf = [float(e.get('confidence', 0) or 0) for e in current]
    ref_avg_conf = sum(ref_conf) / len(ref_conf) if ref_conf else 0
    cur_avg_conf = sum(cur_conf) / len(cur_conf) if cur_conf else 0
    conf_drop = ref_avg_conf - cur_avg_conf

    report = {
        "computed_at": datetime.now(timezone.utc).isoformat(),
        "reference_window": reference_window,
        "current_window": current_window,
        "psi_score": round(psi, 4),
        "drift_detected": drift_detected,
        "drift_critical": drift_critical,
        "confidence_drop": round(conf_drop, 4),
        "alert_sla_breach": drift_critical,
        "label_distribution": {
            "reference": dict(ref_labels),
            "current": dict(cur_labels),
        },
        "avg_confidence": {
            "reference": round(ref_avg_conf, 4),
            "current": round(cur_avg_conf, 4),
        },
        "recommendation": (
            "RETRAIN IMMEDIATELY — distribution shift exceeds threshold"
            if drift_critical else
            "MONITOR — some drift detected" if drift_detected else
            "OK — no significant drift detected"
        ),
    }

    # Persist JSON
    with open(DRIFT_LOG_PATH, 'w') as f:
        json.dump(report, f, indent=2)

    # Try to generate an Evidently HTML report alongside it
    html_path = _maybe_write_evidently_html(reference, current)
    if html_path:
        report['html_report'] = html_path
    else:
        report['html_report'] = None

    return report


def _maybe_write_evidently_html(reference: List[Dict], current: List[Dict]) -> Optional[str]:
    """If Evidently is installed, generate an HTML drift report and return
    its path. If not, return None — the JSON report is still authoritative."""
    try:
        import pandas as pd
        # Evidently has had several API changes; we try the newer first.
        try:
            from evidently import Report
            from evidently.presets import DataDriftPreset
            new_api = True
        except ImportError:
            try:
                from evidently.report import Report
                from evidently.metric_preset import DataDriftPreset
                new_api = False
            except ImportError:
                return None
    except Exception:
        return None

    try:
        ref_df = pd.DataFrame([{
            'label': e.get('label'),
            'confidence': float(e.get('confidence', 0) or 0),
        } for e in reference])
        cur_df = pd.DataFrame([{
            'label': e.get('label'),
            'confidence': float(e.get('confidence', 0) or 0),
        } for e in current])

        report = Report(metrics=[DataDriftPreset()])
        if new_api:
            snapshot = report.run(reference_data=ref_df, current_data=cur_df)
            snapshot.save_html(DRIFT_HTML_PATH)
        else:
            report.run(reference_data=ref_df, current_data=cur_df)
            report.save_html(DRIFT_HTML_PATH)
        return DRIFT_HTML_PATH
    except Exception as e:
        print(f'[mlops] Evidently report generation failed: {e}')
        return None


def check_retraining_trigger(perf_drop_threshold: float = 0.03) -> Dict:
    """
    Check if monthly retraining should be triggered.
    Returns a dict with trigger status and reason.
    """
    entries = _read_audit_log()
    if not entries:
        return {"trigger": False, "reason": "No data available"}

    # Check time-based trigger (monthly)
    latest_ts = entries[-1].get('timestamp_utc', '')
    try:
        latest_dt = datetime.fromisoformat(latest_ts.replace('Z', '+00:00'))
        days_since = (datetime.now(timezone.utc) - latest_dt).days
        if days_since > 30:
            return {"trigger": True, "reason": f"Monthly trigger: {days_since} days since last log"}
    except Exception:
        pass

    # Check drift-based trigger
    drift = compute_drift_report()
    if drift.get('drift_critical'):
        return {
            "trigger": True,
            "reason": f"Drift trigger: PSI={drift.get('psi_score','?')} exceeds threshold",
            "drift_report": drift,
        }

    return {
        "trigger": False,
        "reason": "No retraining needed",
        "drift_report": drift,
    }


# ─────────────────────────────────────────────────────────────
# MLflow Experiment Tracking (local)
# ─────────────────────────────────────────────────────────────
def log_experiment(run_name: str, params: Dict, metrics: Dict, tags: Optional[Dict] = None):
    """Log a training run to local MLflow."""
    try:
        import mlflow
        mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
        mlflow.set_experiment("sensitivity_classification")
        with mlflow.start_run(run_name=run_name):
            mlflow.log_params(params)
            mlflow.log_metrics(metrics)
            if tags:
                mlflow.set_tags(tags)
        print(f"[mlops] Logged run '{run_name}' to MLflow at {MLFLOW_TRACKING_URI}")
        return True
    except ImportError:
        print("[mlops] MLflow not installed — skipping experiment logging")
        # Fallback: log to JSON
        _fallback_log_experiment(run_name, params, metrics, tags)
        return False


def _fallback_log_experiment(run_name: str, params: Dict, metrics: Dict, tags: Optional[Dict] = None):
    """Fallback experiment logging when MLflow is not installed."""
    log_path = os.path.join(PROJECT_DIR, 'logs', 'experiments.jsonl')
    entry = {
        "run_name": run_name,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "params": params,
        "metrics": metrics,
        "tags": tags or {},
    }
    with open(log_path, 'a') as f:
        f.write(json.dumps(entry) + '\n')
    print(f"[mlops] Logged run to {log_path}")


# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────
def _read_audit_log() -> List[Dict]:
    if not os.path.exists(AUDIT_LOG_PATH):
        return []
    entries = []
    with open(AUDIT_LOG_PATH) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except Exception:
                    pass
    return entries


# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print("=" * 60)
    print("MLOps Module — Sensitivity Classification Engine")
    print("=" * 60)



    print("\n[2] Retraining Trigger Check:")
    trigger = check_retraining_trigger()
    print(f"  Trigger: {trigger['trigger']} | Reason: {trigger['reason']}")

    print("\n[3] Drift Report:")
    drift = compute_drift_report()
    print(f"  Status: {drift.get('status', 'computed')}")
    if 'psi_score' in drift:
        print(f"  PSI Score: {drift['psi_score']} | Drift: {drift['drift_detected']}")
        print(f"  Recommendation: {drift['recommendation']}")

    print("\n[4] MLflow Experiment Logging (sample):")
    log_experiment(
        run_name="v3.0.0-baseline-check",
        params={"model": "LR+XGB+Stacking", "force_mode": "fast"},
        metrics={"f1_macro": 0.91, "precision_restricted": 0.97},
        tags={"language": "bilingual", "env": "local"},
    )

    print("\n✅ MLOps module check complete.")