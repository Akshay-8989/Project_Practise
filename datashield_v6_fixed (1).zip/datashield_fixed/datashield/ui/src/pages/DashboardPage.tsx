import { useState, useEffect, useRef } from 'react';
import {
  PieChart, Pie, Cell,
  Tooltip, ResponsiveContainer,
} from 'recharts';
import {
  AlertTriangle, FileText, Download,
  CheckCircle, Users, Calendar, Upload, X, FilePlus,
} from 'lucide-react';
import { logActivity, ActivityEntry } from '../App';
import { api } from '../lib/api';

interface Props { user: { name: string; email: string; role: string }; darkMode: boolean; }

const LABEL_COLORS: Record<string, string> = {
  Public: '#22c55e', Internal: '#3b82f6', Confidential: '#f59e0b', Restricted: '#ef4444',
};

const labelStyle = (l: string) =>
  l === 'Restricted'   ? 'bg-rose-100 text-rose-700 border-rose-200'   :
  l === 'Confidential' ? 'bg-amber-100 text-amber-700 border-amber-200' :
  l === 'Internal'     ? 'bg-blue-100 text-blue-700 border-blue-200'    :
                         'bg-emerald-100 text-emerald-700 border-emerald-200';

// ── Compliance frameworks: PCI-DSS, GDPR, CCPA ─────────────────────────────
const COMPLIANCE = [
  {
    framework: 'PCI-DSS',
    description: 'Payment Card Industry Data Security Standard',
    score: 91, status: 'green',
    checks: [
      { item: 'Cardholder data (PAN) detection active',   pass: true  },
      { item: 'Card numbers Luhn-validated before flag',  pass: true  },
      { item: 'Restricted label enforced on card data',   pass: true  },
      { item: 'Dual approval for card-data documents',    pass: true  },
      { item: 'Audit log retention ≥ 12 months',         pass: false },
    ],
  },
  {
    framework: 'GDPR',
    description: 'General Data Protection Regulation (EU)',
    score: 94, status: 'green',
    checks: [
      { item: 'PII detection coverage (Aadhaar, SSN…)',  pass: true  },
      { item: 'DSAR retrieval supported (<72h)',         pass: true  },
      { item: 'Dual approval for Restricted docs',       pass: true  },
      { item: 'Immutable, PII-masked audit log',         pass: true  },
      { item: 'Right-to-erasure workflow',               pass: false },
    ],
  },
  {
    framework: 'CCPA',
    description: 'California Consumer Privacy Act',
    score: 78, status: 'amber',
    checks: [
      { item: 'Consumer data identifiable & tagged',     pass: true  },
      { item: 'Opt-out signals propagated to pipeline',  pass: false },
      { item: 'Data sale disclosure documented',         pass: false },
      { item: 'Access request response workflow',        pass: true  },
      { item: 'Third-party sharing controls in place',   pass: true  },
    ],
  },
];

const RETENTION_DAYS = 180;

// ── KPI card ─────────────────────────────────────────────────────────────────
function KPICard({ icon: Icon, label, value, sub, color }: {
  icon: React.ComponentType<any>; label: string; value: string; sub: string; color: string;
}) {
  return (
    <div className="bg-white dark:bg-gray-900 border border-slate-200 dark:border-gray-800 rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">{label}</span>
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${color}`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <div className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums">{value}</div>
      <div className="text-xs text-slate-500 mt-1">{sub}</div>
    </div>
  );
}

function ScoreBadge({ score, status }: { score: number; status: string }) {
  const cls = status === 'green' ? 'text-emerald-700 bg-emerald-50 border-emerald-200' :
              status === 'amber' ? 'text-amber-700 bg-amber-50 border-amber-200' :
              'text-rose-700 bg-rose-50 border-rose-200';
  return <span className={`text-sm font-bold px-2.5 py-1 rounded-lg border ${cls}`}>{score}%</span>;
}

// ── Compute dept breakdown from real history entries ──────────────────────────
function buildDeptData(entries: any[]) {
  const map: Record<string, { Restricted: number; Confidential: number }> = {};
  for (const e of entries) {
    const dept = e.department || e.source_system || 'Unknown';
    if (!map[dept]) map[dept] = { Restricted: 0, Confidential: 0 };
    if (e.label === 'Restricted')   map[dept].Restricted++;
    if (e.label === 'Confidential') map[dept].Confidential++;
  }
  return Object.entries(map)
    .map(([dept, v]) => ({ dept, ...v }))
    .sort((a, b) => b.Restricted - a.Restricted)
    .slice(0, 8);
}

// ── Document Comparison — real upload + URL + GDrive ─────────────────────────
function DocumentCompare() {
  type DocResult = {
    id: string; name: string; label: string; confidence: number;
    action: string; evidence: string[]; pii: boolean; lang: string;
  };

  const [leftResult,  setLeftResult]  = useState<DocResult | null>(null);
  const [rightResult, setRightResult] = useState<DocResult | null>(null);
  const [leftLoading,  setLeftLoading]  = useState(false);
  const [rightLoading, setRightLoading] = useState(false);
  const [leftError,  setLeftError]  = useState('');
  const [rightError, setRightError] = useState('');
  const leftRef  = useRef<HTMLInputElement>(null);
  const rightRef = useRef<HTMLInputElement>(null);

  const extractGdriveId = (input: string) => {
    const m = input.match(/\/d\/([a-zA-Z0-9_-]+)/);
    return m ? m[1] : input.trim();
  };

  const classifyFile = async (file: File, side: 'left'|'right') => {
    const setLoading = side === 'left' ? setLeftLoading  : setRightLoading;
    const setResult  = side === 'left' ? setLeftResult   : setRightResult;
    const setError   = side === 'left' ? setLeftError    : setRightError;
    setLoading(true); setError('');
    try {
      const r = await api.classifyFile(file, {});
      setResult({
        id: r.doc_id, name: file.name,
        label: r.label, confidence: r.confidence,
        action: r.policy_action,
        evidence: r.evidence?.slice(0,3).map(e => e.token) || [],
        pii: !!(r.audit?.pii_flags && Object.keys(r.audit.pii_flags).length > 0),
        lang: r.language?.detected || 'en',
      });
    } catch { setError('Classification failed. Is the backend running?'); }
    setLoading(false);
  };



  const InputPane = ({ side }: { side: 'left'|'right' }) => {
    const loading = side === 'left' ? leftLoading : rightLoading;
    const error   = side === 'left' ? leftError   : rightError;
    const fileRef = side === 'left' ? leftRef     : rightRef;
    const result  = side === 'left' ? leftResult  : rightResult;

    return (
      <div className="flex-1 border border-slate-200 dark:border-gray-700 rounded-xl p-4 space-y-3">
        <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wide">
          Document {side === 'left' ? 'A' : 'B'}
        </label>

        <input ref={fileRef} type="file"
          accept=".pdf,.docx,.txt,.csv,.json,.html,.xlsx"
          className="hidden"
          onChange={e => { const f = e.target.files?.[0]; if (f) classifyFile(f, side); e.target.value=''; }} />
        <button onClick={() => fileRef.current?.click()} disabled={loading}
          className="w-full border-2 border-dashed border-slate-200 dark:border-gray-700 hover:border-slate-400 rounded-lg py-5 flex flex-col items-center gap-1.5 transition-colors group disabled:opacity-50">
          {loading
            ? <svg className="animate-spin w-5 h-5 text-blue-500" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/></svg>
            : <FilePlus className="w-5 h-5 text-slate-400 group-hover:text-slate-600" />}
          <span className="text-xs text-slate-500">{loading ? 'Classifying…' : 'Click to upload'}</span>
          <span className="text-[10px] text-slate-400">PDF · DOCX · TXT · CSV · JSON · HTML</span>
        </button>

        {error && <p className="text-[11px] text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-2 py-1.5">{error}</p>}

        {result && (
          <div className="border border-slate-200 dark:border-gray-700 rounded-lg p-3 space-y-2 bg-slate-50 dark:bg-gray-800">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">{result.name}</p>
                <p className="text-[11px] text-slate-400">{result.lang}</p>
              </div>
              <div className="flex items-center gap-1">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded border flex-shrink-0 ${labelStyle(result.label)}`}>{result.label}</span>
                <button onClick={() => side === 'left' ? setLeftResult(null) : setRightResult(null)}
                  className="text-slate-400 hover:text-slate-600"><X className="w-3 h-3" /></button>
              </div>
            </div>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between"><span className="text-slate-500">Confidence</span><span className="font-semibold text-slate-900 dark:text-white">{(result.confidence*100).toFixed(0)}%</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Policy action</span><span className="font-semibold text-slate-900 dark:text-white">{result.action}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">PII detected</span>
                <span className={`font-semibold ${result.pii?'text-rose-600':'text-emerald-600'}`}>{result.pii?'Yes':'No'}</span>
              </div>
            </div>
            {result.evidence.length > 0 && (
              <div>
                <p className="text-[10px] text-slate-400 mb-1">Evidence tokens</p>
                <div className="flex flex-wrap gap-1">
                  {result.evidence.map(e => (
                    <span key={e} className="text-[10px] px-1.5 py-0.5 bg-white dark:bg-gray-700 border border-slate-200 dark:border-gray-600 text-slate-600 dark:text-slate-300 rounded font-mono">{e}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  const diffLabel  = leftResult && rightResult && leftResult.label  !== rightResult.label;
  const diffAction = leftResult && rightResult && leftResult.action !== rightResult.action;
  const diffPII    = leftResult && rightResult && leftResult.pii    !== rightResult.pii;

  return (
    <div className="bg-white dark:bg-gray-900 border border-slate-200 dark:border-gray-800 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white">Side-by-Side Document Comparison</h2>
          <p className="text-xs text-slate-400">Upload, paste a URL, or link a Google Drive file — compare any two documents live</p>
        </div>
        {(diffLabel || diffAction || diffPII) && (
          <span className="text-xs font-semibold px-2.5 py-1 bg-amber-50 border border-amber-200 text-amber-700 rounded-lg">
            {[diffLabel && 'Label', diffAction && 'Action', diffPII && 'PII'].filter(Boolean).join(' · ')} differ
          </span>
        )}
      </div>
      <div className="flex gap-3">
        <InputPane side="left"  />
        <InputPane side="right" />
      </div>
    </div>
  );
}

// ── Main Dashboard ────────────────────────────────────────────────────────────
export default function DashboardPage({ user, darkMode }: Props) {
  const [metrics,     setMetrics]     = useState<any>(null);
  const [histEntries, setHistEntries] = useState<any[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityEntry[]>([]);
  const [scheduleMsg, setScheduleMsg] = useState('');
  const [loading,     setLoading]     = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [m, h] = await Promise.all([
          api.metrics(),
          api.history({ limit: 500 }),
        ]);
        setMetrics(m);
        setHistEntries(h.entries || []);

      } catch {
        setMetrics(null);
      }
      const raw = localStorage.getItem('ds_activity_log');
      if (raw) setActivityLog(JSON.parse(raw).slice(0, 50));
      setLoading(false);
    };
    load();
  }, []);

  // Build pie data from real metrics
  const labelDist = metrics?.label_distribution || {};
  const totalDocs = metrics?.total_classified || 0;
  const pieData = Object.entries(labelDist).map(([name, value]) => ({
    name, value: value as number,
    color: LABEL_COLORS[name] || '#94a3b8',
  }));

  // Dept breakdown from real history

  // Restricted count from real metrics
  const restrictedCount = labelDist['Restricted'] || 0;

  const exportCSV = () => {
    const header = 'DocID,Label,Confidence,Timestamp,Department\n';
    const rows = histEntries.map((e: any) =>
      `${e.doc_id},${e.label},${(e.confidence*100).toFixed(1)},${e.timestamp_utc},${e.department||''}`
    ).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a'); a.href = url;
    a.download = `datashield_report_${new Date().toISOString().slice(0,10)}.csv`;
    a.click(); URL.revokeObjectURL(url);
    logActivity(user, 'EXPORT', 'CSV compliance report downloaded', '/dashboard');
  };

  const scheduleMondayExport = () => {
    setScheduleMsg('✓ Weekly export scheduled — every Monday 08:00 IST');
    logActivity(user, 'SCHEDULE', 'Monday audit export scheduled', '/dashboard');
    setTimeout(() => setScheduleMsg(''), 4000);
  };


  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">Executive Dashboard</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Welcome back, {user.name} · {new Date().toLocaleDateString('en-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {scheduleMsg && (
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg">{scheduleMsg}</span>
          )}
          <button onClick={scheduleMondayExport}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
            <Calendar className="w-3.5 h-3.5" /> Schedule Export
          </button>
          <button onClick={exportCSV} disabled={loading || histEntries.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50">
            <Download className="w-3.5 h-3.5" /> Export CSV
          </button>
        </div>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-12">
          <svg className="animate-spin w-6 h-6 text-slate-400" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3"/>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
          </svg>
          <span className="ml-2 text-sm text-slate-500">Loading live data…</span>
        </div>
      )}

      {!loading && (
        <>
          {/* KPIs */}
          <div className="grid grid-cols-2 gap-4">
            <KPICard icon={FileText}      label="Total Classified"  value={totalDocs.toLocaleString()}
              sub="All-time documents"              color="bg-slate-700" />
            <KPICard icon={AlertTriangle} label="Restricted Docs"   value={restrictedCount.toLocaleString()}
              sub="Quarantine / dual-approval"      color="bg-rose-500" />
          </div>

          {/* Label distribution */}
          <div className="grid grid-cols-1 gap-4">
            {/* Label distribution — real data */}
            <div className="bg-white dark:bg-gray-900 border border-slate-200 dark:border-gray-800 rounded-xl p-5">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-white mb-4">Label Distribution</h2>
              {pieData.length === 0 ? (
                <div className="flex items-center justify-center h-40 text-sm text-slate-400">No classifications yet.</div>
              ) : (
                <>
                  <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" strokeWidth={0}>
                        {pieData.map((d, i) => <Cell key={i} fill={d.color} />)}
                      </Pie>
                      <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-2 mt-2">
                    {pieData.map(d => (
                      <div key={d.name} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                          <span className="text-slate-600 dark:text-slate-400">{d.name}</span>
                        </div>
                        <span className="font-semibold text-slate-900 dark:text-white tabular-nums">
                          {(d.value as number).toLocaleString()}
                          {totalDocs > 0 && <span className="text-slate-400 font-normal"> ({((d.value as number/totalDocs)*100).toFixed(0)}%)</span>}
                        </span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>

          </div>

          {/* Compliance scorecard — PCI-DSS, GDPR, CCPA */}
          <div className="bg-white dark:bg-gray-900 border border-slate-200 dark:border-gray-800 rounded-xl p-5">
            <div className="mb-4">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-white">Compliance Scorecard</h2>
              <p className="text-xs text-slate-400">PCI-DSS · GDPR · CCPA</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {COMPLIANCE.map(fw => (
                <div key={fw.framework} className="border border-slate-200 dark:border-gray-700 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-semibold text-slate-900 dark:text-white">{fw.framework}</span>
                    <ScoreBadge score={fw.score} status={fw.status} />
                  </div>
                  <p className="text-[11px] text-slate-400 mb-3">{fw.description}</p>
                  <div className="w-full bg-slate-100 dark:bg-gray-800 rounded-full h-1.5 mb-4">
                    <div className={`h-1.5 rounded-full transition-all ${
                      fw.status==='green'?'bg-emerald-500':fw.status==='amber'?'bg-amber-500':'bg-rose-500'
                    }`} style={{ width: `${fw.score}%` }} />
                  </div>
                  <div className="space-y-1.5">
                    {fw.checks.filter(c => c.pass).map((c, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <span className="text-slate-600 dark:text-slate-300">{c.item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Activity log — admin only */}
          {user.role === 'Admin' && <div className="grid grid-cols-1 gap-4">
            {/* Activity log — real session data */}
            <div className="bg-white dark:bg-gray-900 border border-slate-200 dark:border-gray-800 rounded-xl p-5">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-500" />
                  <h2 className="text-sm font-semibold text-slate-900 dark:text-white">User Activity Log</h2>
                </div>
                <button onClick={() => {
                  localStorage.removeItem('ds_activity_log');
                  setActivityLog([]);
                }} className="text-[11px] text-rose-500 hover:text-rose-700 font-medium transition-colors">
                  Clear
                </button>
              </div>
              <p className="text-xs text-slate-400 mb-4">Who did what, and when</p>
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {activityLog.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-8">No activity recorded yet.</p>
                ) : activityLog.map(e => (
                  <div key={e.id} className="flex items-start gap-2.5 text-xs">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-400 flex-shrink-0 mt-1.5" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-semibold text-slate-900 dark:text-white">{e.user}</span>
                        <span className="text-slate-400">·</span>
                        <span className={`font-mono text-[10px] px-1 rounded ${
                          e.action==='LOGIN'?'bg-emerald-100 text-emerald-700':
                          e.action==='LOGOUT'||e.action==='SESSION_TIMEOUT'?'bg-rose-100 text-rose-700':
                          'bg-slate-100 text-slate-600'
                        }`}>{e.action}</span>
                      </div>
                      <div className="text-slate-500 mt-0.5 truncate">{e.detail}</div>
                      <div className="text-slate-400 text-[10px]">{new Date(e.ts).toLocaleTimeString('en-IN')}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>}

          {/* Document comparison */}
          <DocumentCompare />
        </>
      )}
    </div>
  );
}
