# 🏦 GenAI Banking Policy & Compliance Copilot

RAG-based chatbot that answers questions from banking policy PDFs.
Uses **Phi-2 (local)** for generation and **TF-IDF** for embeddings — fully offline.

---

## ⚙️ Setup

### 1. Set your Phi-2 local path
Open `src/config.py` and update this line with the path to your Phi-2 folder:
```python
PHI2_MODEL_NAME = r"D:\phi-2"   # ← change this to your actual path
```
Your Phi-2 folder must contain: `config.json`, `tokenizer.json`, `model*.safetensors`

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the app
```bash
streamlit run app.py
```

---

## 🚀 How to use

1. Open `http://localhost:8501` in your browser
2. Upload a policy PDF using the **sidebar**
3. Wait for indexing (you'll see "X chunks indexed")
4. Type your question in the chat box and click **Send 🚀**
5. The answer appears above the input box with cited sources

---

## 🔧 Troubleshoot

Run the diagnostic script first if anything doesn't work:
```bash
python test_pipeline.py
```

### Common issues

| Problem | Fix |
|---|---|
| Still connecting to HuggingFace | Check `src/config.py` — `PHI2_MODEL_NAME` must be a local folder path like `r"D:\phi-2"` |
| No answer after submitting | Run `test_pipeline.py` and share the output |
| "Store is empty" error | Upload a PDF in the sidebar first |
| Phi-2 loads but answer is empty | Reduce `MAX_NEW_TOKENS` in `config.py` to `128` |

---

## 📁 Project Structure

```
compliance_copilot/
├── app.py                   ← Streamlit UI (run this)
├── test_pipeline.py         ← Diagnostic script
├── requirements.txt
│
├── src/
│   ├── config.py            ← All settings (set PHI2_MODEL_NAME here)
│   ├── document_processor.py
│   ├── vector_store.py      ← TF-IDF offline embeddings
│   ├── llm_engine.py        ← Phi-2 local inference
│   └── rag_pipeline.py      ← RAG orchestration
│
└── data/
    ├── uploads/             ← PDFs saved here
    └── vectorstore/         ← TF-IDF index saved here
```
