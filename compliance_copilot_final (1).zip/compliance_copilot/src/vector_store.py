"""
vector_store.py  –  FR3 (Embeddings) + FR4 (Storage) + FR6 (Retrieval)
Uses TF-IDF via scikit-learn — 100% offline, zero downloads, zero internet.
"""
from __future__ import annotations
import logging, pickle
from pathlib import Path
from typing import List, Tuple

logger = logging.getLogger(__name__)
INDEX_FILE = "tfidf_index.pkl"


class _Doc:
    def __init__(self, page_content: str, metadata: dict):
        self.page_content = page_content
        self.metadata     = metadata


def _expand_query(query: str) -> str:
    """Add banking synonyms so TF-IDF matches more relevant chunks."""
    q = query.lower()
    expansions = [query]
    if any(w in q for w in ["kyc","know your customer","identity","identification","id proof","verify"]):
        expansions.append("kyc know your customer identity verification document proof")
    if any(w in q for w in ["aml","money laundering","anti-money","suspicious","laundering"]):
        expansions.append("aml anti money laundering suspicious activity")
    if any(w in q for w in ["sar","suspicious activity","report","filing","file"]):
        expansions.append("sar suspicious activity report filing mlro")
    if any(w in q for w in ["risk","assessment","high risk","low risk","medium","cdd","edd"]):
        expansions.append("risk assessment customer due diligence cdd edd enhanced")
    if any(w in q for w in ["document","proof","certificate","passport","licence","id"]):
        expansions.append("documents required proof identity address passport licence")
    if any(w in q for w in ["threshold","limit","amount","usd","cash","transaction"]):
        expansions.append("threshold limit reporting amount cash transaction usd 10000")
    if any(w in q for w in ["penalty","fine","punishment","consequence","violation","enforcement"]):
        expansions.append("penalty fine enforcement consequences non-compliance violation")
    if any(w in q for w in ["record","retain","keep","store","how long","retention"]):
        expansions.append("record keeping retention period years store documents")
    if any(w in q for w in ["train","employee","staff","compulsory","mandatory","annual"]):
        expansions.append("training employees staff mandatory annual compliance")
    if any(w in q for w in ["sanction","ofac","blacklist","watchlist","screen"]):
        expansions.append("sanctions screening ofac watchlist blacklist")
    if any(w in q for w in ["pep","politically exposed","politician"]):
        expansions.append("pep politically exposed person enhanced due diligence")
    if any(w in q for w in ["fail","fails","reject","denied","not pass","unsuccessful"]):
        expansions.append("customer fails kyc check rejected denied account closure")
    if any(w in q for w in ["escalat","escalation","approval","senior","management"]):
        expansions.append("escalation approval senior management compliance officer")
    return " ".join(expansions)


class ComplianceVectorStore:
    def __init__(self, persist_dir: Path, embedding_model: str = None):
        self.persist_dir = Path(persist_dir)
        self.persist_dir.mkdir(parents=True, exist_ok=True)
        self._store = None
        self._load()

    @property
    def _index_path(self) -> Path:
        return self.persist_dir / INDEX_FILE

    def _load(self):
        if self._index_path.exists():
            try:
                with open(self._index_path, "rb") as f:
                    self._store = pickle.load(f)
                logger.info("Loaded index: %d chunks", len(self._store["texts"]))
            except Exception as e:
                logger.warning("Could not load index: %s", e)
                self._store = None

    def _save(self):
        with open(self._index_path, "wb") as f:
            pickle.dump(self._store, f)

    def add_documents(self, chunks) -> None:
        if not chunks:
            return
        new_texts = [c.text for c in chunks]
        new_metas = [{"source": c.source_file, "page": c.page_number,
                      "chunk_index": c.chunk_index, "doc_hash": c.doc_hash}
                     for c in chunks]
        all_texts = (self._store["texts"] + new_texts) if self._store else new_texts
        all_metas = (self._store["metadatas"] + new_metas) if self._store else new_metas

        from sklearn.feature_extraction.text import TfidfVectorizer
        vectorizer = TfidfVectorizer(
            max_features=8192, ngram_range=(1, 2),
            sublinear_tf=True, min_df=1, strip_accents="unicode",
        )
        matrix = vectorizer.fit_transform(all_texts)
        self._store = {"texts": all_texts, "metadatas": all_metas,
                       "matrix": matrix, "vectorizer": vectorizer}
        self._save()
        logger.info("Index saved: %d total chunks", len(all_texts))

    def similarity_search(self, query: str, k: int = 4) -> List[Tuple[_Doc, float]]:
        if self._store is None:
            raise RuntimeError("Vector store is empty. Upload a PDF first.")
        import numpy as np
        from sklearn.metrics.pairwise import cosine_similarity

        expanded = _expand_query(query)
        query_vec = self._store["vectorizer"].transform([expanded])
        scores    = cosine_similarity(query_vec, self._store["matrix"])[0]
        top_idx   = np.argsort(scores)[::-1][:k]

        # ALWAYS return top-k — never filter by score so every question gets an answer
        return [(_Doc(page_content=self._store["texts"][i],
                      metadata=self._store["metadatas"][i]),
                 max(float(scores[i]), 0.01))
                for i in top_idx]

    def document_count(self) -> int:
        return len(self._store["texts"]) if self._store else 0

    def reset(self):
        if self._index_path.exists():
            self._index_path.unlink()
        self._store = None
