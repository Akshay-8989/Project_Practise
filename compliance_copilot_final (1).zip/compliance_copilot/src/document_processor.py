"""
document_processor.py  –  FR1 (Upload) + FR2 (Text processing + chunking)
"""
from __future__ import annotations

import hashlib
import logging
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

logger = logging.getLogger(__name__)


@dataclass
class DocumentChunk:
    text:        str
    source_file: str
    page_number: int
    chunk_index: int
    doc_hash:    str
    metadata:    dict = field(default_factory=dict)


def _file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _clean_text(raw: str) -> str:
    text = raw.replace("\x00", "")
    text = re.sub(r"[\r\n]+", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", "-").replace("\u2014", "--")
    return text.strip()


def _split_into_chunks(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    if len(text) <= chunk_size:
        return [text] if text.strip() else []
    chunks, start = [], 0
    while start < len(text):
        end = start + chunk_size
        if end >= len(text):
            chunks.append(text[start:].strip())
            break
        search_start = max(start, end - chunk_size // 5)
        boundary = max(
            text.rfind(". ", search_start, end),
            text.rfind(".\n", search_start, end),
            text.rfind("\n\n",  search_start, end),
        )
        if boundary != -1:
            end = boundary + 1
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - chunk_overlap
    return chunks


def _extract_pages(pdf_path: Path) -> List[tuple]:
    try:
        import pdfplumber
        pages = []
        with pdfplumber.open(str(pdf_path)) as pdf:
            for i, page in enumerate(pdf.pages, start=1):
                pages.append((i, page.extract_text() or ""))
        return pages
    except ImportError:
        from pypdf import PdfReader
        reader = PdfReader(str(pdf_path))
        return [(i + 1, page.extract_text() or "") for i, page in enumerate(reader.pages)]


def load_and_chunk_pdf(
    pdf_path: Path,
    chunk_size: int = 512,
    chunk_overlap: int = 64,
) -> List[DocumentChunk]:
    logger.info("Processing: %s", pdf_path.name)
    doc_hash = _file_hash(pdf_path)
    pages    = _extract_pages(pdf_path)
    chunks   = []
    for page_no, raw in pages:
        clean = _clean_text(raw)
        if not clean:
            continue
        for idx, text in enumerate(_split_into_chunks(clean, chunk_size, chunk_overlap)):
            chunks.append(DocumentChunk(
                text=text, source_file=pdf_path.name,
                page_number=page_no, chunk_index=idx, doc_hash=doc_hash,
            ))
    logger.info("  → %d pages, %d chunks", len(pages), len(chunks))
    return chunks
