"""
config.py  –  Central configuration for the Compliance Copilot.
Changes from v3:
  - CHUNK_SIZE    512  → 1500  (keeps full sections + subsections together)
  - CHUNK_OVERLAP  64  → 200   (more overlap so no subsection header is lost)
  - TOP_K_RESULTS   4  → 6     (retrieve more chunks to cover subsections)
  - MAX_NEW_TOKENS 256 → 512   (longer answers to cover all subsection content)
"""
import os
from pathlib import Path

# ── Block ALL HuggingFace network calls ──────────────────────────────────────
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"]  = "1"
os.environ["HF_HUB_OFFLINE"]       = "1"

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).resolve().parent.parent
UPLOAD_DIR      = Path(os.getenv("UPLOAD_PATH",      str(BASE_DIR / "data" / "uploads")))
VECTORSTORE_DIR = Path(os.getenv("VECTORSTORE_PATH", str(BASE_DIR / "data" / "vectorstore")))

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
VECTORSTORE_DIR.mkdir(parents=True, exist_ok=True)

# ── Phi-2 Local Path ──────────────────────────────────────────────────────────
# !! SET THIS TO YOUR LOCAL PHI-2 FOLDER !!
PHI2_MODEL_NAME = os.getenv("PHI2_MODEL_NAME", r"D:\phi-2")

# ── Chunking ──────────────────────────────────────────────────────────────────
CHUNK_SIZE    = int(os.getenv("CHUNK_SIZE",    "1500"))   # v3 was 512
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "200"))    # v3 was 64

# ── Retrieval ─────────────────────────────────────────────────────────────────
TOP_K_RESULTS = int(os.getenv("TOP_K_RESULTS", "6"))      # v3 was 4

# ── Generation ────────────────────────────────────────────────────────────────
MAX_NEW_TOKENS = int(os.getenv("MAX_NEW_TOKENS", "512"))   # v3 was 256
TEMPERATURE    = float(os.getenv("TEMPERATURE",  "0.1"))

# ── EasyOCR ───────────────────────────────────────────────────────────────────
EASYOCR_LANGUAGES = ["en"]

# ── UI ────────────────────────────────────────────────────────────────────────
APP_TITLE = os.getenv("APP_TITLE", "Banking Policy & Compliance Copilot")
