"""
document_processor.py
---------------------
FR1 – Document Upload
FR2 – Document Processing: text + EasyOCR image extraction + chunking

Based exactly on v3. One addition: section-aware chunking.

The only change from v3 is in load_and_chunk_pdf():
  - Instead of splitting page-by-page with _split_into_chunks(),
    we now join ALL pages into one document string and split by
    top-level section headers (1. 2. 3. ... 12. 13.).
  - This keeps every section and ALL its subsections (12.1, 12.2)
    in the same chunk so questions about "section 12" return
    the full section including 12.1 and 12.2.
  - If a section group exceeds CHUNK_SIZE, it is split with overlap
    but the section header is always included in continuation chunks.
  - Image OCR chunks are unchanged from v3.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── Data model ────────────────────────────────────────────────────────────────

@dataclass
class DocumentChunk:
    text:        str
    source_file: str
    page_number: int
    chunk_index: int
    doc_hash:    str
    chunk_type:  str  = "text"
    metadata:    dict = field(default_factory=dict)


# ── Text utilities ────────────────────────────────────────────────────────────

def _file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _clean_text(raw: str) -> str:
    text = raw.replace("\x00", "")
    text = re.sub(r"[\r\n]+", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", "-").replace("\u2014", "--")
    return text.strip()


# ── v3 plain chunker (unchanged) ──────────────────────────────────────────────

def _split_into_chunks(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    """Exact v3 sliding-window split — used for image OCR text."""
    if len(text) <= chunk_size:
        return [text] if text.strip() else []
    chunks, start = [], 0
    while start < len(text):
        end = start + chunk_size
        if end >= len(text):
            chunk = text[start:].strip()
            if chunk:
                chunks.append(chunk)
            break
        search_start = max(start, end - chunk_size // 5)
        boundary = max(
            text.rfind(". ", search_start, end),
            text.rfind(".\n", search_start, end),
            text.rfind("\n\n", search_start, end),
        )
        if boundary != -1:
            end = boundary + 1
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - chunk_overlap
    return chunks


# ── NEW: section-aware chunker for document text ──────────────────────────────

def _split_by_sections(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    """
    Split document text respecting section boundaries.

    Finds top-level section headers like "12. Penalties" (NOT "12.1")
    and groups each section with ALL its subsections into one block.
    Result: asking about "12" returns content from 12, 12.1, and 12.2
    because they are all in the same chunk.

    If a section group is larger than chunk_size, splits it with overlap
    but always includes the parent section header in continuation chunks.
    Falls back to plain split if no section headers found.
    """
    if not text.strip():
        return []

    # Match only top-level: "12. Title" — single integer followed by . or )
    # This does NOT match "12.1" (subsections stay grouped with parent)
    top_re  = re.compile(r"(?m)^(\d{1,2})\s*[.)]\s+\S")
    matches = list(top_re.finditer(text))

    if not matches:
        return _split_into_chunks(text, chunk_size, chunk_overlap)

    # Build one group per top-level section (includes all subsections)
    groups = []
    for i, m in enumerate(matches):
        start = m.start()
        end   = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        g     = text[start:end].strip()
        if g:
            groups.append(g)

    # Split each group if necessary
    result = []
    for group in groups:
        if len(group) <= chunk_size:
            result.append(group)
        else:
            header = group.split("\n")[0].strip()
            parts  = _split_into_chunks(group, chunk_size, chunk_overlap)
            for j, part in enumerate(parts):
                if j > 0 and header and not part.startswith(header[:25]):
                    part = header + " (continued)\n" + part
                if part.strip():
                    result.append(part)

    return result if result else _split_into_chunks(text, chunk_size, chunk_overlap)


# ── EasyOCR (exactly v3) ──────────────────────────────────────────────────────

_easyocr_reader      = None
_ocr_available_cache: Optional[bool] = None


def _get_ocr_reader():
    global _easyocr_reader
    if _easyocr_reader is not None:
        return _easyocr_reader
    try:
        import easyocr
        from src.config import EASYOCR_LANGUAGES
        logger.info("Initialising EasyOCR (may download model ~100 MB on first run)…")
        _easyocr_reader = easyocr.Reader(EASYOCR_LANGUAGES, gpu=False, verbose=False)
        logger.info("EasyOCR ready.")
        return _easyocr_reader
    except Exception as e:
        logger.warning("EasyOCR unavailable: %s", e)
        return None


def _ocr_available() -> bool:
    global _ocr_available_cache
    if _ocr_available_cache is None:
        try:
            import easyocr  # noqa: F401
            _ocr_available_cache = True
        except ImportError:
            _ocr_available_cache = False
            logger.warning(
                "easyocr not installed. Image text extraction disabled. "
                "Run:  pip install easyocr"
            )
    return _ocr_available_cache


def _images_from_page(page) -> List[bytes]:
    images_bytes = []
    try:
        for img in page.images:
            try:
                x0, y0, x1, y1 = img["x0"], img["y0"], img["x1"], img["y1"]
                if (x1 - x0) < 50 or (y1 - y0) < 50:
                    continue
                cropped   = page.crop((x0, y0, x1, y1))
                pil_image = cropped.to_image(resolution=200).original
                import io
                buf = io.BytesIO()
                pil_image.save(buf, format="PNG")
                images_bytes.append(buf.getvalue())
            except Exception as e:
                logger.debug("Could not extract image from page: %s", e)
    except Exception as e:
        logger.debug("Image extraction skipped for page: %s", e)
    return images_bytes


def _ocr_image_bytes(img_bytes: bytes) -> str:
    reader = _get_ocr_reader()
    if reader is None:
        return ""
    try:
        import numpy as np
        from PIL import Image
        import io
        pil_img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        np_img  = np.array(pil_img)
        results = reader.readtext(np_img, detail=0, paragraph=True)
        text    = " ".join(str(r) for r in results)
        return _clean_text(text)
    except Exception as e:
        logger.debug("OCR failed for image: %s", e)
        return ""


def _extract_pages(pdf_path: Path):
    try:
        import pdfplumber
        with pdfplumber.open(str(pdf_path)) as pdf:
            for i, page in enumerate(pdf.pages, start=1):
                text      = page.extract_text() or ""
                ocr_texts = []
                if _ocr_available():
                    for img_bytes in _images_from_page(page):
                        ocr_text = _ocr_image_bytes(img_bytes)
                        if ocr_text and len(ocr_text) > 20:
                            ocr_texts.append(ocr_text)
                yield i, text, ocr_texts
    except ImportError:
        logger.warning("pdfplumber not found — falling back to pypdf (no image extraction).")
        from pypdf import PdfReader
        reader = PdfReader(str(pdf_path))
        for i, page in enumerate(reader.pages, start=1):
            yield i, (page.extract_text() or ""), []


# ── Public API ────────────────────────────────────────────────────────────────

def load_and_chunk_pdf(
    pdf_path:      Path,
    chunk_size:    int = 1500,
    chunk_overlap: int = 200,
) -> List[DocumentChunk]:
    """
    PDF → text + OCR images → section-aware chunking → DocumentChunk list.

    Key change from v3: text is now split section-by-section across the
    WHOLE document (not page-by-page) so that section 12 + 12.1 + 12.2
    are always in the same chunk.

    Image OCR chunks: unchanged from v3 (per-image, per-page).
    """
    logger.info("Processing PDF: %s", pdf_path.name)
    doc_hash     = _file_hash(pdf_path)
    all_chunks:  List[DocumentChunk] = []
    page_data:   List[tuple] = list(_extract_pages(pdf_path))
    text_count   = 0
    ocr_count    = 0

    # ── Text: section-aware split across whole document ───────────────────────
    full_text = "\n\n".join(
        _clean_text(raw) for _, raw, _ in page_data if raw.strip()
    )
    doc_chunks = _split_by_sections(full_text, chunk_size, chunk_overlap)

    for idx, chunk_text in enumerate(doc_chunks):
        if not chunk_text.strip():
            continue
        # Best-effort page number: find first page whose text contains chunk start
        best_page = 1
        snippet   = chunk_text[:50].replace("\n", " ")
        for page_no, raw, _ in page_data:
            if snippet[:30] in raw:
                best_page = page_no
                break
        text_count += 1
        all_chunks.append(DocumentChunk(
            text=chunk_text,
            source_file=pdf_path.name,
            page_number=best_page,
            chunk_index=idx,
            doc_hash=doc_hash,
            chunk_type="text",
        ))

    # ── Image OCR chunks: unchanged from v3 ──────────────────────────────────
    for page_no, _, ocr_texts in page_data:
        for img_idx, ocr_text in enumerate(ocr_texts):
            ocr_count += 1
            for idx, chunk in enumerate(
                _split_into_chunks(ocr_text, chunk_size, chunk_overlap)
            ):
                all_chunks.append(DocumentChunk(
                    text=f"[Image text, Page {page_no}]: {chunk}",
                    source_file=pdf_path.name,
                    page_number=page_no,
                    chunk_index=idx,
                    doc_hash=doc_hash,
                    chunk_type="image_ocr",
                    metadata={"image_index": img_idx},
                ))

    logger.info(
        "  → %d text chunks (section-aware), %d image OCR chunks, %d total",
        text_count, ocr_count, len(all_chunks),
    )
    return all_chunks


def ocr_status() -> dict:
    available = _ocr_available()
    return {
        "available": available,
        "message":   (
            "✅ EasyOCR enabled — text will be extracted from images inside PDFs"
            if available else
            "⚠️ EasyOCR not installed — only text extracted (no image OCR)\n"
            "   Fix: pip install easyocr"
        ),
    }
