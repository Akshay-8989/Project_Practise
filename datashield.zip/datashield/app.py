"""
app.py — Streamlit UI for DataShield Sensitivity Classification Engine
=======================================================================
Run:  streamlit run app.py
Or use run.py to start both the API and the UI together.

Pages:
  📄 Classify          — upload single/multi-file or paste text, with custom doc IDs
  🔍 Preview Layers    — see preprocessing (Layer 2) and features (Layer 3) before classifying
  📜 History           — browse past classifications, drill into details, human-in-the-loop
  ✅ Approvals         — Legal / DataGovernance dual-approval queue
  🔗 Webhooks          — DLP / CASB integration management
  📊 Metrics & MLOps   — KPI dashboard, retraining trigger, model registry
"""
from __future__ import annotations
import os
import sys
import json
import time
from datetime import datetime
from typing import List, Dict, Any, Optional

import requests
import pandas as pd
import streamlit as st

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

API_URL = os.environ.get('DATASHIELD_API_URL', 'http://localhost:8000')


# ─────────────────────────────────────────────────────────────
# Page config & styling
# ─────────────────────────────────────────────────────────────

st.set_page_config(
    page_title='DataShield — Sensitivity Classifier',
    page_icon='🔐',
    layout='wide',
    initial_sidebar_state='expanded',
)

st.markdown("""
<style>
.label-public      { background:#22c55e; color:#fff; padding:4px 14px; border-radius:20px; font-weight:700; font-size:14px;}
.label-internal    { background:#3b82f6; color:#fff; padding:4px 14px; border-radius:20px; font-weight:700; font-size:14px;}
.label-confidential{ background:#f59e0b; color:#fff; padding:4px 14px; border-radius:20px; font-weight:700; font-size:14px;}
.label-restricted  { background:#ef4444; color:#fff; padding:4px 14px; border-radius:20px; font-weight:700; font-size:14px;}

.action-allow     { color:#22c55e; font-weight:700; }
.action-encrypt   { color:#f59e0b; font-weight:700; }
.action-restrict  { color:#f97316; font-weight:700; }
.action-quarantine{ color:#ef4444; font-weight:700; }
.action-humanreview{ color:#7c3aed; font-weight:700; }

.evidence-box  { background:#f8fafc; border-left:3px solid #6366f1; padding:8px 14px; border-radius:6px; margin:4px 0;}
.pii-pill      { background:#fee2e2; color:#991b1b; padding:2px 10px; border-radius:12px; font-size:11px; margin-right:4px;}
.override-badge{ background:#7c3aed; color:#fff; padding:2px 10px; border-radius:12px; font-size:11px;}
.api-offline   { background:#fee2e2; border:1px solid #ef4444; padding:12px; border-radius:8px; color:#7f1d1d;}
.api-online    { background:#dcfce7; border:1px solid #22c55e; padding:8px 12px; border-radius:8px; color:#14532d;}
.muted         { color:#64748b; font-size:12px; }
.metric-good   { color:#16a34a; font-weight:700; }
.metric-bad    { color:#dc2626; font-weight:700; }
</style>
""", unsafe_allow_html=True)


LABEL_CLS = {
    'Public': 'label-public',
    'Internal': 'label-internal',
    'Confidential': 'label-confidential',
    'Restricted': 'label-restricted',
}
ACTION_CLS = {
    'Allow': 'action-allow', 'Encrypt': 'action-encrypt',
    'Restrict': 'action-restrict', 'Quarantine': 'action-quarantine',
    'HumanReview': 'action-humanreview',
}
ACTION_ICON = {
    'Allow': '✅', 'Encrypt': '🔒', 'Restrict': '🚫',
    'Quarantine': '⛔', 'HumanReview': '👤',
}


def label_badge(label: str) -> str:
    cls = LABEL_CLS.get(label or '', 'label-internal')
    return f'<span class="{cls}">{label or "?"}</span>'


def action_badge(action: str) -> str:
    cls = ACTION_CLS.get(action or '', 'action-restrict')
    icon = ACTION_ICON.get(action or '', '⚠️')
    return f'<span class="{cls}">{icon} {action or "?"}</span>'


# ─────────────────────────────────────────────────────────────
# API helpers
# ─────────────────────────────────────────────────────────────

def api_get(path: str, **params) -> Optional[Dict]:
    try:
        r = requests.get(f'{API_URL}{path}', params=params, timeout=30)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f'API error on GET {path}: {e}')
        return None


def api_post(path: str, json_body: Optional[Dict] = None,
             files=None, data=None, timeout: int = 60) -> Optional[Dict]:
    try:
        r = requests.post(f'{API_URL}{path}', json=json_body,
                          files=files, data=data, timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f'API error on POST {path}: {e}')
        return None


def api_delete(path: str) -> Optional[Dict]:
    try:
        r = requests.delete(f'{API_URL}{path}', timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f'API error on DELETE {path}: {e}')
        return None


def check_api_health() -> bool:
    try:
        r = requests.get(f'{API_URL}/health', timeout=2)
        return r.status_code == 200
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# Result renderer (shared between classify + history)
# ─────────────────────────────────────────────────────────────

def render_result(result: Dict[str, Any], index: int = 0):
    """Render a classification result card with all PS-01 outputs + HITL."""
    col1, col2, col3, col4 = st.columns([1.2, 1, 1, 1.4])
    with col1:
        st.markdown('**Label**', help='Sensitivity classification')
        st.markdown(label_badge(result.get('label')), unsafe_allow_html=True)
    with col2:
        conf = result.get('confidence', 0) or 0
        st.markdown('**Confidence**')
        st.markdown(f'**{conf:.1%}**')
    with col3:
        action = result.get('policy_action', '?')
        st.markdown('**Policy Action**', help='Recommended downstream action')
        st.markdown(action_badge(action), unsafe_allow_html=True)
    with col4:
        lat = result.get('latency_ms', {})
        total = lat.get('total') if isinstance(lat, dict) else lat
        st.markdown('**Latency**')
        st.markdown(f'{total:.1f} ms' if total is not None else '—')
        if isinstance(lat, dict) and total is not None:
            st.caption(f"pre {lat.get('preprocessing', 0):.0f} · feat {lat.get('features', 0):.0f} · clf {lat.get('classification', 0):.0f} ms")

    st.divider()

    # Probabilities bar chart
    probs = result.get('class_probabilities', {})
    if probs:
        st.markdown('**Class Probabilities**')
        df = pd.DataFrame({'class': list(probs.keys()), 'prob': list(probs.values())})
        st.bar_chart(df.set_index('class'), height=180)

    # Evidence tokens
    evidence = result.get('evidence', [])
    if evidence:
        st.markdown(f'**Evidence Tokens** ({len(evidence)} ≥ 3 ✅)')
        for e in evidence[:10]:
            tok = e.get('token', '?')
            wt = e.get('weight', 0)
            src = e.get('source', '?')
            st.markdown(
                f'<div class="evidence-box"><b>{tok}</b> · '
                f'<span class="muted">weight {wt:.3f} · {src}</span></div>',
                unsafe_allow_html=True,
            )
    else:
        st.warning('No evidence tokens.')

    # Policy trace
    with st.expander('🛡️ Policy Engine Trace'):
        trace = result.get('policy_trace', {})
        st.json(trace)

    # Preprocessing & features summary
    with st.expander('🔬 Preprocessing & Feature Summary'):
        pre = result.get('preprocessing', {})
        feat = result.get('features', {})
        c1, c2 = st.columns(2)
        with c1:
            st.markdown('**Preprocessing (Layer 2)**')
            st.write({k: v for k, v in pre.items() if k != 'metadata'})
        with c2:
            st.markdown('**Features (Layer 3)**')
            st.write(feat)

    # Model contributions
    model_contribs = result.get('model_contributions', {})
    if model_contribs:
        with st.expander('🤖 Model Contributions (per-class probability)'):
            df = pd.DataFrame.from_dict(model_contribs, orient='index',
                                        columns=['confidence'])
            st.dataframe(df, use_container_width=True)

    # Webhook delivery
    wd = result.get('webhooks_delivered')
    if wd is not None:
        st.caption(f'📡 {wd} webhook(s) delivered downstream.')

    # ── Human-in-the-Loop block ─────────────────────────────
    doc_id = result.get('doc_id', '')
    if doc_id:
        st.divider()
        st.markdown('### 👤 Human-in-the-Loop Review')
        st.caption('Confirm the model got it right, or correct the label if it didn\'t.')
        render_hitl(result, key_prefix=f'hitl_{index}_{doc_id[:8]}')


def render_hitl(result: Dict[str, Any], key_prefix: str):
    """Human-in-the-loop override form."""
    doc_id = result.get('doc_id')
    current = result.get('label', 'Internal')
    LABELS = ['Public', 'Internal', 'Confidential', 'Restricted']
    idx = LABELS.index(current) if current in LABELS else 1

    done_key = f'{key_prefix}_done'
    if st.session_state.get(done_key):
        st.success('✅ Review recorded.')
        return

    col1, col2 = st.columns([1, 1])
    with col1:
        corrected = st.selectbox(
            'Correct label',
            LABELS,
            index=idx,
            key=f'{key_prefix}_sel',
            help='Pick the label you believe is correct.',
        )
        reviewer = st.text_input(
            'Reviewer',
            value=st.session_state.get('reviewer_name', 'analyst@datashield'),
            key=f'{key_prefix}_rev',
        )
        st.session_state['reviewer_name'] = reviewer
    with col2:
        reason = st.text_area(
            'Reason / notes',
            placeholder='Optional — why is the correction needed?',
            key=f'{key_prefix}_reason',
            height=100,
        )

    ca, cb = st.columns([1, 1])
    with ca:
        if st.button('✅ Confirm Correct', key=f'{key_prefix}_confirm'):
            body = {
                'doc_id': doc_id,
                'original_label': current,
                'corrected_label': current,
                'reviewer': reviewer,
                'reason': reason or 'confirmed correct',
            }
            r = api_post('/override', body)
            if r:
                st.success('Confirmation recorded.')
                st.session_state[done_key] = True
                st.rerun()
    with cb:
        if st.button('✏️ Submit Correction', key=f'{key_prefix}_correct', type='primary'):
            if corrected == current:
                st.info('Same label — use "Confirm Correct" instead.')
            else:
                body = {
                    'doc_id': doc_id,
                    'original_label': current,
                    'corrected_label': corrected,
                    'reviewer': reviewer,
                    'reason': reason or '(no reason given)',
                }
                r = api_post('/override', body)
                if r:
                    st.success(f'Correction recorded: {current} → {corrected}')
                    st.session_state[done_key] = True
                    st.rerun()


# ─────────────────────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────────────────────

def render_sidebar() -> str:
    with st.sidebar:
        st.title('🔐 DataShield')
        st.caption('PS-01 · Sensitivity Classification Engine')
        st.divider()

        if check_api_health():
            st.markdown('<div class="api-online">🟢 API Online</div>', unsafe_allow_html=True)
        else:
            st.markdown(
                '<div class="api-offline">⚠️ <b>API Offline</b><br>'
                'Start the API:<br><code>python api.py</code></div>',
                unsafe_allow_html=True,
            )

        st.divider()
        page = st.radio(
            'Navigation',
            [
                '📄 Classify Documents',
                '🔍 Preview Layers',
                '📜 History',
                '✅ Approvals',
                '🔗 Webhooks',
                '📊 Metrics & MLOps',
            ],
            label_visibility='collapsed',
        )

        st.divider()
        st.caption('**Sensitivity Levels**')
        st.markdown('🟢 **Public** — Allow')
        st.markdown('🔵 **Internal** — Allow')
        st.markdown('🟡 **Confidential** — Encrypt + Legal approval')
        st.markdown('🔴 **Restricted** — Quarantine + dual approval')

        st.divider()
        st.caption('Reviewer name (used for HITL)')
        reviewer = st.text_input(
            'Reviewer',
            value=st.session_state.get('reviewer_name', 'analyst@datashield'),
            label_visibility='collapsed',
        )
        st.session_state['reviewer_name'] = reviewer

    return page


# ─────────────────────────────────────────────────────────────
# Page: Classify
# ─────────────────────────────────────────────────────────────

def page_classify():
    st.header('📄 Classify Documents')
    st.caption('Upload one or many documents in any format, or paste text directly. Optionally tag each one with a custom Doc ID.')

    tab1, tab2, tab3 = st.tabs(['📁 Upload Files', '📝 Paste Text', '⚡ Async Batch'])

    # ── File upload ──────────────────────────────────────────
    with tab1:
        SUPPORTED = ['txt', 'pdf', 'docx', 'csv', 'json', 'jsonl', 'md', 'html', 'log']
        uploaded = st.file_uploader(
            'Upload document(s) — any of: ' + ', '.join(SUPPORTED),
            type=SUPPORTED,
            accept_multiple_files=True,
        )

        c1, c2, c3 = st.columns(3)
        with c1:
            custom_doc_id = st.text_input(
                'Custom Doc ID (single file only)',
                placeholder='e.g. TICKET-2025-001',
                help='Provide a stable business ID; auto-generated if blank.',
            )
        with c2:
            source_system = st.selectbox(
                'Source System (optional)',
                ['', 'JIRA', 'ServiceNow', 'Confluence', 'Workday', 'Salesforce',
                 'Gmail', 'SharePoint'],
            )
        with c3:
            department = st.selectbox(
                'Department (optional)',
                ['', 'Engineering', 'HR', 'Finance', 'Legal', 'Sales', 'Marketing',
                 'Operations'],
            )

        if uploaded:
            st.info(f'📋 {len(uploaded)} file(s) ready.')
            if st.button('🚀 Classify All', type='primary', key='classify_files'):
                results = []
                bar = st.progress(0, text='Classifying...')
                for i, f in enumerate(uploaded):
                    bar.progress((i + 1) / len(uploaded), text=f'Processing: {f.name}')
                    files = {'file': (f.name, f.read(), 'application/octet-stream')}
                    data = {}
                    if len(uploaded) == 1 and custom_doc_id:
                        data['doc_id'] = custom_doc_id
                    if source_system:
                        data['source_system'] = source_system
                    if department:
                        data['department'] = department
                    res = api_post('/classify/file', files=files, data=data, timeout=120)
                    if res:
                        results.append(res)
                bar.empty()

                if results:
                    st.success(f'✅ Classified {len(results)} document(s)')
                    for idx, res in enumerate(results):
                        with st.container():
                            fname = res.get('source_file', f'Document {idx + 1}')
                            st.subheader(f'📄 {fname}')
                            render_result(res, index=idx)
                            st.divider()

    # ── Paste text ───────────────────────────────────────────
    with tab2:
        c1, c2 = st.columns([3, 1])
        with c1:
            text_input = st.text_area(
                'Paste text here',
                height=220,
                placeholder='Paste an email, ticket, contract, HR note...',
                key='paste_text',
            )
        with c2:
            st.write('')
            paste_doc_id = st.text_input('Doc ID', placeholder='e.g. TICKET-001',
                                         key='paste_doc_id')
            paste_src = st.selectbox(
                'Source', ['', 'Gmail', 'JIRA', 'ServiceNow', 'Workday'],
                key='paste_src',
            )
            paste_dept = st.selectbox(
                'Department', ['', 'Engineering', 'HR', 'Finance', 'Legal'],
                key='paste_dept',
            )
            classify_btn = st.button('🚀 Classify', type='primary',
                                     key='classify_text_btn', use_container_width=True)

        st.caption('💡 Try a sample:')
        samples = {
            'Public': 'Our Q1 product roadmap is published on the company website and open to all stakeholders.',
            'Internal': 'Please join the all-hands meeting Tuesday at 3pm. Agenda attached for all employees.',
            'Confidential': 'Employee ID 10293 — salary band L5 ($142,000). Performance review scheduled with HR.',
            'Restricted': 'Customer SSN 123-45-6789, credit card 4111-1111-1111-1111. GDPR data transfer agreement.',
        }
        cols = st.columns(4)
        for i, (lbl, sample) in enumerate(samples.items()):
            with cols[i]:
                if st.button(f'Sample: {lbl}', key=f'sample_{lbl}'):
                    st.session_state['paste_text'] = sample
                    st.rerun()

        if classify_btn:
            if not text_input.strip():
                st.warning('Please enter some text.')
            else:
                body = {
                    'text': text_input,
                    'doc_id': paste_doc_id or None,
                    'source_system': paste_src or None,
                    'department': paste_dept or None,
                }
                with st.spinner('Classifying...'):
                    res = api_post('/classify', body)
                if res:
                    st.success('✅ Classification complete')
                    render_result(res, index=999)

    # ── Async batch ──────────────────────────────────────────
    with tab3:
        st.markdown('Submit a batch of files for asynchronous processing. Use this for >5 files.')
        batch = st.file_uploader(
            'Upload batch',
            type=['txt', 'pdf', 'docx', 'csv', 'json', 'md', 'html'],
            accept_multiple_files=True,
            key='batch_uploader',
        )
        if batch and st.button('📤 Submit Async Batch', type='primary'):
            files = [('files', (f.name, f.getvalue(), 'application/octet-stream'))
                     for f in batch]
            r = api_post('/classify/batch', files=files, timeout=120)
            if r and r.get('job_id'):
                st.success(f'Job queued: {r["job_id"]}')
                st.session_state['batch_job_id'] = r['job_id']

        if 'batch_job_id' in st.session_state:
            st.divider()
            jid = st.session_state['batch_job_id']
            st.markdown(f'**Job ID:** `{jid}`')
            if st.button('🔄 Refresh Status'):
                pass  # rerun handles it
            status = api_get(f'/classify/status/{jid}')
            if status:
                prog = status.get('progress', {})
                done = prog.get('completed', 0)
                total = prog.get('total', 1)
                st.progress(done / max(total, 1),
                            text=f"{status.get('status', '?')} — {done}/{total}")
                if status.get('status') == 'completed':
                    st.success('Batch complete.')
                    df = pd.DataFrame(status.get('results', []))
                    if not df.empty:
                        st.dataframe(df, use_container_width=True)


# ─────────────────────────────────────────────────────────────
# Page: Preview Layers
# ─────────────────────────────────────────────────────────────

def page_preview():
    st.header('🔍 Preview Pipeline Layers')
    st.caption('See exactly what Layers 2 (Preprocessing) and 3 (Feature Engineering) do, before classifying.')

    text = st.text_area('Paste a document', height=180,
                        placeholder='Paste any document text...')
    c1, c2 = st.columns(2)
    with c1:
        run_pre = st.button('🧹 Run Preprocessing', use_container_width=True)
    with c2:
        run_feat = st.button('🧮 Show Features', use_container_width=True,
                             type='primary')

    if (run_pre or run_feat) and not text.strip():
        st.warning('Paste some text first.')
        return

    if run_pre:
        r = api_post('/preprocess/preview', {'text': text})
        if r:
            st.subheader('🧹 Preprocessing Output (Layer 2)')

            c1, c2, c3, c4 = st.columns(4)
            c1.metric('Language', f"{r.get('language_label')} ({r.get('detected_language')})")
            c2.metric('Tokens', r.get('token_count', 0))
            c3.metric('Chunks', r.get('chunk_count', 0))
            c4.metric('Chars', r.get('char_count', 0))

            if r.get('pii_entities'):
                st.markdown('**PII Detected:**')
                pills = ' '.join(f'<span class="pii-pill">{p}</span>'
                                 for p in r['pii_entities'])
                st.markdown(pills, unsafe_allow_html=True)
            else:
                st.success('No PII patterns detected.')

            st.markdown('**Inferred Metadata:**')
            st.json(r.get('metadata', {}))

            colA, colB = st.columns(2)
            with colA:
                st.markdown('**Cleaned Text (classifier sees this)**')
                st.text(r.get('clean_text', '')[:1500])
            with colB:
                st.markdown('**Masked Text (audit log sees this)**')
                st.text(r.get('masked_text', '')[:1500])

            with st.expander('Tokens & Chunks'):
                st.write('Tokens (first 60):', r.get('tokens_preview'))
                for i, c in enumerate(r.get('chunks_preview', [])):
                    st.markdown(f'**Chunk {i+1}:**')
                    st.text(c)

    if run_feat:
        r = api_post('/features/preview', {'text': text})
        if r:
            st.subheader('🧮 Feature Engineering (Layer 3)')
            fs = r.get('feature_summary', {})

            c1, c2, c3 = st.columns(3)
            c1.metric('Detected Language', r.get('detected_language'))
            c2.metric('Vocab Size', fs.get('vocab_size', 0))
            c3.metric('Unigrams / Bigrams',
                      f"{fs.get('unigram_count', 0)} / {fs.get('bigram_count', 0)}")

            st.markdown('**Top TF-IDF Tokens (what the model keys on)**')
            tfidf = fs.get('tfidf_top', [])
            if tfidf:
                df = pd.DataFrame(tfidf)
                st.dataframe(df, use_container_width=True, hide_index=True)
            else:
                st.info('No tokens in trained vocabulary.')

            st.markdown('**Numeric Features (used by XGBoost)**')
            st.json(fs.get('numeric_features', {}))

            if fs.get('embedding_dim'):
                st.success(f"Transformer embedding active: dim={fs['embedding_dim']}, "
                           f"norm={fs.get('embedding_norm', 0):.3f}")
            else:
                st.caption('Transformer embedding not loaded (fast-mode).')


# ─────────────────────────────────────────────────────────────
# Page: History
# ─────────────────────────────────────────────────────────────

def page_history():
    st.header('📜 Classification History')
    st.caption('Every classification with full audit trail. Click any row to inspect, correct, or approve.')

    c1, c2, c3, c4 = st.columns([1, 1, 1, 2])
    with c1:
        limit = st.selectbox('Show last', [25, 50, 100, 200, 500], index=2)
    with c2:
        label_filter = st.selectbox(
            'Label filter', ['', 'Public', 'Internal', 'Confidential', 'Restricted'])
    with c3:
        only_overrides = st.checkbox('Only overrides')
    with c4:
        st.write('')
        st.write('')
        if st.button('🔄 Refresh'):
            st.rerun()

    params = {'limit': limit, 'offset': 0}
    if label_filter:
        params['label'] = label_filter
    if only_overrides:
        params['only_overrides'] = True

    data = api_get('/history', **params)
    if not data:
        return

    entries = data.get('entries', [])
    if not entries:
        st.info('No classifications yet. Run something on the Classify page.')
        return

    st.caption(f"Showing {len(entries)} of {data.get('total', 0)} total")

    # Compact table
    table_rows = []
    for e in entries:
        table_rows.append({
            'Time': e.get('timestamp_utc', '')[:19].replace('T', ' '),
            'Doc ID': (e.get('doc_id') or '')[:13] + '...',
            'Label': e.get('label'),
            'Confidence': f"{(e.get('confidence') or 0):.1%}",
            'Action': (e.get('policy_trace') or {}).get('action', '—'),
            'Override?': '✏️' if e.get('human_override') else '',
            'Evidence': e.get('evidence_count', 0),
        })
    df = pd.DataFrame(table_rows)
    st.dataframe(df, use_container_width=True, hide_index=True)

    st.divider()
    st.markdown('### 🔎 Drill into a document')
    options = {f"{e.get('doc_id', '')[:20]}  ·  {e.get('label')}  ·  "
               f"{e.get('timestamp_utc', '')[:19]}": e.get('doc_id')
               for e in entries}
    selected = st.selectbox('Pick a document', list(options.keys()))
    if selected:
        doc_id = options[selected]
        doc = api_get(f'/document/{doc_id}')
        if doc:
            audit = doc.get('audit', {})
            st.subheader('📄 Audit Record')
            colA, colB, colC = st.columns(3)
            colA.markdown(label_badge(audit.get('label')), unsafe_allow_html=True)
            colB.markdown(f"**Confidence:** {(audit.get('confidence') or 0):.1%}")
            colC.markdown(action_badge(
                (audit.get('policy_trace') or {}).get('action', '?')
            ), unsafe_allow_html=True)

            st.markdown('**Masked input snippet** (raw PII never persisted):')
            st.code(audit.get('input_snippet_masked', ''), language='text')

            st.markdown('**Class probabilities**')
            probs = audit.get('class_probabilities', {})
            if probs:
                st.bar_chart(pd.DataFrame(
                    {'class': list(probs.keys()), 'prob': list(probs.values())}
                ).set_index('class'), height=160)

            with st.expander('🛡️ Full policy trace'):
                st.json(audit.get('policy_trace', {}))

            with st.expander('📡 Past overrides'):
                if doc.get('overrides'):
                    st.dataframe(pd.DataFrame(doc['overrides']),
                                 use_container_width=True, hide_index=True)
                else:
                    st.caption('No overrides yet.')

            with st.expander('✅ Approval history'):
                if doc.get('approvals'):
                    st.dataframe(pd.DataFrame(doc['approvals']),
                                 use_container_width=True, hide_index=True)
                else:
                    st.caption('No approval signatures yet.')

            # HITL block on existing record
            st.divider()
            st.markdown('### 👤 Submit a Human Review for this Document')
            render_hitl(
                {'doc_id': doc_id, 'label': audit.get('label', 'Internal')},
                key_prefix=f'hist_hitl_{doc_id[:8]}',
            )


# ─────────────────────────────────────────────────────────────
# Page: Approvals
# ─────────────────────────────────────────────────────────────

def page_approvals():
    st.header('✅ Approval Workflow')
    st.caption('Constraint C4 — Restricted documents require Legal + DataGovernance dual approval.')

    data = api_get('/history', limit=100)
    if not data or not data.get('entries'):
        st.info('No documents yet.')
        return

    # Filter to docs that need approval
    pending = []
    for e in data['entries']:
        lbl = e.get('label')
        if lbl in ('Confidential', 'Restricted'):
            pending.append(e)

    if not pending:
        st.success('No Confidential or Restricted documents in recent history.')
        return

    st.markdown(f'**{len(pending)} document(s) require approval.**')

    for e in pending[:30]:
        doc_id = e.get('doc_id')
        gate = api_get(f'/approval/status/{doc_id}')
        if not gate:
            continue
        with st.container():
            c1, c2, c3 = st.columns([2, 2, 1])
            with c1:
                st.markdown(label_badge(e.get('label')), unsafe_allow_html=True)
                st.caption(f'`{doc_id}`')
            with c2:
                received = gate.get('received', {})
                pending_appr = gate.get('pending_approvers', [])
                received_str = ', '.join(f'{k} ({v})' for k, v in received.items()) or 'none'
                st.markdown(f'**Status:** {gate.get("status")}')
                st.caption(f'Received: {received_str}')
                if pending_appr:
                    st.caption(f'Pending: {", ".join(pending_appr)}')
            with c3:
                pop_key = f'pop_{doc_id[:8]}'
                if st.button('Approve', key=pop_key):
                    st.session_state[f'expand_{doc_id[:8]}'] = True

            if st.session_state.get(f'expand_{doc_id[:8]}'):
                ac1, ac2, ac3 = st.columns([1, 1, 2])
                with ac1:
                    approver = st.selectbox(
                        'As',
                        ['Legal', 'DataGovernance'],
                        key=f'who_{doc_id[:8]}',
                    )
                with ac2:
                    decision = st.selectbox(
                        'Decision', ['approved', 'rejected'],
                        key=f'dec_{doc_id[:8]}',
                    )
                with ac3:
                    notes = st.text_input('Notes',
                                          key=f'note_{doc_id[:8]}')

                if st.button('Submit sign-off',
                             key=f'sub_{doc_id[:8]}', type='primary'):
                    r = api_post('/approval/sign-off', {
                        'doc_id': doc_id,
                        'approver': approver,
                        'decision': decision,
                        'notes': notes,
                    })
                    if r:
                        st.success(f'{approver} → {decision}')
                        st.session_state[f'expand_{doc_id[:8]}'] = False
                        time.sleep(0.5)
                        st.rerun()

            st.divider()


# ─────────────────────────────────────────────────────────────
# Page: Webhooks
# ─────────────────────────────────────────────────────────────

def page_webhooks():
    st.header('🔗 Webhooks — Downstream DLP / CASB Integration')
    st.caption('Outbound HTTP notifications. Every classification fires `classification.completed`; corrections fire `classification.overridden`.')

    # List subscriptions
    data = api_get('/webhooks')
    subs = data.get('subscriptions', []) if data else []
    st.markdown(f'**Current subscriptions: {len(subs)}**')

    if subs:
        for s in subs:
            with st.container():
                c1, c2, c3, c4 = st.columns([3, 2, 1, 1])
                c1.code(s['url'], language=None)
                c2.write('Events: ' + ', '.join(s.get('events', [])))
                if c3.button('Test', key=f'test_{s["id"]}'):
                    r = api_post(f'/webhooks/{s["id"]}/test')
                    if r:
                        st.success(f'Delivered: {r.get("delivered")}')
                if c4.button('Delete', key=f'del_{s["id"]}'):
                    api_delete(f'/webhooks/{s["id"]}')
                    st.rerun()
        st.divider()

    # Add new
    st.subheader('➕ Add subscription')
    with st.form('webhook_add', clear_on_submit=True):
        url = st.text_input('Webhook URL',
                            placeholder='https://your-dlp.example.com/datashield-events')
        events = st.multiselect(
            'Events',
            ['classification.completed', 'classification.overridden', 'webhook.test'],
            default=['classification.completed'],
        )
        secret = st.text_input('HMAC secret (optional)',
                               help='If set, deliveries include X-DataShield-Signature: sha256=…')
        submit = st.form_submit_button('Register', type='primary')
        if submit and url:
            r = api_post('/webhooks', {
                'url': url,
                'events': events,
                'secret': secret or None,
            })
            if r:
                st.success(f'Webhook registered: {r.get("id")}')
                time.sleep(0.5)
                st.rerun()

    st.divider()
    st.subheader('📡 Recent deliveries')
    deliveries = api_get('/webhooks/deliveries', limit=30)
    if deliveries and deliveries.get('deliveries'):
        df = pd.DataFrame(deliveries['deliveries'])
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.caption('No deliveries yet.')


# ─────────────────────────────────────────────────────────────
# Page: Metrics & MLOps
# ─────────────────────────────────────────────────────────────

def page_metrics():
    st.header('📊 Metrics & MLOps')
    st.caption('Live KPIs, model registry, drift, retraining trigger.')

    m = api_get('/metrics')
    if not m:
        return

    # ── KPI cards ───────────────────────────────────────────
    c1, c2, c3, c4 = st.columns(4)
    c1.metric('Total Classified', m.get('total_classified', 0))
    c2.metric('Avg Confidence', f"{m.get('avg_confidence', 0):.1%}")
    or_rate = m.get('human_override_rate', 0)
    c3.metric(
        'Override Rate',
        f'{or_rate:.2f}%',
        delta=('OK' if m.get('override_rate_compliant') else 'KPI BREACH'),
        delta_color='normal' if m.get('override_rate_compliant') else 'inverse',
    )
    c4.metric('Corrections', m.get('total_overrides', 0))

    if not m.get('override_rate_compliant'):
        st.error('⚠️ Human override rate exceeds the 5% KPI threshold from PS-01. '
                 'Consider retraining.')
    else:
        st.success('✅ Override rate within PS-01 KPI (< 5%).')

    st.divider()

    # ── Label distribution ──────────────────────────────────
    st.subheader('Label distribution')
    dist = m.get('label_distribution', {})
    if dist:
        df = pd.DataFrame({'label': list(dist.keys()), 'count': list(dist.values())})
        st.bar_chart(df.set_index('label'), height=220)
    else:
        st.caption('No data yet.')

    st.divider()

    # ── MLOps registry ──────────────────────────────────────
    st.subheader('🏷️ Model Registry')
    reg = api_get('/mlops/registry')
    if reg:
        cc1, cc2 = st.columns(2)
        with cc1:
            st.markdown('**Champion**')
            if reg.get('champion'):
                st.json(reg['champion'])
            else:
                st.caption('None registered.')
        with cc2:
            st.markdown('**Challenger**')
            if reg.get('challenger'):
                st.json(reg['challenger'])
            else:
                st.caption('None registered.')

    st.divider()

    # ── Retraining trigger ──────────────────────────────────
    st.subheader('🔁 Retraining Trigger (Active Learning)')
    rt = api_get('/mlops/retraining')
    if rt:
        trig = rt.get('retraining_trigger', {})
        level = trig.get('level', 'none')
        badge = {
            'none': '🟢',
            'manual': '🔵',
            'auto': '🟡',
            'urgent': '🔴',
        }.get(level, '⚪')

        c1, c2, c3 = st.columns(3)
        c1.metric('Pending overrides', rt.get('pending_overrides', 0))
        c2.metric('Recent override rate',
                  f"{(trig.get('override_rate_recent') or 0) * 100:.2f}%")
        c3.metric('Days since training',
                  trig.get('days_since_last_training') or '—')

        st.markdown(f'**{badge} Recommendation:** {trig.get("recommended_action")}')
        if trig.get('reasons'):
            for r in trig['reasons']:
                st.caption(f'• {r}')

        if rt.get('pending_overrides', 0) > 0:
            if st.button('📦 Export training batch (CSV)'):
                r = api_post('/mlops/export-batch')
                if r and r.get('exported'):
                    st.success(f"Exported: {r['path']}")

    st.divider()

    # ── Compliance check ────────────────────────────────────
    st.subheader('PS-01 Compliance Checklist')
    checks = [
        ('Sensitivity Label (4 classes)', True),
        ('Confidence Score [0–1]', True),
        ('Evidence Tokens ≥ 3', True),
        ('Policy Action Flag', True),
        ('Audit Log Entry', True),
        ('PII masking (Presidio + regex defensive)', True),
        ('Dual approval for Restricted (Legal+DataGov)', True),
        ('Webhook for DLP/CASB integration', True),
        ('Human-in-the-loop override flow', True),
        ('Active learning + retraining trigger', True),
        ('Override rate < 5%', m.get('override_rate_compliant', True)),
    ]
    for label, ok in checks:
        icon = '✅' if ok else '❌'
        st.markdown(f'{icon} {label}')


# ─────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────

def main():
    page = render_sidebar()
    if not check_api_health():
        st.error('🛑 API not reachable at ' + API_URL +
                 '. Start it: `python api.py` then refresh this page.')
        return

    if page.startswith('📄'):
        page_classify()
    elif page.startswith('🔍'):
        page_preview()
    elif page.startswith('📜'):
        page_history()
    elif page.startswith('✅'):
        page_approvals()
    elif page.startswith('🔗'):
        page_webhooks()
    elif page.startswith('📊'):
        page_metrics()


if __name__ == '__main__':
    main()
