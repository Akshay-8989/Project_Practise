# 🔐 DataShield — PS-01 Sensitivity Classification Engine

**Local enterprise prototype** of an automated data sensitivity classification platform.
Built per **PS-01** (Opus Technologies, Team #01: Akshay / Aditi / Shikha) —
runs entirely on a laptop, no Kafka, no Docker, no S3, no cloud calls.

> Classifies any unstructured document into one of **Public / Internal /
> Confidential / Restricted**, returns confidence + evidence + policy
> action, masks PII before audit, logs everything, and exposes a
> human-in-the-loop correction path.

---

## ⚡ Quick start (PyCharm or terminal)

```bash
# 1. Install dependencies (one-time)
pip install -r requirements.txt

# 2. Start both API + UI with one command
python run.py
```

Then open: **http://localhost:8501** (Streamlit UI)
API docs: **http://localhost:8000/docs** (Swagger UI)

To stop: `Ctrl+C` in the terminal.

> PyCharm users — open the project folder, right-click `run.py`, choose
> **Run 'run'**. That's it.

---

## 🏛️ Architecture

The system implements all 8 PS-01 layers:

```
┌─────────────────────────────────────────────────────────────┐
│ 1. INGESTION         ingestion.py                            │
│    pdfplumber + python-docx + json/csv/html parsers          │
│    (Kafka / S3 scoped out per user; REST is sufficient)      │
├─────────────────────────────────────────────────────────────┤
│ 2. PRE-PROCESSING    preprocessing.py                        │
│    Unicode NFKC normalize → strip control chars → strip      │
│    boilerplate → collapse whitespace → language detect →     │
│    Presidio (primary) + regex (fallback) PII masking →       │
│    tokenize → chunk → metadata enrichment                    │
├─────────────────────────────────────────────────────────────┤
│ 3. FEATURE ENGINEERING   feature_engineering.py              │
│    TF-IDF (1-2 grams, 20k vocab) + n-gram counts +           │
│    numeric features + optional transformer embedding hook    │
├─────────────────────────────────────────────────────────────┤
│ 4. CLASSIFICATION    models/ + ensemble/                     │
│    Logistic Regression (baseline) + XGBoost +                │
│    optional Transformer (DistilBERT/RoBERTa) →               │
│    Stacking meta-learner → soft-voting fallback              │
├─────────────────────────────────────────────────────────────┤
│ 5. EXPLAINABILITY    explainability/                         │
│    SHAP (TF-IDF coefficients) + LIME + Integrated Gradients  │
│    Every prediction returns ≥3 evidence tokens               │
├─────────────────────────────────────────────────────────────┤
│ 6. POLICY ENGINE     policy_engine/                          │
│    8+ PII regex rules (SSN, card+Luhn, IBAN, PAN, Aadhaar,   │
│    email, phone, DOB) — any high-severity match overrides    │
│    to Restricted. Dual-approval gate (Legal + DataGov).      │
├─────────────────────────────────────────────────────────────┤
│ 7. OUTPUT / API      api.py (FastAPI)                        │
│    REST endpoints + outbound webhooks (DLP/CASB)             │
├─────────────────────────────────────────────────────────────┤
│ 8. MLOPS             mlops.py + active_learning.py           │
│    Model registry (champion/challenger) + drift detection +  │
│    active-learning loop + automated retraining trigger       │
└─────────────────────────────────────────────────────────────┘
            ↓
        UI: app.py (Streamlit) — 6 pages
```

---

## 🖥️ The UI

Six pages in the Streamlit sidebar:

| Page | What it does |
|------|---|
| **📄 Classify Documents** | Upload single/multi files (PDF/DOCX/TXT/CSV/JSON/HTML), paste text, async batch mode. Custom Doc ID, source-system & department tagging. Inline result card with label, confidence, action, evidence tokens, policy trace, and HITL form. |
| **🔍 Preview Layers** | Inspect Layer 2 (preprocessing) and Layer 3 (features) without classifying — see the cleaned text, masked text, detected PII, tokens, chunks, and top TF-IDF tokens. |
| **📜 History** | Browse the audit log, filter by label or override status, drill into any document to see masked snippet, probabilities, full policy trace, override history, approval signatures, and submit a retrospective correction. |
| **✅ Approvals** | Constraint C4 dual-approval queue. Confidential needs Legal; Restricted needs Legal + DataGovernance. Sign-off recorded to the approval log. |
| **🔗 Webhooks** | DLP / CASB integration management. Register subscription URLs, test deliveries, view recent delivery log. HMAC SHA-256 signing supported. |
| **📊 Metrics & MLOps** | KPI dashboard (override rate vs 5% target), label distribution, model registry, retraining-trigger recommendation, PS-01 compliance checklist. |

---

## 🔌 API reference (highlights)

Full Swagger UI: **http://localhost:8000/docs**

```bash
# Classify text
curl -X POST http://localhost:8000/classify \
  -H "Content-Type: application/json" \
  -d '{"text":"Customer SSN 123-45-6789","doc_id":"TICKET-001"}'

# Classify a file
curl -X POST http://localhost:8000/classify/file \
  -F "file=@/path/to/contract.pdf" \
  -F "doc_id=CONTRACT-99" \
  -F "department=Legal"

# Async batch
curl -X POST http://localhost:8000/classify/batch \
  -F "files=@doc1.txt" -F "files=@doc2.pdf"
# → returns {"job_id": "...", "status": "queued"}
curl http://localhost:8000/classify/status/{job_id}

# Preview preprocessing (PS Layer 2)
curl -X POST http://localhost:8000/preprocess/preview \
  -H "Content-Type: application/json" \
  -d '{"text":"Hi team, SSN 123-45-6789"}'

# History
curl "http://localhost:8000/history?limit=50&label=Restricted"

# Human-in-the-loop override
curl -X POST http://localhost:8000/override \
  -H "Content-Type: application/json" \
  -d '{"doc_id":"TICKET-001","original_label":"Restricted",
       "corrected_label":"Confidential","reviewer":"alice@legal","reason":"…"}'

# Dual-approval sign-off (C4)
curl -X POST http://localhost:8000/approval/sign-off \
  -H "Content-Type: application/json" \
  -d '{"doc_id":"TICKET-001","approver":"Legal","decision":"approved"}'

# Webhook subscription
curl -X POST http://localhost:8000/webhooks \
  -H "Content-Type: application/json" \
  -d '{"url":"https://dlp.example.com/events","events":["classification.completed"]}'

# MLOps — retraining trigger recommendation
curl http://localhost:8000/mlops/retraining
```

Every classify response contains exactly the PS-01 output schema:

```jsonc
{
  "doc_id": "TICKET-001",
  "label": "Restricted",
  "confidence": 0.9946,
  "class_probabilities": {"Public":0.001,"Internal":0.002,"Confidential":0.003,"Restricted":0.994},
  "evidence": [
    {"token":"12*********","weight":1.0,"source":"policy:PII_REGEX_SSN"},
    {"token":"ssn","weight":0.96,"source":"LIME_fallback"},
    {"token":"customer","weight":0.48,"source":"LIME_fallback"}
  ],
  "policy_action": "Quarantine",
  "policy_trace": { /* full rule activations */ },
  "language": {"detected":"en","routed_to":"en"},
  "preprocessing": { "pii_entities":["SSN"], "token_count":18, ... },
  "features": { "tfidf_top":[...], "vocab_size":5288, ... },
  "latency_ms": {"preprocessing":9.4,"features":3.2,"classification":58.1,"total":70.7},
  "audit": {"model_version":"v3.0.0-bilingual", ...},
  "timestamp_utc": "2026-05-13T08:58:19.322734+00:00"
}
```

---

## 🧭 Gap analysis — how each gap was closed

From `PS01_Gap_Analysis_Report.html`:

| Gap | Status | Resolution |
|---|---|---|
| Presidio NOT WIRED | ✅ Fixed | `utils/presidio_masker.py` — real Presidio integration, graceful regex fallback when Presidio not installed. Wired into `preprocessing.py`. |
| Webhooks MISSING | ✅ Fixed | `webhooks.py` — subscription CRUD, HMAC-signed POST, threaded fan-out, delivery log. Fires `classification.completed` and `classification.overridden` events. |
| Active learning NOT DONE | ✅ Fixed | `active_learning.py` — every human override feeds a review queue; `export_training_batch()` emits a CSV ready for the trainer; Constraint C4 honored (never auto-trains). |
| Auto retraining trigger MANUAL ONLY | ✅ Fixed | `active_learning.check_retraining_trigger()` returns `none/manual/auto/urgent` based on PS-01 KPIs (override-rate >5%, drift SLA >3%, 30-day staleness, >50 pending). Surfaced in `/mlops/retraining` and the Metrics page. |
| Approval workflow not exposed | ✅ Fixed | New endpoints `POST /approval/sign-off` and `GET /approval/status/{doc_id}` + the **Approvals** UI page. |
| Async batch orchestration | ✅ Fixed | `POST /classify/batch` runs as a FastAPI BackgroundTask; poll `/classify/status/{job_id}`. No Celery/Redis needed. |
| Apache Tika (multi-format) | Partial — kept | pdfplumber + python-docx cover ~90% of common formats. Tika is one `pip install tika` + a Java JRE; we treat it as a future swap-in. |
| Kafka / S3 connectors | Scoped out | Per user requirement (laptop-only). Production deployment would add these as parallel ingestion entry points. |
| mTLS (Constraint C5) | Out of scope | Production-only; localhost demo uses plain HTTP. uvicorn supports `--ssl-keyfile` / `--ssl-certfile` for a one-line upgrade. |
| Adversarial training | Future | `data/sample_docs/ticket_adversarial.txt` shows the obfuscation patterns; augmentation would extend `data/synthetic_generator.py`. |

---

## 📁 Project structure

```
datashield/
├── api.py                    ← FastAPI service (port 8000)
├── app.py                    ← Streamlit UI (port 8501)
├── run.py                    ← One-command launcher
├── requirements.txt
├── README.md
│
├── ingestion.py              ← Layer 1 — file format parsers
├── preprocessing.py          ← Layer 2 — clean / mask / tokenize / chunk
├── feature_engineering.py    ← Layer 3 — TF-IDF + n-grams + embedding hook
├── pipeline.py               ← Layers 4–6 orchestration
├── webhooks.py               ← DLP / CASB outbound integration
├── active_learning.py        ← HITL feedback → retraining trigger
├── mlops.py                  ← Model registry + drift monitoring
│
├── models/                   ← Layer 4 — Logistic / XGBoost / Transformer
├── ensemble/                 ← Voting + Stacking meta-learner
├── explainability/           ← Layer 5 — SHAP / LIME / IG
├── policy_engine/            ← Layer 6 — PII rules + dual approval
│
├── utils/
│   ├── audit_logger.py       ← PII-safe audit trail
│   ├── pii_masker.py         ← Regex defensive masker (always available)
│   ├── presidio_masker.py    ← Presidio primary masker (fallback aware)
│   └── language_detector.py  ← EN / HI script-based routing
│
├── artifacts/
│   ├── en/                   ← English: logistic.joblib, xgboost.joblib, stacker.joblib
│   └── hi/                   ← Hindi:   same set, language-specific
│
├── configs/
│   ├── model.yaml
│   └── policy.yaml
│
├── data/
│   ├── synthetic_dataset.csv ← 20k labeled examples (5k per class × 2 lang)
│   ├── synthetic_generator.py
│   └── sample_docs/          ← Pre-made examples to drop into the UI
│
├── scripts/
│   ├── train_all.py          ← Retrain everything from synthetic data
│   ├── calibrate_thresholds.py
│   ├── evaluate_compliance.py← Verifies PS-01 hard-metric targets
│   ├── benchmark_latency.py  ← p95 latency check
│   └── predict_cli.py        ← Quick command-line prediction
│
├── tests/                    ← pytest suite (92 tests)
└── logs/                     ← Created at runtime (audit, overrides, ...)
```

---

## 🎯 PS-01 evaluation criteria

The bundled artifacts are pre-trained on the synthetic dataset and pass
the hard metrics:

| Metric | Target | Status |
|--------|--------|--------|
| Precision (Confidential) | ≥ 0.90 | ✅ Achieved on held-out test set |
| Precision (Restricted)   | ≥ 0.95 | ✅ Achieved (policy override → 1.0 recall floor) |
| Recall (Restricted)      | ≥ 0.97 | ✅ Policy engine fires on PII regex hits regardless of model score |
| F1-Macro                 | ≥ 0.88 | ✅ Stacking ensemble |
| Latency p95              | < 200 ms | ✅ ~70 ms warm (fast-mode: LR + XGB) |
| Evidence tokens          | ≥ 3 per prediction | ✅ SHAP + LIME + policy combined |
| Override rate            | < 5% KPI | ✅ Live-tracked on Metrics page, triggers retraining on breach |

Re-run the compliance evaluator:

```bash
python scripts/evaluate_compliance.py
```

---

## 🔒 Constraints satisfied

| | Constraint | How |
|---|---|---|
| **C1** | No raw PII persisted | Two-layer masking: Presidio (or regex fallback) at ingestion, regex defensive at every audit-log write boundary |
| **C2** | Auditable models | LR + XGBoost are inherently interpretable; SHAP + LIME + IG every prediction; full policy trace logged |
| **C3** | On-prem / air-gapped | Zero cloud calls at inference. SQLite for MLflow. All artifacts bundled. |
| **C4** | Dual approval for training data | `policy_engine/approval.py` + `/approval/sign-off` endpoint + Approvals UI page. Restricted needs Legal + DataGov. |
| **C5** | mTLS for payments clients | Localhost demo runs plain HTTP. Drop-in upgrade: pass `--ssl-keyfile`/`--ssl-certfile` to uvicorn. |

---

## 🛠️ Common tasks

| Task | Command |
|---|---|
| Train models from scratch | `python scripts/train_all.py` |
| Evaluate against PS-01 metrics | `python scripts/evaluate_compliance.py` |
| Latency benchmark | `python scripts/benchmark_latency.py` |
| Run tests | `pytest tests/ -q` |
| Predict from CLI | `python scripts/predict_cli.py "Some text..."` |
| Start API only | `python api.py` |
| Start UI only | `streamlit run app.py` |
| Reset audit log | `rm -rf logs/*.jsonl logs/*.json` |

---

## ❓ Troubleshooting

**API offline shown in UI.** Start the API first (`python api.py`) or run `python run.py`.

**First classify is slow (~3s).** That's the pipeline loading the
joblib artifacts on demand. All subsequent calls are < 200 ms.

**Presidio fallback message.** Expected — Presidio is optional. To
enable: uncomment `presidio-analyzer` and `presidio-anonymizer` in
`requirements.txt`, run `pip install -r requirements.txt`, then
`python -m spacy download en_core_web_lg`.

**Port already in use.** Either kill the existing process or change
`API_PORT` / `UI_PORT` in `run.py`.

---

*Built for PS-01 — Data Governance & Privacy Engineering. © Team #01.*
