"""
run.py
------
One-command launcher: starts FastAPI backend + Streamlit UI.
Run: python run.py

This script:
1. Starts the FastAPI backend on port 8000 (background process)
2. Starts the Streamlit UI on port 8501 (foreground)
3. Cleanly shuts down both on Ctrl+C
"""
import os
import sys
import time
import signal
import subprocess
from pathlib import Path

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

API_PORT = 8000
UI_PORT = 8501

BANNER = """
╔══════════════════════════════════════════════════════════════╗
║      🔐  DataShield — PS-01 Sensitivity Classifier            ║
║          Data Governance & Privacy | Team #01                 ║
╠══════════════════════════════════════════════════════════════╣
║  UI  ➜  http://localhost:8501       (open this in browser)    ║
║  API ➜  http://localhost:8000                                 ║
║  Docs➜  http://localhost:8000/docs  (Swagger UI)              ║
╚══════════════════════════════════════════════════════════════╝
Press Ctrl+C to stop both services.
"""


def main():
    os.chdir(PROJECT_DIR)
    print(BANNER)

    api_proc = None
    ui_proc = None

    try:
        # ── Start FastAPI backend ─────────────────────────
        print("[launcher] Starting FastAPI backend on port 8000...")
        api_proc = subprocess.Popen(
            [sys.executable, "api.py"],
            cwd=PROJECT_DIR,
        )
        time.sleep(3)  # Give API time to load models

        if api_proc.poll() is not None:
            print("[launcher] ❌ API failed to start. Check errors above.")
            sys.exit(1)

        print(f"[launcher] ✅ API running (PID {api_proc.pid})")

        # ── Start Streamlit UI ────────────────────────────
        print("[launcher] Starting Streamlit UI on port 8501...")
        ui_proc = subprocess.Popen(
            [
                sys.executable, "-m", "streamlit", "run", "app.py",
                "--server.port", str(UI_PORT),
                "--server.headless", "true",
                "--browser.gatherUsageStats", "false",
            ],
            cwd=PROJECT_DIR,
        )
        time.sleep(2)

        if ui_proc.poll() is not None:
            print("[launcher] ❌ Streamlit failed to start. Check errors above.")
            api_proc.terminate()
            sys.exit(1)

        print(f"[launcher] ✅ Streamlit UI running (PID {ui_proc.pid})")
        print(f"\n👉 Open your browser: http://localhost:{UI_PORT}\n")

        # Keep running until Ctrl+C
        while True:
            # Check if either process died
            if api_proc.poll() is not None:
                print("[launcher] ⚠️  API process ended unexpectedly.")
                break
            if ui_proc.poll() is not None:
                print("[launcher] ⚠️  Streamlit process ended unexpectedly.")
                break
            time.sleep(2)

    except KeyboardInterrupt:
        print("\n[launcher] Shutting down...")
    finally:
        if api_proc and api_proc.poll() is None:
            api_proc.terminate()
            print("[launcher] API stopped.")
        if ui_proc and ui_proc.poll() is None:
            ui_proc.terminate()
            print("[launcher] Streamlit stopped.")
        print("[launcher] Goodbye.")


if __name__ == '__main__':
    main()
