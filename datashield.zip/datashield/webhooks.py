"""
webhooks.py
-----------
Outbound webhook fan-out for downstream DLP / CASB / data-catalog
integration. The PS-01 architecture lists this as a required output:

    "REST API (FastAPI). Response: label + score + evidence + action.
     Webhook for downstream DLP / CASB / data catalog integration."

The gap analysis flagged this component as MISSING — only the action
mapping existed in policy.yaml, but nothing actually fired an HTTP call.
This module wires it in.

Design:
  - Webhook subscriptions live in a JSON file (logs/webhooks.json) so
    they survive restarts and are easy to inspect from PyCharm.
  - The API exposes endpoints to add / list / delete subscriptions.
  - When a classification completes, the API calls fire_classification()
    which POSTs the result to every subscribed URL with optional HMAC
    signature (so the receiver can verify authenticity).
  - Failures are logged but don't block classification — DLP integration
    must be best-effort, the classification itself is the source of truth.
"""
from __future__ import annotations
import hashlib
import hmac
import json
import os
import threading
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional

import requests

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
SUBSCRIPTIONS_PATH = os.path.join(PROJECT_DIR, 'logs', 'webhooks.json')
DELIVERY_LOG_PATH = os.path.join(PROJECT_DIR, 'logs', 'webhook_deliveries.jsonl')

_LOCK = threading.RLock()
os.makedirs(os.path.dirname(SUBSCRIPTIONS_PATH), exist_ok=True)


# ─────────────────────────────────────────────────────────────
# Subscription model
# ─────────────────────────────────────────────────────────────

@dataclass
class WebhookSubscription:
    id: str
    url: str
    events: List[str]                # e.g. ['classification.completed']
    secret: Optional[str] = None     # HMAC secret (optional)
    created_at: str = ''
    enabled: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _load_subs() -> List[WebhookSubscription]:
    if not os.path.exists(SUBSCRIPTIONS_PATH):
        return []
    try:
        with open(SUBSCRIPTIONS_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return [WebhookSubscription(**d) for d in data]
    except Exception:
        return []


def _save_subs(subs: List[WebhookSubscription]) -> None:
    with _LOCK:
        with open(SUBSCRIPTIONS_PATH, 'w', encoding='utf-8') as f:
            json.dump([s.to_dict() for s in subs], f, indent=2)


# ─────────────────────────────────────────────────────────────
# Public CRUD API
# ─────────────────────────────────────────────────────────────

def list_subscriptions() -> List[Dict[str, Any]]:
    return [s.to_dict() for s in _load_subs()]


def add_subscription(url: str, events: Optional[List[str]] = None,
                     secret: Optional[str] = None) -> Dict[str, Any]:
    import uuid
    sub = WebhookSubscription(
        id=str(uuid.uuid4()),
        url=url,
        events=events or ['classification.completed'],
        secret=secret,
        created_at=datetime.now(timezone.utc).isoformat(),
        enabled=True,
    )
    subs = _load_subs()
    subs.append(sub)
    _save_subs(subs)
    return sub.to_dict()


def delete_subscription(sub_id: str) -> bool:
    subs = _load_subs()
    new = [s for s in subs if s.id != sub_id]
    if len(new) == len(subs):
        return False
    _save_subs(new)
    return True


def toggle_subscription(sub_id: str, enabled: bool) -> bool:
    subs = _load_subs()
    found = False
    for s in subs:
        if s.id == sub_id:
            s.enabled = enabled
            found = True
    if found:
        _save_subs(subs)
    return found


# ─────────────────────────────────────────────────────────────
# Delivery
# ─────────────────────────────────────────────────────────────

def _sign(payload: bytes, secret: str) -> str:
    return hmac.new(secret.encode('utf-8'), payload, hashlib.sha256).hexdigest()


def _log_delivery(sub_id: str, url: str, event: str, status_code: int | None,
                  ok: bool, error: Optional[str] = None) -> None:
    entry = {
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'sub_id': sub_id,
        'url': url,
        'event': event,
        'status_code': status_code,
        'ok': ok,
        'error': error,
    }
    try:
        with open(DELIVERY_LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry, sort_keys=True) + '\n')
    except Exception:
        pass


def _post_one(sub: WebhookSubscription, event: str, payload: Dict[str, Any],
              timeout: float = 5.0) -> bool:
    body = json.dumps(payload, sort_keys=True).encode('utf-8')
    headers = {
        'Content-Type': 'application/json',
        'X-DataShield-Event': event,
        'X-DataShield-Delivery': str(int(time.time() * 1000)),
    }
    if sub.secret:
        headers['X-DataShield-Signature'] = 'sha256=' + _sign(body, sub.secret)

    try:
        resp = requests.post(sub.url, data=body, headers=headers, timeout=timeout)
        ok = 200 <= resp.status_code < 300
        _log_delivery(sub.id, sub.url, event, resp.status_code, ok,
                      None if ok else resp.text[:200])
        return ok
    except Exception as e:
        _log_delivery(sub.id, sub.url, event, None, False, str(e))
        return False


def fire_classification(result: Dict[str, Any]) -> int:
    """
    Fire the 'classification.completed' event to every subscribed URL.
    Returns the count of successful deliveries.
    Best-effort: never raises.
    """
    return fire_event('classification.completed', result)


def fire_event(event: str, payload: Dict[str, Any]) -> int:
    """Generic event fan-out. Returns number of successful deliveries."""
    subs = [s for s in _load_subs() if s.enabled and event in s.events]
    if not subs:
        return 0

    enriched = {
        'event': event,
        'fired_at_utc': datetime.now(timezone.utc).isoformat(),
        'payload': payload,
    }

    success = 0
    # Send each in its own thread so we don't block the API response.
    threads = []
    results: List[bool] = []

    def _worker(sub: WebhookSubscription):
        results.append(_post_one(sub, event, enriched))

    for s in subs:
        t = threading.Thread(target=_worker, args=(s,), daemon=True)
        t.start()
        threads.append(t)

    for t in threads:
        t.join(timeout=6.0)

    return sum(1 for ok in results if ok)


def recent_deliveries(limit: int = 50) -> List[Dict[str, Any]]:
    if not os.path.exists(DELIVERY_LOG_PATH):
        return []
    out = []
    with open(DELIVERY_LOG_PATH, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
    return list(reversed(out))[:limit]
