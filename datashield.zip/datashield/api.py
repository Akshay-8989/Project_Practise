"""
api.py
------
FastAPI REST API — the single integration surface for DataShield.

Endpoint groups:
  Classification
    POST /classify              — classify text payload
    POST /classify/file         — classify a single uploaded file (any format)
    POST /classify/batch        — async batch classification (multi-file)
    GET  /classify/status/{job_id}
                                — poll an async batch job
  Inspection (PS Layers 2 & 3 — preprocessing & feature engineering)
    POST /preprocess/preview    — see exactly how text is cleaned/masked/tokenized
    POST /features/preview      — see what the model "sees" before classifying
  History & audit
    GET  /history               — list classifications (paginated, filters)
    GET  /document/{doc_id}     — full record for one document
  Human-in-the-loop
    POST /override              — record a human correction or confirmation
    GET  /review-queue          — pending human reviews
  Policy + approvals (Constraint C4)
    POST /approval/sign-off     — Legal or DataGov approves a Restricted doc
    GET  /approval/status/{doc_id}
                                — approval gate status
  Webhooks (DLP / CASB integration)
    GET  /webhooks              — list subscriptions
    POST /webhooks              — register a new webhook
    DELETE /webhooks/{id}       — remove a webhook
    POST /webhooks/{id}/test    — fire a test event
  MLOps
    GET  /mlops/registry        — champion / challenger
    GET  /mlops/retraining      — retraining trigger recommendation
    POST /mlops/export-batch    — export pending overrides as training CSV
  Health / metrics
    GET  /health
    GET  /metrics

The pipeline is loaded lazily on first request, so import-time is cheap
and PyCharm's "Run" stays snappy.
"""
from __future__ import annotations
import os
import sys
import json
import uuid
import time
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any

# ── Path bootstrap ──────────────────────────────────────────
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Local modules
import webhooks
import active_learning
import preprocessing
import feature_engineering
from ingestion import extract_text_from_bytes


# ─────────────────────────────────────────────────────────────
# Lazy pipeline loader
# ─────────────────────────────────────────────────────────────
_PIPELINE = None
_PIPELINE_LOCK = threading.Lock()


def get_pipeline():
    """Load the classifier on first call only (saves ~3s of startup time)."""
    global _PIPELINE
    if _PIPELINE is None:
        with _PIPELINE_LOCK:
            if _PIPELINE is None:
                from pipeline import SensitivityClassifier
                _PIPELINE = SensitivityClassifier(force_mode='fast')
    return _PIPELINE


# ─────────────────────────────────────────────────────────────
# App config
# ─────────────────────────────────────────────────────────────
app = FastAPI(
    title='DataShield — Sensitivity Classification Engine',
    description='PS-01 | Automated Data Sensitivity Classification | Local enterprise prototype',
    version='1.1.0',
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*'],
)


LOGS_DIR = os.path.join(PROJECT_DIR, 'logs')
AUDIT_LOG = os.path.join(LOGS_DIR, 'audit.jsonl')
OVERRIDE_LOG = os.path.join(LOGS_DIR, 'overrides.jsonl')
APPROVAL_LOG = os.path.join(LOGS_DIR, 'approvals.jsonl')
JOBS_PATH = os.path.join(LOGS_DIR, 'async_jobs.json')

os.makedirs(LOGS_DIR, exist_ok=True)


# ─────────────────────────────────────────────────────────────
# Pydantic request models
# ─────────────────────────────────────────────────────────────

class ClassifyTextRequest(BaseModel):
    text: str
    doc_id: Optional[str] = None
    source_system: Optional[str] = None
    department: Optional[str] = None
    file_type: Optional[str] = 'txt'


class OverrideRequest(BaseModel):
    doc_id: str
    original_label: str
    corrected_label: str
    reviewer: str
    reason: Optional[str] = ''


class WebhookCreateRequest(BaseModel):
    url: str
    events: Optional[List[str]] = Field(default_factory=lambda: ['classification.completed'])
    secret: Optional[str] = None


class ApprovalRequest(BaseModel):
    doc_id: str
    approver: str        # 'Legal' | 'DataGovernance'
    decision: str        # 'approved' | 'rejected'
    notes: Optional[str] = ''


class PreviewRequest(BaseModel):
    text: str
    metadata: Optional[Dict[str, Any]] = None


# ─────────────────────────────────────────────────────────────
# Core classification logic
# ─────────────────────────────────────────────────────────────

def _label_to_action(label: str) -> str:
    return {
        'Public': 'Allow',
        'Internal': 'Allow',
        'Confidential': 'Encrypt',
        'Restricted': 'Quarantine',
    }.get(label, 'Restrict')


def _classify(
    text: str,
    metadata: Optional[Dict[str, Any]] = None,
    doc_id: Optional[str] = None,
    fire_webhook: bool = True,
) -> Dict[str, Any]:
    """Run preprocessing → classification → return enriched result."""
    if not text or not text.strip():
        raise HTTPException(400, 'No text provided.')

    t0 = time.time()

    # Step 1: Preprocessing (Layer 2)
    pre = preprocessing.preprocess(text, metadata or {})
    t_pre = time.time()

    # Step 2: Feature summary (Layer 3) — for inspection only
    feat = feature_engineering.featurize(pre.clean_text, lang=pre.detected_language, top_k=8)
    t_feat = time.time()

    # Step 3: Classify (Layer 4-6). Pipeline runs on RAW text (policy
    # engine needs the PII patterns to fire).
    clf = get_pipeline()
    raw_result = clf.predict(pre.raw_text, pre.metadata, doc_id=doc_id)
    t_clf = time.time()

    final = {
        'doc_id': doc_id or raw_result.get('doc_id') or str(uuid.uuid4()),
        'label': raw_result.get('label'),
        'confidence': raw_result.get('confidence'),
        'class_probabilities': raw_result.get('class_probabilities', {}),
        'evidence': raw_result.get('evidence', []),
        'policy_action': raw_result.get('policy_trace', {}).get('action') or _label_to_action(raw_result.get('label')),
        'policy_trace': raw_result.get('policy_trace', {}),
        'model_contributions': raw_result.get('model_contributions', {}),
        'language': raw_result.get('language', {}),
        'audit': raw_result.get('audit', {}),
        'preprocessing': pre.for_audit(),
        'features': feat.to_dict(),
        'latency_ms': {
            'preprocessing': round((t_pre - t0) * 1000, 1),
            'features': round((t_feat - t_pre) * 1000, 1),
            'classification': round((t_clf - t_feat) * 1000, 1),
            'total': round((t_clf - t0) * 1000, 1),
        },
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    }

    # Fire webhook (best-effort)
    if fire_webhook:
        try:
            n_delivered = webhooks.fire_classification({
                'doc_id': final['doc_id'],
                'label': final['label'],
                'confidence': final['confidence'],
                'policy_action': final['policy_action'],
                'language': final['language'],
                'timestamp_utc': final['timestamp_utc'],
            })
            final['webhooks_delivered'] = n_delivered
        except Exception as e:
            final['webhooks_delivered'] = 0
            final['webhook_error'] = str(e)

    return final


# ─────────────────────────────────────────────────────────────
# Classification endpoints
# ─────────────────────────────────────────────────────────────

@app.post('/classify')
def classify_text(req: ClassifyTextRequest):
    metadata = {
        'source_system': req.source_system,
        'department': req.department,
        'file_type': req.file_type,
    }
    return _classify(req.text, metadata, doc_id=req.doc_id)


@app.post('/classify/file')
async def classify_file(
    file: UploadFile = File(...),
    doc_id: Optional[str] = Form(None),
    source_system: Optional[str] = Form(None),
    department: Optional[str] = Form(None),
):
    """Classify one uploaded file (PDF / DOCX / TXT / JSON / CSV / etc)."""
    data = await file.read()
    text, file_meta = extract_text_from_bytes(data, file.filename)
    if not text or len(text.strip()) < 5:
        raise HTTPException(400, 'Could not extract meaningful text from file.')

    if source_system:
        file_meta['source_system'] = source_system
    if department:
        file_meta['department'] = department

    result = _classify(text, file_meta, doc_id=doc_id)
    result['source_file'] = file.filename
    result['extracted_text_preview'] = text[:400] + ('...' if len(text) > 400 else '')
    return result


# ── Async batch jobs ─────────────────────────────────────────

def _load_jobs() -> Dict[str, Any]:
    if not os.path.exists(JOBS_PATH):
        return {}
    try:
        with open(JOBS_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_jobs(jobs: Dict[str, Any]) -> None:
    with open(JOBS_PATH, 'w', encoding='utf-8') as f:
        json.dump(jobs, f, indent=2, default=str)


def _run_batch_job(job_id: str, items: List[Dict[str, Any]]):
    """Background worker — sequentially classifies each item."""
    jobs = _load_jobs()
    job = jobs.get(job_id, {})
    job['status'] = 'running'
    job['progress'] = {'completed': 0, 'total': len(items)}
    job['results'] = []
    jobs[job_id] = job
    _save_jobs(jobs)

    for i, item in enumerate(items):
        try:
            res = _classify(
                item['text'],
                item.get('metadata') or {},
                doc_id=item.get('doc_id'),
            )
            job['results'].append({
                'doc_id': res['doc_id'],
                'source_file': item.get('source_file'),
                'label': res['label'],
                'confidence': res['confidence'],
                'policy_action': res['policy_action'],
            })
        except Exception as e:
            job['results'].append({
                'doc_id': item.get('doc_id'),
                'source_file': item.get('source_file'),
                'error': str(e),
            })
        job['progress'] = {'completed': i + 1, 'total': len(items)}
        jobs[job_id] = job
        _save_jobs(jobs)

    job['status'] = 'completed'
    job['completed_at'] = datetime.now(timezone.utc).isoformat()
    jobs[job_id] = job
    _save_jobs(jobs)


@app.post('/classify/batch')
async def classify_batch(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
):
    """
    Submit multiple files for asynchronous classification.
    Returns a job_id; poll /classify/status/{job_id} for progress.
    """
    if not files:
        raise HTTPException(400, 'No files supplied.')

    job_id = str(uuid.uuid4())
    items = []
    for f in files:
        data = await f.read()
        text, meta = extract_text_from_bytes(data, f.filename)
        items.append({
            'text': text,
            'metadata': meta,
            'source_file': f.filename,
        })

    jobs = _load_jobs()
    jobs[job_id] = {
        'job_id': job_id,
        'status': 'queued',
        'submitted_at': datetime.now(timezone.utc).isoformat(),
        'progress': {'completed': 0, 'total': len(items)},
        'results': [],
    }
    _save_jobs(jobs)

    background_tasks.add_task(_run_batch_job, job_id, items)
    return {'job_id': job_id, 'status': 'queued', 'item_count': len(items)}


@app.get('/classify/status/{job_id}')
def get_batch_status(job_id: str):
    jobs = _load_jobs()
    if job_id not in jobs:
        raise HTTPException(404, 'Job not found.')
    return jobs[job_id]


# ─────────────────────────────────────────────────────────────
# Inspection endpoints (PS Layer 2 & 3 — explicit previews)
# ─────────────────────────────────────────────────────────────

@app.post('/preprocess/preview')
def preprocess_preview(req: PreviewRequest):
    """Show exactly what preprocessing did."""
    pre = preprocessing.preprocess(req.text, req.metadata or {})
    return {
        'detected_language': pre.detected_language,
        'language_label': pre.language_label,
        'char_count': pre.char_count,
        'token_count': pre.token_count,
        'chunk_count': pre.chunk_count,
        'pii_entities': pre.pii_entities,
        'metadata': pre.metadata,
        'clean_text': pre.clean_text,
        'masked_text': pre.masked_text,
        'tokens_preview': pre.tokens[:60],
        'chunks_preview': [c[:200] for c in pre.chunks[:5]],
    }


@app.post('/features/preview')
def features_preview(req: PreviewRequest):
    """Show the inspectable feature view that the classifier 'sees'."""
    pre = preprocessing.preprocess(req.text, req.metadata or {})
    feat = feature_engineering.featurize(pre.clean_text, lang=pre.detected_language, top_k=15)
    return {
        'detected_language': pre.detected_language,
        'feature_summary': feat.to_dict(),
    }


# ─────────────────────────────────────────────────────────────
# History & document lookup
# ─────────────────────────────────────────────────────────────

def _read_audit_log(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        return []
    out = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
    return out


@app.get('/history')
def get_history(
    limit: int = 50,
    offset: int = 0,
    label: Optional[str] = None,
    only_overrides: bool = False,
):
    """Paginated audit history."""
    entries = _read_audit_log(AUDIT_LOG)
    overrides = _read_audit_log(OVERRIDE_LOG)
    override_map = {o['doc_id']: o for o in overrides if 'doc_id' in o}

    enriched = []
    for e in entries:
        if e.get('doc_id') in override_map:
            e['human_override'] = override_map[e['doc_id']]
        enriched.append(e)

    if label:
        enriched = [e for e in enriched if e.get('label') == label]
    if only_overrides:
        enriched = [e for e in enriched if 'human_override' in e]

    total = len(enriched)
    enriched = list(reversed(enriched))            # newest first
    page = enriched[offset:offset + limit]
    return {'total': total, 'offset': offset, 'limit': limit, 'entries': page}


@app.get('/document/{doc_id}')
def get_document(doc_id: str):
    entries = _read_audit_log(AUDIT_LOG)
    match = [e for e in entries if e.get('doc_id') == doc_id]
    if not match:
        raise HTTPException(404, 'Document not found in audit log.')
    overrides = _read_audit_log(OVERRIDE_LOG)
    approvals = _read_audit_log(APPROVAL_LOG)
    return {
        'audit': match[-1],
        'overrides': [o for o in overrides if o.get('doc_id') == doc_id],
        'approvals': [a for a in approvals if a.get('doc_id') == doc_id],
    }


# ─────────────────────────────────────────────────────────────
# Human-in-the-loop endpoints
# ─────────────────────────────────────────────────────────────

VALID_LABELS = ['Public', 'Internal', 'Confidential', 'Restricted']


@app.post('/override')
def submit_override(req: OverrideRequest):
    """Record a human correction (or confirmation) for a classification."""
    if req.corrected_label not in VALID_LABELS:
        raise HTTPException(400, f'corrected_label must be one of {VALID_LABELS}')
    if req.original_label not in VALID_LABELS:
        raise HTTPException(400, f'original_label must be one of {VALID_LABELS}')

    is_correction = req.corrected_label != req.original_label
    entry = {
        'doc_id': req.doc_id,
        'original_label': req.original_label,
        'corrected_label': req.corrected_label,
        'reviewer': req.reviewer,
        'reason': req.reason or '',
        'is_correction': is_correction,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    }
    with open(OVERRIDE_LOG, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, sort_keys=True) + '\n')

    try:
        webhooks.fire_event('classification.overridden', entry)
    except Exception:
        pass

    return {'status': 'recorded', 'is_correction': is_correction, 'entry': entry}


@app.get('/review-queue')
def get_review_queue():
    queue = active_learning.get_review_queue()
    return {'pending_count': len(queue), 'entries': queue}


# ─────────────────────────────────────────────────────────────
# Approval workflow (Constraint C4)
# ─────────────────────────────────────────────────────────────

@app.post('/approval/sign-off')
def approval_sign_off(req: ApprovalRequest):
    if req.approver not in ('Legal', 'DataGovernance'):
        raise HTTPException(400, "approver must be 'Legal' or 'DataGovernance'")
    if req.decision not in ('approved', 'rejected'):
        raise HTTPException(400, "decision must be 'approved' or 'rejected'")

    entry = {
        'doc_id': req.doc_id,
        'approver': req.approver,
        'decision': req.decision,
        'notes': req.notes or '',
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    }
    with open(APPROVAL_LOG, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, sort_keys=True) + '\n')
    return {'status': 'recorded', 'entry': entry, 'gate_status': _gate_status_for(req.doc_id)}


@app.get('/approval/status/{doc_id}')
def approval_status(doc_id: str):
    return _gate_status_for(doc_id)


def _gate_status_for(doc_id: str) -> Dict[str, Any]:
    audit_entries = [e for e in _read_audit_log(AUDIT_LOG) if e.get('doc_id') == doc_id]
    if not audit_entries:
        return {'doc_id': doc_id, 'error': 'Document not found'}

    latest = audit_entries[-1]
    label = latest.get('label')
    required = {
        'Public': [],
        'Internal': [],
        'Confidential': ['Legal'],
        'Restricted': ['Legal', 'DataGovernance'],
    }.get(label, [])

    approvals = [a for a in _read_audit_log(APPROVAL_LOG) if a.get('doc_id') == doc_id]
    received = {}
    for a in approvals:
        received[a['approver']] = a['decision']

    pending = [r for r in required if received.get(r) != 'approved']
    rejected = any(v == 'rejected' for v in received.values())

    if not required:
        status = 'not_required'
    elif rejected:
        status = 'rejected'
    elif not pending:
        status = 'fully_approved'
    else:
        status = 'pending'

    return {
        'doc_id': doc_id,
        'label': label,
        'required_approvers': required,
        'received': received,
        'pending_approvers': pending,
        'status': status,
    }


# ─────────────────────────────────────────────────────────────
# Webhook CRUD
# ─────────────────────────────────────────────────────────────

@app.get('/webhooks')
def list_webhooks():
    return {'subscriptions': webhooks.list_subscriptions()}


@app.post('/webhooks')
def create_webhook(req: WebhookCreateRequest):
    return webhooks.add_subscription(req.url, req.events, req.secret)


@app.delete('/webhooks/{sub_id}')
def delete_webhook(sub_id: str):
    ok = webhooks.delete_subscription(sub_id)
    if not ok:
        raise HTTPException(404, 'Subscription not found.')
    return {'deleted': sub_id}


@app.post('/webhooks/{sub_id}/test')
def test_webhook(sub_id: str):
    subs = webhooks.list_subscriptions()
    target = next((s for s in subs if s['id'] == sub_id), None)
    if not target:
        raise HTTPException(404, 'Subscription not found.')
    n = webhooks.fire_event('webhook.test', {
        'sub_id': sub_id,
        'note': 'test event from DataShield',
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    })
    return {'delivered': n, 'target_url': target['url']}


@app.get('/webhooks/deliveries')
def webhook_deliveries(limit: int = 50):
    return {'deliveries': webhooks.recent_deliveries(limit)}


# ─────────────────────────────────────────────────────────────
# MLOps endpoints
# ─────────────────────────────────────────────────────────────

@app.get('/mlops/registry')
def mlops_registry():
    try:
        import mlops
        return mlops.load_registry()
    except Exception as e:
        return {'error': str(e)}


@app.get('/mlops/retraining')
def mlops_retraining():
    return active_learning.summary()


@app.post('/mlops/export-batch')
def mlops_export_batch():
    path = active_learning.export_training_batch(include_text=True)
    if not path:
        return {'exported': False, 'reason': 'No pending overrides.'}
    return {'exported': True, 'path': path, 'pending_count': active_learning.count_pending()}


# ─────────────────────────────────────────────────────────────
# Metrics / health
# ─────────────────────────────────────────────────────────────

@app.get('/health')
def health():
    return {
        'status': 'ok',
        'pipeline_loaded': _PIPELINE is not None,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    }


@app.get('/metrics')
def get_metrics():
    entries = _read_audit_log(AUDIT_LOG)
    overrides = _read_audit_log(OVERRIDE_LOG)

    if not entries:
        return {
            'total_classified': 0,
            'total_overrides': 0,
            'human_override_rate': 0.0,
            'override_rate_compliant': True,
            'label_distribution': {},
            'avg_confidence': 0.0,
            'target_override_rate': '< 5%',
        }

    label_counts: Dict[str, int] = {}
    confidence_sum = 0.0
    for e in entries:
        lbl = e.get('label', 'Unknown')
        label_counts[lbl] = label_counts.get(lbl, 0) + 1
        confidence_sum += float(e.get('confidence', 0) or 0)

    total = len(entries)
    real_overrides = [
        o for o in overrides
        if o.get('original_label') != o.get('corrected_label')
    ]
    override_rate = len(real_overrides) / total if total else 0.0

    return {
        'total_classified': total,
        'total_overrides': len(real_overrides),
        'total_confirmations': len(overrides) - len(real_overrides),
        'human_override_rate': round(override_rate * 100, 2),
        'override_rate_compliant': override_rate < 0.05,
        'label_distribution': label_counts,
        'avg_confidence': round(confidence_sum / total, 4) if total else 0.0,
        'target_override_rate': '< 5%',
    }


@app.get('/')
def root():
    return {
        'service': 'DataShield Sensitivity Classification Engine',
        'version': '1.1.0',
        'docs': '/docs',
        'health': '/health',
    }


# ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import uvicorn
    print('[API] Starting DataShield API on http://localhost:8000')
    print('[API] Docs at http://localhost:8000/docs')
    uvicorn.run(app, host='127.0.0.1', port=8000)
