"""
feature_engineering.py
----------------------
PS-01 Layer 3: Feature Engineering — exposed as a separately addressable
layer so the API can return a feature summary and the UI can show what
the model "saw".

What this gives you:
  - Inspectable TF-IDF features (top-k tokens by weight for one document)
  - Hashed n-gram feature stats (used by XGBoost)
  - Metadata-derived numeric features
  - A hook (`embed_optional`) that returns transformer embeddings IF
    transformers + a finetuned artifact are present, else returns None

Why this layer is separate from the model files:
  The PS calls Feature Engineering out as its own component. The classifier
  module already does featurization internally — this layer wraps that with
  introspection: you can ask "what features did doc X produce?" without
  running the full classifier.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Tuple, Optional
import os
import math


@dataclass
class FeatureSummary:
    # TF-IDF top contributing tokens for this doc (cheap to compute)
    tfidf_top: List[Tuple[str, float]] = field(default_factory=list)
    # n-gram stats
    unigram_count: int = 0
    bigram_count: int = 0
    # numeric features used by XGBoost
    numeric_features: Dict[str, float] = field(default_factory=dict)
    # Embedding stats — present only when transformer is loaded
    embedding_dim: Optional[int] = None
    embedding_norm: Optional[float] = None
    # Vocabulary size used (per language)
    vocab_size: int = 0
    used_language: str = 'en'

    def to_dict(self) -> Dict[str, Any]:
        return {
            'tfidf_top': [{'token': t, 'weight': round(float(w), 4)} for t, w in self.tfidf_top],
            'unigram_count': self.unigram_count,
            'bigram_count': self.bigram_count,
            'numeric_features': self.numeric_features,
            'embedding_dim': self.embedding_dim,
            'embedding_norm': self.embedding_norm,
            'vocab_size': self.vocab_size,
            'used_language': self.used_language,
        }


# ─────────────────────────────────────────────────────────────
# TF-IDF introspection — uses the already-trained vectorizer
# ─────────────────────────────────────────────────────────────

def _logistic_model_for_lang(lang: str):
    """
    Lazy load the trained LogisticModel for the given language.
    Cached on first call so we don't reload joblibs on every request.
    """
    cache = _logistic_model_for_lang._cache
    if lang in cache:
        return cache[lang]
    try:
        from models.logistic_model import LogisticModel
        path = os.path.join('artifacts', lang, 'logistic.joblib')
        if not os.path.exists(path):
            cache[lang] = None
            return None
        cache[lang] = LogisticModel.load(path)
        return cache[lang]
    except Exception as e:
        print(f'[feature_engineering] failed to load LR for {lang}: {e}')
        cache[lang] = None
        return None


_logistic_model_for_lang._cache = {}


def tfidf_top_tokens(text: str, lang: str = 'en', top_k: int = 10) -> List[Tuple[str, float]]:
    """
    Return the top-k tokens by TF-IDF weight for this document, using the
    persisted vocabulary from the trained logistic model.

    This is what the UI shows under "Feature Preview" — it lets a human
    auditor see what the model is keying on, even before classification.
    """
    model = _logistic_model_for_lang(lang)
    if model is None:
        return []
    try:
        vec = model.pipeline.named_steps['tfidf']
        feature_names = vec.get_feature_names_out()
        X = vec.transform([text])
        row = X.toarray()[0]
        # Top-k indices
        import numpy as np
        idx = np.argsort(-row)[:top_k]
        return [(feature_names[i], float(row[i])) for i in idx if row[i] > 0]
    except Exception:
        return []


def _ngram_counts(text: str) -> Tuple[int, int]:
    """Count unigrams and bigrams (whitespace-split)."""
    toks = text.split()
    unigram = len(toks)
    bigram = max(0, len(toks) - 1)
    return unigram, bigram


def _numeric_features(text: str) -> Dict[str, float]:
    """Cheap text statistics — same ones XGBoost uses."""
    if not text:
        return {'num_chars': 0.0, 'num_tokens': 0.0, 'num_digits': 0.0, 'digit_ratio': 0.0}
    num_chars = len(text)
    num_tokens = len(text.split())
    num_digits = sum(ch.isdigit() for ch in text)
    return {
        'num_chars': float(num_chars),
        'num_tokens': float(num_tokens),
        'num_digits': float(num_digits),
        'digit_ratio': round(num_digits / max(num_chars, 1), 4),
    }


# ─────────────────────────────────────────────────────────────
# Optional transformer embedding hook
# ─────────────────────────────────────────────────────────────

def embed_optional(text: str, lang: str = 'en') -> Optional[Dict[str, float]]:
    """
    If a fine-tuned transformer exists, return embedding stats (dim, L2 norm).
    Returns None otherwise. The classifier doesn't depend on this — it's
    purely for the UI's "Feature Preview" panel.
    """
    try:
        from models.transformer_model import TORCH_AVAILABLE, TransformerModel
    except Exception:
        return None
    if not TORCH_AVAILABLE:
        return None

    path = os.path.join('artifacts', lang, 'transformer.joblib')
    if not os.path.exists(path):
        return None
    try:
        model = TransformerModel.load(path)
        # Most transformer models in this project expose a hidden-state
        # extraction method; we only need stats, not the vector itself.
        if hasattr(model, 'encode'):
            vec = model.encode([text])
            if vec is None or len(vec) == 0:
                return None
            import numpy as np
            arr = np.asarray(vec[0])
            return {
                'embedding_dim': int(arr.shape[0]),
                'embedding_norm': float(np.linalg.norm(arr)),
            }
    except Exception:
        return None
    return None


# ─────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────

def featurize(text: str, lang: str = 'en', top_k: int = 10) -> FeatureSummary:
    """
    Build a FeatureSummary for one document. The classifier still owns
    the actual feature matrix it uses for inference — this is the
    *inspectable* view of those features.
    """
    if not text:
        return FeatureSummary(used_language=lang)

    tfidf_top = tfidf_top_tokens(text, lang=lang, top_k=top_k)
    uni, bi = _ngram_counts(text)
    nums = _numeric_features(text)

    vocab_size = 0
    model = _logistic_model_for_lang(lang)
    if model is not None:
        try:
            vocab_size = len(model.pipeline.named_steps['tfidf'].get_feature_names_out())
        except Exception:
            vocab_size = 0

    embed_stats = embed_optional(text, lang=lang)

    return FeatureSummary(
        tfidf_top=tfidf_top,
        unigram_count=uni,
        bigram_count=bi,
        numeric_features=nums,
        embedding_dim=embed_stats.get('embedding_dim') if embed_stats else None,
        embedding_norm=embed_stats.get('embedding_norm') if embed_stats else None,
        vocab_size=vocab_size,
        used_language=lang,
    )
