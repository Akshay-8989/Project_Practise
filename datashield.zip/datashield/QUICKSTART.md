# DataShield — 30-second Quickstart

```bash
pip install -r requirements.txt
python run.py
```

Open **http://localhost:8501**

That's it.

---

## Three things to try

1. **Classify** — sidebar → "📄 Classify Documents" → tab "📝 Paste Text" → click **Sample: Restricted** → **🚀 Classify**.
2. **Correct it** — at the bottom of the result, click **✏️ Submit Correction** with a different label. That's the human-in-the-loop flow.
3. **Watch the trigger fire** — sidebar → "📊 Metrics & MLOps" → see the retraining trigger turn 🔴 urgent (because your one override produced a 100% override rate on one classification).

For the full feature tour, see [README.md](README.md).
