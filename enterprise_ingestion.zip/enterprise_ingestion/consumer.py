"""
consumer.py
============
Enterprise Kafka Consumer for the ingestion layer.

Consumes from two topics:

  ingest_requests
    Upstream source systems publish IngestEvent messages here.
    This enables fully event-driven ingestion triggered by ERP, CRM, HRMS,
    SharePoint, email systems, etc. without polling or manual uploads.
    Consumer deserialises → validates → calls process_event().

  retry_queue
    retry_handler publishes RetryEvent messages here when a pipeline
    run fails but hasn't hit the retry limit.
    Consumer re-publishes the original event back to ingest_requests
    after the retry_after timestamp has passed.

Design principles:
  - Manual offset commit: offsets only committed after successful processing
  - Graceful shutdown: SIGINT/SIGTERM handled cleanly
  - Dead-letter on persistent failure: events that keep failing go to DLQ
  - Non-blocking: each message processed synchronously but consumer loop
    handles one message at a time (safe for current throughput)
  - Extensible: easy to add more topics (e.g. storage events from S3)
"""

from __future__ import annotations

import json
import signal
import sys
import time
from datetime import datetime
from typing import Any, Dict

from kafka import KafkaConsumer
from kafka.errors import NoBrokersAvailable

from schema import IngestEvent, BusinessMetadata, RetryEvent
from config import CONFIG
from logger import get_logger
from producer import IngestionProducer
from app import process_event
from retry_handler import build_dlq_record

log = get_logger("consumer")


def _deserialise(data: bytes) -> Dict:
    try:
        return json.loads(data.decode("utf-8")) if data else {}
    except Exception:
        return {}


# ─────────────────────────────────────────────────────────────────────────────
# Ingest Request Consumer
# ─────────────────────────────────────────────────────────────────────────────

class IngestRequestConsumer:
    """
    Consumes IngestEvent messages from the ingest_requests topic.

    Upstream source systems publish events here when documents are ready
    for ingestion. This eliminates the need for polling or manual uploads
    in production environments.

    Event format (what upstream systems publish):
    {
        "event_id":     "uuid",
        "event_timestamp": "ISO 8601",
        "ingest_source": "kafka_event",
        "file_uri":     "s3://bucket/path/to/document.pdf",  OR local path
        "file_name":    "document.pdf",
        "metadata": {
            "source_system": "HRMS",
            "department":    "HR",
            "business_unit": "People Ops",
            "region":        "India",
            "owner":         "hr-team@company.com",
            "document_type": "hr_record",
            "created_at":    "2026-04-18"
        }
    }
    """

    def __init__(self):
        self._running  = True
        self._producer = None
        self._consumer = None

        signal.signal(signal.SIGINT,  self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)

    def run(self):
        """Start the consumer loop. Blocks until shutdown signal received."""
        try:
            self._producer = IngestionProducer()
            self._consumer = KafkaConsumer(
                CONFIG.topics.ingest_requests,
                value_deserializer = _deserialise,
                key_deserializer   = lambda k: k.decode("utf-8") if k else None,
                **CONFIG.kafka.consumer_kwargs([CONFIG.topics.ingest_requests]),
            )
        except NoBrokersAvailable as exc:
            log.critical(
                "Kafka not reachable at %s — start Kafka before running consumer.",
                CONFIG.kafka.bootstrap_servers,
            )
            raise

        log.info(
            "Ingest consumer started | topic=%s | group=%s",
            CONFIG.topics.ingest_requests, CONFIG.kafka.group_id,
        )

        try:
            for msg in self._consumer:
                if not self._running:
                    break
                self._process_message(msg)
        finally:
            self._shutdown()

    def _process_message(self, msg):
        raw = msg.value
        log.info(
            "Received ingest_request | topic=%s partition=%d offset=%d",
            msg.topic, msg.partition, msg.offset,
        )

        # Deserialise IngestEvent
        try:
            meta_data = raw.get("metadata", {})
            event = IngestEvent(
                event_id      = raw.get("event_id", ""),
                event_timestamp=raw.get("event_timestamp", datetime.utcnow().isoformat()),
                ingest_source = raw.get("ingest_source", "kafka_event"),
                file_uri      = raw.get("file_uri"),
                file_name     = raw.get("file_name"),
                metadata      = BusinessMetadata(**{
                    k: v for k, v in meta_data.items()
                    if k in BusinessMetadata.model_fields
                }),
            )
        except Exception as exc:
            log.error("Malformed ingest_request message: %s | raw=%s", exc, raw)
            self._consumer.commit()
            return

        # Run pipeline
        result = process_event(event, producer=self._producer)

        if result.success:
            log.info("Processed successfully: %s", result)
        else:
            log.warning("Processing failed: %s", result)

        # Manual offset commit (only after processing)
        self._consumer.commit()

    def _handle_shutdown(self, *_):
        log.info("Shutdown signal received — stopping consumer after current message.")
        self._running = False

    def _shutdown(self):
        if self._consumer:
            self._consumer.close()
        if self._producer:
            self._producer.close()
        log.info("Consumer shut down cleanly.")


# ─────────────────────────────────────────────────────────────────────────────
# Retry Consumer
# ─────────────────────────────────────────────────────────────────────────────

class RetryConsumer:
    """
    Consumes RetryEvent messages from retry_queue.
    Re-publishes the original IngestEvent to ingest_requests after
    the retry_after timestamp has passed (backoff respected).
    """

    def __init__(self):
        self._running  = True
        self._producer = None
        self._consumer = None

        signal.signal(signal.SIGINT,  self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)

    def run(self):
        try:
            self._producer = IngestionProducer()
            self._consumer = KafkaConsumer(
                CONFIG.topics.retry_queue,
                value_deserializer = _deserialise,
                **CONFIG.kafka.consumer_kwargs([CONFIG.topics.retry_queue]),
            )
        except NoBrokersAvailable as exc:
            log.critical("Kafka not reachable: %s", exc)
            raise

        log.info("Retry consumer started | topic=%s", CONFIG.topics.retry_queue)

        try:
            for msg in self._consumer:
                if not self._running:
                    break
                self._process_retry(msg.value)
                self._consumer.commit()
        finally:
            self._shutdown()

    def _process_retry(self, raw: Dict):
        try:
            retry_event = RetryEvent(**raw)
        except Exception as exc:
            log.error("Malformed retry event: %s", exc)
            return

        # Honour retry_after — wait if needed
        retry_after = datetime.fromisoformat(retry_event.retry_after)
        now         = datetime.utcnow()
        if retry_after > now:
            wait = (retry_after - now).total_seconds()
            log.info("Waiting %.1fs before retry (attempt %d)", wait, retry_event.attempt_number)
            time.sleep(wait)

        if retry_event.attempt_number > CONFIG.retry.max_attempts:
            log.error(
                "Max retries exceeded for event %s — escalating to DLQ",
                retry_event.original_event.get("event_id", "?"),
            )
            ctx = {
                "event_id":    retry_event.original_event.get("event_id", ""),
                "ingest_id":   retry_event.original_event.get("ingest_id", ""),
                "file_name":   retry_event.original_event.get("file_name", ""),
                "source_system": retry_event.original_event.get("metadata", {}).get("source_system", ""),
            }
            dlr = build_dlq_record(
                context     = ctx,
                stage       = "retry_consumer",
                reason      = "MAX_RETRIES_EXCEEDED",
                detail      = retry_event.failure_detail,
                retry_count = retry_event.attempt_number,
                original_event = retry_event.original_event,
            )
            self._producer.send_dlq(dlr.model_dump())
            return

        # Re-publish to ingest_requests for another attempt
        log.info(
            "Re-publishing retry attempt %d for %s",
            retry_event.attempt_number,
            retry_event.original_event.get("file_name", "?"),
        )
        self._producer._send(
            CONFIG.topics.ingest_requests,
            key=retry_event.original_event.get("event_id"),
            data=retry_event.original_event,
        )
        self._producer.flush(timeout=10)

    def _handle_shutdown(self, *_):
        self._running = False

    def _shutdown(self):
        if self._consumer:
            self._consumer.close()
        if self._producer:
            self._producer.close()
        log.info("Retry consumer shut down.")
