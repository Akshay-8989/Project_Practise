"""
main.py
========
Enterprise Ingestion Layer — CLI entry point.

Run modes:
  python main.py folder                     # batch process uploads/
  python main.py folder --path /my/docs     # batch from custom path
  python main.py watch                      # live folder watcher
  python main.py consumer                   # Kafka event consumer (ingest_requests)
  python main.py retry-consumer             # Kafka retry consumer
  python main.py file --uri uploads/doc.pdf # single file
  python main.py api                        # start FastAPI upload endpoint

Metadata can be supplied via:
  --source HRMS --department Finance --owner "Priya Nair"
  --meta path/to/meta.json    (full metadata JSON file)
"""

import argparse
import json
import sys

from config import CONFIG
from logger import get_logger
from schema import BusinessMetadata, IngestEvent, IngestSource

log = get_logger("main")


def main():
    parser = argparse.ArgumentParser(
        description="Enterprise Ingestion Layer — Automated Sensitivity Classification Platform",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Run modes:
  python main.py folder                         Batch process uploads/ folder
  python main.py folder --path /my/docs         Batch from custom folder
  python main.py watch                          Live folder watcher
  python main.py consumer                       Kafka ingest_requests consumer
  python main.py retry-consumer                 Kafka retry_queue consumer
  python main.py file --uri uploads/report.pdf  Single file ingestion
  python main.py api                            FastAPI upload endpoint

Examples:
  python main.py folder --source HRMS --department HR
  python main.py file --uri uploads/contract.pdf --source ERP --department Legal
  python main.py watch --interval 3 --source EMAIL
  python main.py folder --meta sample_events/hrms_meta.json
        """,
    )

    parser.add_argument(
        "mode",
        choices=["folder", "watch", "consumer", "retry-consumer", "file", "api"],
        help="Run mode",
    )

    # File / folder options
    parser.add_argument("--uri",      type=str, help="File URI or path (for 'file' mode)")
    parser.add_argument("--path",     type=str, help="Folder path (for 'folder' / 'watch' modes)")
    parser.add_argument("--interval", type=float, default=5.0,
                        help="Watch mode poll interval in seconds (default: 5)")

    # Metadata inputs
    parser.add_argument("--source",       type=str, default="MANUAL",
                        help="Source system (HRMS, ERP, CRM, EMAIL, …)")
    parser.add_argument("--department",   type=str, help="Department")
    parser.add_argument("--business-unit",type=str, help="Business unit")
    parser.add_argument("--owner",        type=str, help="Document owner / author")
    parser.add_argument("--region",       type=str, help="Region (India, US, EU, …)")
    parser.add_argument("--doc-type",     type=str, default="general",
                        help="Document type (contract, invoice, hr_record, …)")
    parser.add_argument("--meta",         type=str,
                        help="Path to a JSON file containing full metadata dict")

    parser.add_argument("--log-level", default=CONFIG.log_level,
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])

    args = parser.parse_args()

    # Apply log level override
    CONFIG.log_level = args.log_level.upper()

    # Build metadata from CLI args + optional JSON file
    meta_dict = {}
    if args.meta:
        try:
            with open(args.meta, "r", encoding="utf-8") as f:
                meta_dict = json.load(f)
            print(f"Metadata loaded from: {args.meta}")
        except Exception as exc:
            print(f"WARNING: Could not load metadata file {args.meta}: {exc}")

    # CLI args override JSON file
    if args.source:
        meta_dict["source_system"]  = args.source.upper()
    if args.department:
        meta_dict["department"]     = args.department
    if getattr(args, "business_unit", None):
        meta_dict["business_unit"]  = args.business_unit
    if args.owner:
        meta_dict["owner"]          = args.owner
    if args.region:
        meta_dict["region"]         = args.region
    if getattr(args, "doc_type", None):
        meta_dict["document_type"]  = args.doc_type

    biz_meta = BusinessMetadata(**{
        k: v for k, v in meta_dict.items()
        if k in BusinessMetadata.model_fields
    })

    # ── Dispatch to run mode ──────────────────────────────────────────────

    if args.mode == "folder":
        from app import process_folder
        folder = args.path or CONFIG.upload_folder
        print(f"\nBatch ingesting: {folder}")
        results = process_folder(
            folder_path   = folder,
            ingest_source = IngestSource.FOLDER_WATCH.value,
            inline_meta   = meta_dict or None,
        )
        ok   = sum(1 for r in results if r.success)
        fail = len(results) - ok
        print(f"\nSummary: {ok} OK | {fail} FAILED | {len(results)} total")
        if fail:
            sys.exit(1)

    elif args.mode == "watch":
        from app import watch_folder
        folder = args.path or CONFIG.upload_folder
        print(f"\nWatching: {folder}  (interval={args.interval}s)  Ctrl+C to stop")
        watch_folder(
            folder_path   = folder,
            ingest_source = IngestSource.FOLDER_WATCH.value,
            poll_seconds  = args.interval,
            inline_meta   = meta_dict or None,
        )

    elif args.mode == "consumer":
        from consumer import IngestRequestConsumer
        print(f"\nStarting Kafka consumer → topic: {CONFIG.topics.ingest_requests}")
        IngestRequestConsumer().run()

    elif args.mode == "retry-consumer":
        from consumer import RetryConsumer
        print(f"\nStarting Kafka retry consumer → topic: {CONFIG.topics.retry_queue}")
        RetryConsumer().run()

    elif args.mode == "file":
        if not args.uri:
            print("ERROR: --uri is required for 'file' mode")
            sys.exit(1)
        from app import process_event
        from producer import IngestionProducer

        print(f"\nIngesting file: {args.uri}")
        event = IngestEvent(
            ingest_source = IngestSource.API_UPLOAD.value,
            file_uri      = args.uri,
            file_name     = args.uri.split("/")[-1].split("\\")[-1],
            metadata      = biz_meta,
        )
        result = process_event(event)
        print(f"\nResult: {result}")
        if not result.success:
            sys.exit(1)

    elif args.mode == "api":
        _start_api()


def _start_api():
    """Start the FastAPI upload endpoint."""
    try:
        import uvicorn
        from api import create_app
        app = create_app()
        print(f"\nStarting API server at http://{CONFIG.api_host}:{CONFIG.api_port}")
        print("POST /ingest        — Upload file with metadata JSON")
        print("POST /ingest/event  — Submit IngestEvent JSON")
        print("GET  /health        — Health check")
        uvicorn.run(app, host=CONFIG.api_host, port=CONFIG.api_port)
    except ImportError:
        print(
            "FastAPI/uvicorn not installed for API mode.\n"
            "Run: pip install fastapi uvicorn python-multipart"
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
