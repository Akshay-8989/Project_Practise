"""
metadata_handler.py
====================
Enterprise metadata handling.

Metadata arrives from upstream source systems via four patterns:

  Pattern 1: Kafka event payload
    → IngestEvent.metadata already populated by source system
    → This module validates and normalises it

  Pattern 2: API request body (FastAPI)
    → Metadata JSON in request body alongside file bytes
    → Same validation path

  Pattern 3: Storage URI + sidecar metadata
    → File at s3://bucket/key or local path
    → Metadata JSON at same path with .meta.json suffix
    → OR metadata in object metadata tags

  Pattern 4: Embedded file metadata
    → PDF XMP / EXIF tags
    → DOCX custom properties
    → EML headers (From, Subject, Date = business metadata)

This module:
  1. Accepts metadata from any of these patterns
  2. Validates required fields
  3. Normalises formats (dates → ISO 8601, strings → title case)
  4. Fills missing optionals with "UNKNOWN"
  5. Records issues for audit trail WITHOUT blocking ingestion
  6. Returns a validated BusinessMetadata object

Critical design: metadata validation issues are AUDITED, not blocking.
A document with missing department still gets ingested — the audit record
shows the gap so data governance can follow up.
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from schema import BusinessMetadata
from config import CONFIG
from logger import get_logger

log = get_logger("metadata_handler")

# Required fields — absence is flagged in audit
_REQUIRED = [
    "source_system", "department", "business_unit",
    "region", "owner", "document_type",
]

# Date normalisation patterns
_DATE_PATTERNS = [
    (r"^\d{4}-\d{2}-\d{2}$",              "%Y-%m-%d"),    # ISO 8601 — already good
    (r"^\d{2}/\d{2}/\d{4}$",              "%d/%m/%Y"),    # DD/MM/YYYY
    (r"^\d{2}-\d{2}-\d{4}$",              "%d-%m-%Y"),    # DD-MM-YYYY
    (r"^\d{4}/\d{2}/\d{2}$",              "%Y/%m/%d"),    # YYYY/MM/DD
]


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def resolve_metadata(
    file_path:       Optional[str]  = None,
    inline_meta:     Optional[Dict] = None,
    file_bytes:      Optional[bytes]= None,
    file_name:       Optional[str]  = None,
) -> BusinessMetadata:
    """
    Resolve, validate, and normalise business metadata for a document.

    Resolution priority (first non-empty source wins, then merged):
      1. inline_meta  — from Kafka event / API body / programmatic caller
      2. Sidecar JSON — <filename>.meta.json alongside the file
      3. Embedded     — extracted from PDF XMP, DOCX properties, EML headers

    Returns a validated BusinessMetadata object.
    """
    raw: Dict = {}

    # ── Source 1: Inline metadata (highest priority) ──────────────────────
    if inline_meta and isinstance(inline_meta, dict):
        raw.update(inline_meta)
        log.debug("Metadata resolved from inline input")

    # ── Source 2: Sidecar .meta.json ─────────────────────────────────────
    if file_path:
        sidecar = _load_sidecar(file_path)
        if sidecar:
            # Sidecar fills in any gaps not provided inline
            for k, v in sidecar.items():
                if k not in raw or not raw[k]:
                    raw[k] = v
            log.debug("Sidecar metadata loaded for %s", file_path)

    # ── Source 3: Embedded metadata ───────────────────────────────────────
    fname = file_name or (os.path.basename(file_path) if file_path else "")
    ext   = Path(fname).suffix.lower().lstrip(".")

    if ext == "eml" and file_path:
        embedded = _extract_eml_metadata(file_path)
        for k, v in embedded.items():
            if k not in raw or not raw[k]:
                raw[k] = v
        log.debug("EML embedded metadata extracted for %s", fname)

    elif ext == "docx" and file_path:
        embedded = _extract_docx_metadata(file_path)
        for k, v in embedded.items():
            if k not in raw or not raw[k]:
                raw[k] = v
        log.debug("DOCX embedded metadata extracted for %s", fname)

    # ── Validate and normalise ────────────────────────────────────────────
    return _validate_and_normalise(raw, fname)


def _validate_and_normalise(raw: Dict, fname: str = "") -> BusinessMetadata:
    """Validate and normalise a raw metadata dict → BusinessMetadata."""
    issues: List[str] = []
    m = dict(raw)

    # ── Required fields ───────────────────────────────────────────────────
    for field in _REQUIRED:
        val = m.get(field, "")
        if not val or (isinstance(val, str) and val.strip() in ("", "unknown", "UNKNOWN")):
            m[field] = "UNKNOWN"
            issues.append(f"missing_required:{field}")
        else:
            m[field] = str(val).strip()

    # ── source_system — normalise to UPPER ────────────────────────────────
    ss = m.get("source_system", "UNKNOWN")
    if ss != "UNKNOWN":
        ss = ss.upper().strip()
        m["source_system"] = ss
        if ss not in CONFIG.validation.allowed_source_systems:
            issues.append(f"unknown_source_system:{ss}")

    # ── department — Title Case ───────────────────────────────────────────
    dept = m.get("department", "UNKNOWN")
    if dept != "UNKNOWN":
        dept = dept.strip().title()
        m["department"] = dept
        if dept not in CONFIG.validation.allowed_departments:
            issues.append(f"unknown_department:{dept}")

    # ── document_type — lower ─────────────────────────────────────────────
    dt = m.get("document_type", "general")
    if dt and dt != "UNKNOWN":
        dt = dt.lower().strip()
        m["document_type"] = dt
        if dt not in CONFIG.validation.allowed_document_types:
            issues.append(f"unknown_document_type:{dt}")

    # ── region — Title Case ───────────────────────────────────────────────
    region = m.get("region", "UNKNOWN")
    if region != "UNKNOWN":
        region = region.strip().title()
        m["region"] = region
        if region not in CONFIG.validation.allowed_regions:
            issues.append(f"unknown_region:{region}")

    # ── created_at — normalise to ISO 8601 ───────────────────────────────
    created_at = m.get("created_at") or m.get("creation_date") or ""
    if created_at:
        normalised = _normalise_date(str(created_at))
        m["created_at"] = normalised or created_at
        if not normalised:
            issues.append(f"invalid_date_format:{created_at}")

    # ── owner / author aliases ────────────────────────────────────────────
    if not m.get("owner") or m["owner"] == "UNKNOWN":
        m["owner"] = m.get("author") or m.get("created_by") or "UNKNOWN"
    m["owner"] = " ".join(str(m["owner"]).split())

    # ── tags — ensure list ────────────────────────────────────────────────
    tags = m.get("tags", [])
    if isinstance(tags, str):
        tags = [t.strip() for t in tags.split(",") if t.strip()]
    m["tags"] = tags

    is_complete = len([i for i in issues if i.startswith("missing_required")]) == 0

    if issues:
        log.warning("Metadata issues for %s: %s", fname, "; ".join(issues))
    else:
        log.debug("Metadata validated OK for %s", fname)

    return BusinessMetadata(
        document_id    = m.get("document_id") or m.get("doc_id"),
        source_system  = m.get("source_system", "UNKNOWN"),
        department     = m.get("department", "UNKNOWN"),
        business_unit  = m.get("business_unit", "UNKNOWN"),
        region         = m.get("region", "UNKNOWN"),
        owner          = m.get("owner", "UNKNOWN"),
        document_type  = m.get("document_type", "general"),
        client_name    = m.get("client_name", "UNKNOWN"),
        source_channel = m.get("source_channel", "UNKNOWN"),
        created_at     = m.get("created_at"),
        tags           = m.get("tags", []),
        validation_issues = issues,
        is_complete    = is_complete,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Sidecar loader
# ─────────────────────────────────────────────────────────────────────────────

def _load_sidecar(file_path: str) -> Optional[Dict]:
    """
    Look for <basename>.meta.json alongside the file.
    Supports:  report.pdf  →  report.meta.json  OR  report.pdf.meta.json
    """
    p     = Path(file_path)
    candidates = [
        p.parent / f"{p.stem}.meta.json",
        p.parent / f"{p.name}.meta.json",
        # Also look in dedicated metadata/ folder at project root
        Path("metadata") / f"{p.stem}.meta.json",
        Path("metadata") / f"{p.stem}.json",
    ]
    for candidate in candidates:
        if candidate.is_file():
            try:
                with open(candidate, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as exc:
                log.error("Failed reading sidecar %s: %s", candidate, exc)
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Embedded metadata extractors
# ─────────────────────────────────────────────────────────────────────────────

def _extract_eml_metadata(file_path: str) -> Dict:
    """Extract business metadata signals from EML headers."""
    import email as _email
    meta = {}
    try:
        with open(file_path, "rb") as f:
            msg = _email.message_from_bytes(f.read())
        meta["owner"]          = msg.get("From", "")
        meta["source_channel"] = "email_export"
        meta["document_type"]  = "email"
        date_str = msg.get("Date", "")
        if date_str:
            # Parse RFC 2822 date
            from email.utils import parsedate_to_datetime
            try:
                meta["created_at"] = parsedate_to_datetime(date_str).strftime("%Y-%m-%d")
            except Exception:
                pass
    except Exception as exc:
        log.debug("EML metadata extraction failed: %s", exc)
    return meta


def _extract_docx_metadata(file_path: str) -> Dict:
    """Extract business metadata from DOCX core properties."""
    meta = {}
    try:
        from docx import Document
        doc = Document(file_path)
        props = doc.core_properties
        if props.author:
            meta["owner"] = props.author
        if props.created:
            meta["created_at"] = props.created.strftime("%Y-%m-%d")
        if props.category:
            meta["document_type"] = props.category.lower()
        meta["source_channel"] = "direct_upload"
    except Exception as exc:
        log.debug("DOCX metadata extraction failed: %s", exc)
    return meta


# ─────────────────────────────────────────────────────────────────────────────
# Date normalisation
# ─────────────────────────────────────────────────────────────────────────────

def _normalise_date(raw: str) -> Optional[str]:
    """Normalise various date formats to ISO 8601 (YYYY-MM-DD)."""
    raw = raw.strip()
    if re.match(r"^\d{4}-\d{2}-\d{2}$", raw):
        return raw                    # already ISO 8601

    for pattern, fmt in _DATE_PATTERNS[1:]:   # skip ISO which is already handled
        if re.match(pattern, raw):
            try:
                return datetime.strptime(raw, fmt).strftime("%Y-%m-%d")
            except ValueError:
                pass

    # Try Python's flexible parser for formats like "18 April 2026"
    for fmt in ("%d %B %Y", "%B %d, %Y", "%d-%b-%Y", "%d %b %Y"):
        try:
            return datetime.strptime(raw, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass

    return None
