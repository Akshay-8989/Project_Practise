"""
producer.py
============
Enterprise Kafka producer for the ingestion layer.

Design:
  - All sends are async with callbacks (non-blocking pipeline)
  - Manual flush() before close to guarantee delivery
  - Per-topic convenience methods — callers never hardcode topic strings
  - Idempotent producer prevents duplicate messages on retry
  - Compression reduces network cost for large document payloads
  - Context manager support for clean lifecycle management

Topic routing:
  raw_documents        → every document (full history, unfiltered)
  normalized_documents → every valid, enriched document
  single_entity_docs   → single-entity documents (SINGLE structure)
  multi_entity_docs    → each segment of multi-entity documents
  audit_logs           → every document processed (success + failure)
  retry_queue          → failed documents within retry limit
  dead_letter_queue    → failed documents past retry limit
"""

import json
from typing import Any, Dict, Optional

from kafka import KafkaProducer
from kafka.errors import KafkaError, NoBrokersAvailable

from config import CONFIG
from logger import get_logger

log = get_logger("producer")


def _serialise(obj: Any) -> bytes:
    return json.dumps(obj, default=str, ensure_ascii=False).encode("utf-8")

def _key_bytes(key: Optional[str]) -> Optional[bytes]:
    return key.encode("utf-8") if key else None


class IngestionProducer:
    """
    Kafka producer wrapper for the enterprise ingestion layer.

    Usage (context manager — preferred):
        with IngestionProducer() as producer:
            producer.send_normalized(doc.model_dump())
            producer.send_audit(audit.model_dump())

    Usage (explicit lifecycle):
        producer = IngestionProducer()
        producer.send_single(payload)
        producer.flush()
        producer.close()
    """

    def __init__(self):
        try:
            self._producer = KafkaProducer(
                value_serializer = _serialise,
                key_serializer   = _key_bytes,
                **CONFIG.kafka.producer_kwargs(),
            )
            log.info(
                "Kafka producer connected | broker=%s | idempotent=%s",
                CONFIG.kafka.bootstrap_servers,
                CONFIG.kafka.enable_idempotence,
            )
        except NoBrokersAvailable as exc:
            log.critical(
                "Kafka broker not reachable at %s. "
                "Start Kafka before running the ingestion layer. "
                "See README — Kafka setup section.",
                CONFIG.kafka.bootstrap_servers,
            )
            raise

    # ── Context manager ───────────────────────────────────────────────────

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ── Topic senders ─────────────────────────────────────────────────────

    def send_raw(self, payload: Dict):
        """Raw document — written before any processing. Full history."""
        self._send(
            CONFIG.topics.raw_documents,
            key=payload.get("doc_id"),
            data=payload,
        )

    def send_normalized(self, payload: Dict):
        """Normalised document — enriched, validated, ready for downstream."""
        self._send(
            CONFIG.topics.normalized_docs,
            key=payload.get("doc_id"),
            data=payload,
        )

    def send_single(self, payload: Dict):
        """Single-entity document → Classification Layer reads this."""
        self._send(
            CONFIG.topics.single_entity,
            key=payload.get("doc_id"),
            data=payload,
        )

    def send_multi(self, payload: Dict):
        """One segment of a multi-entity document → Classification Layer reads this."""
        self._send(
            CONFIG.topics.multi_entity,
            key=payload.get("doc_id"),
            data=payload,
        )

    def send_audit(self, entry: Dict):
        """Audit record → Governance dashboard / compliance systems read this."""
        self._send(
            CONFIG.topics.audit_logs,
            key=entry.get("ingest_id"),
            data=entry,
        )

    def send_retry(self, entry: Dict):
        """Retry event → retry_handler.py consumes this."""
        self._send(
            CONFIG.topics.retry_queue,
            key=entry.get("retry_id"),
            data=entry,
        )

    def send_dlq(self, record: Dict):
        """Dead letter record → operations team monitors this."""
        self._send(
            CONFIG.topics.dlq,
            key=record.get("ingest_id") or record.get("file_name", "unknown"),
            data=record,
        )

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def flush(self, timeout: int = 30):
        """Block until all pending messages are acknowledged by the broker."""
        self._producer.flush(timeout=timeout)
        log.debug("Producer flushed.")

    def close(self):
        self.flush()
        self._producer.close()
        log.info("Kafka producer closed.")

    # ── Internal ──────────────────────────────────────────────────────────

    def _send(self, topic: str, key: Optional[str], data: Dict):
        try:
            (
                self._producer
                .send(topic, key=key, value=data)
                .add_callback(self._on_success)
                .add_errback(self._on_error)
            )
        except KafkaError as exc:
            log.error("Immediate send failure → topic=%s key=%s err=%s", topic, key, exc)

    @staticmethod
    def _on_success(meta):
        log.debug(
            "Delivered → topic=%-30s partition=%d offset=%d",
            meta.topic, meta.partition, meta.offset,
        )

    @staticmethod
    def _on_error(exc: KafkaError):
        log.error("Kafka delivery failure: %s", exc)
