# Enterprise Ingestion Layer
## Automated Sensitivity Classification Platform — v2.0

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    ENTERPRISE SOURCE SYSTEMS                            │
│  HRMS │ ERP │ CRM │ SharePoint │ Email │ DMS │ S3 │ Manual Upload       │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │  (4 intake patterns)
         ┌─────────────────┼─────────────────────────────┐
         │                 │                             │
  Kafka Event         API Upload                  Folder Watch
  (ingest_requests)   POST /ingest                (local/storage)
         │                 │                             │
         └─────────────────▼─────────────────────────────┘
                           │
              ┌────────────▼────────────┐
              │   ENTERPRISE INGESTION  │
              │        LAYER            │
              │                         │
              │  [1] Event Validation   │
              │  [2] File Resolution    │
              │  [3] Type + Size Check  │
              │  [4] Text Extraction    │  pdfplumber │ python-docx
              │       (with retry)      │  pandas │ stdlib
              │  [5] Metadata Resolve   │  inline → sidecar → embedded
              │  [6] Technical Meta     │  checksum, MIME, size
              │  [7] Structure Detect   │  SINGLE vs MULTI (heuristic)
              │  [8] Build Schema       │  NormalizedDocument
              │  [9] Payload Validate   │  Pydantic
              │ [10] Kafka Publish      │
              │ [11] Audit Log          │
              └────────────┬────────────┘
                           │
         ┌─────────────────┼─────────────────────────────────────────┐
         │                 │                    │                    │
  raw_documents   normalized_documents   single_entity_docs  multi_entity_docs
  (full history)  (all valid docs)       (1 classification)  (N classifications)
         │
         ├── audit_logs           (every document — success + failure)
         ├── retry_queue          (failed, within retry limit)
         └── dead_letter_queue    (failed, all retries exhausted)
                           │
              ┌────────────▼────────────────────────────────────────┐
              │           DOWNSTREAM LAYERS (future)                │
              │                                                     │
              │  [Preprocessing]    PII masking, tokenisation       │
              │  [Feature Eng.]     TF-IDF + BERT embeddings        │
              │  [Classification]   Ensemble model → label          │
              │  [Policy Engine]    Rule overlay for Restricted      │
              │  [Output API]       FastAPI → label + score          │
              │  [Governance]       Audit dashboard, compliance      │
              └─────────────────────────────────────────────────────┘
```

---

## Kafka Topics

| Topic | Written by | Consumed by | Purpose |
|---|---|---|---|
| `ingest_requests` | Source systems / API | `consumer.py` | Event-driven intake |
| `raw_documents` | Ingestion layer | Archive / replay | Full history, unfiltered |
| `normalized_documents` | Ingestion layer | All downstream | Validated, enriched docs |
| `single_entity_docs` | Ingestion layer | Classification Layer | One doc → one label |
| `multi_entity_docs` | Ingestion layer | Classification Layer | One segment → one label |
| `audit_logs` | Ingestion layer | Governance dashboard | Compliance trail |
| `retry_queue` | Ingestion layer | `retry_handler.py` | Backoff retry |
| `dead_letter_queue` | Ingestion layer | Ops team | Manual remediation |

---

## Normalized Document Schema

Every message published to `normalized_documents`, `single_entity_docs`, and
`multi_entity_docs` follows this schema. The Classification Layer reads this.

```json
{
  "doc_id":        "uuid",
  "parent_doc_id": null,
  "event_id":      "evt-20260418-hrms-001",

  "raw_text":      "...extracted content...",
  "segment_index": null,
  "total_segments": null,
  "segment_type":  "full_document",

  "structure_type": "single",
  "data_category":  "unstructured",

  "business_metadata": {
    "document_id":    "HRMS-DOC-2026-00441",
    "source_system":  "HRMS",
    "department":     "HR",
    "business_unit":  "People Operations",
    "region":         "India",
    "owner":          "hr@company.com",
    "document_type":  "hr_record",
    "created_at":     "2026-04-15",
    "tags":           ["onboarding", "pii"],
    "is_complete":    true,
    "validation_issues": []
  },

  "technical_metadata": {
    "ingest_id":        "uuid",
    "ingest_timestamp": "2026-04-18T10:30:15.123456",
    "ingest_source":    "kafka_event",
    "ingestion_version":"2.0.0",
    "file_name":        "employee_record.pdf",
    "file_size_bytes":  45231,
    "mime_type":        "application/pdf",
    "checksum_sha256":  "abc123...",
    "parser_used":      "pdfplumber",
    "parser_status":    "ok",
    "parse_warnings":   [],
    "char_count":       4812,
    "word_count":       891,
    "structure_type":   "single",
    "data_category":    "unstructured",
    "structure_signals":[],
    "split_count":      1,
    "retry_count":      0,
    "processing_status":"success"
  }
}
```

---

## Metadata Flow

Metadata arrives FROM source systems — the ingestion layer never generates business metadata.

### Pattern 1: Kafka Event (production)
Source system publishes to `ingest_requests`:
```json
{
  "file_uri": "s3://bucket/docs/report.pdf",
  "metadata": { "source_system": "ERP", "department": "Finance", ... }
}
```

### Pattern 2: API Upload (integration)
```bash
curl -X POST http://localhost:8000/ingest \
  -F "file=@report.pdf" \
  -F 'metadata={"source_system":"ERP","department":"Finance","owner":"cfo@co.com","document_type":"report","region":"India"}'
```

### Pattern 3: Sidecar JSON File (local/batch)
Place `report.meta.json` alongside `report.pdf` in `uploads/`:
```json
{
  "source_system": "ERP",
  "department": "Finance",
  "owner": "cfo@company.com",
  "document_type": "report",
  "region": "India",
  "created_at": "2026-04-18"
}
```

### Pattern 4: Embedded (auto-extracted)
- **EML files**: `From:`, `Date:` headers → `owner`, `created_at`
- **DOCX files**: Core properties → `owner`, `created_at`, `document_type`

---

## Single vs Multi Entity

| Signal detected | Decision |
|---|---|
| ≥2 email header blocks (From/Subject/Date) | MULTI |
| Forwarded/reply separators (`--- Forwarded ---`) | MULTI |
| ≥2 horizontal separator bars (`======`) | MULTI |
| ≥2 entity record blocks (Employee ID, Client No) | MULTI |
| >5 timestamped log entries | MULTI |
| ≥2 page-break markers | MULTI |
| ≥2 contract exhibit headers (Exhibit A, Schedule B) | MULTI |
| CSV file type | MULTI (one row per entity) |
| None of the above | SINGLE |

**MULTI parent-child lineage:**
- Parent document `ingest_id` → all segments share it
- Each segment carries `parent_doc_id` → links back to parent
- `segment_index` + `total_segments` → ordering + completeness check
- `segment_type` → email_message / hr_record / contract_exhibit / etc.

**Final MULTI label rule** (computed by Classification Layer, not here):
```
final_label = max_severity(all segment labels)
Severity: Public=1 < Internal=2 < Confidential=3 < Restricted=4
```

---

## Project Structure

```
enterprise_ingestion/
│
├── main.py               CLI entry point (all run modes)
├── app.py                Pipeline orchestrator (wires all steps)
├── consumer.py           Kafka consumers (ingest_requests + retry_queue)
├── producer.py           Kafka producer wrapper
├── parser.py             Text extraction (PDF/DOCX/TXT/CSV/XLSX/JSON/EML/ZIP)
├── splitter.py           Single vs Multi entity detection
├── validator.py          Schema + event validation (Pydantic)
├── metadata_handler.py   Enterprise metadata resolution
├── schema.py             All Pydantic models
├── retry_handler.py      Exponential backoff retry + DLQ escalation
├── api.py                FastAPI upload endpoint (optional)
├── logger.py             Structured rotating logger
├── config.py             Environment-driven configuration
│
├── .env.example          Environment variable template
├── requirements.txt
│
├── uploads/              Drop files here (or configure path)
├── logs/                 ingestion.log (auto-created)
│
└── sample_events/        Example IngestEvent JSON payloads
    ├── hrms_ingest_event.json
    ├── erp_financial_event.json
    └── api_upload_meta.json
```

---

## Windows — Kafka Setup (No Docker)

### Prerequisites

**Step 1: Install Java 11+**
Download from: https://adoptium.net/
Verify: `java -version`

**Step 2: Download Kafka**
https://kafka.apache.org/downloads
Choose: `kafka_2.13-3.7.0.tgz`
Extract to: `C:\kafka\`

---

### Start Kafka (3 terminal windows)

**Terminal 1 — Zookeeper**
```cmd
cd C:\kafka
.\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties
```
Wait for: `binding to port 0.0.0.0/0.0.0.0:2181`

**Terminal 2 — Kafka Broker**
```cmd
cd C:\kafka
.\bin\windows\kafka-server-start.bat .\config\server.properties
```
Wait for: `started (kafka.server.KafkaServer)`

---

### Create Topics

**Terminal 3 — Topic creation (run once)**
```cmd
cd C:\kafka

.\bin\windows\kafka-topics.bat --create --topic ingest_requests --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic raw_documents --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic normalized_documents --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic single_entity_docs --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic multi_entity_docs --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic audit_logs --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic retry_queue --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic dead_letter_queue --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
```

**Verify:**
```cmd
.\bin\windows\kafka-topics.bat --list --bootstrap-server localhost:9092
```

---

## Install Dependencies

```bash
pip install -r requirements.txt
```

For API mode (optional):
```bash
pip install fastapi uvicorn python-multipart
```

---

## How to Run

### Copy .env.example to .env (optional)
```bash
copy .env.example .env
```

### Mode 1 — Batch folder
```bash
python main.py folder
python main.py folder --path C:\docs\hr_batch --source HRMS --department HR
python main.py folder --meta sample_events/hrms_ingest_event.json
```

### Mode 2 — Single file
```bash
python main.py file --uri uploads/contract.pdf
python main.py file --uri uploads/report.pdf --source ERP --department Finance --owner "Priya Nair"
```

### Mode 3 — Live folder watcher
```bash
python main.py watch
python main.py watch --path uploads/ --interval 3 --source EMAIL
```

### Mode 4 — Kafka event consumer (production mode)
```bash
python main.py consumer
```
Upstream systems publish to `ingest_requests` topic. Consumer processes continuously.

### Mode 5 — Retry consumer
```bash
python main.py retry-consumer
```
Run alongside the main consumer to handle backoff retry processing.

### Mode 6 — FastAPI upload endpoint
```bash
python main.py api
```
Then visit: http://localhost:8000/docs for interactive Swagger UI.

---

## Monitor Kafka Topics

Read messages from any topic (Windows):
```cmd
cd C:\kafka

# Watch normalized documents (what Classification Layer will consume)
.\bin\windows\kafka-console-consumer.bat --topic normalized_documents --from-beginning --bootstrap-server localhost:9092

# Watch audit log
.\bin\windows\kafka-console-consumer.bat --topic audit_logs --from-beginning --bootstrap-server localhost:9092

# Watch dead letter queue
.\bin\windows\kafka-console-consumer.bat --topic dead_letter_queue --from-beginning --bootstrap-server localhost:9092
```

---

## Integration with Classification Layer

The Classification Layer (built next) will:

**1. Consume from:**
- `single_entity_docs` — process each as one unit
- `multi_entity_docs` — process each segment independently

**2. Read these fields from NormalizedDocument:**
```python
doc["raw_text"]                              # text to classify
doc["business_metadata"]["department"]       # prior signal
doc["business_metadata"]["document_type"]    # prior signal
doc["business_metadata"]["source_system"]    # prior signal
doc["technical_metadata"]["data_category"]   # structured/semi/unstructured
doc["structure_type"]                        # single or multi
doc["segment_type"]                          # email_message, hr_record, etc.
```

**3. Produce to a new `classified_documents` topic:**
```json
{
  "doc_id":        "same doc_id from ingestion",
  "ingest_id":     "same ingest_id for traceability",
  "parent_doc_id": "for MULTI segment linkage",
  "label":         "Confidential",
  "confidence":    0.94,
  "evidence_tokens": ["salary", "PAN", "compensation"],
  "policy_action": "Encrypt",
  "classified_at": "2026-04-18T10:31:02"
}
```

**4. For MULTI documents — aggregate segment labels:**
```python
SEVERITY = {"Public": 1, "Internal": 2, "Confidential": 3, "Restricted": 4}
final_label = max(segment_labels, key=lambda l: SEVERITY[l])
```

**5. No changes needed to ingestion layer** — it publishes all required signals.

---

## PS Constraints Mapping

| Constraint | Implementation |
|---|---|
| C1: No raw PII stored post-classification | PII masking in Preprocessing layer (next); ingestion only flags, never stores classified PII |
| C2: Black-box models not acceptable | Ingestion captures all metadata for SHAP/LIME evidence attribution downstream |
| C3: On-prem deployment | Pure local Kafka binary + Python; no cloud dependency |
| C4: Dual-approval for training data labels | Labels not assigned in ingestion; governance workflow sits in Classification Layer |
| C5: mTLS for payments client integrations | `KAFKA_SECURITY_PROTOCOL=SSL` + cert paths in `.env` → passed to KafkaProducer/Consumer |

---

## Future Upgrade Path

| Layer | What to build | Consumes from |
|---|---|---|
| Preprocessing | PII masking (Presidio), tokenisation, language detection | `normalized_documents` |
| Feature Engineering | TF-IDF, BERT/RoBERTa/DeBERTa embeddings | `normalized_documents` |
| Classification | LR + XGBoost + fine-tuned transformer ensemble | `single_entity_docs`, `multi_entity_docs` |
| Policy Engine | Rule overlay: Restricted token → override label | Classification output |
| Output API | FastAPI: label + score + evidence + action | `classified_documents` |
| Governance Dashboard | Audit trail, drift alerts, human override queue | `audit_logs`, `classified_documents` |
| MLOps | MLflow tracking, Evidently AI drift, monthly retrain | Model registry |
