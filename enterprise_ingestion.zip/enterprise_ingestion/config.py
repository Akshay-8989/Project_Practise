"""
config.py
==========
Environment-driven configuration for the Enterprise Ingestion Layer.

All values can be overridden via environment variables or a .env file.
Production deployments set these in their secrets manager / CI pipeline.
Local development sets them in .env (never committed to VCS).

Hierarchy: .env file → environment variable → hardcoded default
"""

import os
from dataclasses import dataclass, field
from typing import Optional

# Load .env file if python-dotenv is available (dev convenience)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass   # In production, env vars are set externally — dotenv not required


def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)

def _env_bool(key: str, default: bool = False) -> bool:
    return _env(key, str(default)).lower() in ("true", "1", "yes")

def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(_env(key, str(default)))
    except ValueError:
        return default

def _env_float(key: str, default: float = 0.0) -> float:
    try:
        return float(_env(key, str(default)))
    except ValueError:
        return default


# ─────────────────────────────────────────────────────────────────────────────
# Kafka configuration
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class KafkaConfig:
    bootstrap_servers:   str  = field(default_factory=lambda: _env("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"))
    security_protocol:   str  = field(default_factory=lambda: _env("KAFKA_SECURITY_PROTOCOL", "PLAINTEXT"))

    # mTLS fields (used when security_protocol=SSL)
    ssl_cafile:    Optional[str] = field(default_factory=lambda: _env("KAFKA_SSL_CAFILE")  or None)
    ssl_certfile:  Optional[str] = field(default_factory=lambda: _env("KAFKA_SSL_CERTFILE") or None)
    ssl_keyfile:   Optional[str] = field(default_factory=lambda: _env("KAFKA_SSL_KEYFILE")  or None)

    # Producer
    acks:                str  = field(default_factory=lambda: _env("KAFKA_ACKS", "all"))
    retries:             int  = field(default_factory=lambda: _env_int("KAFKA_RETRIES", 3))
    compression_type:    str  = field(default_factory=lambda: _env("KAFKA_COMPRESSION", "gzip"))
    enable_idempotence:  bool = field(default_factory=lambda: _env_bool("KAFKA_ENABLE_IDEMPOTENCE", True))
    request_timeout_ms:  int  = 30_000
    max_block_ms:        int  = 60_000

    # Consumer
    group_id:            str  = field(default_factory=lambda: _env("KAFKA_CONSUMER_GROUP", "ingestion_service_v1"))
    auto_offset_reset:   str  = field(default_factory=lambda: _env("KAFKA_AUTO_OFFSET_RESET", "earliest"))
    enable_auto_commit:  bool = False        # always manual commit for reliability
    max_poll_records:    int  = field(default_factory=lambda: _env_int("KAFKA_MAX_POLL_RECORDS", 50))
    session_timeout_ms:  int  = 30_000

    def producer_kwargs(self) -> dict:
        """Build kwargs dict for KafkaProducer constructor."""
        kwargs = dict(
            bootstrap_servers  = self.bootstrap_servers,
            security_protocol  = self.security_protocol,
            acks               = self.acks,
            retries            = self.retries,
            compression_type   = self.compression_type,
            enable_idempotence = self.enable_idempotence,
            request_timeout_ms = self.request_timeout_ms,
            max_block_ms       = self.max_block_ms,
        )
        if self.security_protocol == "SSL":
            kwargs.update(
                ssl_cafile   = self.ssl_cafile,
                ssl_certfile = self.ssl_certfile,
                ssl_keyfile  = self.ssl_keyfile,
            )
        return kwargs

    def consumer_kwargs(self, topics: list) -> dict:
        """Build kwargs dict for KafkaConsumer constructor."""
        kwargs = dict(
            bootstrap_servers  = self.bootstrap_servers,
            security_protocol  = self.security_protocol,
            group_id           = self.group_id,
            auto_offset_reset  = self.auto_offset_reset,
            enable_auto_commit = self.enable_auto_commit,
            max_poll_records   = self.max_poll_records,
            session_timeout_ms = self.session_timeout_ms,
        )
        if self.security_protocol == "SSL":
            kwargs.update(
                ssl_cafile   = self.ssl_cafile,
                ssl_certfile = self.ssl_certfile,
                ssl_keyfile  = self.ssl_keyfile,
            )
        return kwargs


# ─────────────────────────────────────────────────────────────────────────────
# Kafka topic registry
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TopicsConfig:
    """
    All Kafka topics used by the ingestion layer.
    Downstream teams consume from normalized_documents, single_entity_docs,
    multi_entity_docs. They never need to touch raw_documents.
    """
    ingest_requests:    str = field(default_factory=lambda: _env("TOPIC_INGEST_REQUESTS",    "ingest_requests"))
    raw_documents:      str = field(default_factory=lambda: _env("TOPIC_RAW_DOCUMENTS",      "raw_documents"))
    normalized_docs:    str = field(default_factory=lambda: _env("TOPIC_NORMALIZED_DOCUMENTS","normalized_documents"))
    single_entity:      str = field(default_factory=lambda: _env("TOPIC_SINGLE_ENTITY",      "single_entity_docs"))
    multi_entity:       str = field(default_factory=lambda: _env("TOPIC_MULTI_ENTITY",        "multi_entity_docs"))
    audit_logs:         str = field(default_factory=lambda: _env("TOPIC_AUDIT_LOGS",          "audit_logs"))
    retry_queue:        str = field(default_factory=lambda: _env("TOPIC_RETRY_QUEUE",         "retry_queue"))
    dlq:                str = field(default_factory=lambda: _env("TOPIC_DLQ",                 "dead_letter_queue"))


# ─────────────────────────────────────────────────────────────────────────────
# Validation rules
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ValidationConfig:
    min_text_length: int = 10
    max_text_length: int = 1_000_000      # 1 MB of text

    allowed_source_systems: tuple = (
        "HRMS", "ERP", "CRM", "DMS", "EMAIL",
        "SHAREPOINT", "S3", "DRIVE", "API", "MANUAL",
    )
    allowed_departments: tuple = (
        "Finance", "HR", "Legal", "IT",
        "Sales", "Support", "Operations", "Compliance", "Engineering",
    )
    allowed_document_types: tuple = (
        "contract", "invoice", "report", "email", "ticket",
        "hr_record", "policy", "payroll", "log", "general",
    )
    allowed_file_types: tuple = (
        "pdf", "docx", "txt", "csv", "json",
        "eml", "msg", "zip", "xlsx",
    )
    allowed_regions: tuple = (
        "India", "US", "EU", "APAC", "UK", "LATAM", "MEA", "Global",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Structure detection
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class StructureConfig:
    email_header_threshold: int   = 2       # min email header blocks → MULTI
    entity_block_threshold: int   = 2       # min entity record blocks → MULTI
    min_segment_chars:      int   = 80      # discard segments below this length
    log_entry_threshold:    int   = 5       # dense log lines → MULTI


# ─────────────────────────────────────────────────────────────────────────────
# Retry policy
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RetryConfig:
    max_attempts:       int   = field(default_factory=lambda: _env_int("RETRY_MAX_ATTEMPTS", 3))
    backoff_seconds:    float = field(default_factory=lambda: _env_float("RETRY_BACKOFF_SECONDS", 2.0))
    backoff_multiplier: float = field(default_factory=lambda: _env_float("RETRY_BACKOFF_MULTIPLIER", 2.0))


# ─────────────────────────────────────────────────────────────────────────────
# Application
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AppConfig:
    env:               str   = field(default_factory=lambda: _env("APP_ENV", "development"))
    log_level:         str   = field(default_factory=lambda: _env("LOG_LEVEL", "INFO"))
    log_file:          str   = field(default_factory=lambda: _env("LOG_FILE", "logs/ingestion.log"))
    upload_folder:     str   = field(default_factory=lambda: _env("UPLOAD_FOLDER", "uploads"))
    max_file_size_mb:  int   = field(default_factory=lambda: _env_int("MAX_FILE_SIZE_MB", 50))
    storage_base_path: str   = field(default_factory=lambda: _env("STORAGE_BASE_PATH", "uploads"))

    # FastAPI
    api_host: str = field(default_factory=lambda: _env("API_HOST", "0.0.0.0"))
    api_port: int = field(default_factory=lambda: _env_int("API_PORT", 8000))

    # Tika
    tika_enabled:    bool = field(default_factory=lambda: _env_bool("TIKA_ENABLED", False))
    tika_server_url: str  = field(default_factory=lambda: _env("TIKA_SERVER_URL", "http://localhost:9998"))

    # Composed sub-configs
    kafka:      KafkaConfig      = field(default_factory=KafkaConfig)
    topics:     TopicsConfig     = field(default_factory=TopicsConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    structure:  StructureConfig  = field(default_factory=StructureConfig)
    retry:      RetryConfig      = field(default_factory=RetryConfig)


# ── Module-level singleton ────────────────────────────────────────────────────
CONFIG = AppConfig()
