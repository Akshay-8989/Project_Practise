"""
api.py
=======
FastAPI upload endpoint for the Enterprise Ingestion Layer.

Provides HTTP-based document ingestion as an alternative to:
  - Kafka event-driven ingestion
  - Folder watcher
  - Batch folder processing

Endpoints:
  POST /ingest
    Multipart form: file upload + optional metadata JSON string.
    Returns: ingest_id, structure_type, segment_count, topics_written.

  POST /ingest/event
    JSON body: full IngestEvent payload (for programmatic integration).
    Upstream systems can POST events directly without file transfer.

  GET /health
    Returns: service status + Kafka connectivity.

  GET /topics
    Returns: configured Kafka topic names.

Install for API mode:
  pip install fastapi uvicorn python-multipart

Run:
  python main.py api
  OR
  uvicorn api:app --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

import json
import os
import tempfile
import uuid
from datetime import datetime
from typing import Optional

try:
    from fastapi import FastAPI, File, Form, HTTPException, UploadFile
    from fastapi.responses import JSONResponse
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False

from schema import BusinessMetadata, IngestEvent, IngestSource
from config import CONFIG
from logger import get_logger
from app import process_event
from producer import IngestionProducer

log = get_logger("api")


def create_app():
    if not _FASTAPI_AVAILABLE:
        raise ImportError(
            "FastAPI not installed. Run: pip install fastapi uvicorn python-multipart"
        )

    app = FastAPI(
        title       = "Enterprise Ingestion Layer",
        description = "Document ingestion API for the Automated Sensitivity Classification Platform",
        version     = "2.0.0",
    )

    # Shared producer (created once at app startup)
    _producer: Optional[IngestionProducer] = None

    @app.on_event("startup")
    async def startup():
        nonlocal _producer
        try:
            _producer = IngestionProducer()
            log.info("API startup: Kafka producer initialised")
        except Exception as exc:
            log.error("API startup: Kafka unavailable: %s", exc)

    @app.on_event("shutdown")
    async def shutdown():
        if _producer:
            _producer.close()
            log.info("API shutdown: Kafka producer closed")

    # ── Health check ──────────────────────────────────────────────────────

    @app.get("/health", tags=["System"])
    async def health():
        return {
            "status":    "ok",
            "timestamp": datetime.utcnow().isoformat(),
            "kafka":     CONFIG.kafka.bootstrap_servers,
            "version":   "2.0.0",
        }

    @app.get("/topics", tags=["System"])
    async def topics():
        t = CONFIG.topics
        return {
            "ingest_requests":   t.ingest_requests,
            "raw_documents":     t.raw_documents,
            "normalized_docs":   t.normalized_docs,
            "single_entity":     t.single_entity,
            "multi_entity":      t.multi_entity,
            "audit_logs":        t.audit_logs,
            "retry_queue":       t.retry_queue,
            "dead_letter_queue": t.dlq,
        }

    # ── File upload endpoint ──────────────────────────────────────────────

    @app.post("/ingest", tags=["Ingestion"])
    async def ingest_file(
        file:     UploadFile = File(..., description="Document to ingest"),
        metadata: Optional[str] = Form(
            None,
            description=(
                "Business metadata JSON string. Example:\n"
                '{"source_system":"HRMS","department":"HR","owner":"hr@co.com",'
                '"document_type":"hr_record","region":"India"}'
            ),
        ),
    ):
        """
        Upload a document with optional business metadata.

        The file is saved to a temp location, processed through the full
        ingestion pipeline, then deleted. The result is streamed to Kafka.
        """
        if not _producer:
            raise HTTPException(503, "Kafka producer not available — check broker connection")

        # Parse metadata
        meta_dict = {}
        if metadata:
            try:
                meta_dict = json.loads(metadata)
            except json.JSONDecodeError as exc:
                raise HTTPException(400, f"Invalid metadata JSON: {exc}")

        # Save uploaded file to temp location
        suffix   = os.path.splitext(file.filename)[1]
        tmp_path = os.path.join(tempfile.gettempdir(), f"ingest_{uuid.uuid4()}{suffix}")

        try:
            content = await file.read()
            with open(tmp_path, "wb") as f_out:
                f_out.write(content)

            biz_meta = BusinessMetadata(**{
                k: v for k, v in meta_dict.items()
                if k in BusinessMetadata.model_fields
            })

            event = IngestEvent(
                ingest_source = IngestSource.API_UPLOAD.value,
                file_uri      = tmp_path,
                file_name     = file.filename,
                metadata      = biz_meta,
            )

            result = process_event(event, producer=_producer)

            if result.success:
                return JSONResponse(status_code=200, content={
                    "status":         "ingested",
                    "ingest_id":      result.ingest_id,
                    "file_name":      result.file_name,
                    "structure_type": result.structure_type,
                    "data_category":  result.data_category,
                    "segment_count":  result.segment_count,
                    "topics_written": result.topics_written,
                    "warnings":       result.warnings,
                })
            else:
                return JSONResponse(status_code=422, content={
                    "status":         "failed",
                    "ingest_id":      result.ingest_id,
                    "file_name":      result.file_name,
                    "failure_reason": result.failure_reason,
                    "failure_detail": result.failure_detail,
                })

        finally:
            try:
                os.remove(tmp_path)
            except Exception:
                pass

    # ── Event submission endpoint ─────────────────────────────────────────

    @app.post("/ingest/event", tags=["Ingestion"])
    async def ingest_event(event_data: dict):
        """
        Submit a full IngestEvent JSON. Used for programmatic integration
        where the caller has already prepared the event payload (e.g. storage
        trigger, DB change event, scheduled job).
        """
        if not _producer:
            raise HTTPException(503, "Kafka producer not available")

        try:
            meta_raw = event_data.get("metadata", {})
            biz_meta = BusinessMetadata(**{
                k: v for k, v in meta_raw.items()
                if k in BusinessMetadata.model_fields
            })
            event = IngestEvent(
                event_id      = event_data.get("event_id", str(uuid.uuid4())),
                ingest_source = event_data.get("ingest_source", IngestSource.API_UPLOAD.value),
                file_uri      = event_data.get("file_uri"),
                file_name     = event_data.get("file_name"),
                metadata      = biz_meta,
            )
        except Exception as exc:
            raise HTTPException(400, f"Invalid event payload: {exc}")

        result = process_event(event, producer=_producer)

        return JSONResponse(
            status_code=200 if result.success else 422,
            content={
                "status":         "ingested" if result.success else "failed",
                "ingest_id":      result.ingest_id,
                "structure_type": result.structure_type,
                "segment_count":  result.segment_count,
                "topics_written": result.topics_written,
                "failure_reason": result.failure_reason,
            },
        )

    return app


# Allow direct uvicorn invocation: uvicorn api:app --reload
if _FASTAPI_AVAILABLE:
    app = create_app()
