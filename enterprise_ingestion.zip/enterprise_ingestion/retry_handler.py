"""
retry_handler.py
=================
Enterprise retry and dead-letter-queue management.

Retry policy:
  - Max attempts: configurable (default 3)
  - Backoff: exponential with multiplier (default: 2s → 4s → 8s)
  - After max_attempts exhausted: escalate to dead_letter_queue
  - Operations team monitors DLQ for manual remediation

Two modes of operation:

  Mode 1 — Inline retry (used by app.py pipeline)
    Wraps a callable with automatic retry logic.
    On persistent failure: publishes RetryEvent or DeadLetterRecord.

  Mode 2 — Queue-based retry (used by consumer.py)
    Consumes from retry_queue topic.
    Re-emits the original IngestEvent to ingest_requests.
    Useful for infrastructure failures (Kafka down, parser timeout).
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, Optional, Tuple, TypeVar

from schema import DeadLetterRecord, RetryEvent
from config import CONFIG
from logger import get_logger

log = get_logger("retry_handler")

T = TypeVar("T")


# ─────────────────────────────────────────────────────────────────────────────
# Retry execution wrapper
# ─────────────────────────────────────────────────────────────────────────────

def with_retry(
    func:              Callable[[], T],
    context:           Dict[str, Any],
    producer:          Any,               # IngestionProducer — avoid circular import
    stage:             str = "unknown",
) -> Tuple[bool, Optional[T], Optional[str]]:
    """
    Execute func with retry logic.

    Args:
        func:      The callable to retry (zero-arg lambda wrapping the work).
        context:   Dict with {event_id, ingest_id, file_name, source_system}
                   used to build audit / DLQ records.
        producer:  IngestionProducer instance for DLQ / retry publishing.
        stage:     Pipeline stage name for error attribution.

    Returns:
        (success: bool, result: T | None, error_detail: str | None)
    """
    max_attempts = CONFIG.retry.max_attempts
    backoff      = CONFIG.retry.backoff_seconds
    multiplier   = CONFIG.retry.backoff_multiplier

    last_error = ""
    last_exc   = None

    for attempt in range(1, max_attempts + 1):
        try:
            result = func()
            if attempt > 1:
                log.info(
                    "[%s] Succeeded on attempt %d/%d",
                    context.get("ingest_id", "?"), attempt, max_attempts,
                )
            return True, result, None

        except Exception as exc:
            last_error = str(exc)
            last_exc   = exc
            log.warning(
                "[%s] Attempt %d/%d FAILED | stage=%s | error=%s",
                context.get("ingest_id", "?"), attempt, max_attempts, stage, exc,
            )

            if attempt < max_attempts:
                sleep_time = backoff * (multiplier ** (attempt - 1))
                log.info(
                    "[%s] Retrying in %.1fs …",
                    context.get("ingest_id", "?"), sleep_time,
                )
                time.sleep(sleep_time)

    # ── All attempts exhausted → DLQ ─────────────────────────────────────
    log.error(
        "[%s] All %d attempts failed | stage=%s | sending to DLQ",
        context.get("ingest_id", "?"), max_attempts, stage,
    )
    _send_to_dlq(
        producer   = producer,
        context    = context,
        stage      = stage,
        reason     = f"MAX_RETRIES_EXCEEDED ({max_attempts} attempts)",
        detail     = last_error,
        retry_count= max_attempts,
    )
    return False, None, last_error


# ─────────────────────────────────────────────────────────────────────────────
# Retry event builder (for queue-based retry via consumer)
# ─────────────────────────────────────────────────────────────────────────────

def build_retry_event(
    original_event: Dict,
    attempt_number: int,
    failure_reason: str,
    failure_detail: str,
) -> RetryEvent:
    """
    Build a RetryEvent to be published to retry_queue.
    The retry consumer will pick this up and re-attempt ingestion.
    """
    backoff = CONFIG.retry.backoff_seconds * (
        CONFIG.retry.backoff_multiplier ** (attempt_number - 1)
    )
    retry_after = (
        datetime.utcnow() + timedelta(seconds=backoff)
    ).isoformat()

    return RetryEvent(
        original_event = original_event,
        attempt_number = attempt_number,
        failure_reason = failure_reason,
        failure_detail = failure_detail,
        retry_after    = retry_after,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Dead letter builder
# ─────────────────────────────────────────────────────────────────────────────

def build_dlq_record(
    context:        Dict[str, Any],
    stage:          str,
    reason:         str,
    detail:         str,
    retry_count:    int = 0,
    original_event: Optional[Dict] = None,
) -> DeadLetterRecord:
    return DeadLetterRecord(
        event_id       = context.get("event_id", ""),
        ingest_id      = context.get("ingest_id", ""),
        file_name      = context.get("file_name", ""),
        source_system  = context.get("source_system", "UNKNOWN"),
        failure_stage  = stage,
        failure_reason = reason,
        failure_detail = detail,
        retry_count    = retry_count,
        original_event = original_event,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _send_to_dlq(
    producer:    Any,
    context:     Dict,
    stage:       str,
    reason:      str,
    detail:      str,
    retry_count: int,
):
    try:
        record = build_dlq_record(
            context     = context,
            stage       = stage,
            reason      = reason,
            detail      = detail,
            retry_count = retry_count,
        )
        producer.send_dlq(record.model_dump())
        log.info(
            "DLQ entry written | ingest_id=%s file=%s reason=%s",
            context.get("ingest_id"), context.get("file_name"), reason,
        )
    except Exception as exc:
        log.error("Failed to write DLQ record: %s", exc)
