"""
validator.py
=============
Enterprise schema validation for all Kafka payloads.

Two validation passes per document:

  Pass 1 — Event validation
    Validates the incoming IngestEvent before any processing begins.
    Catches: missing file URI, invalid source, malformed event.

  Pass 2 — Payload validation
    Validates the NormalizedDocument before it is published to Kafka.
    Catches: empty text, text too long, missing metadata, invalid structure_type.

Validation failures route to DLQ (after retry exhaustion).
Validation WARNINGS are recorded in the audit log but do NOT block ingestion.
"""

from __future__ import annotations

import re
from typing import Optional

from pydantic import ValidationError

from schema import (
    BusinessMetadata,
    IngestEvent,
    NormalizedDocument,
    ValidationResult,
)
from config import CONFIG
from logger import get_logger

log = get_logger("validator")

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_ISODATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")


# ─────────────────────────────────────────────────────────────────────────────
# Event validator
# ─────────────────────────────────────────────────────────────────────────────

def validate_event(event: IngestEvent) -> ValidationResult:
    """
    Validate an IngestEvent before processing starts.
    Checks that we have something to actually process.
    """
    if not event.file_uri and not event.file_name:
        return ValidationResult.fail(
            "MISSING_FILE_REFERENCE",
            "IngestEvent must have either file_uri or file_name set",
        )

    if event.file_uri:
        # Local path check (storage URI simulation)
        uri = event.file_uri
        if uri.startswith(("s3://", "gcs://", "azure://")):
            pass   # Storage URI — resolved by fetch layer
        elif not _path_exists(uri):
            return ValidationResult.fail(
                "FILE_NOT_FOUND",
                f"file_uri '{uri}' does not exist on local filesystem",
            )

    return ValidationResult.ok()


# ─────────────────────────────────────────────────────────────────────────────
# Payload validator
# ─────────────────────────────────────────────────────────────────────────────

def validate_payload(doc: NormalizedDocument) -> ValidationResult:
    """
    Validate a NormalizedDocument before publishing to Kafka.
    """

    # ── Text content ──────────────────────────────────────────────────────
    text = doc.raw_text.strip() if doc.raw_text else ""
    if not text:
        return ValidationResult.fail("EMPTY_TEXT", "raw_text is empty after stripping")

    if len(text) < CONFIG.validation.min_text_length:
        return ValidationResult.fail(
            "TEXT_TOO_SHORT",
            f"raw_text has {len(text)} chars; minimum is {CONFIG.validation.min_text_length}",
        )

    if len(text) > CONFIG.validation.max_text_length:
        return ValidationResult.fail(
            "TEXT_TOO_LONG",
            f"raw_text has {len(text)} chars; maximum is {CONFIG.validation.max_text_length}",
        )

    # ── Structure type ────────────────────────────────────────────────────
    if doc.structure_type not in ("single", "multi"):
        return ValidationResult.fail(
            "INVALID_STRUCTURE_TYPE",
            f"structure_type '{doc.structure_type}' must be 'single' or 'multi'",
        )

    # ── Identity fields ───────────────────────────────────────────────────
    if not doc.doc_id or not doc.doc_id.strip():
        return ValidationResult.fail("EMPTY_DOC_ID", "doc_id must not be empty")

    if not doc.technical_metadata.ingest_id:
        return ValidationResult.fail(
            "EMPTY_INGEST_ID", "technical_metadata.ingest_id must not be empty"
        )

    if not doc.technical_metadata.ingest_timestamp:
        return ValidationResult.fail(
            "EMPTY_TIMESTAMP", "technical_metadata.ingest_timestamp must not be empty"
        )

    # ── Metadata validation (warnings only — don't block) ─────────────────
    meta = doc.business_metadata
    _warn_metadata(meta, doc.technical_metadata.ingest_id)

    return ValidationResult.ok()


def validate_metadata(meta: BusinessMetadata) -> ValidationResult:
    """
    Standalone metadata validator (used in event intake before parsing).
    """
    issues = []
    required = ["source_system", "department", "owner", "document_type"]
    for field in required:
        val = getattr(meta, field, "")
        if not val or val in ("UNKNOWN", "unknown", ""):
            issues.append(field)

    if issues:
        return ValidationResult.fail(
            "INCOMPLETE_METADATA",
            f"Required metadata fields missing: {issues}",
        )
    return ValidationResult.ok()


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _warn_metadata(meta: BusinessMetadata, ingest_id: str):
    """Log metadata warnings without blocking ingestion."""
    if meta.source_system == "UNKNOWN":
        log.warning("[%s] Metadata: source_system is UNKNOWN", ingest_id)
    if meta.department == "UNKNOWN":
        log.warning("[%s] Metadata: department is UNKNOWN", ingest_id)
    if not meta.created_at:
        log.debug("[%s] Metadata: created_at not set", ingest_id)
    if meta.validation_issues:
        log.warning(
            "[%s] Metadata validation issues: %s",
            ingest_id, "; ".join(meta.validation_issues),
        )


def _path_exists(path: str) -> bool:
    import os
    return os.path.exists(path)
