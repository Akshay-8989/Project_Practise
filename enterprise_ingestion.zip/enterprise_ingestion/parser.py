"""
parser.py
==========
Enterprise-grade text extraction layer.

Supports:
  PDF    → pdfplumber (primary), PyMuPDF (fallback), Tika (last resort)
  DOCX   → python-docx (paragraphs + tables + headers)
  TXT    → native (multi-encoding fallback chain)
  CSV    → pandas (full DataFrame → text representation)
  XLSX   → openpyxl / pandas (multi-sheet support)
  JSON   → stdlib json (pretty-printed for tokenisation)
  EML    → stdlib email (headers + body + inline parts)
  ZIP    → recursive (each inner file parsed independently)

Each parse returns a ParsedContent with:
  - raw_text       (cleaned, normalised whitespace)
  - mime_type      (detected, not just from extension)
  - checksum_sha256 (of raw bytes — for dedup/integrity)
  - parser_used
  - warnings       (soft issues — don't block ingestion)
  - data_category  (structured / semi_structured / unstructured)
"""

from __future__ import annotations

import csv
import email
import hashlib
import json
import os
import re
import zipfile
from pathlib import Path
from typing import List, Optional, Union

from schema import DataCategory, ParsedContent
from config import CONFIG
from logger import get_logger

log = get_logger("parser")

# MIME type map by extension
_MIME_MAP = {
    "pdf":  "application/pdf",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "txt":  "text/plain",
    "csv":  "text/csv",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "json": "application/json",
    "eml":  "message/rfc822",
    "msg":  "application/vnd.ms-outlook",
    "zip":  "application/zip",
}

# Data category by extension
_CATEGORY_MAP = {
    "csv":  DataCategory.STRUCTURED,
    "xlsx": DataCategory.STRUCTURED,
    "json": DataCategory.SEMI_STRUCTURED,
    "eml":  DataCategory.SEMI_STRUCTURED,
    "msg":  DataCategory.SEMI_STRUCTURED,
    "pdf":  DataCategory.UNSTRUCTURED,
    "docx": DataCategory.UNSTRUCTURED,
    "txt":  DataCategory.UNSTRUCTURED,
}


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def parse_file(
    file_path: str,
    file_name: Optional[str] = None,
) -> Union[ParsedContent, List[ParsedContent]]:
    """
    Parse a file and return extracted text content.

    Returns:
      ParsedContent            for all single-file formats
      List[ParsedContent]      for ZIP (one result per inner file)

    Never raises — failures are captured inside ParsedContent.error.
    """
    fname     = file_name or os.path.basename(file_path)
    ext       = Path(fname).suffix.lower().lstrip(".")
    mime_type = _MIME_MAP.get(ext, "application/octet-stream")

    # Compute file checksum and size
    checksum, file_size = _checksum_and_size(file_path)

    log.debug("Parsing %s (ext=%s, size=%d bytes)", fname, ext, file_size)

    try:
        if ext == "pdf":
            result = _parse_pdf(file_path, fname)
        elif ext == "docx":
            result = _parse_docx(file_path, fname)
        elif ext in ("txt", "text"):
            result = _parse_txt(file_path, fname)
        elif ext == "csv":
            result = _parse_csv(file_path, fname)
        elif ext == "xlsx":
            result = _parse_xlsx(file_path, fname)
        elif ext == "json":
            result = _parse_json(file_path, fname)
        elif ext in ("eml", "msg"):
            result = _parse_eml(file_path, fname)
        elif ext == "zip":
            return _parse_zip(file_path, fname)
        elif CONFIG.tika_enabled:
            result = _parse_tika(file_path, fname)
        else:
            return ParsedContent(
                file_name=fname, file_type=ext,
                raw_text="", mime_type=mime_type,
                success=False,
                error=f"Unsupported file type '.{ext}'. Enable Tika for exotic formats.",
            )
    except Exception as exc:
        log.error("Unexpected parse error for %s: %s", fname, exc, exc_info=True)
        return ParsedContent(
            file_name=fname, file_type=ext,
            raw_text="", mime_type=mime_type,
            success=False, error=str(exc),
        )

    # Attach computed fields to result
    result.mime_type = mime_type
    return result


def get_data_category(file_type: str) -> str:
    """Return the DataCategory for a given file extension."""
    return _CATEGORY_MAP.get(file_type.lower(), DataCategory.UNSTRUCTURED).value


# ─────────────────────────────────────────────────────────────────────────────
# PDF
# ─────────────────────────────────────────────────────────────────────────────

def _parse_pdf(file_path: str, fname: str) -> ParsedContent:
    warnings: List[str] = []

    # Primary: pdfplumber
    try:
        import pdfplumber
        pages = []
        page_count = 0
        with pdfplumber.open(file_path) as pdf:
            page_count = len(pdf.pages)
            for i, page in enumerate(pdf.pages):
                try:
                    t = page.extract_text()
                    if t and t.strip():
                        pages.append(f"[Page {i+1}]\n{t}")
                    else:
                        warnings.append(f"Page {i+1}: no text (image-only?)")
                except Exception as pe:
                    warnings.append(f"Page {i+1} error: {pe}")

        raw_text = "\n\n".join(pages)
        if not raw_text.strip():
            warnings.append("PDF returned no text — may require OCR (Tesseract)")

        return ParsedContent(
            file_name=fname, file_type="pdf",
            raw_text=_clean(raw_text), page_count=page_count,
            parser_used="pdfplumber", warnings=warnings,
        )
    except ImportError:
        log.warning("pdfplumber not installed, trying PyMuPDF")

    # Fallback: PyMuPDF
    try:
        import fitz
        doc = fitz.open(file_path)
        pages = [f"[Page {i+1}]\n{page.get_text()}" for i, page in enumerate(doc)]
        return ParsedContent(
            file_name=fname, file_type="pdf",
            raw_text=_clean("\n\n".join(pages)),
            page_count=len(pages), parser_used="pymupdf", warnings=warnings,
        )
    except ImportError:
        pass

    if CONFIG.tika_enabled:
        return _parse_tika(file_path, fname)

    return ParsedContent(
        file_name=fname, file_type="pdf", raw_text="",
        success=False,
        error="No PDF parser available. Run: pip install pdfplumber",
    )


# ─────────────────────────────────────────────────────────────────────────────
# DOCX
# ─────────────────────────────────────────────────────────────────────────────

def _parse_docx(file_path: str, fname: str) -> ParsedContent:
    try:
        from docx import Document
    except ImportError:
        return ParsedContent(
            file_name=fname, file_type="docx", raw_text="",
            success=False, error="python-docx not installed. Run: pip install python-docx",
        )

    warnings: List[str] = []
    parts: List[str] = []

    try:
        doc = Document(file_path)

        # Headings + body paragraphs (preserving heading hierarchy)
        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            if para.style.name.startswith("Heading"):
                parts.append(f"\n### {text}")   # mark headings for splitter hints
            else:
                parts.append(text)

        # Tables — important for contracts, HR forms, financial reports
        for table in doc.tables:
            table_rows = []
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells if c.text.strip()]
                if cells:
                    table_rows.append(" | ".join(cells))
            if table_rows:
                parts.append("\n[TABLE]\n" + "\n".join(table_rows))

        raw_text = "\n".join(parts)
        if not raw_text.strip():
            warnings.append("DOCX body appears empty")

        return ParsedContent(
            file_name=fname, file_type="docx",
            raw_text=_clean(raw_text), parser_used="python-docx", warnings=warnings,
        )
    except Exception as exc:
        return ParsedContent(
            file_name=fname, file_type="docx", raw_text="",
            success=False, error=f"DOCX parse failed: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# TXT
# ─────────────────────────────────────────────────────────────────────────────

def _parse_txt(file_path: str, fname: str) -> ParsedContent:
    for enc in ("utf-8", "utf-8-sig", "latin-1", "cp1252", "cp1250"):
        try:
            with open(file_path, "r", encoding=enc) as f:
                raw = f.read()
            return ParsedContent(
                file_name=fname, file_type="txt",
                raw_text=_clean(raw), parser_used=f"native_txt({enc})",
            )
        except (UnicodeDecodeError, LookupError):
            continue

    return ParsedContent(
        file_name=fname, file_type="txt", raw_text="",
        success=False, error="Cannot decode TXT file with any supported encoding",
    )


# ─────────────────────────────────────────────────────────────────────────────
# CSV
# ─────────────────────────────────────────────────────────────────────────────

def _parse_csv(file_path: str, fname: str) -> ParsedContent:
    warnings: List[str] = []
    try:
        import pandas as pd
        df = pd.read_csv(file_path, encoding="utf-8", on_bad_lines="warn",
                         dtype=str)
        header = " | ".join(str(c) for c in df.columns)
        rows   = df.fillna("").apply(lambda r: " | ".join(r.values), axis=1).tolist()
        if len(rows) > 50_000:
            warnings.append(f"Large CSV ({len(rows)} rows) — consider chunking")
        raw_text = header + "\n" + "\n".join(rows)
        return ParsedContent(
            file_name=fname, file_type="csv",
            raw_text=_clean(raw_text), parser_used="pandas", warnings=warnings,
        )
    except ImportError:
        # stdlib csv fallback
        rows = []
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            for row in csv.reader(f):
                rows.append(" | ".join(c.strip() for c in row if c.strip()))
        return ParsedContent(
            file_name=fname, file_type="csv",
            raw_text=_clean("\n".join(rows)), parser_used="stdlib_csv",
        )
    except Exception as exc:
        return ParsedContent(
            file_name=fname, file_type="csv", raw_text="",
            success=False, error=f"CSV parse failed: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# XLSX (multi-sheet)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_xlsx(file_path: str, fname: str) -> ParsedContent:
    warnings: List[str] = []
    try:
        import pandas as pd
        xl = pd.ExcelFile(file_path)
        sheets = []
        for sheet_name in xl.sheet_names:
            df = xl.parse(sheet_name, dtype=str)
            header = " | ".join(str(c) for c in df.columns)
            rows   = df.fillna("").apply(lambda r: " | ".join(r.values), axis=1).tolist()
            sheets.append(f"[Sheet: {sheet_name}]\n{header}\n" + "\n".join(rows))
        raw_text = "\n\n".join(sheets)
        return ParsedContent(
            file_name=fname, file_type="xlsx",
            raw_text=_clean(raw_text), parser_used="pandas_excel", warnings=warnings,
        )
    except ImportError:
        return ParsedContent(
            file_name=fname, file_type="xlsx", raw_text="",
            success=False, error="pandas not installed. Run: pip install pandas openpyxl",
        )
    except Exception as exc:
        return ParsedContent(
            file_name=fname, file_type="xlsx", raw_text="",
            success=False, error=f"XLSX parse failed: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# JSON
# ─────────────────────────────────────────────────────────────────────────────

def _parse_json(file_path: str, fname: str) -> ParsedContent:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        raw_text = json.dumps(data, indent=2, ensure_ascii=False)
        return ParsedContent(
            file_name=fname, file_type="json",
            raw_text=raw_text, parser_used="stdlib_json",
        )
    except Exception as exc:
        return ParsedContent(
            file_name=fname, file_type="json", raw_text="",
            success=False, error=f"JSON parse failed: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# EML / Email
# ─────────────────────────────────────────────────────────────────────────────

def _parse_eml(file_path: str, fname: str) -> ParsedContent:
    warnings: List[str] = []
    parts:    List[str] = []

    try:
        with open(file_path, "rb") as f:
            msg = email.message_from_bytes(f.read())
    except Exception as exc:
        return ParsedContent(
            file_name=fname, file_type="eml", raw_text="",
            success=False, error=f"EML parse failed: {exc}",
        )

    # Business-relevant headers
    for hdr in ("From", "To", "CC", "Subject", "Date", "Message-ID"):
        val = msg.get(hdr)
        if val:
            parts.append(f"{hdr}: {val}")
    parts.append("")

    # Body extraction
    if msg.is_multipart():
        for part in msg.walk():
            ct   = part.get_content_type()
            disp = str(part.get("Content-Disposition", ""))
            if "attachment" in disp:
                warnings.append(f"Attachment skipped: {part.get_filename()}")
                continue
            if ct in ("text/plain", "text/html"):
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    text = payload.decode(charset, errors="replace")
                    if ct == "text/html":
                        text = re.sub(r"<[^>]+>", " ", text)
                    parts.append(text)
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            parts.append(payload.decode(charset, errors="replace"))

    return ParsedContent(
        file_name=fname, file_type="eml",
        raw_text=_clean("\n".join(parts)),
        parser_used="stdlib_email", warnings=warnings,
    )


# ─────────────────────────────────────────────────────────────────────────────
# ZIP (recursive)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_zip(file_path: str, fname: str) -> List[ParsedContent]:
    results: List[ParsedContent] = []
    try:
        with zipfile.ZipFile(file_path, "r") as zf:
            for inner_name in zf.namelist():
                if inner_name.endswith("/"):
                    continue
                try:
                    tmp_path = os.path.join(
                        os.path.dirname(file_path),
                        f"_ztmp_{os.path.basename(inner_name)}",
                    )
                    with zf.open(inner_name) as src, open(tmp_path, "wb") as dst:
                        dst.write(src.read())
                    inner = parse_file(tmp_path, file_name=inner_name)
                    if isinstance(inner, list):
                        results.extend(inner)
                    else:
                        results.append(inner)
                    os.remove(tmp_path)
                except Exception as inner_exc:
                    log.warning("ZIP inner %s failed: %s", inner_name, inner_exc)
    except zipfile.BadZipFile as exc:
        return [ParsedContent(
            file_name=fname, file_type="zip", raw_text="",
            success=False, error=f"Bad ZIP: {exc}", is_zip=True,
        )]

    for r in results:
        r.is_zip = True
    return results


# ─────────────────────────────────────────────────────────────────────────────
# Apache Tika fallback
# ─────────────────────────────────────────────────────────────────────────────

def _parse_tika(file_path: str, fname: str) -> ParsedContent:
    try:
        import requests
        with open(file_path, "rb") as f:
            resp = requests.put(
                f"{CONFIG.tika_server_url}/tika",
                data=f,
                headers={"Accept": "text/plain"},
                timeout=30,
            )
        if resp.status_code == 200:
            ext = Path(fname).suffix.lower().lstrip(".")
            return ParsedContent(
                file_name=fname, file_type=ext or "unknown",
                raw_text=_clean(resp.text),
                parser_used="apache_tika",
            )
        return ParsedContent(
            file_name=fname, file_type="unknown", raw_text="",
            success=False, error=f"Tika HTTP {resp.status_code}",
        )
    except Exception as exc:
        return ParsedContent(
            file_name=fname, file_type="unknown", raw_text="",
            success=False, error=f"Tika error: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _clean(text: str) -> str:
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip()


def _checksum_and_size(file_path: str) -> tuple:
    """Return (sha256_hex, file_size_bytes) for a file."""
    try:
        h = hashlib.sha256()
        size = 0
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
                size += len(chunk)
        return h.hexdigest(), size
    except Exception:
        return "", 0


def compute_checksum(file_path: str) -> str:
    return _checksum_and_size(file_path)[0]


def get_file_size(file_path: str) -> int:
    try:
        return os.path.getsize(file_path)
    except Exception:
        return 0
