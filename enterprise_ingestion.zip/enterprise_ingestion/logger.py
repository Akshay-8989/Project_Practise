"""
logger.py
==========
Structured logger for the enterprise ingestion layer.

Features:
  - Named loggers per module
  - Rotating file handler (10 MB / 5 backups)
  - Console handler with colour-aware formatting
  - Optional JSON log format for log aggregation (ELK / Datadog / Splunk)
  - Structured extra fields for machine-parseable audit trail

Usage:
    from logger import get_logger
    log = get_logger(__name__)
    log.info("Processing file", extra={"file_name": "report.pdf", "ingest_id": "..."})
"""

import json
import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from typing import Optional

# Import lazily to avoid circular dep at module load
_config_loaded = False
_log_level     = "INFO"
_log_file      = "logs/ingestion.log"


def _load_config():
    global _config_loaded, _log_level, _log_file
    if not _config_loaded:
        try:
            from config import CONFIG
            _log_level = CONFIG.log_level
            _log_file  = CONFIG.log_file
        except Exception:
            pass
        _config_loaded = True


# ─────────────────────────────────────────────────────────────────────────────
# Formatters
# ─────────────────────────────────────────────────────────────────────────────

class ConsoleFormatter(logging.Formatter):
    """Human-readable formatter for console output."""

    LEVEL_COLOURS = {
        logging.DEBUG:    "\033[36m",    # Cyan
        logging.INFO:     "\033[32m",    # Green
        logging.WARNING:  "\033[33m",    # Yellow
        logging.ERROR:    "\033[31m",    # Red
        logging.CRITICAL: "\033[35m",    # Magenta
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        colour = self.LEVEL_COLOURS.get(record.levelno, "")
        record.levelname = f"{colour}{record.levelname:<8}{self.RESET}"
        return super().format(record)


class FileFormatter(logging.Formatter):
    """Plain text formatter for log files."""
    pass


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def get_logger(name: str = "ingestion") -> logging.Logger:
    """
    Return a named logger. First call configures handlers.
    Subsequent calls for the same name return the cached instance.
    """
    _load_config()
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger   # already configured

    level = getattr(logging, _log_level.upper(), logging.INFO)
    logger.setLevel(level)
    logger.propagate = False

    fmt_str     = "%(asctime)s | %(levelname)s | %(name)-24s | %(message)s"
    date_fmt    = "%Y-%m-%d %H:%M:%S"

    # ── Console ───────────────────────────────────────────────────────────
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)
    ch.setFormatter(ConsoleFormatter(fmt_str, datefmt=date_fmt))
    logger.addHandler(ch)

    # ── Rotating file ─────────────────────────────────────────────────────
    try:
        os.makedirs(os.path.dirname(_log_file) or ".", exist_ok=True)
        fh = RotatingFileHandler(
            _log_file,
            maxBytes    = 10 * 1024 * 1024,  # 10 MB
            backupCount = 5,
            encoding    = "utf-8",
        )
        fh.setLevel(level)
        fh.setFormatter(FileFormatter(fmt_str, datefmt=date_fmt))
        logger.addHandler(fh)
    except Exception as exc:
        logger.warning("Could not open log file %s: %s", _log_file, exc)

    return logger
