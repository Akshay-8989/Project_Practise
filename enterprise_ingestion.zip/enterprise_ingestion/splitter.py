"""
splitter.py
============
Enterprise single-entity vs multi-entity detection and intelligent splitting.

SINGLE entity:
  One document = one logical entity → one classification downstream.
  Examples: contract, invoice, payroll report, policy document, HR form.

MULTI entity:
  One file contains N logical sub-entities, each needing independent classification.
  Examples: email threads, CSV with many tickets, PDF with multiple forms,
            log bundles, multi-record HR exports.

Parent-child lineage is preserved:
  Each segment carries parent_doc_id so downstream systems can:
  - Reconstruct the original document
  - Aggregate all segment labels for final document-level label
  - Audit the full document's classification trail

Final document label rule (applied by Classification Layer, not here):
  max_severity( all segment labels )
  where: Public=1 < Internal=2 < Confidential=3 < Restricted=4
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

from schema import DocumentSegment, StructureType
from config import CONFIG
from logger import get_logger

log = get_logger("splitter")


# ─────────────────────────────────────────────────────────────────────────────
# Compiled detection patterns
# ─────────────────────────────────────────────────────────────────────────────

_EMAIL_HDR = re.compile(
    r"(?:^|\n)(?:From|Date|To|Subject)\s*:.+",
    re.IGNORECASE,
)
_FWD_SEP = re.compile(
    r"(?:^|\n)-{3,}.*?(?:Forwarded|Original Message|Begin forwarded).*?-{3,}",
    re.IGNORECASE | re.DOTALL,
)
_BAR_SEP   = re.compile(r"(?:^|\n)(?:={5,}|-{5,}|_{5,}|\*{5,}|\#{5,})")
_ENTITY    = re.compile(
    r"(?:^|\n)(?:Employee|Staff|Client|Customer|Record|Account|Case|Entry|Ticket)"
    r"\s*(?:ID|No|#|Number|Ref)?\s*[:\-#]\s*\S+",
    re.IGNORECASE,
)
_LOG_LINE  = re.compile(r"(?:^|\n)\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")
_PAGE_BRK  = re.compile(r"\f|---\s*[Pp]age\s+\d+\s*---")
_EXHIBIT   = re.compile(
    r"(?:^|\n)(?:Exhibit|Schedule|Annex|Appendix|Attachment)\s+[A-Z0-9]+",
    re.IGNORECASE,
)
# CSV: row count in parsed text (each line after header = one record)
_CSV_ROW   = re.compile(r"(?:^|\n)[^\n]+\|[^\n]+")


# ─────────────────────────────────────────────────────────────────────────────
# Result dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class StructureResult:
    structure_type: str                          # "single" | "multi"
    segments:       List[DocumentSegment] = field(default_factory=list)
    signals:        List[str]             = field(default_factory=list)

    @property
    def segment_count(self) -> int:
        return len(self.segments)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def detect_structure(
    text:       str,
    source:     str = "",
    file_type:  str = "",
    doc_type:   str = "general",
) -> StructureResult:
    """
    Analyse document text and return a StructureResult.

    Uses heuristic signals to decide SINGLE vs MULTI.
    For MULTI documents, splits into DocumentSegment objects.

    Args:
        text:       Extracted document text.
        source:     Source system (e.g. EMAIL, CRM).
        file_type:  File extension (pdf, docx, csv, …).
        doc_type:   Business document type from metadata.
    """
    signals:    List[str] = []
    split_pos:  List[int] = []

    # ── 1. Email header blocks ────────────────────────────────────────────
    email_blocks = list(_EMAIL_HDR.finditer(text))
    if len(email_blocks) >= CONFIG.structure.email_header_threshold:
        signals.append(f"email_headers:{len(email_blocks)}")
        for m in email_blocks[1:]:            # first = current message
            split_pos.append(m.start())

    # ── 2. Forwarded / reply separators ───────────────────────────────────
    fwd_matches = list(_FWD_SEP.finditer(text))
    if fwd_matches:
        signals.append(f"forwarded_separators:{len(fwd_matches)}")
        for m in fwd_matches:
            split_pos.append(m.start())

    # ── 3. Horizontal separator bars ──────────────────────────────────────
    bar_matches = list(_BAR_SEP.finditer(text))
    if len(bar_matches) >= 2:
        signals.append(f"separator_bars:{len(bar_matches)}")
        for m in bar_matches:
            split_pos.append(m.start())

    # ── 4. Entity record blocks (HR / CRM / Support bundles) ──────────────
    entity_matches = list(_ENTITY.finditer(text))
    if len(entity_matches) >= CONFIG.structure.entity_block_threshold:
        signals.append(f"entity_blocks:{len(entity_matches)}")
        for m in entity_matches:
            split_pos.append(m.start())

    # ── 5. Dense log entries ──────────────────────────────────────────────
    log_lines = list(_LOG_LINE.finditer(text))
    if len(log_lines) > CONFIG.structure.log_entry_threshold:
        signals.append(f"log_entries:{len(log_lines)}")
        for m in log_lines[CONFIG.structure.log_entry_threshold::5]:
            split_pos.append(m.start())

    # ── 6. Page-break markers ─────────────────────────────────────────────
    pb_matches = list(_PAGE_BRK.finditer(text))
    if len(pb_matches) >= 2:
        signals.append(f"page_breaks:{len(pb_matches)}")
        for m in pb_matches:
            split_pos.append(m.start())

    # ── 7. Contract exhibit / schedule / appendix sections ────────────────
    exhibit_matches = list(_EXHIBIT.finditer(text))
    if len(exhibit_matches) >= 2:
        signals.append(f"contract_exhibits:{len(exhibit_matches)}")
        for m in exhibit_matches:
            split_pos.append(m.start())

    # ── 8. CSV multi-record heuristic ─────────────────────────────────────
    if file_type == "csv":
        csv_rows = list(_CSV_ROW.finditer(text))
        if len(csv_rows) > 10:
            signals.append(f"csv_records:{len(csv_rows)}")
            for m in csv_rows[1:]:           # each row = one entity
                split_pos.append(m.start())

    # ── 9. Source hints ───────────────────────────────────────────────────
    if source in ("EMAIL", "CRM") and len(text) > 1500 and not signals:
        signals.append("source_bulk_heuristic")
        for pos in range(800, len(text), 800):
            nl = text.find("\n", pos)
            if nl != -1:
                split_pos.append(nl)

    # ── Decision ──────────────────────────────────────────────────────────
    if not signals:
        return _as_single(text)

    segments = _build_segments(text, split_pos)

    if len(segments) < 2:
        # Signals triggered but text couldn't be split usefully
        return _as_single(text, signals)

    log.info(
        "MULTI: %d segments | signals: %s",
        len(segments), ", ".join(signals),
    )
    return StructureResult(
        structure_type=StructureType.MULTI.value,
        segments=segments,
        signals=signals,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _as_single(text: str, signals: List[str] = None) -> StructureResult:
    return StructureResult(
        structure_type=StructureType.SINGLE.value,
        segments=[DocumentSegment(
            segment_index=0,
            text=text,
            segment_type="full_document",
            char_start=0,
            char_end=len(text),
        )],
        signals=signals or [],
    )


def _build_segments(text: str, raw_positions: List[int]) -> List[DocumentSegment]:
    """
    Convert raw split positions → clean, non-overlapping DocumentSegments.
    Filters out fragments shorter than MIN_SEGMENT_CHARS.
    Preserves original char offsets for lineage/audit.
    """
    boundaries = sorted(set([0] + raw_positions + [len(text)]))
    segments: List[DocumentSegment] = []
    idx = 0

    for i in range(len(boundaries) - 1):
        start = boundaries[i]
        end   = boundaries[i + 1]
        chunk = text[start:end].strip()

        if len(chunk) < CONFIG.structure.min_segment_chars:
            continue

        segments.append(DocumentSegment(
            segment_index = idx,
            text          = chunk,
            segment_type  = _infer_segment_type(chunk),
            char_start    = start,
            char_end      = end,
        ))
        idx += 1

    return segments


def _infer_segment_type(chunk: str) -> str:
    """
    Lightweight heuristic label for a segment.
    Used by downstream classifiers as a feature hint.
    """
    lower = chunk.lower()
    if re.search(r"^from\s*:", lower, re.MULTILINE):
        return "email_message"
    if re.search(r"employee|emp_id|staff_id|employee number", lower):
        return "hr_record"
    if re.search(r"client|customer|account_no|account number", lower):
        return "customer_record"
    if re.search(r"\d{4}-\d{2}-\d{2}[t ]\d{2}:\d{2}", lower):
        return "log_entry_block"
    if re.search(r"exhibit|schedule|annex|appendix", lower):
        return "contract_exhibit"
    if re.search(r"invoice|amount due|bill to|total due", lower):
        return "invoice"
    if re.search(r"salary|payslip|payroll|compensation|ctc", lower):
        return "salary_record"
    if re.search(r"ticket|issue|case id|support request", lower):
        return "support_ticket"
    if re.search(r"whereas|agree|parties|obligations|indemnif", lower):
        return "contract_clause"
    return "general_segment"
