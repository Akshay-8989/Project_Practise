"""
app.py
=======
Enterprise Ingestion Pipeline Orchestrator.

This module wires all components into the full pipeline and exposes
three clean entry points:

  process_event(event)     — process one IngestEvent end-to-end
  process_folder(path)     — batch process a local folder
  watch_folder(path)       — live folder watcher (polls every N seconds)

Full pipeline per IngestEvent:
─────────────────────────────────────────────────────────────────────────
  [1] Event validation        validator.validate_event()
  [2] File fetch / resolve    _resolve_file()
  [3] File type check         extension + size guard
  [4] Text extraction         parser.parse_file()
                              → returns ParsedContent or List[ParsedContent]
  [5] Metadata resolution     metadata_handler.resolve_metadata()
                              (inline → sidecar → embedded → defaults)
  [6] Technical metadata      _build_technical_meta()
                              (ingest_id, checksum, mime, parser info)
  [7] Structure detection     splitter.detect_structure()
                              → SINGLE or MULTI with segments
  [8] Build NormalizedDocument(s)
  [9] Payload validation      validator.validate_payload()
  [10] Kafka publish          producer.send_*()
       → raw_documents (all)
       → normalized_documents (valid)
       → single_entity_docs OR multi_entity_docs
  [11] Audit log              producer.send_audit()
─────────────────────────────────────────────────────────────────────────

Failures at any stage:
  - Retried via retry_handler.with_retry()
  - After max retries: DeadLetterRecord → dead_letter_queue
  - Audit record written regardless of outcome
"""

from __future__ import annotations

import os
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from schema import (
    AuditRecord,
    BusinessMetadata,
    DataCategory,
    DeadLetterRecord,
    IngestEvent,
    IngestSource,
    NormalizedDocument,
    ParsedContent,
    ProcessingStatus,
    StructureType,
    TechnicalMetadata,
)
from config import CONFIG
from logger import get_logger
from metadata_handler import resolve_metadata
from parser import (
    ParsedContent as _PC,
    compute_checksum,
    get_data_category,
    get_file_size,
    parse_file,
)
from producer import IngestionProducer
from splitter import detect_structure
from validator import validate_event, validate_payload
from retry_handler import with_retry, build_dlq_record

log = get_logger("app")


# ─────────────────────────────────────────────────────────────────────────────
# Processing result (returned to callers)
# ─────────────────────────────────────────────────────────────────────────────

class PipelineResult:
    __slots__ = [
        "event_id", "ingest_id", "file_name", "success",
        "structure_type", "data_category", "segment_count",
        "topics_written", "failure_reason", "failure_detail",
        "retry_count", "warnings",
    ]

    def __init__(self, event_id: str = "", file_name: str = ""):
        self.event_id       = event_id
        self.ingest_id      = str(uuid.uuid4())
        self.file_name      = file_name
        self.success        = False
        self.structure_type = None
        self.data_category  = None
        self.segment_count  = 0
        self.topics_written: List[str] = []
        self.failure_reason = None
        self.failure_detail = None
        self.retry_count    = 0
        self.warnings:      List[str] = []

    def __repr__(self):
        if self.success:
            return (
                f"<OK  {self.file_name} | "
                f"type={self.structure_type} "
                f"segs={self.segment_count} "
                f"cat={self.data_category} "
                f"topics={self.topics_written}>"
            )
        return (
            f"<FAIL {self.file_name} | "
            f"{self.failure_reason}: {self.failure_detail}>"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Main pipeline entry point
# ─────────────────────────────────────────────────────────────────────────────

def process_event(
    event:    IngestEvent,
    producer: Optional[IngestionProducer] = None,
) -> PipelineResult:
    """
    Execute the full ingestion pipeline for one IngestEvent.

    Args:
        event:    The IngestEvent (from Kafka / API / folder watcher / direct).
        producer: Optional shared IngestionProducer. If None, one is created.

    Returns:
        PipelineResult with outcome details.
    """
    result        = PipelineResult(event_id=event.event_id, file_name=event.file_name or "")
    result.ingest_id = str(uuid.uuid4())
    _own_producer = producer is None

    if _own_producer:
        try:
            producer = IngestionProducer()
        except Exception as exc:
            result.failure_reason = "KAFKA_UNAVAILABLE"
            result.failure_detail = str(exc)
            log.critical("Cannot connect to Kafka: %s", exc)
            return result

    ctx = {
        "event_id":     event.event_id,
        "ingest_id":    result.ingest_id,
        "file_name":    result.file_name,
        "source_system":event.metadata.source_system,
    }

    try:
        # ── [1] Event validation ──────────────────────────────────────────
        ev_val = validate_event(event)
        if not ev_val.success:
            return _pipeline_fail(
                result, producer, ctx,
                "EVENT_VALIDATION", ev_val.failure_reason, ev_val.failure_detail,
            )

        # ── [2] Resolve file ──────────────────────────────────────────────
        file_path, file_name = _resolve_file(event)
        result.file_name = file_name
        ctx["file_name"] = file_name

        # ── [3] File type + size check ────────────────────────────────────
        ext = Path(file_name).suffix.lower().lstrip(".")
        if not ext or f".{ext}" not in {
            ".pdf", ".docx", ".txt", ".csv", ".json",
            ".eml", ".msg", ".zip", ".xlsx"
        }:
            return _pipeline_fail(
                result, producer, ctx,
                "UNSUPPORTED_FORMAT", "UNSUPPORTED_EXT",
                f"Extension '.{ext}' is not supported",
            )

        size_bytes = get_file_size(file_path)
        if size_bytes > CONFIG.max_file_size_mb * 1024 * 1024:
            return _pipeline_fail(
                result, producer, ctx,
                "FILE_CHECK", "FILE_TOO_LARGE",
                f"{size_bytes / 1048576:.1f} MB exceeds limit of {CONFIG.max_file_size_mb} MB",
            )

        # ── [4] Text extraction (with retry) ──────────────────────────────
        success, parse_result, err = with_retry(
            func    = lambda: parse_file(file_path, file_name=file_name),
            context = ctx,
            producer= producer,
            stage   = "parse",
        )
        if not success:
            return _mark_failed(result, "PARSE", "MAX_RETRIES_EXCEEDED", err)

        # ZIP returns list — treat as MULTI
        if isinstance(parse_result, list):
            return _handle_zip_results(
                parse_results=parse_result,
                event=event,
                file_path=file_path,
                file_name=file_name,
                result=result,
                ctx=ctx,
                producer=producer,
            )

        parsed: ParsedContent = parse_result
        if not parsed.success:
            return _pipeline_fail(
                result, producer, ctx,
                "PARSE", "PARSE_FAILED", parsed.error or "Unknown parse error",
            )
        result.warnings.extend(parsed.warnings)

        # ── [5] Metadata resolution ────────────────────────────────────────
        biz_meta = resolve_metadata(
            file_path    = file_path,
            inline_meta  = event.metadata.model_dump(exclude={"validation_issues", "is_complete"}),
            file_name    = file_name,
        )

        # ── [6] Technical metadata ────────────────────────────────────────
        tech_meta = TechnicalMetadata(
            ingest_id       = result.ingest_id,
            ingest_source   = event.ingest_source,
            file_name       = file_name,
            file_size_bytes = size_bytes,
            mime_type       = parsed.mime_type,
            checksum_sha256 = compute_checksum(file_path),
            parser_used     = parsed.parser_used,
            parse_warnings  = parsed.warnings,
            char_count      = len(parsed.raw_text),
            word_count      = len(parsed.raw_text.split()),
        )

        # ── [7] Structure detection ────────────────────────────────────────
        struct = detect_structure(
            text       = parsed.raw_text,
            source     = biz_meta.source_system,
            file_type  = parsed.file_type,
            doc_type   = biz_meta.document_type,
        )

        tech_meta.structure_type   = struct.structure_type
        tech_meta.data_category    = get_data_category(parsed.file_type)
        tech_meta.structure_signals= struct.signals
        tech_meta.split_count      = struct.segment_count

        result.structure_type = struct.structure_type
        result.data_category  = tech_meta.data_category
        result.segment_count  = struct.segment_count

        log.info(
            "[%s] %s | structure=%s | segments=%d | category=%s",
            result.ingest_id, file_name,
            struct.structure_type, struct.segment_count, tech_meta.data_category,
        )

        # ── [8–10] Build, validate, publish ───────────────────────────────
        ingest_ts  = datetime.utcnow().isoformat()
        parent_id  = result.ingest_id   # used as parent for MULTI segments
        topics     = []

        if struct.structure_type == StructureType.SINGLE.value:
            doc = _build_normalized_doc(
                event_id      = event.event_id,
                doc_id        = str(uuid.uuid4()),
                parent_doc_id = None,
                raw_text      = parsed.raw_text,
                segment_index = None,
                total_segments= None,
                segment_type  = None,
                biz_meta      = biz_meta,
                tech_meta     = tech_meta,
            )

            val = validate_payload(doc)
            if not val.success:
                return _pipeline_fail(
                    result, producer, ctx,
                    "VALIDATION", val.failure_reason, val.failure_detail,
                )

            payload = doc.model_dump()
            producer.send_raw(payload)
            producer.send_normalized(payload)
            producer.send_single(payload)
            topics = [
                CONFIG.topics.raw_documents,
                CONFIG.topics.normalized_docs,
                CONFIG.topics.single_entity,
            ]
            log.info(
                "[%s] → %s | doc_id=%s",
                result.ingest_id, CONFIG.topics.single_entity, doc.doc_id,
            )

        else:
            # MULTI: one message per segment
            sent = 0
            for seg in struct.segments:
                seg_tech = tech_meta.model_copy()
                seg_tech.ingest_id = result.ingest_id   # all segments share ingest_id

                doc = _build_normalized_doc(
                    event_id      = event.event_id,
                    doc_id        = str(uuid.uuid4()),
                    parent_doc_id = parent_id,
                    raw_text      = seg.text,
                    segment_index = seg.segment_index,
                    total_segments= struct.segment_count,
                    segment_type  = seg.segment_type,
                    biz_meta      = biz_meta,
                    tech_meta     = seg_tech,
                )

                val = validate_payload(doc)
                if not val.success:
                    log.warning(
                        "[%s] Segment %d failed validation → DLQ: %s",
                        result.ingest_id, seg.segment_index, val.failure_detail,
                    )
                    dlr = build_dlq_record(
                        context  = ctx,
                        stage    = "segment_validation",
                        reason   = val.failure_reason,
                        detail   = f"Segment {seg.segment_index}: {val.failure_detail}",
                    )
                    producer.send_dlq(dlr.model_dump())
                    continue

                payload = doc.model_dump()
                producer.send_raw(payload)
                producer.send_normalized(payload)
                producer.send_multi(payload)
                sent += 1
                log.info(
                    "[%s] → %s | seg=%d/%d | type=%s | doc_id=%s",
                    result.ingest_id, CONFIG.topics.multi_entity,
                    seg.segment_index + 1, struct.segment_count,
                    seg.segment_type, doc.doc_id,
                )

            topics = [
                CONFIG.topics.raw_documents,
                CONFIG.topics.normalized_docs,
                CONFIG.topics.multi_entity,
            ]
            result.segment_count = sent

        result.topics_written = topics
        result.success        = True

        # ── [11] Audit log ─────────────────────────────────────────────────
        _write_audit(result, producer, event, biz_meta, tech_meta)
        return result

    except Exception as exc:
        log.error(
            "[%s] Unexpected pipeline error for %s: %s",
            result.ingest_id, file_name, exc, exc_info=True,
        )
        return _pipeline_fail(
            result, producer, ctx,
            "UNEXPECTED", "UNHANDLED_EXCEPTION", str(exc),
        )

    finally:
        if _own_producer:
            producer.close()


# ─────────────────────────────────────────────────────────────────────────────
# ZIP handler
# ─────────────────────────────────────────────────────────────────────────────

def _handle_zip_results(
    parse_results: List[ParsedContent],
    event:         IngestEvent,
    file_path:     str,
    file_name:     str,
    result:        PipelineResult,
    ctx:           Dict,
    producer:      IngestionProducer,
) -> PipelineResult:
    """Each file inside a ZIP is treated as an independent MULTI segment."""
    biz_meta = resolve_metadata(
        file_path   = file_path,
        inline_meta = event.metadata.model_dump(exclude={"validation_issues", "is_complete"}),
        file_name   = file_name,
    )
    tech_meta = TechnicalMetadata(
        ingest_id       = result.ingest_id,
        ingest_source   = event.ingest_source,
        file_name       = file_name,
        file_size_bytes = get_file_size(file_path),
        checksum_sha256 = compute_checksum(file_path),
        structure_type  = StructureType.MULTI.value,
        data_category   = DataCategory.UNSTRUCTURED.value,
        split_count     = len(parse_results),
    )

    parent_id = result.ingest_id
    sent = 0

    for i, inner in enumerate(parse_results):
        if not inner.success:
            log.warning("ZIP inner '%s' parse failed: %s", inner.file_name, inner.error)
            continue

        doc = _build_normalized_doc(
            event_id      = event.event_id,
            doc_id        = str(uuid.uuid4()),
            parent_doc_id = parent_id,
            raw_text      = inner.raw_text,
            segment_index = i,
            total_segments= len(parse_results),
            segment_type  = f"zip_entry:{inner.file_name}",
            biz_meta      = biz_meta,
            tech_meta     = tech_meta.model_copy(
                update={"parser_used": inner.parser_used, "mime_type": inner.mime_type}
            ),
        )

        val = validate_payload(doc)
        if not val.success:
            dlr = build_dlq_record(
                context = ctx,
                stage   = "zip_segment_validation",
                reason  = val.failure_reason,
                detail  = val.failure_detail,
            )
            producer.send_dlq(dlr.model_dump())
            continue

        payload = doc.model_dump()
        producer.send_raw(payload)
        producer.send_normalized(payload)
        producer.send_multi(payload)
        sent += 1

    result.success        = True
    result.structure_type = StructureType.MULTI.value
    result.data_category  = DataCategory.UNSTRUCTURED.value
    result.segment_count  = sent
    result.topics_written = [
        CONFIG.topics.raw_documents,
        CONFIG.topics.normalized_docs,
        CONFIG.topics.multi_entity,
    ]
    _write_audit(result, producer, event, biz_meta, tech_meta)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Batch folder processor
# ─────────────────────────────────────────────────────────────────────────────

def process_folder(
    folder_path:  str          = None,
    ingest_source:str          = IngestSource.FOLDER_WATCH.value,
    inline_meta:  Optional[Dict] = None,
) -> List[PipelineResult]:
    """
    Batch process all supported files in a folder.
    Reuses one Kafka producer for the entire batch (efficient).
    """
    folder = folder_path or CONFIG.upload_folder
    os.makedirs(folder, exist_ok=True)

    supported = {
        ".pdf", ".docx", ".txt", ".csv", ".json",
        ".eml", ".msg", ".zip", ".xlsx",
    }
    files = [
        os.path.join(folder, f)
        for f in sorted(os.listdir(folder))
        if os.path.isfile(os.path.join(folder, f))
        and Path(f).suffix.lower() in supported
    ]

    if not files:
        log.warning("No supported files found in %s", folder)
        return []

    log.info("Batch starting: %d files from %s", len(files), folder)
    results = []

    try:
        producer = IngestionProducer()
    except Exception as exc:
        log.critical("Kafka unavailable — cannot start batch: %s", exc)
        return []

    with producer:
        for i, file_path in enumerate(files, 1):
            fname = os.path.basename(file_path)
            log.info("[%d/%d] Processing: %s", i, len(files), fname)

            meta_dict = dict(inline_meta) if inline_meta else {}
            event = IngestEvent(
                ingest_source = ingest_source,
                file_uri      = file_path,
                file_name     = fname,
                metadata      = BusinessMetadata(**{
                    k: v for k, v in meta_dict.items()
                    if k in BusinessMetadata.model_fields
                }),
            )

            result = process_event(event, producer=producer)
            results.append(result)
            log.info("Result: %s", result)

        producer.flush()

    ok   = sum(1 for r in results if r.success)
    fail = len(results) - ok
    log.info(
        "Batch complete: %d/%d succeeded, %d failed",
        ok, len(results), fail,
    )
    return results


# ─────────────────────────────────────────────────────────────────────────────
# Folder watcher (polling, no external dependency)
# ─────────────────────────────────────────────────────────────────────────────

def watch_folder(
    folder_path:   str   = None,
    ingest_source: str   = IngestSource.FOLDER_WATCH.value,
    poll_seconds:  float = 5.0,
    inline_meta:   Optional[Dict] = None,
) -> None:
    """
    Continuously watch a folder and process new files as they appear.
    Tracks seen files to avoid reprocessing.
    Press Ctrl+C to stop.
    """
    folder = folder_path or CONFIG.upload_folder
    os.makedirs(folder, exist_ok=True)
    seen = set(os.listdir(folder))

    log.info(
        "Folder watcher started | path=%s | interval=%.0fs | Ctrl+C to stop",
        folder, poll_seconds,
    )

    try:
        producer = IngestionProducer()
    except Exception as exc:
        log.critical("Kafka unavailable — watcher cannot start: %s", exc)
        return

    supported = {
        ".pdf", ".docx", ".txt", ".csv", ".json",
        ".eml", ".msg", ".zip", ".xlsx",
    }

    try:
        with producer:
            while True:
                time.sleep(poll_seconds)
                current = set(os.listdir(folder))
                new_files = current - seen

                for fname in sorted(new_files):
                    fpath = os.path.join(folder, fname)
                    if not os.path.isfile(fpath):
                        seen.add(fname)
                        continue
                    if Path(fname).suffix.lower() not in supported:
                        log.debug("Ignoring unsupported: %s", fname)
                        seen.add(fname)
                        continue

                    log.info("New file detected: %s", fname)
                    meta_dict = dict(inline_meta) if inline_meta else {}
                    event = IngestEvent(
                        ingest_source = ingest_source,
                        file_uri      = fpath,
                        file_name     = fname,
                        metadata      = BusinessMetadata(**{
                            k: v for k, v in meta_dict.items()
                            if k in BusinessMetadata.model_fields
                        }),
                    )
                    result = process_event(event, producer=producer)
                    log.info("Result: %s", result)

                seen = current

    except KeyboardInterrupt:
        log.info("Folder watcher stopped by user.")


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_file(event: IngestEvent) -> tuple:
    """
    Resolve the IngestEvent to (file_path, file_name).
    Handles local paths and simulated storage URIs.
    """
    if event.file_uri:
        uri = event.file_uri

        # Simulated cloud URI → resolve to local path under storage_base_path
        if uri.startswith(("s3://", "gcs://", "azure://")):
            # Strip protocol prefix and resolve locally
            key  = uri.split("//", 1)[1].split("/", 1)[-1]
            path = os.path.join(CONFIG.storage_base_path, key)
            return path, os.path.basename(path)

        return uri, event.file_name or os.path.basename(uri)

    if event.file_name:
        # Resolve by filename from upload folder
        path = os.path.join(CONFIG.upload_folder, event.file_name)
        return path, event.file_name

    raise ValueError("IngestEvent has neither file_uri nor file_name")


def _build_normalized_doc(
    event_id:       str,
    doc_id:         str,
    parent_doc_id:  Optional[str],
    raw_text:       str,
    segment_index:  Optional[int],
    total_segments: Optional[int],
    segment_type:   Optional[str],
    biz_meta:       BusinessMetadata,
    tech_meta:      TechnicalMetadata,
) -> NormalizedDocument:
    return NormalizedDocument(
        doc_id          = doc_id,
        parent_doc_id   = parent_doc_id,
        event_id        = event_id,
        raw_text        = raw_text,
        segment_index   = segment_index,
        total_segments  = total_segments,
        segment_type    = segment_type,
        business_metadata  = biz_meta,
        technical_metadata = tech_meta,
        structure_type  = tech_meta.structure_type,
        data_category   = tech_meta.data_category,
    )


def _write_audit(
    result:    PipelineResult,
    producer:  IngestionProducer,
    event:     IngestEvent,
    biz_meta:  BusinessMetadata,
    tech_meta: TechnicalMetadata,
):
    audit = AuditRecord(
        event_id          = event.event_id,
        ingest_id         = result.ingest_id,
        file_name         = result.file_name,
        source_system     = biz_meta.source_system,
        department        = biz_meta.department,
        ingest_source     = event.ingest_source,
        status            = ProcessingStatus.SUCCESS.value if result.success
                            else ProcessingStatus.FAILED.value,
        structure_type    = result.structure_type,
        data_category     = result.data_category,
        segment_count     = result.segment_count,
        topics_written    = result.topics_written,
        failure_reason    = result.failure_reason,
        failure_detail    = result.failure_detail,
        retry_count       = result.retry_count,
        checksum_sha256   = tech_meta.checksum_sha256,
        metadata_complete = biz_meta.is_complete,
        metadata_issues   = biz_meta.validation_issues,
        parse_warnings    = result.warnings,
    )
    producer.send_audit(audit.model_dump())


def _pipeline_fail(
    result:   PipelineResult,
    producer: IngestionProducer,
    ctx:      Dict,
    stage:    str,
    reason:   str,
    detail:   str,
) -> PipelineResult:
    result.failure_reason = reason
    result.failure_detail = detail
    dlr = build_dlq_record(ctx, stage, reason, detail)
    producer.send_dlq(dlr.model_dump())
    audit = AuditRecord(
        event_id      = ctx.get("event_id", ""),
        ingest_id     = ctx.get("ingest_id", ""),
        file_name     = ctx.get("file_name", ""),
        source_system = ctx.get("source_system", "UNKNOWN"),
        status        = ProcessingStatus.FAILED.value,
        failure_reason= reason,
        failure_detail= detail,
    )
    producer.send_audit(audit.model_dump())
    log.error("FAILED | file=%s | stage=%s | reason=%s | %s", ctx.get("file_name"), stage, reason, detail)
    return result


def _mark_failed(result, stage, reason, detail):
    result.failure_reason = reason
    result.failure_detail = detail
    return result
