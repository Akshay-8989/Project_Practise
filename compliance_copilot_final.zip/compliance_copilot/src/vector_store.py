"""
vector_store.py  –  FR3 (Embeddings) + FR4 (Storage) + FR6 (Retrieval)
Uses TF-IDF via scikit-learn — 100% offline, zero downloads, zero internet.
"""
from __future__ import annotations

import logging
import pickle
from pathlib import Path
from typing import List, Tuple

logger = logging.getLogger(__name__)

INDEX_FILE = "tfidf_index.pkl"


class _Doc:
    """Minimal document object."""
    def __init__(self, page_content: str, metadata: dict):
        self.page_content = page_content
        self.metadata     = metadata


class ComplianceVectorStore:
    """
    TF-IDF + cosine similarity vector store.
    Fully offline — scikit-learn only, no HuggingFace, no internet.
    """

    def __init__(self, persist_dir: Path, embedding_model: str = None):
        self.persist_dir = Path(persist_dir)
        self.persist_dir.mkdir(parents=True, exist_ok=True)
        self._store = None
        self._load()

    @property
    def _index_path(self) -> Path:
        return self.persist_dir / INDEX_FILE

    def _load(self):
        if self._index_path.exists():
            try:
                with open(self._index_path, "rb") as f:
                    self._store = pickle.load(f)
                logger.info("Loaded index: %d chunks", len(self._store["texts"]))
            except Exception as e:
                logger.warning("Could not load index: %s", e)
                self._store = None

    def _save(self):
        with open(self._index_path, "wb") as f:
            pickle.dump(self._store, f)

    def add_documents(self, chunks) -> None:
        if not chunks:
            return

        new_texts = [c.text for c in chunks]
        new_metas = [
            {"source": c.source_file, "page": c.page_number,
             "chunk_index": c.chunk_index, "doc_hash": c.doc_hash}
            for c in chunks
        ]

        all_texts = (self._store["texts"] + new_texts) if self._store else new_texts
        all_metas = (self._store["metadatas"] + new_metas) if self._store else new_metas

        from sklearn.feature_extraction.text import TfidfVectorizer
        vectorizer = TfidfVectorizer(
            max_features=8192, ngram_range=(1, 2),
            sublinear_tf=True, min_df=1, strip_accents="unicode",
        )
        matrix = vectorizer.fit_transform(all_texts)

        self._store = {
            "texts":      all_texts,
            "metadatas":  all_metas,
            "matrix":     matrix,
            "vectorizer": vectorizer,
        }
        self._save()
        logger.info("Index saved: %d total chunks", len(all_texts))

    def similarity_search(self, query: str, k: int = 4) -> List[Tuple[_Doc, float]]:
        if self._store is None:
            raise RuntimeError("Vector store is empty. Upload a PDF first.")

        import numpy as np
        from sklearn.metrics.pairwise import cosine_similarity

        query_vec = self._store["vectorizer"].transform([query])
        scores    = cosine_similarity(query_vec, self._store["matrix"])[0]
        top_idx   = np.argsort(scores)[::-1][:k]

        results = []
        for idx in top_idx:
            score = float(scores[idx])
            if score > 0.0:
                results.append((_Doc(
                    page_content=self._store["texts"][idx],
                    metadata=self._store["metadatas"][idx],
                ), score))
        return results

    def document_count(self) -> int:
        return len(self._store["texts"]) if self._store else 0

    def reset(self):
        if self._index_path.exists():
            self._index_path.unlink()
        self._store = None
        logger.info("Vector store reset.")
