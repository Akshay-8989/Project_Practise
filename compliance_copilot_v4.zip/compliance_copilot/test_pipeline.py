"""
test_pipeline.py  –  Diagnostic script v4
Run with:  python test_pipeline.py
"""
import sys
sys.path.insert(0, '.')

print("=" * 60)
print("STEP 1: EasyOCR")
print("=" * 60)
try:
    import easyocr
    print("✅ easyocr installed")
except ImportError:
    print("⚠️  easyocr not installed — run: pip install easyocr")

print()
print("=" * 60)
print("STEP 2: FAISS")
print("=" * 60)
try:
    import faiss
    print("✅ faiss-cpu installed")
except ImportError:
    print("❌ faiss not installed — run: pip install faiss-cpu")
    print("   If numpy error: pip install 'numpy<2.0'")

print()
print("=" * 60)
print("STEP 3: Section-aware chunking test")
print("=" * 60)
try:
    from src.document_processor import _split_by_sections, _plain_split

    # Simulate policy text with sections 12, 12.1, 12.2
    sample = """12. Penalties and Enforcement
Non-compliance exposes the bank to severe penalties.

12.1 Regulatory Penalties
Fines up to USD 1,000,000 per violation.
Suspension or revocation of banking licence.
Public enforcement actions.

12.2 Individual Employee Consequences
Criminal prosecution up to 20 years imprisonment.
Personal fines up to USD 500,000.
Immediate termination of employment."""

    chunks = _split_by_sections(sample, chunk_size=1024, chunk_overlap=200)
    print(f"Chunks produced: {len(chunks)}")
    for i, c in enumerate(chunks):
        has_parent = "12." in c and "Penalties" in c
        has_sub1   = "12.1" in c
        has_sub2   = "12.2" in c
        print(f"  Chunk {i+1}: {len(c)} chars | "
              f"has '12.': {has_parent} | has '12.1': {has_sub1} | has '12.2': {has_sub2}")

    # Key assertion: 12, 12.1 and 12.2 should be in the same chunk
    all_in_one = any("12.1" in c and "12.2" in c for c in chunks)
    if all_in_one:
        print("✅ Section 12 + 12.1 + 12.2 are in the SAME chunk — subsection fix works!")
    else:
        print("⚠️  Sections split across chunks (may happen if text is very large)")
except Exception as e:
    import traceback
    print(f"❌ Error: {e}")
    traceback.print_exc()

print()
print("=" * 60)
print("STEP 4: Vector store")
print("=" * 60)
try:
    from src.vector_store import ComplianceVectorStore
    from pathlib import Path
    store = ComplianceVectorStore(Path('data/vectorstore'))
    count = store.document_count()
    print(f"FAISS vectors: {count}")
    if count == 0:
        print("⚠️  Empty — upload a PDF first via the UI")
    else:
        results = store.similarity_search('penalties enforcement 12 12.1 12.2', k=4)
        print(f"Search results: {len(results)}")
        for i, (doc, score) in enumerate(results, 1):
            has_sub = "12.1" in doc.page_content or "12.2" in doc.page_content
            print(f"  [{i}] score={score:.3f} has_subsections={has_sub} | "
                  f"{doc.page_content[:100].replace(chr(10),' ')}")
        print("✅ Vector store OK")
except Exception as e:
    import traceback
    print(f"❌ Error: {e}")
    traceback.print_exc()

print()
print("=" * 60)
print("STEP 5: Phi-2 LLM")
print("=" * 60)
try:
    from src.config import PHI2_MODEL_NAME
    print(f"Path: {PHI2_MODEL_NAME}")
    from src.llm_engine import get_llm
    print("Loading model…")
    llm    = get_llm(model_name=PHI2_MODEL_NAME)
    result = llm.generate("Instruct: What is KYC? One sentence. Output:")
    print(f"Output: {result}")
    print("✅ Phi-2 OK")
except Exception as e:
    import traceback
    print(f"❌ Phi-2 error: {e}")
    traceback.print_exc()

print()
print("=" * 60)
print("STEP 6: Full RAG pipeline — subsection test")
print("=" * 60)
try:
    from src.rag_pipeline import ComplianceRAGPipeline
    pipeline = ComplianceRAGPipeline()
    if pipeline.vectorstore.document_count() == 0:
        print("⚠️  Skipping — upload a PDF first")
    else:
        print("Testing: 'What are the penalties for non-compliance?'")
        response = pipeline.query("What are the penalties for non-compliance?")
        has_sub1 = "12.1" in response.answer or "Regulatory" in response.answer
        has_sub2 = "12.2" in response.answer or "Individual" in response.answer or "imprisonment" in response.answer
        print(f"Answer contains 12.1 content: {has_sub1}")
        print(f"Answer contains 12.2 content: {has_sub2}")
        print(f"Answer preview: {response.answer[:400]}")
        if has_sub1 and has_sub2:
            print("✅ Both subsections returned — fix works!")
        else:
            print("⚠️  Some subsections may be missing")
except Exception as e:
    import traceback
    print(f"❌ Error: {e}")
    traceback.print_exc()
