"""
vector_store.py
---------------
FR3 – Embedding Generation : TF-IDF + SVD dense vectors (offline)
FR4 – Vector Database      : FAISS IndexFlatIP (persisted to disk)
FR6 – Context Retrieval    : FAISS similarity search with query expansion

KEY FIX in v4:
- Query expansion now includes section number variants so "section 12"
  also searches for "12.1" and "12.2" explicitly.
- TOP_K increased to 6 to capture parent + subsections.
"""
from __future__ import annotations

import logging
import pickle
from pathlib import Path
from typing import List, Tuple

import numpy as np

logger = logging.getLogger(__name__)

FAISS_INDEX_FILE = "faiss_index.bin"
META_FILE        = "faiss_meta.pkl"
TFIDF_FILE       = "tfidf_vectorizer.pkl"
SVD_FILE         = "svd_transformer.pkl"

VECTOR_DIM = 256


class _Doc:
    def __init__(self, page_content: str, metadata: dict):
        self.page_content = page_content
        self.metadata     = metadata


def _expand_query(query: str) -> str:
    """
    Expand query with:
    1. Banking/compliance synonyms
    2. Section number variants — if query mentions "12" also include "12.1" "12.2"
       so subsections are always retrieved alongside their parent.
    """
    q   = query.lower()
    exp = [query]

    # ── Section number expansion ──────────────────────────────────────────────
    # Find any numbers in the query and add subsection variants
    numbers = re.findall(r'\b(\d{1,2})\b', q)
    for n in numbers:
        exp.append(f"{n}.1 {n}.2 {n}.3 section {n}")

    # ── Banking/compliance synonyms ───────────────────────────────────────────
    mapping = [
        (["kyc", "know your customer", "identity", "identification", "verify", "id proof"],
         "kyc know your customer identity verification document proof"),
        (["aml", "money laundering", "anti-money", "laundering"],
         "aml anti money laundering suspicious activity"),
        (["sar", "suspicious activity", "report", "filing"],
         "sar suspicious activity report filing mlro isar"),
        (["risk", "assessment", "cdd", "edd", "due diligence"],
         "risk assessment customer due diligence cdd edd enhanced simplified"),
        (["document", "proof", "certificate", "passport", "licence", "id"],
         "documents required proof identity address passport licence photo"),
        (["threshold", "limit", "amount", "usd", "cash", "transaction", "wire"],
         "threshold limit reporting amount cash transaction usd 10000 50000 wire transfer"),
        (["penalty", "penalt", "fine", "punishment", "consequence", "violation",
          "enforcement", "imprisonment", "criminal"],
         "penalty fine enforcement consequences non-compliance violation criminal prosecution "
         "imprisonment termination ban 12 12.1 12.2 regulatory individual"),
        (["record", "retain", "keep", "store", "how long", "retention"],
         "record keeping retention period years store documents 5 years 7 years"),
        (["train", "employee", "staff", "mandatory", "annual", "programme"],
         "training employees staff mandatory annual compliance programme frequency"),
        (["sanction", "ofac", "blacklist", "watchlist", "screen"],
         "sanctions screening ofac watchlist blacklist un eu hm treasury"),
        (["pep", "politically exposed", "politician", "public function"],
         "pep politically exposed person enhanced due diligence high risk"),
        (["fail", "reject", "denied", "not pass", "unsuccessful", "refuse"],
         "customer fails kyc check rejected denied account closure edd"),
        (["escalat", "approval", "senior", "management", "authoris"],
         "escalation approval senior management compliance officer head"),
        (["placement", "layering", "integration", "stage", "money laundering process"],
         "placement layering integration stages money laundering process"),
        (["whistleblow", "hotline", "report anonymously", "protection"],
         "whistleblower protection hotline report anonymously compliance fnb"),
        (["image", "chart", "table", "diagram", "figure", "visual"],
         "image chart table diagram figure visual embedded"),
    ]
    for keywords, expansion in mapping:
        if any(w in q for w in keywords):
            exp.append(expansion)

    return " ".join(exp)


import re   # needed by _expand_query — import here to avoid circular issues


class ComplianceVectorStore:
    """
    FAISS-backed vector store using TF-IDF + SVD embeddings.
    Fully offline — no HuggingFace, no internet.
    """

    def __init__(self, persist_dir: Path, embedding_model: str = None):
        self.persist_dir = Path(persist_dir)
        self.persist_dir.mkdir(parents=True, exist_ok=True)
        self._index      = None
        self._texts:  List[str]  = []
        self._metas:  List[dict] = []
        self._vectorizer = None
        self._svd        = None
        self._load()

    @property
    def _index_path(self) -> Path:
        return self.persist_dir / FAISS_INDEX_FILE

    def _load(self):
        paths = [
            self.persist_dir / FAISS_INDEX_FILE,
            self.persist_dir / META_FILE,
            self.persist_dir / TFIDF_FILE,
            self.persist_dir / SVD_FILE,
        ]
        if all(p.exists() for p in paths):
            try:
                import faiss
                self._index = faiss.read_index(str(self.persist_dir / FAISS_INDEX_FILE))
                with open(self.persist_dir / META_FILE, "rb") as f:
                    data = pickle.load(f)
                    self._texts = data["texts"]
                    self._metas = data["metas"]
                with open(self.persist_dir / TFIDF_FILE, "rb") as f:
                    self._vectorizer = pickle.load(f)
                with open(self.persist_dir / SVD_FILE, "rb") as f:
                    self._svd = pickle.load(f)
                logger.info("FAISS index loaded: %d vectors", self._index.ntotal)
            except Exception as e:
                logger.warning("Could not load FAISS index: %s — will rebuild.", e)
                self._reset_state()

    def _save(self):
        import faiss
        faiss.write_index(self._index, str(self.persist_dir / FAISS_INDEX_FILE))
        with open(self.persist_dir / META_FILE,  "wb") as f:
            pickle.dump({"texts": self._texts, "metas": self._metas}, f)
        with open(self.persist_dir / TFIDF_FILE, "wb") as f:
            pickle.dump(self._vectorizer, f)
        with open(self.persist_dir / SVD_FILE,   "wb") as f:
            pickle.dump(self._svd, f)
        logger.info("FAISS index saved: %d vectors", self._index.ntotal)

    def _reset_state(self):
        self._index      = None
        self._texts      = []
        self._metas      = []
        self._vectorizer = None
        self._svd        = None

    def _embed(self, texts: List[str]) -> np.ndarray:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.decomposition import TruncatedSVD
        from sklearn.preprocessing import normalize

        self._vectorizer = TfidfVectorizer(
            max_features=16384,
            ngram_range=(1, 2),
            sublinear_tf=True,
            min_df=1,
            strip_accents="unicode",
        )
        sparse    = self._vectorizer.fit_transform(texts)
        actual_dim = min(VECTOR_DIM, sparse.shape[1] - 1, sparse.shape[0] - 1)
        self._svd  = TruncatedSVD(n_components=actual_dim, random_state=42)
        dense      = self._svd.fit_transform(sparse)
        return normalize(dense, norm="l2").astype(np.float32)

    def _embed_query(self, query: str) -> np.ndarray:
        from sklearn.preprocessing import normalize
        sparse = self._vectorizer.transform([query])
        dense  = self._svd.transform(sparse)
        return normalize(dense, norm="l2").astype(np.float32)

    def add_documents(self, chunks) -> None:
        if not chunks:
            return
        import faiss

        new_texts = [c.text for c in chunks]
        new_metas = [
            {
                "source":      c.source_file,
                "page":        c.page_number,
                "chunk_index": c.chunk_index,
                "doc_hash":    c.doc_hash,
                "chunk_type":  getattr(c, "chunk_type", "text"),
            }
            for c in chunks
        ]

        all_texts = self._texts + new_texts
        all_metas = self._metas + new_metas

        logger.info("Building embeddings for %d chunks…", len(all_texts))
        vectors = self._embed(all_texts)
        dim     = vectors.shape[1]

        self._index = faiss.IndexFlatIP(dim)
        self._index.add(vectors)
        self._texts = all_texts
        self._metas = all_metas
        self._save()
        logger.info("FAISS index built: %d vectors, dim=%d", self._index.ntotal, dim)

    def similarity_search(self, query: str, k: int = 6) -> List[Tuple[_Doc, float]]:
        if self._index is None or self._index.ntotal == 0:
            raise RuntimeError("Vector store is empty. Upload a PDF first.")

        expanded  = _expand_query(query)
        query_vec = self._embed_query(expanded)
        k_actual  = min(k, self._index.ntotal)
        scores, indices = self._index.search(query_vec, k_actual)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append((_Doc(
                page_content=self._texts[idx],
                metadata=self._metas[idx],
            ), float(score)))

        if not results:
            results = [(_Doc(
                page_content=self._texts[0],
                metadata=self._metas[0],
            ), 0.01)]

        return results

    def document_count(self) -> int:
        return self._index.ntotal if self._index else 0

    def reset(self):
        for fname in [FAISS_INDEX_FILE, META_FILE, TFIDF_FILE, SVD_FILE]:
            p = self.persist_dir / fname
            if p.exists():
                p.unlink()
        self._reset_state()
        logger.info("FAISS vector store reset.")
