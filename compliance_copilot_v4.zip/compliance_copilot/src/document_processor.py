"""
document_processor.py
---------------------
FR1 – Document Upload
FR2 – Document Processing: text + EasyOCR image extraction + smart chunking

KEY FIX in v4: Section-aware chunking.
Instead of blindly splitting by character count, we first split by section
headers (1., 1.1, 12., 12.1 etc.) so that a section and ALL its subsections
stay in the same chunk. This ensures that asking about "Section 12" returns
12.1 Regulatory Penalties AND 12.2 Individual Employee Consequences together.

Fallback: if a section is still too large, it is split by character with
generous overlap so no subsection is ever orphaned.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


# ── Data model ────────────────────────────────────────────────────────────────

@dataclass
class DocumentChunk:
    text:        str
    source_file: str
    page_number: int
    chunk_index: int
    doc_hash:    str
    chunk_type:  str  = "text"
    metadata:    dict = field(default_factory=dict)


# ── Utilities ─────────────────────────────────────────────────────────────────

def _file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _clean_text(raw: str) -> str:
    text = raw.replace("\x00", "")
    text = re.sub(r"[\r\n]+", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", "-").replace("\u2014", "--")
    return text.strip()


# ── Section-aware chunking ────────────────────────────────────────────────────

# Matches top-level section headers like:
#   "1. Purpose"  "12. Penalties"  "3.1 When CDD"  "12.2 Individual"
_SECTION_HEADER = re.compile(
    r"(?m)^(\d{1,2}(?:\.\d{1,2})?)\s*[.\)]\s+[A-Z]"
)


def _split_by_sections(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    """
    Split document text into chunks that respect section boundaries.

    Strategy:
    1. Find all TOP-LEVEL section headers (e.g. "1.", "12." but NOT "12.1")
    2. Group each top-level section with ALL its subsections (12 + 12.1 + 12.2)
    3. If the resulting group is still > chunk_size, split it with overlap
       but always include the section header in every sub-chunk for context.
    """
    if not text.strip():
        return []

    # Find positions of top-level sections only (single number, e.g. "12.")
    top_level = re.compile(r"(?m)^(\d{1,2})\s*[.\)]\s+[A-Z]")
    matches   = list(top_level.finditer(text))

    if not matches:
        # No section headers found — fall back to plain chunking
        return _plain_split(text, chunk_size, chunk_overlap)

    # Build section groups: each group = header text + all subsection text
    groups = []
    for i, m in enumerate(matches):
        start = m.start()
        end   = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        groups.append(text[start:end].strip())

    # Split each group if needed
    chunks = []
    for group in groups:
        if len(group) <= chunk_size:
            if group:
                chunks.append(group)
        else:
            # Group is large — split but keep section header in each sub-chunk
            header_match = re.match(r"^.+\n", group)
            header       = header_match.group(0).strip() if header_match else ""
            sub_chunks   = _plain_split(group, chunk_size, chunk_overlap)
            for j, sc in enumerate(sub_chunks):
                # Prepend section header to every sub-chunk after the first
                if j > 0 and header and not sc.startswith(header[:20]):
                    sc = f"{header}\n{sc}"
                if sc.strip():
                    chunks.append(sc)

    return chunks if chunks else _plain_split(text, chunk_size, chunk_overlap)


def _plain_split(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    """Plain character-level sliding window split."""
    if len(text) <= chunk_size:
        return [text] if text.strip() else []
    chunks, start = [], 0
    while start < len(text):
        end = start + chunk_size
        if end >= len(text):
            chunk = text[start:].strip()
            if chunk:
                chunks.append(chunk)
            break
        search_start = max(start, end - chunk_size // 5)
        boundary = max(
            text.rfind(". ",  search_start, end),
            text.rfind(".\n", search_start, end),
            text.rfind("\n\n", search_start, end),
        )
        if boundary != -1:
            end = boundary + 1
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - chunk_overlap
    return chunks


# ── EasyOCR ───────────────────────────────────────────────────────────────────

_easyocr_reader      = None
_ocr_available_cache: Optional[bool] = None


def _get_ocr_reader():
    global _easyocr_reader
    if _easyocr_reader is not None:
        return _easyocr_reader
    try:
        import easyocr
        from src.config import EASYOCR_LANGUAGES
        logger.info("Initialising EasyOCR…")
        _easyocr_reader = easyocr.Reader(EASYOCR_LANGUAGES, gpu=False, verbose=False)
        logger.info("EasyOCR ready.")
        return _easyocr_reader
    except Exception as e:
        logger.warning("EasyOCR unavailable: %s", e)
        return None


def _ocr_available() -> bool:
    global _ocr_available_cache
    if _ocr_available_cache is None:
        try:
            import easyocr  # noqa
            _ocr_available_cache = True
        except ImportError:
            _ocr_available_cache = False
    return _ocr_available_cache


def _images_from_page(page) -> List[bytes]:
    images_bytes = []
    try:
        for img in page.images:
            try:
                x0, y0, x1, y1 = img["x0"], img["y0"], img["x1"], img["y1"]
                if (x1 - x0) < 50 or (y1 - y0) < 50:
                    continue
                cropped   = page.crop((x0, y0, x1, y1))
                pil_image = cropped.to_image(resolution=200).original
                import io
                buf = io.BytesIO()
                pil_image.save(buf, format="PNG")
                images_bytes.append(buf.getvalue())
            except Exception as e:
                logger.debug("Image extract failed: %s", e)
    except Exception as e:
        logger.debug("Page image extraction skipped: %s", e)
    return images_bytes


def _ocr_image_bytes(img_bytes: bytes) -> str:
    reader = _get_ocr_reader()
    if reader is None:
        return ""
    try:
        import numpy as np
        from PIL import Image
        import io
        pil_img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        np_img  = np.array(pil_img)
        results = reader.readtext(np_img, detail=0, paragraph=True)
        return _clean_text(" ".join(str(r) for r in results))
    except Exception as e:
        logger.debug("OCR failed: %s", e)
        return ""


# ── Page extraction ───────────────────────────────────────────────────────────

def _extract_pages(pdf_path: Path):
    try:
        import pdfplumber
        with pdfplumber.open(str(pdf_path)) as pdf:
            for i, page in enumerate(pdf.pages, start=1):
                text      = page.extract_text() or ""
                ocr_texts = []
                if _ocr_available():
                    for img_bytes in _images_from_page(page):
                        ocr_text = _ocr_image_bytes(img_bytes)
                        if ocr_text and len(ocr_text) > 20:
                            ocr_texts.append(ocr_text)
                yield i, text, ocr_texts
    except ImportError:
        from pypdf import PdfReader
        reader = PdfReader(str(pdf_path))
        for i, page in enumerate(reader.pages, start=1):
            yield i, (page.extract_text() or ""), []


# ── Public API ────────────────────────────────────────────────────────────────

def load_and_chunk_pdf(
    pdf_path:      Path,
    chunk_size:    int = 1024,
    chunk_overlap: int = 200,
) -> List[DocumentChunk]:
    """
    PDF → extract text + OCR images → section-aware chunking → DocumentChunk list.

    Section-aware chunking keeps parent sections and their subsections together.
    e.g. Section 12 + 12.1 + 12.2 will be in the SAME chunk so the LLM sees all
    subsections when asked about the parent section.
    """
    logger.info("Processing PDF: %s", pdf_path.name)
    doc_hash    = _file_hash(pdf_path)
    all_chunks: List[DocumentChunk] = []
    text_count  = 0
    ocr_count   = 0

    # Collect full text per page first
    page_texts: List[tuple] = []
    for page_no, raw_text, ocr_texts in _extract_pages(pdf_path):
        page_texts.append((page_no, raw_text, ocr_texts))

    # Build full document text for section-aware splitting
    full_text = "\n\n".join(
        _clean_text(raw) for _, raw, _ in page_texts if raw.strip()
    )

    # Section-aware split on full document text
    doc_chunks = _split_by_sections(full_text, chunk_size, chunk_overlap)

    # Assign page numbers by finding which page each chunk came from
    for idx, chunk_text in enumerate(doc_chunks):
        if not chunk_text.strip():
            continue
        # Find best matching page (first page whose text overlaps this chunk)
        best_page = 1
        first_words = chunk_text[:80].replace("\n", " ")
        for page_no, raw, _ in page_texts:
            if first_words[:40] in raw:
                best_page = page_no
                break

        text_count += 1
        all_chunks.append(DocumentChunk(
            text=chunk_text,
            source_file=pdf_path.name,
            page_number=best_page,
            chunk_index=idx,
            doc_hash=doc_hash,
            chunk_type="text",
        ))

    # OCR image chunks (per page)
    for page_no, _, ocr_texts in page_texts:
        for img_idx, ocr_text in enumerate(ocr_texts):
            ocr_count += 1
            plain_chunks = _plain_split(ocr_text, chunk_size, chunk_overlap)
            for idx, chunk in enumerate(plain_chunks):
                all_chunks.append(DocumentChunk(
                    text=f"[Image text, Page {page_no}]: {chunk}",
                    source_file=pdf_path.name,
                    page_number=page_no,
                    chunk_index=idx,
                    doc_hash=doc_hash,
                    chunk_type="image_ocr",
                    metadata={"image_index": img_idx},
                ))

    logger.info(
        "  → %d text chunks (section-aware), %d image OCR chunks, %d total",
        text_count, ocr_count, len(all_chunks),
    )
    return all_chunks


def ocr_status() -> dict:
    available = _ocr_available()
    return {
        "available": available,
        "message": (
            "✅ EasyOCR enabled — text extracted from images inside PDFs"
            if available else
            "⚠️ EasyOCR not installed — only text extracted\n   Fix: pip install easyocr"
        ),
    }
