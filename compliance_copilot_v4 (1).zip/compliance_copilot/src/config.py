"""
config.py  –  Central configuration for the Compliance Copilot.
"""
import os
from pathlib import Path

# ── Block ALL HuggingFace network calls ──────────────────────────────────────
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"]  = "1"
os.environ["HF_HUB_OFFLINE"]       = "1"

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).resolve().parent.parent
UPLOAD_DIR      = Path(os.getenv("UPLOAD_PATH",      str(BASE_DIR / "data" / "uploads")))
VECTORSTORE_DIR = Path(os.getenv("VECTORSTORE_PATH", str(BASE_DIR / "data" / "vectorstore")))

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
VECTORSTORE_DIR.mkdir(parents=True, exist_ok=True)

# ── Phi-2 Local Path ──────────────────────────────────────────────────────────
# !! SET THIS TO YOUR LOCAL PHI-2 FOLDER !!
PHI2_MODEL_NAME = os.getenv("PHI2_MODEL_NAME", r"D:\phi-2")

# ── Chunking ──────────────────────────────────────────────────────────────────
# Larger chunk size keeps parent section + all subsections (12, 12.1, 12.2) together.
CHUNK_SIZE    = int(os.getenv("CHUNK_SIZE",    "1024"))   # was 512 — doubled
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "200"))    # was 64  — increased

# ── Retrieval ─────────────────────────────────────────────────────────────────
# More results so parent section + subsections both come back
TOP_K_RESULTS = int(os.getenv("TOP_K_RESULTS", "6"))      # was 4

# ── Generation ────────────────────────────────────────────────────────────────
MAX_NEW_TOKENS = int(os.getenv("MAX_NEW_TOKENS", "512"))   # was 256 — more room for full answers
TEMPERATURE    = float(os.getenv("TEMPERATURE",  "0.1"))

# ── EasyOCR ───────────────────────────────────────────────────────────────────
EASYOCR_LANGUAGES = ["en"]

# ── UI ────────────────────────────────────────────────────────────────────────
APP_TITLE = os.getenv("APP_TITLE", "Banking Policy & Compliance Copilot")
