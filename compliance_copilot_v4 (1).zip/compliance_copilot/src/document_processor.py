"""
document_processor.py
---------------------
FR1 – Document Upload
FR2 – Document Processing: text + EasyOCR image extraction + chunking

Based on v3 (which was working well for OCR).
ONE addition: section-aware chunking so that section 12 + 12.1 + 12.2
are always kept in the same chunk.

Section-aware strategy:
  - Split the full document on TOP-LEVEL section headers (1. 2. 3. ... 12. 13.)
  - Each top-level section includes ALL its subsections (12.1, 12.2 etc.)
  - If a section group is still larger than CHUNK_SIZE, split it with generous
    overlap so no subsection header is ever orphaned without its content.
  - Fallback to plain chunking if no section headers found.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


# ── Data model ────────────────────────────────────────────────────────────────

@dataclass
class DocumentChunk:
    text:        str
    source_file: str
    page_number: int
    chunk_index: int
    doc_hash:    str
    chunk_type:  str  = "text"
    metadata:    dict = field(default_factory=dict)


# ── Text utilities ────────────────────────────────────────────────────────────

def _file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _clean_text(raw: str) -> str:
    text = raw.replace("\x00", "")
    text = re.sub(r"[\r\n]+", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", "-").replace("\u2014", "--")
    return text.strip()


# ── Chunking ──────────────────────────────────────────────────────────────────

def _plain_split(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    """Standard sliding-window character split."""
    if len(text) <= chunk_size:
        return [text] if text.strip() else []
    chunks, start = [], 0
    while start < len(text):
        end = start + chunk_size
        if end >= len(text):
            chunk = text[start:].strip()
            if chunk:
                chunks.append(chunk)
            break
        search_start = max(start, end - chunk_size // 5)
        boundary = max(
            text.rfind(". ",  search_start, end),
            text.rfind(".\n", search_start, end),
            text.rfind("\n\n", search_start, end),
        )
        if boundary != -1:
            end = boundary + 1
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - chunk_overlap
    return chunks


def _split_by_sections(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    """
    Section-aware split.

    Finds TOP-LEVEL section headers (e.g. "12. Penalties") and groups each
    section with ALL its subsections (12.1, 12.2 ...) into one block.
    Then splits that block only if it exceeds chunk_size.

    This ensures: asking about "Section 12" returns 12 + 12.1 + 12.2.
    """
    if not text.strip():
        return []

    # Match only top-level sections: "12. Title" or "12) Title" at line start
    # NOT subsections like "12.1" — those are grouped inside the parent
    top_level_re = re.compile(r"(?m)^(\d{1,2})\s*[.)]\s+[A-Z]")
    matches = list(top_level_re.finditer(text))

    if not matches:
        # No section headers — use plain split
        return _plain_split(text, chunk_size, chunk_overlap)

    # Build groups: each group = top-level section + all its subsections
    groups = []
    for i, m in enumerate(matches):
        start = m.start()
        end   = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        group = text[start:end].strip()
        if group:
            groups.append(group)

    # Now split each group if it's too large
    final_chunks = []
    for group in groups:
        if len(group) <= chunk_size:
            final_chunks.append(group)
        else:
            # Extract the section header line to prepend to continuation chunks
            first_line = group.split("\n")[0].strip()
            sub_chunks = _plain_split(group, chunk_size, chunk_overlap)
            for j, sc in enumerate(sub_chunks):
                # Add section header to continuation chunks so context is clear
                if j > 0 and first_line and not sc.startswith(first_line[:30]):
                    sc = first_line + " (continued)\n" + sc
                if sc.strip():
                    final_chunks.append(sc)

    return final_chunks if final_chunks else _plain_split(text, chunk_size, chunk_overlap)


# ── EasyOCR setup ─────────────────────────────────────────────────────────────

_easyocr_reader      = None
_ocr_available_cache: Optional[bool] = None


def _get_ocr_reader():
    global _easyocr_reader
    if _easyocr_reader is not None:
        return _easyocr_reader
    try:
        import easyocr
        from src.config import EASYOCR_LANGUAGES
        logger.info("Initialising EasyOCR (downloads model ~100MB on first run)...")
        _easyocr_reader = easyocr.Reader(EASYOCR_LANGUAGES, gpu=False, verbose=False)
        logger.info("EasyOCR ready.")
        return _easyocr_reader
    except Exception as e:
        logger.warning("EasyOCR unavailable: %s", e)
        return None


def _ocr_available() -> bool:
    global _ocr_available_cache
    if _ocr_available_cache is None:
        try:
            import easyocr  # noqa
            _ocr_available_cache = True
        except ImportError:
            _ocr_available_cache = False
            logger.warning("easyocr not installed. Run: pip install easyocr")
    return _ocr_available_cache


# ── Image extraction from PDF pages ──────────────────────────────────────────

def _images_from_page(page) -> List[bytes]:
    """Extract raw PNG bytes from each image on a pdfplumber page."""
    result = []
    try:
        for img in page.images:
            try:
                x0, y0, x1, y1 = img["x0"], img["y0"], img["x1"], img["y1"]
                if (x1 - x0) < 50 or (y1 - y0) < 50:
                    continue   # skip tiny decorative images
                cropped   = page.crop((x0, y0, x1, y1))
                pil_image = cropped.to_image(resolution=200).original
                import io
                buf = io.BytesIO()
                pil_image.save(buf, format="PNG")
                result.append(buf.getvalue())
            except Exception as e:
                logger.debug("Could not extract image: %s", e)
    except Exception as e:
        logger.debug("Image extraction skipped: %s", e)
    return result


def _ocr_image_bytes(img_bytes: bytes) -> str:
    """Run EasyOCR on PNG bytes, return extracted text."""
    reader = _get_ocr_reader()
    if reader is None:
        return ""
    try:
        import numpy as np
        from PIL import Image
        import io
        pil_img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        np_img  = np.array(pil_img)
        results = reader.readtext(np_img, detail=0, paragraph=True)
        return _clean_text(" ".join(str(r) for r in results))
    except Exception as e:
        logger.debug("OCR failed: %s", e)
        return ""


# ── Page-level extraction ─────────────────────────────────────────────────────

def _extract_pages(pdf_path: Path):
    """
    Yield (page_number, text, [ocr_texts]) for each page.
    Uses pdfplumber for text + image extraction.
    Falls back to pypdf if pdfplumber not available (no images then).
    """
    try:
        import pdfplumber
        with pdfplumber.open(str(pdf_path)) as pdf:
            for i, page in enumerate(pdf.pages, start=1):
                text      = page.extract_text() or ""
                ocr_texts = []
                if _ocr_available():
                    for img_bytes in _images_from_page(page):
                        ocr_text = _ocr_image_bytes(img_bytes)
                        if ocr_text and len(ocr_text) > 20:
                            ocr_texts.append(ocr_text)
                yield i, text, ocr_texts
    except ImportError:
        logger.warning("pdfplumber not found — using pypdf (no image extraction)")
        from pypdf import PdfReader
        reader = PdfReader(str(pdf_path))
        for i, page in enumerate(reader.pages, start=1):
            yield i, (page.extract_text() or ""), []


# ── Public API ────────────────────────────────────────────────────────────────

def load_and_chunk_pdf(
    pdf_path:      Path,
    chunk_size:    int = 1024,
    chunk_overlap: int = 200,
) -> List[DocumentChunk]:
    """
    Full pipeline:
      PDF → extract text + OCR images → section-aware chunking → DocumentChunk list

    Text is split section-by-section so subsections (12.1, 12.2) always appear
    in the same chunk as their parent section (12).
    OCR image text is split with plain chunking per image.
    """
    logger.info("Processing PDF: %s", pdf_path.name)
    doc_hash    = _file_hash(pdf_path)
    all_chunks: List[DocumentChunk] = []
    text_count  = 0
    ocr_count   = 0

    # Collect all pages first
    page_data: List[tuple] = list(_extract_pages(pdf_path))

    # ── Text: section-aware split on full document ────────────────────────────
    # Join all page text into one document, then split by sections
    full_text = "\n\n".join(
        _clean_text(raw) for _, raw, _ in page_data if raw.strip()
    )

    doc_chunks = _split_by_sections(full_text, chunk_size, chunk_overlap)

    for idx, chunk_text in enumerate(doc_chunks):
        if not chunk_text.strip():
            continue
        # Best-effort page assignment: find first page containing chunk start
        best_page = 1
        snippet   = chunk_text[:60].replace("\n", " ")
        for page_no, raw, _ in page_data:
            if snippet[:30] in raw:
                best_page = page_no
                break
        text_count += 1
        all_chunks.append(DocumentChunk(
            text=chunk_text,
            source_file=pdf_path.name,
            page_number=best_page,
            chunk_index=idx,
            doc_hash=doc_hash,
            chunk_type="text",
        ))

    # ── OCR image text: plain split per image ────────────────────────────────
    for page_no, _, ocr_texts in page_data:
        for img_idx, ocr_text in enumerate(ocr_texts):
            ocr_count += 1
            for idx, chunk in enumerate(
                _plain_split(ocr_text, chunk_size, chunk_overlap)
            ):
                all_chunks.append(DocumentChunk(
                    text=f"[Image text, Page {page_no}]: {chunk}",
                    source_file=pdf_path.name,
                    page_number=page_no,
                    chunk_index=idx,
                    doc_hash=doc_hash,
                    chunk_type="image_ocr",
                    metadata={"image_index": img_idx},
                ))

    logger.info(
        "  → %d text chunks (section-aware), %d image OCR chunks, %d total",
        text_count, ocr_count, len(all_chunks),
    )
    return all_chunks


def ocr_status() -> dict:
    available = _ocr_available()
    return {
        "available": available,
        "message": (
            "✅ EasyOCR enabled — text extracted from images inside PDFs"
            if available else
            "⚠️ EasyOCR not installed — only text extracted\n   Fix: pip install easyocr"
        ),
    }
