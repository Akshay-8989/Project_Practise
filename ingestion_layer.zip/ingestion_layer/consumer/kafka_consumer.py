"""
Kafka Consumer — Validation & Routing
======================================
Consumes from 'raw_documents', validates each record, then routes:

  ┌─────────────────┐   valid + SINGLE   ┌──────────────────────┐
  │  raw_documents  │ ─────────────────► │  validated_documents │
  │  (Kafka topic)  │                    └──────────────────────┘
  │                 │   valid + MULTI    ┌──────────────────────┐
  │                 │ ─────────────────► │  multi_struct_segs   │
  │                 │   (N segment msgs) └──────────────────────┘
  │                 │   invalid          ┌──────────────────────┐
  │                 │ ─────────────────► │  dead_letter_queue   │
  └─────────────────┘                    └──────────────────────┘

For MULTI documents:
  - The parent ValidatedDocument is sent to validated_documents
    (with structure_type=MULTI, segments populated)
  - Each individual segment is ALSO sent to multi_struct_segments
    as its own mini-document so downstream classifiers can process
    them independently. The final label for the parent = max severity.

Kafka commitments:
  - Manual offset commit after successful downstream produce
  - Failed records go to DLQ — offset still committed to avoid blocking
"""

from __future__ import annotations

import json
import logging
import signal
import sys
from pathlib import Path
from typing import Any

from kafka import KafkaConsumer, KafkaProducer
from kafka.errors import KafkaError

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import CONFIG
from schemas.document_schema import (
    DeadLetterRecord,
    DocumentSegment,
    StructureType,
    ValidatedDocument,
)
from consumer.validator import DocumentValidator

logging.basicConfig(
    level=getattr(logging, CONFIG.log_level),
    format="%(asctime)s [CONSUMER] %(levelname)s %(message)s",
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Serialisers / deserialisers
# ─────────────────────────────────────────────

def _ser(obj: Any) -> bytes:
    return json.dumps(obj, default=str).encode("utf-8")

def _deser(data: bytes) -> dict:
    return json.loads(data.decode("utf-8")) if data else {}


# ─────────────────────────────────────────────
# Consumer class
# ─────────────────────────────────────────────

class ValidationConsumer:
    """
    Listens on raw_documents, validates, and routes to downstream topics.
    """

    def __init__(self):
        self._running = True
        self._validator = DocumentValidator()

        self._consumer = KafkaConsumer(
            CONFIG.kafka.raw_docs_topic,
            bootstrap_servers      = CONFIG.kafka.bootstrap_servers,
            group_id               = CONFIG.kafka.consumer_group_id,
            auto_offset_reset      = CONFIG.kafka.auto_offset_reset,
            enable_auto_commit     = CONFIG.kafka.enable_auto_commit,
            value_deserializer     = _deser,
            key_deserializer       = lambda k: k.decode("utf-8") if k else None,
            max_poll_records       = CONFIG.kafka.max_poll_records,
            session_timeout_ms     = CONFIG.kafka.session_timeout_ms,
        )

        self._producer = KafkaProducer(
            bootstrap_servers = CONFIG.kafka.bootstrap_servers,
            value_serializer  = _ser,
            key_serializer    = lambda k: k.encode("utf-8") if k else None,
            acks              = "all",
            retries           = 3,
            enable_idempotence= True,
            compression_type  = "gzip",
        )

        # Stats
        self._stats = {"received": 0, "valid": 0, "invalid": 0,
                       "single": 0, "multi": 0, "segments_emitted": 0}

        signal.signal(signal.SIGINT,  self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

    # ── main loop ───────────────────────────────────────────────────────────

    def run(self):
        log.info(
            "Consumer started — topic=%s  group=%s",
            CONFIG.kafka.raw_docs_topic,
            CONFIG.kafka.consumer_group_id,
        )
        try:
            for msg in self._consumer:
                if not self._running:
                    break
                self._handle_message(msg)

        finally:
            self._consumer.close()
            self._producer.flush(timeout=30)
            self._producer.close()
            self._log_stats()
            log.info("Consumer shut down cleanly.")

    # ── message handler ──────────────────────────────────────────────────────

    def _handle_message(self, msg):
        self._stats["received"] += 1
        raw_payload: dict = msg.value

        result = self._validator.validate(raw_payload)

        if not result.success:
            # ── Route to Dead Letter Queue ────────────────────────────────
            self._stats["invalid"] += 1
            log.warning(
                "Validation FAILED doc_id=%s type=%s detail=%s",
                raw_payload.get("doc_id"), result.error_type, result.error_detail,
            )
            self._publish(
                CONFIG.kafka.dlq_topic,
                key=raw_payload.get("doc_id", "unknown"),
                payload=result.dead_letter.model_dump(),
            )
        else:
            vdoc: ValidatedDocument = result.validated_doc
            self._stats["valid"] += 1

            # ── Route parent doc to validated_documents ───────────────────
            self._publish(
                CONFIG.kafka.validated_docs_topic,
                key=vdoc.doc_id,
                payload=vdoc.model_dump(),
            )
            log.debug(
                "Validated doc_id=%s structure=%s segments=%d pii=%s policy=%s",
                vdoc.doc_id, vdoc.structure_type.value,
                vdoc.segment_count, vdoc.pii_flags, vdoc.policy_action_hint,
            )

            if vdoc.structure_type == StructureType.SINGLE:
                self._stats["single"] += 1

            elif vdoc.structure_type == StructureType.MULTI:
                # ── Emit each segment to multi_struct_segments ────────────
                self._stats["multi"] += 1
                for seg in vdoc.segments:
                    self._emit_segment(vdoc, seg)
                    self._stats["segments_emitted"] += 1
                log.info(
                    "MULTI doc %s → %d segments emitted (signals=%s)",
                    vdoc.doc_id, vdoc.segment_count, vdoc.structure_signals,
                )

        # Manual commit after processing
        self._consumer.commit()

        # Periodic stats log
        if self._stats["received"] % 1000 == 0:
            self._log_stats()

    # ── segment emitter ──────────────────────────────────────────────────────

    def _emit_segment(self, parent: ValidatedDocument, seg: DocumentSegment):
        """
        Publish one segment from a MULTI document as its own classify-able unit.
        Carries the parent doc_id so results can be re-aggregated.
        """
        segment_payload = {
            "parent_doc_id":  parent.doc_id,
            "parent_ingest_id": parent.ingest_id,
            "segment_id":     seg.segment_id,
            "segment_index":  seg.segment_index,
            "segment_type":   seg.detected_type,
            "text":           seg.text,
            "source":         parent.source.value,
            "department":     parent.department,
            "file_type":      parent.file_type.value,
            "created_at":     parent.created_at,
            "char_start":     seg.char_start,
            "char_end":       seg.char_end,
            # Inherit parent label if training mode; will be re-labelled by model
            "parent_label":   parent.label.value if parent.label else None,
            "pii_flags":      parent.pii_flags,
            "policy_action_hint": parent.policy_action_hint,
        }
        self._publish(
            CONFIG.kafka.multi_struct_topic,
            key=f"{parent.doc_id}__seg{seg.segment_index}",
            payload=segment_payload,
        )

    # ── helpers ─────────────────────────────────────────────────────────────

    def _publish(self, topic: str, key: str, payload: dict):
        try:
            self._producer.send(topic, key=key, value=payload)
        except KafkaError as exc:
            log.error("Failed to publish to %s: %s", topic, exc)

    def _log_stats(self):
        s = self._stats
        log.info(
            "Stats | received=%d  valid=%d  invalid=%d  "
            "single=%d  multi=%d  segments_emitted=%d",
            s["received"], s["valid"], s["invalid"],
            s["single"], s["multi"], s["segments_emitted"],
        )

    def _shutdown(self, *_):
        log.info("Shutdown signal received.")
        self._running = False


# ─────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────

if __name__ == "__main__":
    ValidationConsumer().run()
