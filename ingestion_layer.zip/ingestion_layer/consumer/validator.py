"""
Document Validator
==================
Validates raw Kafka messages against the expected schema and business rules.

Validation layers:
  1. Schema validation  — Pydantic model parsing (type checking, required fields)
  2. Value validation   — allowed enums, length bounds, date formats
  3. Business rules     — label-source plausibility, PII flag consistency

Returns a ValidationResult with either a ValidatedDocument or error details.
"""

from __future__ import annotations

import json
import logging
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import CONFIG
from schemas.document_schema import (
    DeadLetterRecord,
    DocumentSource,
    FileType,
    RawDocument,
    SensitivityLabel,
    ValidatedDocument,
)
from utils.pii_detector import derive_policy_hint, detect_pii
from utils.structure_detector import StructureDetector

log = logging.getLogger(__name__)
_detector = StructureDetector()

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


@dataclass
class ValidationResult:
    success: bool
    validated_doc: Optional[ValidatedDocument] = None
    dead_letter:   Optional[DeadLetterRecord]  = None
    error_type:    Optional[str] = None
    error_detail:  Optional[str] = None


# ─────────────────────────────────────────────
# Validator
# ─────────────────────────────────────────────

class DocumentValidator:

    def validate(self, raw_payload: dict) -> ValidationResult:
        """
        Full validation pipeline for one raw document payload.

        Steps:
          1. Parse into RawDocument (schema + type check)
          2. Value-level validation (enums, lengths, date)
          3. Structure analysis (single vs multi)
          4. PII detection
          5. Build ValidatedDocument
        """
        # ── Step 1: Schema parse ─────────────────────────────────────────
        try:
            raw = RawDocument(**raw_payload)
        except Exception as exc:
            return self._fail(raw_payload, "SCHEMA_ERROR", str(exc))

        # ── Step 2: Value validation ─────────────────────────────────────
        err = self._validate_values(raw)
        if err:
            return self._fail(raw_payload, "VALUE_ERROR", err)

        # ── Step 3: Structure analysis ───────────────────────────────────
        analysis = _detector.analyse(
            text=raw.text,
            source=raw.source,
            file_type=raw.file_type,
        )

        # ── Step 4: PII detection ────────────────────────────────────────
        pii_flags = detect_pii(raw.text)

        # ── Step 5: Build ValidatedDocument ─────────────────────────────
        try:
            validated = ValidatedDocument(
                doc_id           = raw.doc_id,
                ingest_id        = raw.ingest_id,
                text             = raw.text,
                source           = DocumentSource(raw.source),
                department       = raw.department,
                file_type        = FileType(raw.file_type),
                created_at       = raw.created_at,
                label            = SensitivityLabel(raw.label) if raw.label else None,
                ingested_at      = raw.ingested_at,
                structure_type   = analysis.structure_type,
                segment_count    = analysis.segment_count,
                segments         = analysis.segments,
                structure_signals= analysis.signals,
                pii_flags        = pii_flags,
                policy_action_hint = derive_policy_hint(pii_flags, raw.label),
            )
        except Exception as exc:
            return self._fail(raw_payload, "BUILD_ERROR", str(exc))

        return ValidationResult(success=True, validated_doc=validated)

    # ── value checks ────────────────────────────────────────────────────────

    def _validate_values(self, raw: RawDocument) -> Optional[str]:
        """Returns error string or None if clean."""

        # Text length
        if len(raw.text) < CONFIG.min_text_length:
            return f"text too short ({len(raw.text)} chars)"
        if len(raw.text) > CONFIG.max_text_length:
            return f"text too long ({len(raw.text)} chars)"

        # Enums
        if raw.source not in CONFIG.allowed_sources:
            return f"unknown source '{raw.source}'"
        if raw.file_type not in CONFIG.allowed_file_types:
            return f"unknown file_type '{raw.file_type}'"
        if raw.department not in CONFIG.allowed_departments:
            return f"unknown department '{raw.department}'"
        if raw.label and raw.label not in CONFIG.allowed_labels:
            return f"unknown label '{raw.label}'"

        # Date format
        if raw.created_at and not DATE_RE.match(raw.created_at):
            return f"invalid created_at format '{raw.created_at}'"

        # Non-empty doc_id
        if not raw.doc_id or not raw.doc_id.strip():
            return "doc_id is empty"

        return None

    # ── helpers ─────────────────────────────────────────────────────────────

    @staticmethod
    def _fail(payload: dict, error_type: str, detail: str) -> ValidationResult:
        dlr = DeadLetterRecord(
            original_payload=payload,
            error_type=error_type,
            error_detail=detail,
        )
        return ValidationResult(
            success=False,
            dead_letter=dlr,
            error_type=error_type,
            error_detail=detail,
        )
