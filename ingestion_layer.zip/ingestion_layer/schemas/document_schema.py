"""
Schema definitions for document records flowing through the pipeline.

StructureType Enum:
  - SINGLE: One coherent document (financial report, contract, HR record, etc.)
  - MULTI:  Composite doc containing multiple logical sub-documents
            (email thread, bulk export, meeting notes with attachments, etc.)
            Each sub-doc needs its own classification.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# ─────────────────────────────────────────────
# Enums
# ─────────────────────────────────────────────

class SensitivityLabel(str, Enum):
    PUBLIC       = "Public"
    INTERNAL     = "Internal"
    CONFIDENTIAL = "Confidential"
    RESTRICTED   = "Restricted"


class StructureType(str, Enum):
    """
    SINGLE: treat document as one unit → 1 classification.
    MULTI:  document contains N logical segments → N classifications,
            final label = max(segment_labels) by severity order.
    """
    SINGLE = "single"
    MULTI  = "multi"


class DocumentSource(str, Enum):
    EMAIL  = "email"
    SLACK  = "slack"
    CRM    = "crm"
    UPLOAD = "upload"
    API    = "api"
    DRIVE  = "drive"


class FileType(str, Enum):
    PDF   = "pdf"
    DOCX  = "docx"
    TXT   = "txt"
    XLSX  = "xlsx"
    EMAIL = "email"


# ─────────────────────────────────────────────
# Sub-document segment (used for MULTI docs)
# ─────────────────────────────────────────────

class DocumentSegment(BaseModel):
    """One logical segment extracted from a MULTI-structure document."""
    segment_id:    str = Field(default_factory=lambda: str(uuid.uuid4()))
    segment_index: int                         # 0-based position in parent
    text:          str
    detected_type: Optional[str] = None        # e.g. "email_body", "attachment"
    char_start:    Optional[int] = None
    char_end:      Optional[int] = None


# ─────────────────────────────────────────────
# Raw document (produced → Kafka raw topic)
# ─────────────────────────────────────────────

class RawDocument(BaseModel):
    """Exactly mirrors the CSV schema + ingestion metadata."""
    
    # From dataset
    doc_id:     str
    text:       str
    source:     str
    department: str
    file_type:  str
    created_at: str                            # ISO date string from CSV
    label:      Optional[str] = None           # ground-truth label (training only)
    
    # Added by producer
    ingest_id:        str = Field(default_factory=lambda: str(uuid.uuid4()))
    ingested_at:      str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    producer_version: str = "1.0.0"


# ─────────────────────────────────────────────
# Validated document (consumer → validated topic)
# ─────────────────────────────────────────────

class ValidatedDocument(BaseModel):
    """Post-validation enriched record, ready for the ML pipeline."""
    
    # Pass-through fields
    doc_id:     str
    ingest_id:  str
    text:       str
    source:     DocumentSource
    department: str
    file_type:  FileType
    created_at: str
    label:      Optional[SensitivityLabel] = None
    ingested_at: str
    
    # Structure analysis results
    structure_type:     StructureType
    segment_count:      int = 1               # 1 for SINGLE, N for MULTI
    segments:           List[DocumentSegment] = Field(default_factory=list)
    structure_signals:  List[str] = Field(default_factory=list)  # why MULTI was detected
    
    # Validation metadata
    validated_at:       str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    validation_version: str = "1.0.0"
    char_count:         int = 0
    pii_flags:          List[str] = Field(default_factory=list)  # PII pattern hits
    
    # Policy hint for downstream
    policy_action_hint: Optional[str] = None  # Allow / Encrypt / Restrict / Quarantine
    
    @model_validator(mode="after")
    def set_char_count(self) -> ValidatedDocument:
        self.char_count = len(self.text)
        return self


# ─────────────────────────────────────────────
# Dead-letter record
# ─────────────────────────────────────────────

class DeadLetterRecord(BaseModel):
    """Records that failed validation."""
    original_payload: dict
    error_type:       str
    error_detail:     str
    failed_at:        str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    source_topic:     str = "raw_documents"
