"""
Kafka Producer
==============
Reads the synthetic dataset CSV and publishes RawDocument records
to the 'raw_documents' Kafka topic at a configurable interval.

Features:
  - Configurable send interval (simulates real-time ingestion)
  - Batch mode for fast bulk ingestion
  - Idempotent production (acks=all)
  - Graceful shutdown on SIGINT / SIGTERM
  - Per-record metadata enrichment before send
  - Progress logging every N records
"""

from __future__ import annotations

import csv
import json
import logging
import signal
import sys
import time
from pathlib import Path
from typing import Iterator

from kafka import KafkaProducer
from kafka.errors import KafkaError

# ── path setup so sibling packages resolve ─────────────────────────────────
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import CONFIG
from schemas.document_schema import RawDocument

logging.basicConfig(
    level=getattr(logging, CONFIG.log_level),
    format="%(asctime)s [PRODUCER] %(levelname)s %(message)s",
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Serialiser
# ─────────────────────────────────────────────

def _serialise(record: dict) -> bytes:
    return json.dumps(record, default=str).encode("utf-8")


# ─────────────────────────────────────────────
# CSV loader
# ─────────────────────────────────────────────

def load_dataset(path: str) -> Iterator[RawDocument]:
    """
    Yields RawDocument objects from the CSV one at a time.
    Skips malformed rows with a warning rather than crashing.
    """
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                yield RawDocument(
                    doc_id     = row["doc_id"],
                    text       = row["text"],
                    source     = row["source"],
                    department = row["department"],
                    file_type  = row["file_type"],
                    created_at = row["created_at"],
                    label      = row.get("label"),          # None for inference docs
                )
            except Exception as exc:
                log.warning("Skipping malformed row %s: %s", row.get("doc_id"), exc)


# ─────────────────────────────────────────────
# Producer class
# ─────────────────────────────────────────────

class DocumentProducer:
    """
    Publishes RawDocument records to Kafka.

    Usage:
        producer = DocumentProducer()
        producer.run()          # streams with interval
        producer.run_batch()    # no sleep — as fast as possible
    """

    def __init__(self):
        self._running = True
        self._producer = KafkaProducer(
            bootstrap_servers=CONFIG.kafka.bootstrap_servers,
            value_serializer=_serialise,
            key_serializer=lambda k: k.encode("utf-8") if k else None,
            acks=CONFIG.kafka.acks,
            retries=CONFIG.kafka.retries,
            enable_idempotence=True,
            compression_type="gzip",
        )
        signal.signal(signal.SIGINT,  self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

    # ── callbacks ───────────────────────────────────────────────────────────

    @staticmethod
    def _on_send_success(metadata):
        log.debug(
            "Sent → topic=%s partition=%s offset=%s",
            metadata.topic, metadata.partition, metadata.offset,
        )

    @staticmethod
    def _on_send_error(exc: KafkaError):
        log.error("Send error: %s", exc)

    # ── main loop ───────────────────────────────────────────────────────────

    def run(self, dataset_path: str | None = None, loop: bool = False):
        """
        Stream records from the CSV to Kafka, sleeping between each send
        to simulate a real-time ingestion pipeline.

        Args:
            dataset_path: Override default CSV path from config.
            loop:         If True, re-read the CSV indefinitely (useful for
                          sustained load testing).
        """
        path = dataset_path or CONFIG.dataset_path
        log.info("Producer starting — dataset=%s  topic=%s  interval=%.2fs",
                 path, CONFIG.kafka.raw_docs_topic, CONFIG.kafka.producer_interval_seconds)

        iteration = 0
        while self._running:
            iteration += 1
            sent = 0
            log.info("=== Iteration %d — reading %s ===", iteration, path)

            for doc in load_dataset(path):
                if not self._running:
                    break
                self._send(doc)
                sent += 1
                if sent % 500 == 0:
                    log.info("  … %d records sent", sent)
                time.sleep(CONFIG.kafka.producer_interval_seconds)

            log.info("Iteration %d complete — %d records sent", iteration, sent)
            if not loop:
                break

        self._flush_and_close()

    def run_batch(self, dataset_path: str | None = None):
        """
        Send all records as fast as possible (no sleep).
        Useful for initial dataset load / smoke testing.
        """
        path = dataset_path or CONFIG.dataset_path
        log.info("Batch producer starting — dataset=%s  topic=%s",
                 path, CONFIG.kafka.raw_docs_topic)

        sent = 0
        for doc in load_dataset(path):
            if not self._running:
                break
            self._send(doc)
            sent += 1
            if sent % 1000 == 0:
                self._producer.flush()
                log.info("  … %d records sent", sent)

        self._flush_and_close()
        log.info("Batch complete — total %d records", sent)

    # ── helpers ─────────────────────────────────────────────────────────────

    def _send(self, doc: RawDocument):
        """Send one RawDocument. Uses doc_id as the partition key."""
        payload = doc.model_dump()
        (
            self._producer
            .send(
                CONFIG.kafka.raw_docs_topic,
                key=doc.doc_id,
                value=payload,
            )
            .add_callback(self._on_send_success)
            .add_errback(self._on_send_error)
        )

    def _flush_and_close(self):
        log.info("Flushing remaining messages …")
        self._producer.flush(timeout=30)
        self._producer.close()
        log.info("Producer closed.")

    def _shutdown(self, *_):
        log.info("Shutdown signal received — stopping after current record.")
        self._running = False


# ─────────────────────────────────────────────
# CLI entry point
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Document Kafka Producer")
    parser.add_argument("--dataset", default=CONFIG.dataset_path,
                        help="Path to the CSV dataset file")
    parser.add_argument("--batch", action="store_true",
                        help="Send all records without sleep (bulk mode)")
    parser.add_argument("--loop", action="store_true",
                        help="Re-stream the dataset in a loop indefinitely")
    parser.add_argument("--interval", type=float,
                        default=CONFIG.kafka.producer_interval_seconds,
                        help="Seconds between each send in stream mode")
    args = parser.parse_args()

    CONFIG.kafka.producer_interval_seconds = args.interval

    p = DocumentProducer()
    if args.batch:
        p.run_batch(dataset_path=args.dataset)
    else:
        p.run(dataset_path=args.dataset, loop=args.loop)
