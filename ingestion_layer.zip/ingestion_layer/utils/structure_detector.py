"""
Structure Detector
==================
Determines whether an incoming document is:
  - SINGLE: one coherent logical document requiring ONE classification
  - MULTI:  composite document containing multiple logical sub-documents,
            each requiring its OWN classification

Multi-document examples:
  • Email thread dump (multiple From:/Subject: headers)
  • CRM export with multiple customer records
  • Bulk Slack export
  • Contract packet (cover letter + exhibits + schedules)
  • HR file with multiple employee records

Why this matters (from the PS):
  The ingestion layer must not collapse a multi-document into a single
  classification — a Public cover email attached to a Restricted contract
  would be incorrectly labelled if treated as one unit.
  The final label for a MULTI doc is: max(segment_labels) by severity.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Tuple

from schemas.document_schema import DocumentSegment, StructureType


# ─────────────────────────────────────────────
# Segment boundary patterns
# ─────────────────────────────────────────────

# Email header block: "From: ... Subject: ..."
EMAIL_HEADER_RE = re.compile(
    r"(?:^|\n)(?:From|Date|To|Subject)\s*:.*(?:\n(?:From|Date|To|Subject|Cc|Bcc)\s*:.*)*",
    re.IGNORECASE,
)

# Forwarded / reply separators
FWD_RE = re.compile(
    r"(?:^|\n)-{3,}.*(?:Forwarded|Original Message|Begin forwarded).*-{3,}",
    re.IGNORECASE,
)

# Section headers that suggest packed records
RECORD_SEP_RE = re.compile(
    r"(?:^|\n)(?:={5,}|-{5,}|_{5,}|\*{5,})",
)

# Multiple "Employee:", "Client:", "Customer:" blocks
ENTITY_BLOCK_RE = re.compile(
    r"(?:^|\n)(?:Employee|Client|Customer|Record|Entry|Case)\s*(?:ID|No|#|:)\s*\S+",
    re.IGNORECASE,
)

# Multiple date-stamped log entries
LOG_ENTRY_RE = re.compile(
    r"(?:^|\n)\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}",
)

# Explicit page-break markers
PAGE_BREAK_RE = re.compile(r"(?:^|\n)\f|--- ?[Pp]age \d+ ?---")


@dataclass
class StructureAnalysis:
    structure_type:    StructureType
    segment_count:     int
    segments:          List[DocumentSegment] = field(default_factory=list)
    signals:           List[str] = field(default_factory=list)   # human-readable why


class StructureDetector:
    """
    Lightweight rule-based detector. Fast enough for the ingestion layer
    (no model calls here). The ML classifier downstream gets per-segment text.
    """

    # Minimum chars for a segment to be worth classifying independently
    MIN_SEGMENT_LENGTH = 80

    def analyse(self, text: str, source: str, file_type: str) -> StructureAnalysis:
        """
        Returns a StructureAnalysis with type, segments, and why-signals.
        """
        signals: List[str] = []
        split_points: List[int] = []  # char positions where new segments start

        # ── 1. Email thread detection ─────────────────────────────────────
        email_headers = list(EMAIL_HEADER_RE.finditer(text))
        if len(email_headers) >= 2:
            signals.append(f"email_headers_detected:{len(email_headers)}")
            for m in email_headers[1:]:          # first one = current message
                split_points.append(m.start())

        fwd_matches = list(FWD_RE.finditer(text))
        if fwd_matches:
            signals.append(f"forwarded_message_separators:{len(fwd_matches)}")
            for m in fwd_matches:
                split_points.append(m.start())

        # ── 2. Explicit separator lines ───────────────────────────────────
        sep_matches = list(RECORD_SEP_RE.finditer(text))
        if len(sep_matches) >= 2:
            signals.append(f"record_separators:{len(sep_matches)}")
            for m in sep_matches:
                split_points.append(m.start())

        # ── 3. Repeated entity blocks ─────────────────────────────────────
        entity_matches = list(ENTITY_BLOCK_RE.finditer(text))
        if len(entity_matches) >= 2:
            signals.append(f"entity_blocks:{len(entity_matches)}")
            for m in entity_matches:
                split_points.append(m.start())

        # ── 4. Dense log entries (> 5 timestamped lines) ──────────────────
        log_matches = list(LOG_ENTRY_RE.finditer(text))
        if len(log_matches) > 5:
            signals.append(f"log_entries:{len(log_matches)}")
            # treat every 5th entry as a new segment boundary
            for m in log_matches[5::5]:
                split_points.append(m.start())

        # ── 5. Page-break markers ─────────────────────────────────────────
        pb_matches = list(PAGE_BREAK_RE.finditer(text))
        if len(pb_matches) >= 2:
            signals.append(f"page_breaks:{len(pb_matches)}")
            for m in pb_matches:
                split_points.append(m.start())

        # ── 6. Source-hint: bulk Slack / CRM exports ──────────────────────
        if source in ("slack", "crm") and len(text) > 2000:
            # Heuristic: long Slack/CRM payloads are typically multi-record
            signals.append("source_hint_bulk_export")
            # Split every ~500 chars at a newline boundary
            for pos in range(500, len(text), 500):
                nl = text.find("\n", pos)
                if nl != -1:
                    split_points.append(nl)

        # ── Decide structure type ─────────────────────────────────────────
        if not signals:
            return StructureAnalysis(
                structure_type=StructureType.SINGLE,
                segment_count=1,
                segments=[DocumentSegment(
                    segment_index=0,
                    text=text,
                    detected_type="full_document",
                    char_start=0,
                    char_end=len(text),
                )],
                signals=[],
            )

        # Build segments from unique sorted split points
        segments = self._build_segments(text, split_points)
        if len(segments) < 2:
            return StructureAnalysis(
                structure_type=StructureType.SINGLE,
                segment_count=1,
                segments=[DocumentSegment(
                    segment_index=0,
                    text=text,
                    detected_type="full_document",
                    char_start=0,
                    char_end=len(text),
                )],
                signals=signals,
            )

        return StructureAnalysis(
            structure_type=StructureType.MULTI,
            segment_count=len(segments),
            segments=segments,
            signals=signals,
        )

    # ─────────────────────────────────────────
    def _build_segments(
        self, text: str, split_points: List[int]
    ) -> List[DocumentSegment]:
        """
        Given raw split positions, build non-overlapping DocumentSegments,
        filtering out tiny fragments below MIN_SEGMENT_LENGTH.
        """
        boundaries = sorted(set([0] + split_points + [len(text)]))
        segments: List[DocumentSegment] = []
        idx = 0

        for i in range(len(boundaries) - 1):
            start = boundaries[i]
            end   = boundaries[i + 1]
            chunk = text[start:end].strip()
            if len(chunk) < self.MIN_SEGMENT_LENGTH:
                continue
            segments.append(DocumentSegment(
                segment_index=idx,
                text=chunk,
                detected_type=self._infer_segment_type(chunk),
                char_start=start,
                char_end=end,
            ))
            idx += 1

        return segments

    def _infer_segment_type(self, chunk: str) -> str:
        """Best-effort label for a segment (informational only)."""
        lower = chunk.lower()
        if re.search(r"^from\s*:", lower, re.MULTILINE):
            return "email_message"
        if re.search(r"employee|emp_id|staff", lower):
            return "employee_record"
        if re.search(r"client|customer|account_no", lower):
            return "customer_record"
        if re.search(r"\d{4}-\d{2}-\d{2}[t ]\d{2}:\d{2}", lower):
            return "log_entry_block"
        if re.search(r"exhibit|schedule|annex|appendix", lower):
            return "contract_exhibit"
        return "general_segment"
