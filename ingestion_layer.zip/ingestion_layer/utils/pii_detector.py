"""
PII Pattern Detector
====================
Detects known PII patterns from the Problem Statement:
  SSN, PAN (card number), IBAN, DOB, email, phone

Used at ingestion time to:
  1. Flag records for masking (Constraint C1: no raw PII stored post-classification)
  2. Provide a policy_action_hint for downstream
  3. Act as a soft override signal toward Restricted/Confidential
"""

from __future__ import annotations

import re
from typing import List


# ─────────────────────────────────────────────
# Compiled PII Patterns
# ─────────────────────────────────────────────

PII_PATTERNS = {
    "SSN": re.compile(
        r"\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b"
    ),
    "PAN": re.compile(
        r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}"
        r"|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12})\b"
    ),
    "IBAN": re.compile(
        r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}(?:[A-Z0-9]?){0,16}\b"
    ),
    "DOB": re.compile(
        r"\b(?:0[1-9]|[12]\d|3[01])[-/.](?:0[1-9]|1[0-2])[-/.](?:19|20)\d{2}\b"
        r"|\b(?:19|20)\d{2}[-/.](?:0[1-9]|1[0-2])[-/.](?:0[1-9]|[12]\d|3[01])\b"
    ),
    "EMAIL": re.compile(
        r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
    ),
    "PHONE": re.compile(
        r"\b(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}\b"
    ),
    "PASSPORT": re.compile(
        r"\b[A-Z]{1,2}\d{6,9}\b"
    ),
    "IP_ADDRESS": re.compile(
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
    ),
}

# Severity mapping: which PII types force policy escalation
RESTRICTED_PII = {"SSN", "PAN", "IBAN", "PASSPORT"}
CONFIDENTIAL_PII = {"DOB", "PHONE", "EMAIL"}


def detect_pii(text: str) -> List[str]:
    """
    Returns list of detected PII type names found in the text.
    Example: ["SSN", "EMAIL"]
    """
    found = []
    for pii_type, pattern in PII_PATTERNS.items():
        if pattern.search(text):
            found.append(pii_type)
    return found


def derive_policy_hint(pii_flags: List[str], label: str | None) -> str:
    """
    Derive a recommended policy action based on PII flags and label.
    This is a rule-overlay hint consistent with the Policy Engine in section 3.

    Priority:
      RESTRICTED PII present → Quarantine
      CONFIDENTIAL PII + label Confidential/Restricted → Restrict
      Any PII + label Internal → Encrypt
      No PII + Public → Allow
    """
    if any(p in RESTRICTED_PII for p in pii_flags):
        return "Quarantine"
    if any(p in CONFIDENTIAL_PII for p in pii_flags):
        if label in ("Confidential", "Restricted"):
            return "Restrict"
        return "Encrypt"
    if label in ("Confidential", "Restricted"):
        return "Encrypt"
    return "Allow"
