# Ingestion Layer — Data Sensitivity Classification System

## Overview

This is the **Ingestion Layer** of the document sensitivity classification pipeline described in the Problem Statement. It handles:

1. **Kafka Producer** — streams the synthetic training dataset (CSV) to Kafka at configurable intervals
2. **Schema Validation** — validates every record against the expected schema + business rules
3. **Structure Detection** — classifies each document as `SINGLE` or `MULTI` structured
4. **PII Detection** — flags SSN, PAN, IBAN, DOB, email, phone patterns
5. **Routing** — sends valid records to the ML pipeline, invalid records to DLQ

---

## Topic Architecture

```
CSV Dataset
    │
    ▼
[Producer] ──────────────────────────────► raw_documents (topic)
                                                │
                                    [Consumer + Validator]
                                           │         │
                          ┌────────────────┘         └────────────────┐
                          │                                            │
                    (valid records)                             (invalid records)
                          │                                            │
               ┌──────────┴──────────┐                         dead_letter_queue
               │                     │
           SINGLE docs           MULTI docs
               │                     │
               ▼                     ├──► validated_documents  (full parent doc)
    validated_documents              │
                                     └──► multi_struct_segments (one msg per segment)
```

### Why SINGLE vs MULTI matters

- **SINGLE**: One coherent document → one classification call → one label
- **MULTI**: A composite document (e.g., email thread, bulk CRM export, contract packet) contains N logical sub-documents. Each sub-document gets its **own** classification. The final label for the parent document = **max severity** among all segment labels.

| Sensitivity Level | Severity |
|---|---|
| Public | 1 (lowest) |
| Internal | 2 |
| Confidential | 3 |
| Restricted | 4 (highest) |

---

## Project Structure

```
ingestion_layer/
├── config/
│   └── settings.py          # All config: Kafka topics, thresholds, allowed values
├── schemas/
│   └── document_schema.py   # Pydantic models: RawDocument, ValidatedDocument,
│                            #   DocumentSegment, DeadLetterRecord
├── utils/
│   ├── structure_detector.py  # SINGLE vs MULTI detection (rule-based)
│   └── pii_detector.py        # SSN / PAN / IBAN / DOB / email / phone regex
├── producer/
│   └── kafka_producer.py    # CSV → Kafka producer
├── consumer/
│   ├── kafka_consumer.py    # Kafka consumer + validation + routing
│   └── validator.py         # DocumentValidator class
└── docker/
    └── docker-compose.yml   # Kafka + Zookeeper + Kafka-UI
```

---

## Quick Start

### 1. Start Kafka

```bash
cd docker
docker-compose up -d
```

Kafka UI will be available at http://localhost:8080

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Copy your dataset

```bash
mkdir -p data
cp /path/to/final_synthetic_dataset_20000.csv data/
```

### 4. Start the Consumer (in one terminal)

```bash
python consumer/kafka_consumer.py
```

### 5. Start the Producer (in another terminal)

```bash
# Stream mode (0.5s interval between records)
python producer/kafka_producer.py --dataset data/final_synthetic_dataset_20000.csv

# Batch mode (no sleep — as fast as possible)
python producer/kafka_producer.py --batch

# Loop mode (re-stream indefinitely for load testing)
python producer/kafka_producer.py --loop --interval 0.1
```

---

## Configuration

All settings are in `config/settings.py`:

| Setting | Default | Description |
|---|---|---|
| `bootstrap_servers` | `localhost:9092` | Kafka broker address |
| `producer_interval_seconds` | `0.5` | Sleep between sends (stream mode) |
| `raw_docs_topic` | `raw_documents` | Input topic |
| `validated_docs_topic` | `validated_documents` | Valid records output |
| `multi_struct_topic` | `multi_structure_segments` | Segments from MULTI docs |
| `dlq_topic` | `dead_letter_queue` | Failed validation records |
| `max_text_length` | `50000` | Max chars per document |
| `min_text_length` | `5` | Min chars per document |

---

## Validation Rules

| Rule | Detail |
|---|---|
| Schema | All required fields present and correctly typed |
| `source` | Must be one of: email, slack, crm, upload, api, drive |
| `file_type` | Must be one of: pdf, docx, txt, xlsx, email |
| `department` | Must be one of: Sales, HR, IT, Legal, Support, Finance |
| `label` | Must be one of: Public, Internal, Confidential, Restricted (or absent) |
| `created_at` | Must match YYYY-MM-DD format |
| Text length | 5–50,000 characters |
| `doc_id` | Non-empty string |

---

## Structure Detection (Single vs Multi)

The `StructureDetector` uses regex heuristics to identify MULTI documents:

| Signal | Example |
|---|---|
| ≥2 email header blocks (From/Subject/Date) | Forwarded email thread |
| Forwarded message separators | "--- Forwarded Message ---" |
| ≥2 `===` / `---` separator lines | HR bulk export |
| ≥2 entity blocks (Employee ID, Client No) | CRM export |
| >5 timestamped log entries | System log dump |
| ≥2 page break markers | Multi-page contract with exhibits |
| Long Slack/CRM source + text > 2000 chars | Bulk Slack export |

---

## PII Detection

Patterns detected (from PS regex/rule seeds):

| Type | Pattern |
|---|---|
| SSN | `XXX-XX-XXXX` |
| PAN (card) | Visa, Mastercard, Amex, Discover patterns |
| IBAN | `CC99 XXXX...` |
| DOB | DD/MM/YYYY or YYYY-MM-DD |
| Email | standard RFC pattern |
| Phone | US formats |
| Passport | `XX9999999` |
| IP Address | IPv4 |

### Policy Action derivation

| PII found | Derived policy hint |
|---|---|
| SSN / PAN / IBAN / Passport | Quarantine |
| DOB / Phone / Email + Confidential/Restricted label | Restrict |
| DOB / Phone / Email + any other label | Encrypt |
| No PII + Confidential/Restricted label | Encrypt |
| No PII + Public/Internal | Allow |

---

## Downstream Integration

The validated_documents and multi_struct_segments topics feed directly into the ML pipeline:

- **Feature Engineering**: TF-IDF + BERT/RoBERTa/DeBERTa embeddings
- **Classification**: Ensemble (LR + XGBoost + fine-tuned transformer)
- **Explainability**: SHAP / LIME evidence tokens
- **Policy Engine**: Rule overlay for Restricted token override
- **Output API**: FastAPI → label + score + evidence + action
- **MLOps**: MLflow tracking, Evidently AI drift monitoring

---

## Compliance Notes (from PS Constraints)

| Constraint | How this layer addresses it |
|---|---|
| C1: No raw PII stored | PII is **flagged** at ingestion; masking happens downstream before persistence |
| C2: Model must be auditable | Structure type and validation metadata are captured for every record |
| C3: On-prem support | Kafka + Zookeeper run fully on-prem via Docker |
| C4: Dual-approval for training data | Labels from CSV are passed through unchanged; approval workflow is upstream |
| C5: mTLS for payments clients | Configure `ssl_*` options in `KafkaConfig` for mTLS |
