from dataclasses import dataclass, field
from typing import Optional


@dataclass
class KafkaConfig:
    bootstrap_servers: str = "localhost:9092"
    
    # Topics
    raw_docs_topic: str = "raw_documents"
    validated_docs_topic: str = "validated_documents"
    dlq_topic: str = "dead_letter_queue"          # failed validation
    multi_struct_topic: str = "multi_structure_segments" # multi-doc segments
    
    # Producer
    producer_interval_seconds: float = 0.5        # interval between sends
    batch_size: int = 50
    acks: str = "all"
    retries: int = 3
    
    # Consumer
    consumer_group_id: str = "ingestion_validator_group"
    auto_offset_reset: str = "earliest"
    enable_auto_commit: bool = False
    max_poll_records: int = 100
    session_timeout_ms: int = 30000


@dataclass
class AppConfig:
    kafka: KafkaConfig = field(default_factory=KafkaConfig)
    
    dataset_path: str = "data/final_synthetic_dataset_20000.csv"
    
    # Document structure detection thresholds
    multi_struct_min_segments: int = 2             # min segments to be "multi"
    email_boundary_pattern: bool = True
    min_segment_length: int = 80                   # chars per segment
    
    # Validation
    max_text_length: int = 50_000
    min_text_length: int = 5
    allowed_labels: tuple = ("Public", "Internal", "Confidential", "Restricted")
    allowed_sources: tuple = ("email", "slack", "crm", "upload", "api", "drive")
    allowed_file_types: tuple = ("pdf", "docx", "txt", "xlsx", "email")
    allowed_departments: tuple = ("Sales", "HR", "IT", "Legal", "Support", "Finance")
    
    # Logging
    log_level: str = "INFO"


CONFIG = AppConfig()
