"""
utils/metadata_enricher.py
===========================
Adds metadata to parsed documents before they go to Kafka.

Metadata fields (from PS Section 2 — Metadata Signals):
  - source system
  - file type
  - author
  - department
  - creation date

Enrichment sources (priority order):
  1. Caller-supplied metadata dict (from upload form / API headers)
  2. Extracted from document content (e.g. email From: header → author)
  3. Filesystem metadata (created_at from file mtime)
  4. Defaults / unknown fallback
"""

from __future__ import annotations

import os
import re
from datetime import datetime
from typing import Optional


_FROM_RE    = re.compile(r"(?:^|\n)From\s*:\s*(.+)", re.IGNORECASE)
_AUTHOR_RE  = re.compile(r"(?:Author|Prepared by|Submitted by)\s*:\s*(.+)", re.IGNORECASE)
_DATE_RE    = re.compile(r"(?:Date|Created|Dated)\s*:\s*(\d{4}-\d{2}-\d{2})", re.IGNORECASE)


def enrich_metadata(
    text:       str,
    file_path:  str,
    file_name:  str,
    file_type:  str,
    source:     str,
    caller_meta: Optional[dict] = None,
) -> dict:
    """
    Returns a metadata dict to be merged into the IngestionPayload.

    caller_meta can contain: department, author, created_at, tags
    (passed from upload form fields or API request headers)
    """
    meta = caller_meta or {}

    # ── author ────────────────────────────────────────────────────────────
    author = meta.get("author") or _extract_author(text, file_type)

    # ── department ────────────────────────────────────────────────────────
    department = meta.get("department") or None   # must be supplied explicitly

    # ── created_at ───────────────────────────────────────────────────────
    created_at = (
        meta.get("created_at")
        or _extract_date_from_text(text)
        or _file_mtime(file_path)
    )

    return {
        "author":     author,
        "department": department,
        "created_at": created_at,
        "source":     source,
        "file_type":  file_type,
        "file_name":  file_name,
    }


# ── helpers ──────────────────────────────────────────────────────────────────

def _extract_author(text: str, file_type: str) -> Optional[str]:
    # Email: extract From header
    if file_type in ("eml", "msg"):
        m = _FROM_RE.search(text)
        if m:
            return m.group(1).strip()[:200]

    # Docs: look for "Author:" or "Prepared by:" line
    m = _AUTHOR_RE.search(text)
    if m:
        return m.group(1).strip()[:200]

    return None


def _extract_date_from_text(text: str) -> Optional[str]:
    m = _DATE_RE.search(text)
    if m:
        return m.group(1).strip()
    return None


def _file_mtime(file_path: str) -> Optional[str]:
    try:
        ts = os.path.getmtime(file_path)
        return datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d")
    except Exception:
        return None
