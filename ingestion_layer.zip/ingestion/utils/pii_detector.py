"""
utils/pii_detector.py
======================
Detects PII patterns from the PS regex/rule seeds:
  SSN, PAN (card number), IBAN, DOB, email, phone
Plus: Passport number, IP address

Used at ingestion to:
  1. Flag records so masking happens before persistence (Constraint C1)
  2. Derive a policy_action_hint for downstream triage
  3. Surface evidence for the audit log
"""

from __future__ import annotations

import re
from typing import List, Set

# ─────────────────────────────────────────────────────────────────────────────
# Patterns
# ─────────────────────────────────────────────────────────────────────────────

_PATTERNS = {
    "SSN": re.compile(
        r"\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b"
    ),
    "PAN": re.compile(                          # card number (Visa/MC/Amex/Discover)
        r"\b(?:4[0-9]{12}(?:[0-9]{3})?"
        r"|5[1-5][0-9]{14}"
        r"|3[47][0-9]{13}"
        r"|3(?:0[0-5]|[68][0-9])[0-9]{11}"
        r"|6(?:011|5[0-9]{2})[0-9]{12})\b"
    ),
    "IBAN": re.compile(
        r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}(?:[A-Z0-9]?){0,16}\b"
    ),
    "DOB": re.compile(
        r"\b(?:0[1-9]|[12]\d|3[01])[-/.](?:0[1-9]|1[0-2])[-/.](?:19|20)\d{2}\b"
        r"|\b(?:19|20)\d{2}[-/.](?:0[1-9]|1[0-2])[-/.](?:0[1-9]|[12]\d|3[01])\b"
    ),
    "EMAIL": re.compile(
        r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
    ),
    "PHONE": re.compile(
        r"\b(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}\b"
    ),
    "PASSPORT": re.compile(r"\b[A-Z]{1,2}\d{6,9}\b"),
    "IP_ADDRESS": re.compile(
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
        r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
    ),
}

_RESTRICTED_PII:    Set[str] = {"SSN", "PAN", "IBAN", "PASSPORT"}
_CONFIDENTIAL_PII:  Set[str] = {"DOB", "PHONE", "EMAIL"}


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def detect_pii(text: str) -> List[str]:
    """Return list of detected PII type names, e.g. ['SSN', 'EMAIL']."""
    return [ptype for ptype, pat in _PATTERNS.items() if pat.search(text)]


def derive_policy_hint(pii_flags: List[str]) -> str:
    """
    Rule-based policy hint derived from PII flags alone.
    The Classification Model will produce the real sensitivity label later.
    This hint is for immediate triage / audit.

    Severity ladder (highest wins):
      RESTRICTED PII (SSN/PAN/IBAN/Passport) → Quarantine
      CONFIDENTIAL PII (DOB/Phone/Email)      → Restrict
      No PII                                  → Allow
    """
    flags = set(pii_flags)
    if flags & _RESTRICTED_PII:
        return "Quarantine"
    if flags & _CONFIDENTIAL_PII:
        return "Restrict"
    return "Allow"
