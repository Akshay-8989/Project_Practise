"""
validator/schema_validator.py
==============================
Schema and business-rule validation for parsed document payloads.

Two validation passes:
  Pass 1 — Structural: required fields present, correct types, length bounds
  Pass 2 — Business rules: enum membership, date format, plausibility checks

Returns a ValidationResult with either success=True or a specific error.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import CONFIG
from schemas.models import FailureReason

_DATE_RE   = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_ISO_DT_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")


@dataclass
class ValidationResult:
    success:        bool
    failure_reason: Optional[str] = None
    failure_detail: Optional[str] = None

    @classmethod
    def ok(cls) -> "ValidationResult":
        return cls(success=True)

    @classmethod
    def fail(cls, reason: str, detail: str) -> "ValidationResult":
        return cls(success=False, failure_reason=reason, failure_detail=detail)


class SchemaValidator:
    """
    Validates the raw payload dict that will become an IngestionPayload.
    Called BEFORE Pydantic model construction to give cleaner error messages.
    """

    def validate(self, payload: dict) -> ValidationResult:

        # ── Pass 1: Required fields ───────────────────────────────────────
        required = ["doc_id", "file_name", "file_type", "source", "raw_text"]
        for f in required:
            if f not in payload:
                return ValidationResult.fail(
                    FailureReason.SCHEMA_INVALID,
                    f"Missing required field: '{f}'",
                )
            if not isinstance(payload[f], str):
                return ValidationResult.fail(
                    FailureReason.SCHEMA_INVALID,
                    f"Field '{f}' must be a string, got {type(payload[f]).__name__}",
                )

        # ── Pass 2: Text length ───────────────────────────────────────────
        text = payload["raw_text"].strip()
        if not text:
            return ValidationResult.fail(
                FailureReason.EMPTY_CONTENT,
                "raw_text is empty after stripping whitespace",
            )
        if len(text) < CONFIG.validation.min_text_length:
            return ValidationResult.fail(
                FailureReason.TEXT_TOO_SHORT,
                f"raw_text has {len(text)} chars; minimum is {CONFIG.validation.min_text_length}",
            )
        if len(text) > CONFIG.validation.max_text_length:
            return ValidationResult.fail(
                FailureReason.TEXT_TOO_LONG,
                f"raw_text has {len(text)} chars; maximum is {CONFIG.validation.max_text_length}",
            )

        # ── Pass 3: Enum fields ───────────────────────────────────────────
        source = payload.get("source", "")
        if source not in CONFIG.validation.allowed_sources:
            return ValidationResult.fail(
                FailureReason.SCHEMA_INVALID,
                f"Unknown source '{source}'. "
                f"Allowed: {CONFIG.validation.allowed_sources}",
            )

        file_type = payload.get("file_type", "")
        if file_type not in CONFIG.validation.allowed_file_types:
            return ValidationResult.fail(
                FailureReason.SCHEMA_INVALID,
                f"Unknown file_type '{file_type}'. "
                f"Allowed: {CONFIG.validation.allowed_file_types}",
            )

        # Optional department
        dept = payload.get("department")
        if dept and dept not in CONFIG.validation.allowed_departments:
            return ValidationResult.fail(
                FailureReason.SCHEMA_INVALID,
                f"Unknown department '{dept}'. "
                f"Allowed: {CONFIG.validation.allowed_departments}",
            )

        # Optional date
        created_at = payload.get("created_at")
        if created_at:
            if not (_DATE_RE.match(created_at) or _ISO_DT_RE.match(created_at)):
                return ValidationResult.fail(
                    FailureReason.SCHEMA_INVALID,
                    f"created_at '{created_at}' does not match YYYY-MM-DD or ISO datetime",
                )

        # ── Pass 4: doc_id non-empty ──────────────────────────────────────
        doc_id = payload.get("doc_id", "").strip()
        if not doc_id:
            return ValidationResult.fail(
                FailureReason.SCHEMA_INVALID,
                "doc_id is empty",
            )

        return ValidationResult.ok()
