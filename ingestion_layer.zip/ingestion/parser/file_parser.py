"""
parser/file_parser.py
======================
Handles all file format parsing.

Parser priority (from PS Section 3 — Baseline System Architecture):
  1. pdfplumber       → PDF
  2. python-docx      → DOCX
  3. Native Python    → TXT, CSV, EML
  4. Apache Tika      → fallback for exotic / unsupported formats
  5. ZIP              → recursive: each file inside is processed separately

Each parser returns a ParsedDocument with:
  - raw_text (cleaned)
  - file_type
  - page_count (PDF only)
  - parser_used
  - parse_warnings (soft issues that didn't block extraction)
"""

from __future__ import annotations

import email
import io
import logging
import os
import sys
import zipfile
from pathlib import Path
from typing import List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from schemas.models import ParsedDocument

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _clean(text: str) -> str:
    """Normalise whitespace without destroying paragraph structure."""
    import re
    # Collapse runs of spaces/tabs but keep newlines
    text = re.sub(r"[ \t]+", " ", text)
    # Collapse more than 3 consecutive blank lines into 2
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip()


def _ext(file_name: str) -> str:
    return os.path.splitext(file_name)[1].lower().lstrip(".")


# ─────────────────────────────────────────────────────────────────────────────
# PDF Parser (pdfplumber)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_pdf(file_path: str, file_name: str) -> ParsedDocument:
    warnings: List[str] = []
    try:
        import pdfplumber
    except ImportError:
        raise RuntimeError(
            "pdfplumber not installed. Run: pip install pdfplumber"
        )

    pages_text: List[str] = []
    page_count = 0

    try:
        with pdfplumber.open(file_path) as pdf:
            page_count = len(pdf.pages)
            for i, page in enumerate(pdf.pages):
                try:
                    t = page.extract_text()
                    if t:
                        pages_text.append(t)
                    else:
                        warnings.append(f"page {i+1}: no text extracted (may be image-based)")
                except Exception as page_err:
                    warnings.append(f"page {i+1} extraction error: {page_err}")
    except Exception as exc:
        raise RuntimeError(f"pdfplumber failed: {exc}") from exc

    raw_text = "\n".join(pages_text)
    if not raw_text.strip() and page_count > 0:
        warnings.append(
            "PDF appears to be image-based; consider running OCR (Tesseract/Tika)"
        )

    return ParsedDocument(
        file_name=file_name,
        file_type="pdf",
        raw_text=_clean(raw_text),
        page_count=page_count,
        parser_used="pdfplumber",
        parse_warnings=warnings,
    )


# ─────────────────────────────────────────────────────────────────────────────
# DOCX Parser (python-docx)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_docx(file_path: str, file_name: str) -> ParsedDocument:
    try:
        from docx import Document
    except ImportError:
        raise RuntimeError(
            "python-docx not installed. Run: pip install python-docx"
        )

    warnings: List[str] = []
    try:
        doc = Document(file_path)
    except Exception as exc:
        raise RuntimeError(f"python-docx failed to open: {exc}") from exc

    parts: List[str] = []

    # Main body paragraphs
    for para in doc.paragraphs:
        if para.text.strip():
            parts.append(para.text)

    # Tables (important for financial reports, HR forms)
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(
                cell.text.strip() for cell in row.cells if cell.text.strip()
            )
            if row_text:
                parts.append(row_text)

    raw_text = "\n".join(parts)

    if not raw_text.strip():
        warnings.append("DOCX body appears empty; may be header/footer only")

    return ParsedDocument(
        file_name=file_name,
        file_type="docx",
        raw_text=_clean(raw_text),
        parser_used="python-docx",
        parse_warnings=warnings,
    )


# ─────────────────────────────────────────────────────────────────────────────
# TXT / plain text
# ─────────────────────────────────────────────────────────────────────────────

def _parse_txt(file_path: str, file_name: str) -> ParsedDocument:
    warnings: List[str] = []
    for encoding in ("utf-8", "latin-1", "cp1252"):
        try:
            with open(file_path, "r", encoding=encoding) as f:
                raw_text = f.read()
            return ParsedDocument(
                file_name=file_name,
                file_type="txt",
                raw_text=_clean(raw_text),
                parser_used="native_txt",
                parse_warnings=warnings,
            )
        except UnicodeDecodeError:
            continue

    raise RuntimeError("Could not decode TXT file with any supported encoding")


# ─────────────────────────────────────────────────────────────────────────────
# EML / MSG (email exports)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_eml(file_path: str, file_name: str) -> ParsedDocument:
    """
    Parses .eml (and simple .msg) files.
    Extracts: headers (From, To, Subject, Date) + body text.
    Inline attachments are extracted as additional text blocks.
    """
    warnings: List[str] = []
    parts: List[str] = []

    try:
        with open(file_path, "rb") as f:
            msg = email.message_from_bytes(f.read())
    except Exception as exc:
        raise RuntimeError(f"EML parse failed: {exc}") from exc

    # Headers
    for header in ("From", "To", "CC", "Subject", "Date"):
        val = msg.get(header)
        if val:
            parts.append(f"{header}: {val}")

    parts.append("")  # blank line separator

    # Body
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            disposition  = str(part.get("Content-Disposition", ""))
            if "attachment" in disposition:
                warnings.append(
                    f"Skipped binary attachment: {part.get_filename()}"
                )
                continue
            if content_type in ("text/plain", "text/html"):
                payload = part.get_payload(decode=True)
                if payload:
                    try:
                        text = payload.decode(
                            part.get_content_charset() or "utf-8", errors="replace"
                        )
                        # Strip basic HTML tags if HTML part
                        if content_type == "text/html":
                            import re
                            text = re.sub(r"<[^>]+>", " ", text)
                        parts.append(text)
                    except Exception as dec_err:
                        warnings.append(f"Body decode error: {dec_err}")
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            try:
                parts.append(
                    payload.decode(msg.get_content_charset() or "utf-8", errors="replace")
                )
            except Exception as dec_err:
                warnings.append(f"Body decode error: {dec_err}")

    return ParsedDocument(
        file_name=file_name,
        file_type="eml",
        raw_text=_clean("\n".join(parts)),
        parser_used="native_email",
        parse_warnings=warnings,
    )


# ─────────────────────────────────────────────────────────────────────────────
# CSV
# ─────────────────────────────────────────────────────────────────────────────

def _parse_csv(file_path: str, file_name: str) -> ParsedDocument:
    import csv
    warnings: List[str] = []
    rows: List[str] = []

    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f)
            for row in reader:
                rows.append(" | ".join(cell.strip() for cell in row if cell.strip()))
    except Exception as exc:
        raise RuntimeError(f"CSV parse failed: {exc}") from exc

    if len(rows) > 10_000:
        warnings.append(
            f"CSV has {len(rows)} rows — consider chunking before ingestion"
        )

    return ParsedDocument(
        file_name=file_name,
        file_type="csv",
        raw_text=_clean("\n".join(rows)),
        parser_used="native_csv",
        parse_warnings=warnings,
    )


# ─────────────────────────────────────────────────────────────────────────────
# ZIP (recursive)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_zip(file_path: str, file_name: str) -> List[ParsedDocument]:
    """
    ZIPs are treated as multi-document containers.
    Each file inside is parsed independently and returned as a list.
    Caller is responsible for treating the result as MULTI-structured.
    """
    results: List[ParsedDocument] = []

    try:
        with zipfile.ZipFile(file_path, "r") as zf:
            for inner_name in zf.namelist():
                if inner_name.endswith("/"):
                    continue  # skip directories
                try:
                    with zf.open(inner_name) as inner_file:
                        tmp_path = f"/tmp/_zip_{os.path.basename(inner_name)}"
                        with open(tmp_path, "wb") as tmp:
                            tmp.write(inner_file.read())
                        parsed = parse_file(tmp_path, file_name=inner_name)
                        if isinstance(parsed, list):
                            results.extend(parsed)
                        else:
                            results.append(parsed)
                        os.remove(tmp_path)
                except Exception as inner_err:
                    log.warning("ZIP inner file %s failed: %s", inner_name, inner_err)
    except zipfile.BadZipFile as exc:
        raise RuntimeError(f"Bad ZIP file: {exc}") from exc

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Apache Tika fallback
# ─────────────────────────────────────────────────────────────────────────────

def _parse_tika(file_path: str, file_name: str, tika_url: str) -> ParsedDocument:
    """
    Fallback for any format not handled natively.
    Requires a running Tika server (see PS Section 3).
    Start with: java -jar tika-server.jar --port 9998
    """
    import requests
    warnings: List[str] = []

    try:
        with open(file_path, "rb") as f:
            response = requests.put(
                f"{tika_url}/tika",
                data=f,
                headers={"Accept": "text/plain"},
                timeout=30,
            )
        if response.status_code != 200:
            raise RuntimeError(
                f"Tika returned HTTP {response.status_code}"
            )
        raw_text = response.text
    except Exception as exc:
        raise RuntimeError(f"Tika parse failed: {exc}") from exc

    ext = _ext(file_name) or "unknown"
    return ParsedDocument(
        file_name=file_name,
        file_type=ext,
        raw_text=_clean(raw_text),
        parser_used="apache_tika",
        parse_warnings=warnings,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def parse_file(
    file_path: str,
    file_name: Optional[str] = None,
    tika_enabled: bool = False,
    tika_url: str = "http://localhost:9998",
) -> ParsedDocument | List[ParsedDocument]:
    """
    Main parser dispatcher.

    Returns:
      - ParsedDocument          for single-file formats
      - List[ParsedDocument]    for ZIP (each inner file is a document)

    Raises RuntimeError if parsing fails unrecoverably.
    """
    fname = file_name or os.path.basename(file_path)
    ext   = _ext(fname)

    log.debug("Parsing %s (ext=%s)", fname, ext)

    if ext == "pdf":
        return _parse_pdf(file_path, fname)

    elif ext == "docx":
        return _parse_docx(file_path, fname)

    elif ext in ("txt", "text"):
        return _parse_txt(file_path, fname)

    elif ext in ("eml", "msg"):
        return _parse_eml(file_path, fname)

    elif ext == "csv":
        return _parse_csv(file_path, fname)

    elif ext == "zip":
        return _parse_zip(file_path, fname)

    elif tika_enabled:
        log.info("Using Apache Tika fallback for %s", fname)
        return _parse_tika(file_path, fname, tika_url)

    else:
        raise RuntimeError(
            f"Unsupported file type '{ext}'. "
            f"Enable Tika (tika_enabled=True) for exotic formats."
        )
