"""
api/ingestion_pipeline.py
==========================
Main ingestion pipeline.

Flow per uploaded file:
─────────────────────────────────────────────────────────────────
  Upload (file path + optional metadata)
        │
        ▼
  File Type Detection
  (extension → parser routing)
        │
        ▼
  Text Extraction
  (pdfplumber / python-docx / native / tika)
        │
        ▼
  Single vs Multi-Entity Detection
  (rule-based heuristics)
        │
        ├─ SINGLE ──────────────────────────────┐
        │                                       │
        └─ MULTI (split into N segments) ──────►│
                                                ▼
                                       Schema Validation
                                                │
                                       Metadata Enrichment
                                                │
                                       PII Detection
                                                │
                                   ┌────────────┴────────────┐
                                   │                         │
                               valid?                    invalid?
                                   │                         │
                             Kafka publish              Dead Letter Queue
                          (single / multi topic)
                                   │
                                Audit Log
─────────────────────────────────────────────────────────────────

Public entry points:
  process_file()    → process one file by path
  process_folder()  → process all files in a folder (batch mode)
  process_bytes()   → process in-memory bytes (for REST API / streaming)
"""

from __future__ import annotations

import logging
import os
import sys
import tempfile
import uuid
from pathlib import Path
from typing import Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import CONFIG
from parser.file_parser import parse_file
from schemas.models import (
    AuditLogEntry,
    DeadLetterRecord,
    FailureReason,
    IngestionPayload,
    StructureType,
)
from splitter.structure_detector import StructureDetector
from validator.schema_validator import SchemaValidator
from utils.pii_detector import detect_pii, derive_policy_hint
from utils.metadata_enricher import enrich_metadata
from producer.kafka_producer import IngestionProducer

log = logging.getLogger(__name__)

_detector   = StructureDetector()
_validator  = SchemaValidator()


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline result
# ─────────────────────────────────────────────────────────────────────────────

class ProcessingResult:
    """Returned from process_file() so callers can inspect what happened."""
    def __init__(self):
        self.file_name:       str = ""
        self.ingest_id:       str = str(uuid.uuid4())
        self.success:         bool = False
        self.structure_type:  Optional[str] = None
        self.segment_count:   int = 0
        self.pii_flags:       List[str] = []
        self.policy_hint:     Optional[str] = None
        self.failure_reason:  Optional[str] = None
        self.failure_detail:  Optional[str] = None
        self.warnings:        List[str] = []

    def __repr__(self):
        if self.success:
            return (
                f"<ProcessingResult OK file={self.file_name} "
                f"structure={self.structure_type} segments={self.segment_count} "
                f"pii={self.pii_flags}>"
            )
        return (
            f"<ProcessingResult FAILED file={self.file_name} "
            f"reason={self.failure_reason} detail={self.failure_detail}>"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Core pipeline function
# ─────────────────────────────────────────────────────────────────────────────

def process_file(
    file_path:    str,
    source:       str  = "direct_upload",
    caller_meta:  Optional[Dict] = None,
    producer:     Optional[IngestionProducer] = None,
) -> ProcessingResult:
    """
    Full ingestion pipeline for one file.

    Args:
        file_path:    Absolute or relative path to the uploaded file.
        source:       Where this file came from (direct_upload, email_connector, etc.)
        caller_meta:  Optional dict with {department, author, created_at, tags}
                      — from upload form fields or API headers.
        producer:     Reuse an existing IngestionProducer (for batch mode).
                      If None, a fresh producer is created and closed after.

    Returns:
        ProcessingResult with status and enriched metadata.
    """
    result      = ProcessingResult()
    ingest_id   = result.ingest_id
    file_name   = os.path.basename(file_path)
    result.file_name = file_name

    _own_producer = producer is None
    if _own_producer:
        producer = IngestionProducer()

    try:
        # ── Step 1: File type detection ───────────────────────────────────
        ext = Path(file_name).suffix.lower().lstrip(".")
        if not ext or f".{ext}" not in CONFIG.files.supported_extensions:
            return _fail(
                result, producer, file_name, source, ingest_id,
                FailureReason.UNSUPPORTED_FORMAT,
                f"Extension '.{ext}' is not supported. "
                f"Supported: {CONFIG.files.supported_extensions}",
            )

        # ── Step 2: File size check ───────────────────────────────────────
        size_mb = os.path.getsize(file_path) / (1024 * 1024)
        if size_mb > CONFIG.files.max_file_size_mb:
            return _fail(
                result, producer, file_name, source, ingest_id,
                FailureReason.FILE_TOO_LARGE,
                f"File is {size_mb:.1f} MB; limit is {CONFIG.files.max_file_size_mb} MB",
            )

        # ── Step 3: Text extraction ───────────────────────────────────────
        try:
            parsed_result = parse_file(
                file_path,
                file_name=file_name,
                tika_enabled=CONFIG.files.tika_enabled,
                tika_url=CONFIG.files.tika_server_url,
            )
        except RuntimeError as exc:
            return _fail(
                result, producer, file_name, source, ingest_id,
                FailureReason.PARSE_FAILED,
                str(exc),
            )

        # ZIP returns a list of ParsedDocuments — each treated as MULTI segment
        if isinstance(parsed_result, list):
            log.info("%s is a ZIP with %d inner files", file_name, len(parsed_result))
            for i, inner_parsed in enumerate(parsed_result):
                _process_parsed(
                    parsed=inner_parsed,
                    file_path=file_path,
                    source=source,
                    caller_meta=caller_meta,
                    ingest_id=ingest_id,
                    parent_doc_id=ingest_id,
                    segment_index=i,
                    total_segments=len(parsed_result),
                    producer=producer,
                    result=result,
                )
            result.success       = True
            result.structure_type = StructureType.MULTI.value
            result.segment_count  = len(parsed_result)
            _write_audit(result, producer, file_name, source, ingest_id)
            return result

        # Single ParsedDocument
        return _process_parsed(
            parsed=parsed_result,
            file_path=file_path,
            source=source,
            caller_meta=caller_meta,
            ingest_id=ingest_id,
            parent_doc_id=None,
            segment_index=None,
            total_segments=None,
            producer=producer,
            result=result,
        )

    finally:
        if _own_producer:
            producer.close()


# ─────────────────────────────────────────────────────────────────────────────
# Inner processor for one ParsedDocument
# ─────────────────────────────────────────────────────────────────────────────

def _process_parsed(
    parsed,
    file_path:       str,
    source:          str,
    caller_meta:     Optional[Dict],
    ingest_id:       str,
    parent_doc_id:   Optional[str],
    segment_index:   Optional[int],
    total_segments:  Optional[int],
    producer:        IngestionProducer,
    result:          ProcessingResult,
) -> ProcessingResult:

    file_name = parsed.file_name
    result.warnings.extend(parsed.parse_warnings)

    # ── Step 4: Single vs Multi-Entity Detection ──────────────────────────
    struct = _detector.detect(
        text=parsed.raw_text,
        source=source,
        file_type=parsed.file_type,
    )
    log.info(
        "%s → structure=%s segments=%d signals=%s",
        file_name, struct.structure_type.value,
        struct.segment_count, struct.signals,
    )

    # ── Step 5: Metadata enrichment ───────────────────────────────────────
    meta = enrich_metadata(
        text=parsed.raw_text,
        file_path=file_path,
        file_name=file_name,
        file_type=parsed.file_type,
        source=source,
        caller_meta=caller_meta,
    )

    # ── Step 6: PII detection (across full document text) ─────────────────
    pii_flags    = detect_pii(parsed.raw_text)
    policy_hint  = derive_policy_hint(pii_flags)
    result.pii_flags   = pii_flags
    result.policy_hint = policy_hint

    if pii_flags:
        log.info("PII detected in %s: %s → hint=%s", file_name, pii_flags, policy_hint)

    # ── Step 7: Build payloads and validate + publish ─────────────────────

    if struct.structure_type == StructureType.SINGLE:
        result.structure_type = StructureType.SINGLE.value
        result.segment_count  = 1

        payload_dict = _build_payload_dict(
            ingest_id       = ingest_id,
            file_name       = file_name,
            file_type       = parsed.file_type,
            source          = source,
            raw_text        = parsed.raw_text,
            structure_type  = StructureType.SINGLE.value,
            segment_index   = segment_index,
            total_segments  = total_segments,
            parent_doc_id   = parent_doc_id,
            segment_type    = None,
            structure_signals = struct.signals,
            pii_flags       = pii_flags,
            policy_hint     = policy_hint,
            meta            = meta,
            parser_used     = parsed.parser_used,
            warnings        = parsed.parse_warnings,
        )

        val = _validator.validate(payload_dict)
        if not val.success:
            return _fail(
                result, producer, file_name, source, ingest_id,
                val.failure_reason, val.failure_detail,
            )

        producer.send_single(payload_dict)
        log.info("→ single_entity_docs: %s", payload_dict["doc_id"])

    else:
        # MULTI: publish one message per segment
        result.structure_type = StructureType.MULTI.value
        result.segment_count  = struct.segment_count
        parent_id = parent_doc_id or ingest_id

        for seg in struct.segments:
            seg_payload = _build_payload_dict(
                ingest_id       = ingest_id,
                file_name       = file_name,
                file_type       = parsed.file_type,
                source          = source,
                raw_text        = seg.text,
                structure_type  = StructureType.MULTI.value,
                segment_index   = seg.segment_index,
                total_segments  = struct.segment_count,
                parent_doc_id   = parent_id,
                segment_type    = seg.segment_type,
                structure_signals = struct.signals,
                pii_flags       = detect_pii(seg.text),    # per-segment PII
                policy_hint     = derive_policy_hint(detect_pii(seg.text)),
                meta            = meta,
                parser_used     = parsed.parser_used,
                warnings        = parsed.parse_warnings,
            )

            val = _validator.validate(seg_payload)
            if not val.success:
                # Send this segment to DLQ but continue with others
                dlr = DeadLetterRecord(
                    file_name=file_name,
                    source=source,
                    failure_reason=val.failure_reason,
                    failure_detail=f"Segment {seg.segment_index}: {val.failure_detail}",
                    raw_payload=seg_payload,
                ).model_dump()
                producer.send_dlq(dlr)
                log.warning("Segment %d of %s failed validation → DLQ", seg.segment_index, file_name)
                continue

            producer.send_multi(seg_payload)
            log.info(
                "→ multi_entity_docs: %s seg=%d/%d type=%s",
                seg_payload["doc_id"], seg.segment_index + 1,
                struct.segment_count, seg.segment_type,
            )

    result.success = True
    _write_audit(result, producer, file_name, source, ingest_id)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Batch folder processor
# ─────────────────────────────────────────────────────────────────────────────

def process_folder(
    folder_path:  str = None,
    source:       str = "direct_upload",
    caller_meta:  Optional[Dict] = None,
) -> List[ProcessingResult]:
    """
    Process all supported files in a folder.
    Reuses a single Kafka producer for efficiency.
    """
    folder = folder_path or CONFIG.files.upload_folder
    results: List[ProcessingResult] = []

    files = [
        os.path.join(folder, f)
        for f in os.listdir(folder)
        if os.path.isfile(os.path.join(folder, f))
        and Path(f).suffix.lower() in CONFIG.files.supported_extensions
    ]

    if not files:
        log.warning("No supported files found in %s", folder)
        return results

    log.info("Processing %d files from %s", len(files), folder)

    with IngestionProducer() as producer:
        for i, file_path in enumerate(files, 1):
            log.info("[%d/%d] Processing: %s", i, len(files), file_path)
            result = process_file(
                file_path=file_path,
                source=source,
                caller_meta=caller_meta,
                producer=producer,
            )
            results.append(result)
            if result.success:
                log.info("✓ %s  structure=%s  segments=%d",
                         result.file_name, result.structure_type, result.segment_count)
            else:
                log.warning("✗ %s  reason=%s", result.file_name, result.failure_reason)

        producer.flush()

    ok    = sum(1 for r in results if r.success)
    fail  = len(results) - ok
    log.info("Batch complete: %d/%d succeeded, %d failed", ok, len(results), fail)
    return results


# ─────────────────────────────────────────────────────────────────────────────
# In-memory bytes processor (for REST API / streaming ingest)
# ─────────────────────────────────────────────────────────────────────────────

def process_bytes(
    file_bytes:   bytes,
    file_name:    str,
    source:       str = "api_push",
    caller_meta:  Optional[Dict] = None,
) -> ProcessingResult:
    """
    Process raw file bytes (e.g. from a multipart/form-data HTTP upload).
    Writes to a temp file, processes, then deletes.
    """
    suffix = Path(file_name).suffix
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(file_bytes)
        tmp_path = tmp.name

    try:
        return process_file(
            file_path=tmp_path,
            source=source,
            caller_meta={"file_name_override": file_name, **(caller_meta or {})},
        )
    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _build_payload_dict(
    ingest_id, file_name, file_type, source, raw_text,
    structure_type, segment_index, total_segments, parent_doc_id,
    segment_type, structure_signals, pii_flags, policy_hint,
    meta, parser_used, warnings,
) -> dict:
    return {
        "doc_id":           str(uuid.uuid4()),
        "ingest_id":        ingest_id,
        "parent_doc_id":    parent_doc_id,
        "file_name":        file_name,
        "file_type":        file_type,
        "source":           source,
        "raw_text":         raw_text,
        "structure_type":   structure_type,
        "segment_index":    segment_index,
        "segment_type":     segment_type,
        "total_segments":   total_segments,
        "structure_signals":structure_signals,
        "department":       meta.get("department"),
        "author":           meta.get("author"),
        "created_at":       meta.get("created_at"),
        "pii_flags":        pii_flags,
        "policy_action_hint": policy_hint,
        "parser_used":      parser_used,
        "parse_warnings":   warnings,
        "ingestion_version": "1.0.0",
    }


def _fail(
    result: ProcessingResult,
    producer: IngestionProducer,
    file_name: str,
    source: str,
    ingest_id: str,
    failure_reason: str,
    failure_detail: str,
) -> ProcessingResult:
    result.success        = False
    result.failure_reason = failure_reason
    result.failure_detail = failure_detail

    dlr = DeadLetterRecord(
        file_name=file_name,
        source=source,
        failure_reason=failure_reason,
        failure_detail=failure_detail,
    ).model_dump()
    producer.send_dlq(dlr)
    log.error("FAILED %s: %s — %s", file_name, failure_reason, failure_detail)

    _write_audit(result, producer, file_name, source, ingest_id)
    return result


def _write_audit(
    result: ProcessingResult,
    producer: IngestionProducer,
    file_name: str,
    source: str,
    ingest_id: str,
):
    entry = AuditLogEntry(
        ingest_id      = ingest_id,
        file_name      = file_name,
        file_type      = Path(file_name).suffix.lstrip(".").lower() or "unknown",
        source         = source,
        status         = "ingested" if result.success else "failed",
        structure_type = result.structure_type,
        segment_count  = result.segment_count,
        pii_flags      = result.pii_flags,
        policy_hint    = result.policy_hint,
        failure_reason = result.failure_reason,
        failure_detail = result.failure_detail,
    ).model_dump()
    producer.send_audit(entry)
