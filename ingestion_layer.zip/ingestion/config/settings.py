"""
settings.py
============
Central configuration for the Ingestion Layer.
Change values here; nothing else needs to be touched.
"""

from dataclasses import dataclass, field
from typing import Tuple


# ─────────────────────────────────────────────────────────────────────────────
# Kafka
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class KafkaConfig:
    bootstrap_servers: str = "localhost:9092"

    # Topic names
    single_entity_topic: str = "single_entity_docs"
    multi_entity_topic:  str = "multi_entity_docs"
    audit_topic:         str = "audit_logs"
    dlq_topic:           str = "dead_letter_queue"

    # Producer tuning
    acks:              str = "all"       # wait for all replicas
    retries:           int = 3
    compression_type:  str = "gzip"
    enable_idempotence: bool = True


# ─────────────────────────────────────────────────────────────────────────────
# File handling
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class FileConfig:
    upload_folder:   str = "uploads"
    max_file_size_mb: int = 50

    # Supported extensions and their parser routing
    supported_extensions: Tuple[str, ...] = (
        ".pdf", ".docx", ".txt", ".eml", ".msg", ".csv", ".zip"
    )

    # Apache Tika server (fallback parser for exotic formats)
    # Set tika_enabled=False to skip Tika and use only native parsers
    tika_enabled: bool = False
    tika_server_url: str = "http://localhost:9998"


# ─────────────────────────────────────────────────────────────────────────────
# Structure detection thresholds
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class StructureConfig:
    # Min number of email header blocks to flag MULTI
    email_header_threshold: int = 2

    # Min entity blocks (Employee ID, Client No, etc.) to flag MULTI
    entity_block_threshold: int = 2

    # Min chars a split segment must have to be worth emitting
    min_segment_chars: int = 80

    # Long doc from bulk source (Slack/CRM) → always try splitting
    bulk_source_text_threshold: int = 2000


# ─────────────────────────────────────────────────────────────────────────────
# Schema validation constraints
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ValidationConfig:
    min_text_length: int = 10
    max_text_length: int = 500_000     # 500 KB of text

    allowed_sources: Tuple[str, ...] = (
        "direct_upload", "email_connector",
        "api_push", "s3_sync", "drive_sync",
    )

    allowed_file_types: Tuple[str, ...] = (
        "pdf", "docx", "txt", "eml", "msg", "csv", "zip",
    )

    allowed_departments: Tuple[str, ...] = (
        "Sales", "HR", "IT", "Legal", "Support", "Finance",
    )


# ─────────────────────────────────────────────────────────────────────────────
# PII detection  (from PS regex / rule seeds)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PIIConfig:
    # PII types that force a Quarantine policy hint
    restricted_pii: Tuple[str, ...] = ("SSN", "PAN", "IBAN", "PASSPORT")

    # PII types that force Restrict / Encrypt hint
    confidential_pii: Tuple[str, ...] = ("DOB", "PHONE", "EMAIL")


# ─────────────────────────────────────────────────────────────────────────────
# Composed app config (single import everywhere)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AppConfig:
    kafka:      KafkaConfig      = field(default_factory=KafkaConfig)
    files:      FileConfig       = field(default_factory=FileConfig)
    structure:  StructureConfig  = field(default_factory=StructureConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    pii:        PIIConfig        = field(default_factory=PIIConfig)
    log_level:  str = "INFO"


CONFIG = AppConfig()
