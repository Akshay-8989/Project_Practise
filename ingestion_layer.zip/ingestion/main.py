"""
main.py
========
CLI entry point for the Ingestion Layer.

Usage examples:

  # Process all files in uploads/ folder
  python main.py

  # Process a specific file
  python main.py --file uploads/contract.pdf

  # Specify department metadata
  python main.py --file uploads/salary_report.docx --department Finance

  # Different source
  python main.py --folder /path/to/docs --source email_connector

  # Enable Apache Tika fallback for exotic formats
  python main.py --tika
"""

import argparse
import logging
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config.settings import CONFIG
from api.ingestion_pipeline import process_file, process_folder


def main():
    parser = argparse.ArgumentParser(
        description="Data Sensitivity Classification — Ingestion Layer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Input source
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--file", type=str,
        help="Path to a single file to ingest",
    )
    group.add_argument(
        "--folder", type=str, default=CONFIG.files.upload_folder,
        help=f"Folder to batch-process (default: {CONFIG.files.upload_folder})",
    )

    # Metadata
    parser.add_argument("--department", type=str, help="Department override")
    parser.add_argument("--author",     type=str, help="Author override")
    parser.add_argument("--source",     type=str,
                        default="direct_upload",
                        choices=list(CONFIG.validation.allowed_sources),
                        help="Ingestion source (default: direct_upload)")

    # Options
    parser.add_argument("--tika", action="store_true",
                        help="Enable Apache Tika fallback parser")
    parser.add_argument("--log-level", default=CONFIG.log_level,
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        help="Logging verbosity")

    args = parser.parse_args()

    # Apply settings
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
    )

    if args.tika:
        CONFIG.files.tika_enabled = True
        print("Apache Tika fallback enabled")

    caller_meta = {}
    if args.department:
        caller_meta["department"] = args.department
    if args.author:
        caller_meta["author"] = args.author

    # Run
    if args.file:
        print(f"\nIngesting single file: {args.file}")
        result = process_file(
            file_path=args.file,
            source=args.source,
            caller_meta=caller_meta or None,
        )
        print(f"\nResult: {result}")

    else:
        print(f"\nIngesting folder: {args.folder}")
        results = process_folder(
            folder_path=args.folder,
            source=args.source,
            caller_meta=caller_meta or None,
        )
        ok   = sum(1 for r in results if r.success)
        fail = len(results) - ok
        print(f"\nSummary: {ok} succeeded, {fail} failed out of {len(results)} files")


if __name__ == "__main__":
    main()
