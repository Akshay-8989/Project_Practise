"""
schemas/models.py
==================
All Pydantic models used across the ingestion layer.

Flow:
  UploadRequest  →  (parse)  →  ParsedDocument
  ParsedDocument →  (split)  →  DocumentSegment (for MULTI)
  ParsedDocument →  (enrich) →  IngestionPayload  (what goes to Kafka)
  Any failure    →            →  DeadLetterRecord
"""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


# ─────────────────────────────────────────────────────────────────────────────
# Enums
# ─────────────────────────────────────────────────────────────────────────────

class StructureType(str, Enum):
    SINGLE = "single"   # one logical entity → one classification later
    MULTI  = "multi"    # many sub-entities → each gets own classification later


class DocumentSource(str, Enum):
    DIRECT_UPLOAD    = "direct_upload"
    EMAIL_CONNECTOR  = "email_connector"
    API_PUSH         = "api_push"
    S3_SYNC          = "s3_sync"
    DRIVE_SYNC       = "drive_sync"


class PolicyHint(str, Enum):
    """
    Derived at ingestion time from PII flags only.
    Classification model will produce the real sensitivity label later.
    This hint helps downstream triage before the model runs.
    """
    ALLOW      = "Allow"
    ENCRYPT    = "Encrypt"
    RESTRICT   = "Restrict"
    QUARANTINE = "Quarantine"


class FailureReason(str, Enum):
    UNSUPPORTED_FORMAT = "unsupported_format"
    PARSE_FAILED       = "parse_failed"
    SCHEMA_INVALID     = "schema_invalid"
    TEXT_TOO_SHORT     = "text_too_short"
    TEXT_TOO_LONG      = "text_too_long"
    FILE_TOO_LARGE     = "file_too_large"
    EMPTY_CONTENT      = "empty_content"
    UNKNOWN            = "unknown"


# ─────────────────────────────────────────────────────────────────────────────
# Core models
# ─────────────────────────────────────────────────────────────────────────────

class DocumentSegment(BaseModel):
    """
    One logical sub-document extracted from a MULTI-structured document.
    Examples: single email from a thread, one customer record from a bulk export.
    """
    segment_id:    str = Field(default_factory=lambda: str(uuid.uuid4()))
    segment_index: int                          # 0-based position in parent
    text:          str
    segment_type:  Optional[str] = None         # "email_message", "customer_record", etc.
    char_start:    Optional[int] = None
    char_end:      Optional[int] = None
    word_count:    int = 0

    def model_post_init(self, __context):
        self.word_count = len(self.text.split())


class ParsedDocument(BaseModel):
    """Intermediate model: raw text extracted from file, before validation/enrichment."""
    file_name:  str
    file_type:  str                             # pdf, docx, txt, eml, etc.
    raw_text:   str
    page_count: Optional[int] = None           # for PDFs
    parser_used: str = "unknown"               # which parser handled this file
    parse_warnings: List[str] = Field(default_factory=list)


class IngestionPayload(BaseModel):
    """
    Final enriched payload pushed to Kafka.
    One per document (SINGLE) or one per segment (MULTI).
    """
    # Identity
    doc_id:          str = Field(default_factory=lambda: str(uuid.uuid4()))
    parent_doc_id:   Optional[str] = None      # set for MULTI segments
    ingest_id:       str = Field(default_factory=lambda: str(uuid.uuid4()))

    # File info
    file_name:       str
    file_type:       str
    source:          str = DocumentSource.DIRECT_UPLOAD.value

    # Content
    raw_text:        str
    char_count:      int = 0
    word_count:      int = 0

    # Structure info
    structure_type:  str = StructureType.SINGLE.value
    segment_index:   Optional[int] = None      # position in parent (MULTI only)
    segment_type:    Optional[str] = None      # "email_message", "contract_exhibit", etc.
    total_segments:  Optional[int] = None      # how many siblings (MULTI only)
    structure_signals: List[str] = Field(default_factory=list)

    # Metadata (from PS: source system, file type, author, department, creation date)
    department:      Optional[str] = None
    author:          Optional[str] = None
    created_at:      Optional[str] = None
    ingested_at:     str = Field(default_factory=lambda: datetime.utcnow().isoformat())

    # PII / policy
    pii_flags:           List[str] = Field(default_factory=list)
    policy_action_hint:  str = PolicyHint.ALLOW.value

    # Audit
    parser_used:         str = "unknown"
    parse_warnings:      List[str] = Field(default_factory=list)
    ingestion_version:   str = "1.0.0"

    def model_post_init(self, __context):
        self.char_count = len(self.raw_text)
        self.word_count = len(self.raw_text.split())

    @field_validator("raw_text")
    @classmethod
    def text_not_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("raw_text cannot be empty")
        return v


class AuditLogEntry(BaseModel):
    """Written to audit_logs topic for every document processed."""
    audit_id:        str = Field(default_factory=lambda: str(uuid.uuid4()))
    ingest_id:       str
    file_name:       str
    file_type:       str
    source:          str
    status:          str                        # "ingested" | "failed"
    structure_type:  Optional[str] = None
    segment_count:   int = 1
    pii_flags:       List[str] = Field(default_factory=list)
    policy_hint:     Optional[str] = None
    failure_reason:  Optional[str] = None
    failure_detail:  Optional[str] = None
    timestamp:       str = Field(default_factory=lambda: datetime.utcnow().isoformat())


class DeadLetterRecord(BaseModel):
    """Pushed to dead_letter_queue when ingestion fails at any stage."""
    dlq_id:          str = Field(default_factory=lambda: str(uuid.uuid4()))
    file_name:       str
    source:          str
    failure_reason:  str
    failure_detail:  str
    raw_payload:     Optional[Dict] = None     # whatever we had at time of failure
    failed_at:       str = Field(default_factory=lambda: datetime.utcnow().isoformat())
