"""
splitter/structure_detector.py
================================
Detects whether a parsed document is:

  SINGLE — one logical entity → one classification later
            Examples: financial report, contract, salary slip, invoice, HR form

  MULTI  — many logical sub-entities → each gets its own classification later
            Examples: email thread, PDF with many customer forms,
                      bulk CRM export, HR file with many employee records,
                      ZIP bundle (handled separately by parser)

Detection strategy:
  Pure rule-based at this stage — fast, no ML, runs inline in the ingestion
  pipeline. The classification model sits downstream; this layer's job is
  only to correctly SPLIT the document so that each segment reaches the model
  as a clean, independent unit.

Multi-doc detection signals:
  1. ≥2 email header blocks (From/To/Subject/Date)
  2. Forwarded / reply separator lines
  3. ≥2 repeated separator bars (===, ---, ___)
  4. ≥2 entity keyword blocks (Employee ID, Client No, Record #)
  5. Dense timestamped log entries (>5)
  6. Page-break markers (form feeds, "--- Page N ---")
  7. Exhibit / schedule headers (contract packets)
  8. Source-based heuristic (long CSV or CRM text → bulk export)
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from schemas.models import DocumentSegment, StructureType
from config.settings import CONFIG


# ─────────────────────────────────────────────────────────────────────────────
# Compiled patterns
# ─────────────────────────────────────────────────────────────────────────────

# Email block: starts with From: or Date: at line start
_EMAIL_HEADER = re.compile(
    r"(?:^|\n)(?:From|Date|To|Subject)\s*:.*"
    r"(?:\n(?:From|Date|To|Subject|Cc|Bcc|Reply-To)\s*:.*)*",
    re.IGNORECASE,
)

# Forwarded / reply dividers
_FWD_SEP = re.compile(
    r"(?:^|\n)-{3,}.*?(?:Forwarded|Original Message|Begin forwarded).*?-{3,}",
    re.IGNORECASE,
)

# Horizontal separator bars
_BAR_SEP = re.compile(r"(?:^|\n)(?:={5,}|-{5,}|_{5,}|\*{5,}|\#{5,})")

# Entity record headers (HR, CRM)
_ENTITY_BLOCK = re.compile(
    r"(?:^|\n)(?:Employee|Staff|Client|Customer|Record|Entry|Case|Account)"
    r"\s*(?:ID|No|#|Number|Ref)?\s*[:\-#]\s*\S+",
    re.IGNORECASE,
)

# Timestamped log lines
_LOG_LINE = re.compile(r"(?:^|\n)\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")

# Form feed / explicit page breaks
_PAGE_BREAK = re.compile(r"\f|---\s*[Pp]age\s+\d+\s*---")

# Contract exhibit / schedule / appendix sections
_EXHIBIT = re.compile(
    r"(?:^|\n)(?:Exhibit|Schedule|Annex|Appendix|Attachment)\s+[A-Z0-9]+",
    re.IGNORECASE,
)


# ─────────────────────────────────────────────────────────────────────────────
# Result dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class StructureResult:
    structure_type:  StructureType
    segments:        List[DocumentSegment] = field(default_factory=list)
    signals:         List[str] = field(default_factory=list)  # why MULTI was detected

    @property
    def segment_count(self) -> int:
        return len(self.segments)


# ─────────────────────────────────────────────────────────────────────────────
# Detector
# ─────────────────────────────────────────────────────────────────────────────

class StructureDetector:
    """
    Lightweight, synchronous detector.
    Call `detect(text, source, file_type)` to get a StructureResult.
    """

    _MIN_SEG = CONFIG.structure.min_segment_chars

    def detect(self, text: str, source: str = "", file_type: str = "") -> StructureResult:
        signals: List[str] = []
        split_positions: List[int] = []      # char offsets where new segments start

        # ── Signal 1: Email header blocks ────────────────────────────────
        email_blocks = list(_EMAIL_HEADER.finditer(text))
        if len(email_blocks) >= CONFIG.structure.email_header_threshold:
            signals.append(f"email_headers:{len(email_blocks)}")
            # First block = current/newest message; every subsequent block
            # marks the start of an older message in the thread
            for m in email_blocks[1:]:
                split_positions.append(m.start())

        # ── Signal 2: Forwarded/reply separators ─────────────────────────
        fwd_matches = list(_FWD_SEP.finditer(text))
        if fwd_matches:
            signals.append(f"forwarded_separators:{len(fwd_matches)}")
            for m in fwd_matches:
                split_positions.append(m.start())

        # ── Signal 3: Horizontal separator bars ──────────────────────────
        bar_matches = list(_BAR_SEP.finditer(text))
        if len(bar_matches) >= 2:
            signals.append(f"separator_bars:{len(bar_matches)}")
            for m in bar_matches:
                split_positions.append(m.start())

        # ── Signal 4: Entity record blocks (HR / CRM) ────────────────────
        entity_matches = list(_ENTITY_BLOCK.finditer(text))
        if len(entity_matches) >= CONFIG.structure.entity_block_threshold:
            signals.append(f"entity_blocks:{len(entity_matches)}")
            for m in entity_matches:
                split_positions.append(m.start())

        # ── Signal 5: Dense log entries ───────────────────────────────────
        log_lines = list(_LOG_LINE.finditer(text))
        if len(log_lines) > 5:
            signals.append(f"log_entries:{len(log_lines)}")
            # A new segment every 5 log lines
            for m in log_lines[5::5]:
                split_positions.append(m.start())

        # ── Signal 6: Page breaks ─────────────────────────────────────────
        pb_matches = list(_PAGE_BREAK.finditer(text))
        if len(pb_matches) >= 2:
            signals.append(f"page_breaks:{len(pb_matches)}")
            for m in pb_matches:
                split_positions.append(m.start())

        # ── Signal 7: Contract exhibits / schedules ───────────────────────
        exhibit_matches = list(_EXHIBIT.finditer(text))
        if len(exhibit_matches) >= 2:
            signals.append(f"contract_exhibits:{len(exhibit_matches)}")
            for m in exhibit_matches:
                split_positions.append(m.start())

        # ── Signal 8: Source heuristic (bulk CSV / CRM export) ───────────
        if (
            source in ("crm", "csv", "drive_sync", "s3_sync")
            and file_type in ("csv", "txt")
            and len(text) > CONFIG.structure.bulk_source_text_threshold
        ):
            signals.append("bulk_source_heuristic")
            # Split at newline every ~500 chars
            pos = 500
            while pos < len(text):
                nl = text.find("\n", pos)
                if nl != -1:
                    split_positions.append(nl)
                pos += 500

        # ── Decision ─────────────────────────────────────────────────────
        if not signals:
            return self._single(text)

        segments = self._build_segments(text, split_positions)

        if len(segments) < 2:
            # Signals fired but splitting produced only 1 usable chunk
            return self._single(text, signals)

        return StructureResult(
            structure_type=StructureType.MULTI,
            segments=segments,
            signals=signals,
        )

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _single(self, text: str, signals: List[str] = None) -> StructureResult:
        return StructureResult(
            structure_type=StructureType.SINGLE,
            segments=[DocumentSegment(
                segment_index=0,
                text=text,
                segment_type="full_document",
                char_start=0,
                char_end=len(text),
            )],
            signals=signals or [],
        )

    def _build_segments(self, text: str, raw_positions: List[int]) -> List[DocumentSegment]:
        """
        Turn a list of raw split positions into clean, non-overlapping
        DocumentSegments. Filters out fragments below MIN_SEG chars.
        """
        boundaries = sorted(set([0] + raw_positions + [len(text)]))
        segments: List[DocumentSegment] = []
        idx = 0

        for i in range(len(boundaries) - 1):
            start = boundaries[i]
            end   = boundaries[i + 1]
            chunk = text[start:end].strip()

            if len(chunk) < self._MIN_SEG:
                continue

            segments.append(DocumentSegment(
                segment_index=idx,
                text=chunk,
                segment_type=self._infer_segment_type(chunk),
                char_start=start,
                char_end=end,
            ))
            idx += 1

        return segments

    @staticmethod
    def _infer_segment_type(chunk: str) -> str:
        """
        Best-effort human-readable label for a segment.
        Informational only — not used for classification.
        """
        lower = chunk.lower()
        if re.search(r"^from\s*:", lower, re.MULTILINE):
            return "email_message"
        if re.search(r"employee|emp_id|staff_id", lower):
            return "employee_record"
        if re.search(r"client|customer|account_no|account number", lower):
            return "customer_record"
        if re.search(r"\d{4}-\d{2}-\d{2}[t ]\d{2}:\d{2}", lower):
            return "log_entry_block"
        if re.search(r"exhibit|schedule|annex|appendix", lower):
            return "contract_exhibit"
        if re.search(r"invoice|total|amount due|bill to", lower):
            return "invoice"
        if re.search(r"salary|compensation|pay slip|payroll", lower):
            return "salary_record"
        return "general_segment"
