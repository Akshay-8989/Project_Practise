"""
producer/kafka_producer.py
===========================
Thin Kafka producer wrapper used by the ingestion pipeline.

Provides:
  - send_single()     → single_entity_docs
  - send_multi()      → multi_entity_docs
  - send_audit()      → audit_logs
  - send_dlq()        → dead_letter_queue

All sends are fire-and-callback (non-blocking).
Call flush() after a batch to wait for broker acks.
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict

from kafka import KafkaProducer
from kafka.errors import KafkaError

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import CONFIG

log = logging.getLogger(__name__)


def _serialise(obj: Any) -> bytes:
    return json.dumps(obj, default=str).encode("utf-8")


class IngestionProducer:
    """
    Wraps a KafkaProducer with topic-specific convenience methods.

    Usage:
        with IngestionProducer() as prod:
            prod.send_single(payload)
            prod.send_audit(audit_entry)
    """

    def __init__(self):
        self._producer = KafkaProducer(
            bootstrap_servers   = CONFIG.kafka.bootstrap_servers,
            value_serializer    = _serialise,
            key_serializer      = lambda k: k.encode("utf-8") if k else None,
            acks                = CONFIG.kafka.acks,
            retries             = CONFIG.kafka.retries,
            compression_type    = CONFIG.kafka.compression_type,
            enable_idempotence  = CONFIG.kafka.enable_idempotence,
        )

    # ── Context manager ───────────────────────────────────────────────────

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ── Topic-specific senders ────────────────────────────────────────────

    def send_single(self, payload: Dict):
        """Valid single-entity document → single_entity_docs topic."""
        self._send(
            CONFIG.kafka.single_entity_topic,
            key=payload.get("doc_id"),
            data=payload,
        )

    def send_multi(self, payload: Dict):
        """One segment of a multi-entity document → multi_entity_docs topic."""
        self._send(
            CONFIG.kafka.multi_entity_topic,
            key=payload.get("doc_id"),
            data=payload,
        )

    def send_audit(self, entry: Dict):
        """Audit record → audit_logs topic. Key = ingest_id."""
        self._send(
            CONFIG.kafka.audit_topic,
            key=entry.get("ingest_id"),
            data=entry,
        )

    def send_dlq(self, record: Dict):
        """Failed record → dead_letter_queue. Key = file_name."""
        self._send(
            CONFIG.kafka.dlq_topic,
            key=record.get("file_name", "unknown"),
            data=record,
        )

    # ── Flush / close ─────────────────────────────────────────────────────

    def flush(self, timeout: int = 30):
        """Block until all pending messages are delivered."""
        self._producer.flush(timeout=timeout)

    def close(self):
        self.flush()
        self._producer.close()
        log.info("Kafka producer closed.")

    # ── Internal ──────────────────────────────────────────────────────────

    def _send(self, topic: str, key: str | None, data: Dict):
        try:
            (
                self._producer
                .send(topic, key=key, value=data)
                .add_callback(self._on_success)
                .add_errback(self._on_error)
            )
        except KafkaError as exc:
            log.error("Send to %s failed immediately: %s", topic, exc)

    @staticmethod
    def _on_success(meta):
        log.debug(
            "Delivered → topic=%s partition=%d offset=%d",
            meta.topic, meta.partition, meta.offset,
        )

    @staticmethod
    def _on_error(exc: KafkaError):
        log.error("Kafka delivery error: %s", exc)
