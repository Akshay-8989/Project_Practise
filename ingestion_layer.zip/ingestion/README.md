# Ingestion Layer — Data Sensitivity Classification System

## What This Layer Does

Accepts documents from multiple sources, parses them, detects their structure,
validates their schema, enriches with metadata, detects PII patterns, and
streams clean payloads to Kafka. **No classification happens here.**

---

## Full Pipeline Flow

```
Uploads / Emails / APIs / Storage
            │
            ▼
    File Type Detection
    (extension → parser routing)
            │
            ▼
    Text Extraction
    pdfplumber (PDF) | python-docx (DOCX)
    native (TXT/EML/CSV) | Apache Tika (fallback)
            │
            ▼
    Single vs Multi-Entity Check
    (rule-based, no ML)
            │
      ┌─────┴──────┐
   SINGLE         MULTI
      │          (split into N segments)
      └─────┬──────┘
            │
    Schema Validation
    (required fields, enums, text length, date format)
            │
    Metadata Enrichment
    (source, file type, author, department, created_at)
            │
    PII Detection
    (SSN / PAN / IBAN / DOB / email / phone)
            │
    ┌───────┴──────────┐
  valid               invalid
    │                   │
Kafka publish     Dead Letter Queue
    │
  Audit Log
```

---

## Kafka Topics

| Topic | Content |
|---|---|
| `single_entity_docs` | One coherent document (contract, report, invoice) → gets ONE classification |
| `multi_entity_docs` | One segment extracted from a composite doc → gets its OWN classification |
| `audit_logs` | Every file processed: status, structure type, PII flags, timestamps |
| `dead_letter_queue` | Files that failed: parse error, schema violation, unsupported format |

### Why Single vs Multi?

A document like a financial report is **SINGLE** — it's one entity, it gets one label.

A document that's an email thread dump is **MULTI** — it contains N separate emails,
each is its own logical entity and may have a different sensitivity level.
A Public cover email attached to a Restricted contract cannot be collapsed into one classification.

The final label for a MULTI document = max severity across all segment labels.

Severity order: `Public < Internal < Confidential < Restricted`

---

## Structure Detection Signals

The `StructureDetector` runs entirely rule-based (no model call) and looks for:

| Signal | Example |
|---|---|
| ≥2 email header blocks (From/To/Subject) | Forwarded email thread |
| Forwarded message separators | `--- Forwarded Message ---` |
| ≥2 horizontal separator bars | HR bulk export with `======` dividers |
| ≥2 entity blocks (Employee ID, Client No) | CRM export |
| >5 timestamped log entries | System log dump |
| ≥2 page-break markers | Contract with exhibits |
| ≥2 Exhibit/Schedule/Annex headers | Contract packet |
| Long CSV/CRM text from bulk source | Bulk export heuristic |

---

## PII Detection (from PS Regex/Rule Seeds)

| PII Type | Policy Hint |
|---|---|
| SSN / PAN / IBAN / Passport | **Quarantine** |
| DOB / Phone / Email | **Restrict** |
| None detected | **Allow** |

---

## Project Structure

```
ingestion/
├── main.py                          # CLI entry point
├── requirements.txt
├── uploads/                         # Drop files here
│
├── api/
│   └── ingestion_pipeline.py        # Orchestrator: wires all steps together
│
├── parser/
│   └── file_parser.py               # pdfplumber | python-docx | native | tika
│
├── splitter/
│   └── structure_detector.py        # Single vs Multi detection + splitting
│
├── validator/
│   └── schema_validator.py          # Schema + business rule validation
│
├── utils/
│   ├── pii_detector.py              # SSN/PAN/IBAN/DOB/email/phone patterns
│   └── metadata_enricher.py        # author, department, created_at extraction
│
├── producer/
│   └── kafka_producer.py            # Kafka producer wrapper
│
├── schemas/
│   └── models.py                    # All Pydantic models
│
└── config/
    └── settings.py                  # All configuration knobs
```

---

## Quick Start

### 1. Start Kafka (any method — no Docker required)

Option A — Kafka binary:
```bash
# Download from https://kafka.apache.org/downloads
bin/zookeeper-server-start.sh config/zookeeper.properties
bin/kafka-server-start.sh config/server.properties
```

Option B — Confluent Cloud / any managed Kafka  
Update `bootstrap_servers` in `config/settings.py`.

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Drop files into uploads/

```
uploads/
  contract.pdf
  salary_report.docx
  email_thread.txt
  hr_bulk_export.csv
```

### 4. Run

```bash
# Process all files in uploads/ folder
python main.py

# Single file
python main.py --file uploads/contract.pdf

# With department metadata
python main.py --file uploads/salary.docx --department Finance

# Email connector source
python main.py --folder /path/to/emails --source email_connector

# Enable Tika fallback
python main.py --tika
```

---

## Configuration

Edit `config/settings.py`:

| Setting | Default | Purpose |
|---|---|---|
| `bootstrap_servers` | `localhost:9092` | Kafka broker |
| `upload_folder` | `uploads` | Default input folder |
| `max_file_size_mb` | `50` | Max file size |
| `tika_enabled` | `False` | Enable Tika fallback |
| `min_text_length` | `10` | Min text chars |
| `max_text_length` | `500000` | Max text chars |
| `email_header_threshold` | `2` | Min email headers to flag MULTI |
| `entity_block_threshold` | `2` | Min entity blocks to flag MULTI |

---

## Programmatic API

```python
from api.ingestion_pipeline import process_file, process_folder, process_bytes

# Single file
result = process_file(
    file_path="uploads/report.pdf",
    source="direct_upload",
    caller_meta={"department": "Finance", "author": "John Doe"},
)
print(result.structure_type)   # "single"
print(result.pii_flags)        # []
print(result.policy_hint)      # "Allow"

# Folder batch
results = process_folder("uploads/", source="email_connector")

# Raw bytes (for REST API)
with open("doc.pdf", "rb") as f:
    result = process_bytes(f.read(), file_name="doc.pdf", source="api_push")
```

---

## Compliance (from PS Constraints)

| Constraint | How addressed |
|---|---|
| C1: No raw PII stored | PII is **flagged** at ingestion; masking happens downstream before persistence |
| C2: Auditable | Every record gets an audit log entry with structure type, PII flags, timestamps |
| C3: On-prem support | Kafka binary runs fully on-prem, no Docker required |
| C4: Dual-approval for labels | No labels assigned here; label comes only from Classification Layer |
| C5: mTLS for clients | Configure `ssl_*` options in `KafkaConfig` in settings.py |

---

## What Comes Next (Classification Layer)

Each Kafka message from this layer contains clean, validated `raw_text` ready for:

1. **Pre-processing** → Presidio PII masking → tokenization
2. **Feature Engineering** → TF-IDF + BERT/RoBERTa/DeBERTa embeddings  
3. **Classification** → Ensemble (LR + XGBoost + fine-tuned transformer)
4. **Explainability** → SHAP / LIME evidence tokens
5. **Policy Engine** → Rule overlay for Restricted token override
6. **Output API** → FastAPI → label + confidence + evidence + action
