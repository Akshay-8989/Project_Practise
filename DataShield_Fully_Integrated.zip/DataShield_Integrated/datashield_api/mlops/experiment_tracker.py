"""
mlops/experiment_tracking/tracker.py
──────────────────────────────────────
MLflow experiment tracking wrapper.

Wraps MLflow so the rest of the codebase never imports mlflow directly.
Makes swapping tracking backends (e.g. W&B, Neptune) a one-file change.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Dict, Optional

try:
    import mlflow
    _MLFLOW_AVAILABLE = True
except ImportError:
    _MLFLOW_AVAILABLE = False

logger = logging.getLogger(__name__)


class ExperimentTracker:
    """
    Thin MLflow wrapper for logging training runs.

    Usage:
        tracker = ExperimentTracker(experiment_name="sensitivity-classifier")
        with tracker.start_run(run_name="deberta-v3-run1") as run_id:
            tracker.log_params({"lr": 2e-5, "epochs": 5})
            tracker.log_metrics({"f1_macro": 0.91, "recall_restricted": 0.98})
            tracker.log_artifact("/path/to/confusion_matrix.png")
    """

    def __init__(
        self,
        experiment_name: str = "sensitivity-classifier",
        tracking_uri: str = "mlruns",
    ):
        self.experiment_name = experiment_name
        self._active_run_id: Optional[str] = None

        if _MLFLOW_AVAILABLE:
            mlflow.set_tracking_uri(tracking_uri)
            mlflow.set_experiment(experiment_name)
            logger.info("MLflow tracking initialised. Experiment: %s", experiment_name)
        else:
            logger.warning("mlflow not installed — tracking calls are no-ops.")

    @contextmanager
    def start_run(self, run_name: Optional[str] = None, tags: Optional[Dict] = None):
        """Context manager for a single training run."""
        if not _MLFLOW_AVAILABLE:
            yield "NO-OP-RUN-ID"
            return

        with mlflow.start_run(run_name=run_name, tags=tags or {}) as run:
            self._active_run_id = run.info.run_id
            logger.info("MLflow run started: %s (id=%s)", run_name, self._active_run_id)
            yield self._active_run_id
            logger.info("MLflow run ended: %s", self._active_run_id)

    def log_params(self, params: Dict[str, Any]) -> None:
        if _MLFLOW_AVAILABLE:
            mlflow.log_params(params)

    def log_metrics(self, metrics: Dict[str, float], step: Optional[int] = None) -> None:
        if _MLFLOW_AVAILABLE:
            mlflow.log_metrics(metrics, step=step)
        logger.info("Metrics: %s", metrics)

    def log_artifact(self, local_path: str, artifact_path: Optional[str] = None) -> None:
        if _MLFLOW_AVAILABLE:
            mlflow.log_artifact(local_path, artifact_path)

    def log_model(self, model, artifact_path: str = "model") -> None:
        """Log a sklearn-compatible model. Extend for pytorch/transformers."""
        if _MLFLOW_AVAILABLE:
            mlflow.sklearn.log_model(model, artifact_path)

    def get_best_run(
        self,
        metric: str = "f1_macro",
        ascending: bool = False,
    ) -> Optional[Dict]:
        """
        Returns the run dict with the best value of `metric` in this experiment.
        Returns None if mlflow is unavailable or no runs exist.
        """
        if not _MLFLOW_AVAILABLE:
            return None
        try:
            order = "ASC" if ascending else "DESC"
            runs = mlflow.search_runs(
                experiment_names=[self.experiment_name],
                order_by=[f"metrics.{metric} {order}"],
                max_results=1,
            )
            if runs.empty:
                return None
            return runs.iloc[0].to_dict()
        except Exception as exc:
            logger.error("Failed to query best run: %s", exc)
            return None
