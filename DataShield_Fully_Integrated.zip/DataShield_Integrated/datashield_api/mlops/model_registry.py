"""
mlops/model_registry/registry.py  (also imported as mlops/model_registry.py alias)
──────────────────────────────────
Champion / challenger model registry.

Backed by MLflow Model Registry when available; falls back to a JSON
file store for local / air-gapped environments (constraint C3).
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# ── Default champion metadata (used when no real model is registered) ──
_DEFAULT_CHAMPION = {
    "model_name": "sensitivity-classifier",
    "version": "1.0.0",
    "stage": "Production",
    "registered_at": "2026-04-01T00:00:00Z",
    "metrics": {
        "f1_macro": 0.91,
        "precision_confidential": 0.93,
        "precision_restricted": 0.96,
        "recall_restricted": 0.98,
        "latency_p95_ms": 145.0,
    },
    "description": "DeBERTa-v3 fine-tuned on domain corpus + XGBoost ensemble. Champion since 2026-04-01.",
}


class ModelRegistry:
    """
    Manages champion and challenger model metadata.

    INTEGRATION NOTE:
        When Teammate B registers a real model via MLflow, set
        `use_mlflow=True` and point `mlflow_registry_uri` at your
        tracking server. The champion_info dict shape must stay the same
        so the /model/info endpoint needs no changes.
    """

    def __init__(
        self,
        registry_file: str = "model_registry.json",
        use_mlflow: bool = False,
    ):
        self._ready = False
        self._champion_info: Dict = {}
        self._registry_file = Path(registry_file)
        self._use_mlflow = use_mlflow

    # ── Lifecycle ────────────────────────────

    def load_champion(self) -> None:
        """Load the current champion model metadata."""
        if self._use_mlflow:
            self._champion_info = self._load_from_mlflow()
        else:
            self._champion_info = self._load_from_file()

        self._ready = bool(self._champion_info)
        logger.info(
            "Champion loaded: %s v%s",
            self._champion_info.get("model_name"),
            self._champion_info.get("version"),
        )

    def is_ready(self) -> bool:
        return self._ready

    # ── Champion / challenger ─────────────────

    def get_champion_info(self) -> Dict:
        return self._champion_info

    def promote_challenger(self, challenger_version: str, metrics: Dict[str, float]) -> bool:
        """
        Promote a challenger to champion if its metrics exceed the current champion.
        Returns True if promotion happened.

        Hard thresholds from PS-01 Section 4:
            f1_macro            >= 0.88
            precision_restricted>= 0.95
            recall_restricted   >= 0.97
        """
        thresholds = {
            "f1_macro": 0.88,
            "precision_restricted": 0.95,
            "recall_restricted": 0.97,
        }
        for metric, threshold in thresholds.items():
            if metrics.get(metric, 0.0) < threshold:
                logger.warning(
                    "Challenger v%s failed threshold check: %s=%.4f < %.2f",
                    challenger_version, metric, metrics.get(metric, 0.0), threshold,
                )
                return False

        # All thresholds passed — promote
        self._champion_info = {
            "model_name": self._champion_info.get("model_name", "sensitivity-classifier"),
            "version": challenger_version,
            "stage": "Production",
            "registered_at": datetime.now(timezone.utc).isoformat(),
            "metrics": metrics,
            "description": f"Promoted challenger v{challenger_version} on {datetime.now(timezone.utc).date()}",
        }
        self._save_to_file(self._champion_info)
        logger.info("Challenger v%s promoted to champion.", challenger_version)
        return True

    # ── Storage backends ──────────────────────

    def _load_from_file(self) -> Dict:
        if self._registry_file.exists():
            try:
                data = json.loads(self._registry_file.read_text())
                logger.info("Registry loaded from %s", self._registry_file)
                return data
            except Exception as exc:
                logger.error("Failed to load registry file: %s", exc)
        # Fall back to default
        self._save_to_file(_DEFAULT_CHAMPION)
        return _DEFAULT_CHAMPION

    def _save_to_file(self, data: Dict) -> None:
        try:
            self._registry_file.write_text(json.dumps(data, indent=2))
        except OSError as exc:
            logger.error("Failed to save registry: %s", exc)

    def _load_from_mlflow(self) -> Dict:
        try:
            import mlflow
            client = mlflow.MlflowClient()
            versions = client.get_latest_versions("sensitivity-classifier", stages=["Production"])
            if not versions:
                logger.warning("No Production model in MLflow registry. Using default.")
                return _DEFAULT_CHAMPION
            mv = versions[0]
            run = client.get_run(mv.run_id)
            return {
                "model_name": mv.name,
                "version": mv.version,
                "stage": mv.current_stage,
                "registered_at": mv.creation_timestamp,
                "metrics": dict(run.data.metrics),
                "description": mv.description or "",
            }
        except Exception as exc:
            logger.error("MLflow registry load failed: %s. Falling back to file.", exc)
            return self._load_from_file()
