"""
mlops/drift_monitoring/monitor.py
───────────────────────────────────
Model and data drift monitoring via Evidently AI.

Checks:
  1. Label distribution drift (concept drift proxy)
  2. Prediction confidence drift
  3. Feature/text-length drift

Triggers retraining when performance drops > 3 % (PS-01 Section 4: Drift Alert SLA).
"""

from __future__ import annotations

import json
import logging
from collections import Counter, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Deque, Dict, List, Optional

logger = logging.getLogger(__name__)

# Rolling window size for drift comparison
_WINDOW_SIZE = 1_000
# Retraining alert threshold (3 % relative degradation)
_DRIFT_THRESHOLD = 0.03


class DriftMonitor:
    """
    Lightweight online drift detector.

    Compares a rolling window of recent predictions against a reference
    distribution captured at training time.

    INTEGRATION NOTE:
        Call `monitor.record_prediction(label, confidence)` inside the
        FastAPI classify route (after receiving ClassificationResult).
        The monitor handles all windowing and alerting internally.

        For full Evidently AI HTML reports, call `monitor.generate_report()`.
    """

    def __init__(
        self,
        reference_distribution: Optional[Dict[str, float]] = None,
        alert_sink: Optional[str] = "drift_alerts.jsonl",
    ):
        # Reference label distribution from training set
        self._reference: Dict[str, float] = reference_distribution or {
            "Public": 0.30,
            "Internal": 0.35,
            "Confidential": 0.25,
            "Restricted": 0.10,
        }
        self._window: Deque[dict] = deque(maxlen=_WINDOW_SIZE)
        self._alert_sink = Path(alert_sink) if alert_sink else None
        self._alerts_fired: List[dict] = []

    # ── Public interface ─────────────────────

    def record_prediction(self, label: str, confidence: float) -> None:
        """Call this for every live classification."""
        self._window.append({"label": label, "confidence": confidence})

    def check_drift(self) -> dict:
        """
        Evaluate current window against reference.
        Returns a drift report dict and fires an alert if threshold is breached.
        """
        if len(self._window) < 100:
            return {"status": "insufficient_data", "window_size": len(self._window)}

        counts = Counter(r["label"] for r in self._window)
        total = sum(counts.values())
        current_dist = {k: counts.get(k, 0) / total for k in self._reference}

        # PSI (Population Stability Index) per class
        psi_values: Dict[str, float] = {}
        for label in self._reference:
            ref = max(self._reference[label], 1e-6)
            cur = max(current_dist.get(label, 1e-6), 1e-6)
            psi_values[label] = (cur - ref) * (cur / ref)

        total_psi = sum(psi_values.values())
        avg_confidence = sum(r["confidence"] for r in self._window) / len(self._window)

        drift_detected = total_psi > _DRIFT_THRESHOLD
        report = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "window_size": len(self._window),
            "current_distribution": current_dist,
            "reference_distribution": self._reference,
            "psi_per_class": psi_values,
            "total_psi": round(total_psi, 6),
            "avg_confidence": round(avg_confidence, 4),
            "drift_detected": drift_detected,
            "retraining_recommended": drift_detected,
        }

        if drift_detected:
            self._fire_alert(report)

        return report

    def generate_report(self, output_path: str = "drift_report.html") -> str:
        """
        Generate a full Evidently AI HTML drift report.
        Requires `evidently` to be installed.

        INTEGRATION NOTE:
            Hook this into a scheduled job (e.g. daily cron or Airflow DAG).
            The report is written to `output_path` and can be served statically.
        """
        try:
            import pandas as pd
            from evidently.report import Report
            from evidently.metric_preset import DataDriftPreset

            if len(self._window) < 10:
                return "Insufficient data for Evidently report."

            ref_df = pd.DataFrame([
                {"label": label}
                for label, freq in self._reference.items()
                for _ in range(int(freq * 100))
            ])
            cur_df = pd.DataFrame(list(self._window))

            report = Report(metrics=[DataDriftPreset()])
            report.run(reference_data=ref_df, current_data=cur_df)
            report.save_html(output_path)
            logger.info("Evidently drift report saved to %s", output_path)
            return output_path
        except ImportError:
            logger.warning("evidently not installed — skipping HTML report generation.")
            return "evidently not installed"
        except Exception as exc:
            logger.error("Evidently report failed: %s", exc)
            return str(exc)

    def get_alerts(self) -> List[dict]:
        return list(self._alerts_fired)

    # ── Internal ─────────────────────────────

    def _fire_alert(self, report: dict) -> None:
        alert = {"alert_type": "drift", **report}
        self._alerts_fired.append(alert)
        logger.warning("DRIFT ALERT: PSI=%.4f > threshold=%.3f. Retraining recommended within 48h.",
                       report["total_psi"], _DRIFT_THRESHOLD)
        if self._alert_sink:
            try:
                with self._alert_sink.open("a") as fh:
                    fh.write(json.dumps(alert) + "\n")
            except OSError as exc:
                logger.error("Failed to write drift alert: %s", exc)
