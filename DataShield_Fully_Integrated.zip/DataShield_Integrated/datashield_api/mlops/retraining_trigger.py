"""
mlops/retraining/trigger.py
────────────────────────────
Automated retraining trigger.

Fires when:
  A) Drift alert is raised (PSI > 3 % threshold) — must retrain within 48 h.
  B) Human correction rate exceeds 5 % over a rolling window (PS-01 KPI).
  C) Explicit manual trigger via CLI / admin endpoint.

Retraining pipeline stub:
  The `run_retraining_pipeline()` method is the integration point.
  In production it would launch an MLflow project, a Kubernetes Job,
  or an Airflow DAG run.
"""

from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, List, Optional

logger = logging.getLogger(__name__)

_CORRECTION_RATE_THRESHOLD = 0.05   # 5 % → triggers retraining
_CORRECTION_WINDOW = 1_000           # rolling window for correction rate calc


class RetrainingTrigger:
    """
    Monitors correction rate and drift alerts, fires retraining when needed.

    INTEGRATION NOTE:
        1. Call `trigger.record_classification(was_corrected=False)` for
           every live classification from the API.
        2. Call `trigger.record_classification(was_corrected=True)` when a
           /feedback correction is received.
        3. Call `trigger.on_drift_alert()` from DriftMonitor when PSI > threshold.
        4. Replace `_launch_pipeline()` with your actual retraining job dispatch.
    """

    def __init__(
        self,
        pipeline_fn: Optional[Callable] = None,
        log_path: str = "retraining_log.jsonl",
    ):
        self._pipeline_fn = pipeline_fn or self._default_pipeline_fn
        self._log_path = Path(log_path)
        self._lock = threading.Lock()

        self._total_classifications = 0
        self._corrections_in_window: List[bool] = []
        self._retraining_runs: List[dict] = []

    # ── Public interface ─────────────────────

    def record_classification(self, was_corrected: bool = False) -> None:
        with self._lock:
            self._total_classifications += 1
            self._corrections_in_window.append(was_corrected)
            # Keep rolling window
            if len(self._corrections_in_window) > _CORRECTION_WINDOW:
                self._corrections_in_window.pop(0)

        if was_corrected:
            self._check_correction_rate()

    def on_drift_alert(self, drift_report: dict) -> None:
        """Called by DriftMonitor when drift threshold is breached."""
        logger.warning("Retraining trigger received drift alert. Scheduling pipeline.")
        self._launch_pipeline(reason="drift_alert", metadata=drift_report)

    def force_retrain(self, reason: str = "manual") -> dict:
        """Admin-triggered retraining."""
        return self._launch_pipeline(reason=reason)

    def get_correction_rate(self) -> float:
        if not self._corrections_in_window:
            return 0.0
        return sum(self._corrections_in_window) / len(self._corrections_in_window)

    def get_history(self) -> List[dict]:
        return list(self._retraining_runs)

    # ── Internal ─────────────────────────────

    def _check_correction_rate(self) -> None:
        rate = self.get_correction_rate()
        if rate > _CORRECTION_RATE_THRESHOLD:
            logger.warning(
                "Human correction rate %.2f%% exceeds %.0f%% threshold. Triggering retraining.",
                rate * 100, _CORRECTION_RATE_THRESHOLD * 100,
            )
            self._launch_pipeline(
                reason="high_correction_rate",
                metadata={"correction_rate": rate},
            )

    def _launch_pipeline(self, reason: str, metadata: Optional[dict] = None) -> dict:
        run_record = {
            "trigger_reason": reason,
            "triggered_at": datetime.now(timezone.utc).isoformat(),
            "correction_rate_at_trigger": self.get_correction_rate(),
            "total_classifications": self._total_classifications,
            "metadata": metadata or {},
            "status": "launched",
        }
        try:
            self._pipeline_fn(run_record)
            run_record["status"] = "launched"
        except Exception as exc:
            run_record["status"] = "failed"
            run_record["error"] = str(exc)
            logger.error("Retraining pipeline launch failed: %s", exc)

        with self._lock:
            self._retraining_runs.append(run_record)
        self._write_log(run_record)
        return run_record

    def _write_log(self, record: dict) -> None:
        try:
            with self._log_path.open("a") as fh:
                fh.write(json.dumps(record) + "\n")
        except OSError as exc:
            logger.error("Failed to write retraining log: %s", exc)

    @staticmethod
    def _default_pipeline_fn(run_record: dict) -> None:
        """
        Stub retraining launcher.

        INTEGRATION NOTE — replace with one of:
            - mlflow.projects.run(".", entry_point="retrain", ...)
            - subprocess.Popen(["python", "train.py", ...])
            - requests.post("https://airflow/api/v1/dags/retrain/dagRuns", ...)
            - kubernetes.client dispatch
        """
        logger.info(
            "[STUB] Retraining pipeline would launch here. Reason: %s",
            run_record.get("trigger_reason"),
        )
