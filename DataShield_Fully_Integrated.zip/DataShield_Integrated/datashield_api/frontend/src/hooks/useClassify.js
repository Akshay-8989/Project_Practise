// hooks/useClassify.js
// ─────────────────────────────────────────────────────────
// Manages the state for the Classify page:
//   - single document classification
//   - batch classification
//   - history of results in the current session
// ─────────────────────────────────────────────────────────

import { useState, useCallback } from 'react';
import { classifyDocument, classifyBatch } from '../utils/api';

export function useClassify() {
  const [result, setResult]     = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState(null);
  const [history, setHistory]   = useState([]);   // session history

  const classify = useCallback(async (text, meta = {}) => {
    setLoading(true);
    setError(null);
    try {
      const data = await classifyDocument({ text, ...meta });
      setResult(data);
      setHistory(prev => [data, ...prev].slice(0, 50));  // keep last 50
      return data;
    } catch (err) {
      const msg = err.response?.data?.detail || err.message || 'Classification failed';
      setError(msg);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const classifyMany = useCallback(async (documents) => {
    setLoading(true);
    setError(null);
    try {
      const data = await classifyBatch(documents);
      // Add all successful results to history
      if (data.results) {
        setHistory(prev => [...data.results, ...prev].slice(0, 50));
      }
      return data;
    } catch (err) {
      const msg = err.response?.data?.detail || err.message || 'Batch classification failed';
      setError(msg);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearResult = () => { setResult(null); setError(null); };

  return { result, loading, error, history, classify, classifyMany, clearResult };
}
