// src/App.js
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import './styles/globals.css';

import Sidebar   from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Classify  from './pages/Classify';
import Batch     from './pages/Batch';
import AuditLog  from './pages/AuditLog';
import Feedback  from './pages/Feedback';
import ModelInfo from './pages/ModelInfo';

export default function App() {
  return (
    <BrowserRouter>
      <div className="noise-bg scanlines" style={{ display: 'flex', minHeight: '100vh', position: 'relative', zIndex: 2 }}>

        {/* Global grid overlay */}
        <div style={{
          position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none',
          backgroundImage: `
            linear-gradient(rgba(59,130,246,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59,130,246,0.03) 1px, transparent 1px)
          `,
          backgroundSize: '48px 48px',
        }} />

        <Sidebar />

        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative', zIndex: 2 }}>
          <Routes>
            <Route path="/"         element={<Dashboard />} />
            <Route path="/classify" element={<Classify />}  />
            <Route path="/batch"    element={<Batch />}     />
            <Route path="/audit"    element={<AuditLog />}  />
            <Route path="/feedback" element={<Feedback />}  />
            <Route path="/model"    element={<ModelInfo />} />
            <Route path="*"         element={<Navigate to="/" replace />} />
          </Routes>
        </main>

        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: 'var(--bg-raised)',
              color: 'var(--text-primary)',
              border: '1px solid var(--border-mid)',
              fontFamily: 'var(--font-mono)',
              fontSize: '0.78rem',
              borderRadius: '8px',
            },
          }}
        />
      </div>
    </BrowserRouter>
  );
}
