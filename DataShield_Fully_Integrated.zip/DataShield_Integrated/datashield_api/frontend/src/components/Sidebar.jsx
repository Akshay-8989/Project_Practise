// components/Sidebar.jsx
import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  Shield, Zap, BarChart2, GitBranch, FileSearch,
  MessageSquare, Settings, ChevronRight, Activity
} from 'lucide-react';

const NAV = [
  { to: '/',          icon: BarChart2,   label: 'Dashboard',    desc: 'Overview & metrics' },
  { to: '/classify',  icon: Zap,         label: 'Classify',     desc: 'Analyse documents' },
  { to: '/batch',     icon: GitBranch,   label: 'Batch',        desc: 'Bulk classification' },
  { to: '/audit',     icon: FileSearch,  label: 'Audit Log',    desc: 'Compliance trail' },
  { to: '/feedback',  icon: MessageSquare,label:'Feedback',     desc: 'Human corrections' },
  { to: '/model',     icon: Activity,    label: 'Model Info',   desc: 'Champion details' },
];

export default function Sidebar() {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside style={{
      width: collapsed ? 72 : 240,
      minHeight: '100vh',
      background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border-dim)',
      display: 'flex',
      flexDirection: 'column',
      transition: 'width 0.3s var(--ease-out)',
      flexShrink: 0,
      position: 'relative',
      zIndex: 10,
    }}>

      {/* Logo */}
      <div style={{
        padding: collapsed ? '24px 0' : '24px 20px',
        borderBottom: '1px solid var(--border-dim)',
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        justifyContent: collapsed ? 'center' : 'flex-start',
        overflow: 'hidden',
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 8,
          background: 'linear-gradient(135deg, #1d4ed8, #3b82f6)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
          boxShadow: '0 0 16px var(--accent-glow)',
        }}>
          <Shield size={18} color="white" />
        </div>
        {!collapsed && (
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1rem', color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
              DataShield
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-muted)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>
              PS-01 · v1.0
            </div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '12px 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV.map(({ to, icon: Icon, label, desc }) => {
          const active = location.pathname === to;
          return (
            <NavLink key={to} to={to} style={{ textDecoration: 'none' }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                padding: collapsed ? '10px 0' : '10px 12px',
                borderRadius: 'var(--radius-md)',
                justifyContent: collapsed ? 'center' : 'flex-start',
                background: active ? 'var(--accent-dim)' : 'transparent',
                border: `1px solid ${active ? 'rgba(59,130,246,0.25)' : 'transparent'}`,
                transition: 'all 0.15s var(--ease-out)',
                cursor: 'pointer',
              }}
              onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--bg-hover)'; }}
              onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}
              >
                <Icon
                  size={18}
                  color={active ? 'var(--accent)' : 'var(--text-muted)'}
                  style={{ flexShrink: 0 }}
                />
                {!collapsed && (
                  <div style={{ overflow: 'hidden' }}>
                    <div style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: '0.85rem',
                      fontWeight: active ? 600 : 400,
                      color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
                      whiteSpace: 'nowrap',
                    }}>
                      {label}
                    </div>
                    <div style={{
                      fontFamily: 'var(--font-mono)',
                      fontSize: '0.65rem',
                      color: 'var(--text-muted)',
                      whiteSpace: 'nowrap',
                    }}>
                      {desc}
                    </div>
                  </div>
                )}
              </div>
            </NavLink>
          );
        })}
      </nav>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(c => !c)}
        style={{
          margin: 8,
          padding: '10px',
          background: 'transparent',
          border: '1px solid var(--border-dim)',
          borderRadius: 'var(--radius-md)',
          color: 'var(--text-muted)',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.15s',
        }}
        onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--border-mid)'; e.currentTarget.style.color = 'var(--text-secondary)'; }}
        onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border-dim)'; e.currentTarget.style.color = 'var(--text-muted)'; }}
      >
        <ChevronRight
          size={16}
          style={{ transform: collapsed ? 'rotate(0deg)' : 'rotate(180deg)', transition: 'transform 0.3s' }}
        />
      </button>
    </aside>
  );
}
