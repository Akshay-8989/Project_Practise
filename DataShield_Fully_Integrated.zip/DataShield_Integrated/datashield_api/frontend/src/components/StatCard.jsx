// components/StatCard.jsx
import React from 'react';

export default function StatCard({ label, value, sub, icon: Icon, color = 'var(--accent)', delay = 0 }) {
  return (
    <div
      className="card animate-fade-up"
      style={{ animationDelay: `${delay}s`, position: 'relative', overflow: 'hidden' }}
    >
      {/* Glow blob */}
      <div style={{
        position: 'absolute', top: -20, right: -20,
        width: 80, height: 80, borderRadius: '50%',
        background: color, opacity: 0.06, filter: 'blur(24px)',
        pointerEvents: 'none',
      }} />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: '0.65rem',
          color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase',
        }}>
          {label}
        </div>
        {Icon && (
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: `rgba(${color.includes('var') ? '59,130,246' : color}, 0.1)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '1px solid rgba(59,130,246,0.2)',
          }}>
            <Icon size={15} color={color} />
          </div>
        )}
      </div>

      <div style={{
        fontFamily: 'var(--font-display)', fontWeight: 700,
        fontSize: '1.9rem', color: 'var(--text-primary)',
        letterSpacing: '-0.03em', lineHeight: 1,
        marginBottom: 6,
      }}>
        {value}
      </div>

      {sub && (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
          {sub}
        </div>
      )}
    </div>
  );
}
