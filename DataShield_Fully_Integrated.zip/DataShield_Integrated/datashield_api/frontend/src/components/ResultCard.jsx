// components/ResultCard.jsx
// Displays a single classification result with all fields.

import React, { useState } from 'react';
import { getLabelClass, getActionClass } from '../utils/api';
import { submitFeedback } from '../utils/api';
import { CheckCircle, AlertTriangle, Clock, Cpu, Eye, RotateCcw } from 'lucide-react';
import toast from 'react-hot-toast';

function ConfidenceBar({ label, value, color }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--text-secondary)' }}>{label}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color }}>{(value * 100).toFixed(1)}%</span>
      </div>
      <div style={{ height: 4, background: 'var(--bg-raised)', borderRadius: 2, overflow: 'hidden' }}>
        <div style={{
          height: '100%', width: `${value * 100}%`,
          background: color, borderRadius: 2,
          transition: 'width 0.8s var(--ease-out)',
        }} />
      </div>
    </div>
  );
}

const LABEL_COLORS = {
  Public: 'var(--col-public)',
  Internal: 'var(--col-internal)',
  Confidential: 'var(--col-confidential)',
  Restricted: 'var(--col-restricted)',
};

const LABELS = ['Public', 'Internal', 'Confidential', 'Restricted'];

export default function ResultCard({ result, onFeedbackSubmit }) {
  const [showFeedback, setShowFeedback] = useState(false);
  const [correctedLabel, setCorrectedLabel] = useState('');
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!result) return null;

  const handleFeedback = async () => {
    if (!correctedLabel) return;
    setSubmitting(true);
    try {
      await submitFeedback({
        doc_id: result.doc_id,
        original_label: result.predicted_label,
        corrected_label: correctedLabel,
        reason,
      });
      toast.success('Correction submitted — thank you!');
      setShowFeedback(false);
      onFeedbackSubmit?.();
    } catch {
      toast.error('Failed to submit correction');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="card animate-fade-up" style={{ marginTop: 24 }}>
      {/* Header row */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', marginBottom: 6, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Classification Result
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span className={`label-badge ${getLabelClass(result.predicted_label)}`} style={{ fontSize: '0.85rem', padding: '4px 14px' }}>
              {result.predicted_label}
            </span>
            <span className={`label-badge ${getActionClass(result.policy_action)}`} style={{ fontSize: '0.8rem' }}>
              {result.policy_action}
            </span>
            {result.policy_override && (
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 4,
                fontFamily: 'var(--font-mono)', fontSize: '0.65rem',
                color: 'var(--col-restricted)', background: 'var(--col-restricted-dim)',
                border: '1px solid rgba(239,68,68,0.3)', borderRadius: 3, padding: '3px 8px',
              }}>
                <AlertTriangle size={10} /> RULE OVERRIDE
              </span>
            )}
          </div>
        </div>

        {/* Meta chips */}
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            <Clock size={12} /> {result.total_latency_ms?.toFixed(1)} ms
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            <Cpu size={12} /> {result.model_version}
          </div>
        </div>
      </div>

      {/* Doc ID */}
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)', marginBottom: 20, padding: '6px 10px', background: 'var(--bg-raised)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-dim)' }}>
        doc_id: {result.doc_id}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Confidence scores */}
        <div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', marginBottom: 12, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Confidence Scores
          </div>
          {LABELS.map(label => (
            <ConfidenceBar
              key={label}
              label={label}
              value={result.confidence_scores?.[label] || 0}
              color={LABEL_COLORS[label]}
            />
          ))}
        </div>

        {/* Evidence + PII */}
        <div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', marginBottom: 12, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            <Eye size={10} style={{ display: 'inline', marginRight: 5 }} />
            Evidence Tokens
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
            {result.evidence_tokens?.map((token, i) => (
              <span key={i} style={{
                fontFamily: 'var(--font-mono)', fontSize: '0.68rem',
                color: 'var(--text-accent)', background: 'var(--accent-dim)',
                border: '1px solid rgba(59,130,246,0.2)', borderRadius: 3, padding: '2px 8px',
              }}>
                {token}
              </span>
            ))}
          </div>

          {result.pii_types_detected?.length > 0 && (
            <>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', marginBottom: 8, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                PII Detected
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {result.pii_types_detected.map((pii, i) => (
                  <span key={i} style={{
                    fontFamily: 'var(--font-mono)', fontSize: '0.68rem',
                    color: 'var(--col-restricted)', background: 'var(--col-restricted-dim)',
                    border: '1px solid rgba(239,68,68,0.2)', borderRadius: 3, padding: '2px 8px',
                  }}>
                    {pii}
                  </span>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Feedback section */}
      <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--border-dim)' }}>
        {!showFeedback ? (
          <button
            onClick={() => setShowFeedback(true)}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              fontFamily: 'var(--font-mono)', fontSize: '0.72rem',
              color: 'var(--text-muted)', background: 'transparent',
              border: '1px solid var(--border-dim)', borderRadius: 'var(--radius-sm)',
              padding: '6px 12px', cursor: 'pointer',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--border-mid)'; e.currentTarget.style.color = 'var(--text-secondary)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border-dim)'; e.currentTarget.style.color = 'var(--text-muted)'; }}
          >
            <RotateCcw size={11} /> Submit Correction
          </button>
        ) : (
          <div className="animate-fade-up" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
              Correct Label
            </div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {LABELS.filter(l => l !== result.predicted_label).map(label => (
                <button
                  key={label}
                  onClick={() => setCorrectedLabel(label)}
                  className={`label-badge ${getLabelClass(label)}`}
                  style={{
                    cursor: 'pointer', border: correctedLabel === label ? '2px solid currentColor' : '1px solid rgba(255,255,255,0.15)',
                    opacity: correctedLabel && correctedLabel !== label ? 0.5 : 1,
                    transition: 'all 0.15s',
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
            <input
              placeholder="Reason (optional)"
              value={reason}
              onChange={e => setReason(e.target.value)}
              style={{
                background: 'var(--bg-raised)', border: '1px solid var(--border-mid)',
                borderRadius: 'var(--radius-sm)', padding: '8px 12px',
                fontFamily: 'var(--font-mono)', fontSize: '0.8rem',
                color: 'var(--text-primary)', outline: 'none', width: '100%',
              }}
            />
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                onClick={handleFeedback}
                disabled={!correctedLabel || submitting}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  fontFamily: 'var(--font-mono)', fontSize: '0.72rem',
                  color: 'white', background: correctedLabel ? 'var(--accent)' : 'var(--bg-hover)',
                  border: 'none', borderRadius: 'var(--radius-sm)',
                  padding: '7px 16px', cursor: correctedLabel ? 'pointer' : 'not-allowed',
                  opacity: submitting ? 0.6 : 1, transition: 'all 0.15s',
                }}
              >
                <CheckCircle size={12} /> {submitting ? 'Submitting…' : 'Submit'}
              </button>
              <button
                onClick={() => setShowFeedback(false)}
                style={{
                  fontFamily: 'var(--font-mono)', fontSize: '0.72rem',
                  color: 'var(--text-muted)', background: 'transparent',
                  border: '1px solid var(--border-dim)', borderRadius: 'var(--radius-sm)',
                  padding: '7px 14px', cursor: 'pointer',
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
