// components/TopBar.jsx
import React, { useEffect, useState } from 'react';
import { fetchHealth } from '../utils/api';
import { Activity, Wifi, WifiOff } from 'lucide-react';

export default function TopBar({ title, subtitle }) {
  const [online, setOnline] = useState(null);

  useEffect(() => {
    fetchHealth()
      .then(() => setOnline(true))
      .catch(() => setOnline(false));
    const id = setInterval(() => {
      fetchHealth().then(() => setOnline(true)).catch(() => setOnline(false));
    }, 30000);
    return () => clearInterval(id);
  }, []);

  return (
    <header style={{
      height: 60,
      background: 'var(--bg-surface)',
      borderBottom: '1px solid var(--border-dim)',
      display: 'flex', alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
      flexShrink: 0,
    }}>
      <div>
        <h1 style={{
          fontFamily: 'var(--font-display)', fontWeight: 700,
          fontSize: '1rem', color: 'var(--text-primary)',
          letterSpacing: '-0.01em',
        }}>
          {title}
        </h1>
        {subtitle && (
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', marginTop: 1 }}>
            {subtitle}
          </p>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        {/* API status */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'var(--font-mono)', fontSize: '0.7rem' }}>
          {online === null ? (
            <Activity size={13} color="var(--text-muted)" className="spinner" />
          ) : online ? (
            <><Wifi size={13} color="var(--col-public)" /><span style={{ color: 'var(--col-public)' }}>API Online</span></>
          ) : (
            <><WifiOff size={13} color="var(--col-restricted)" /><span style={{ color: 'var(--col-restricted)' }}>API Offline</span></>
          )}
        </div>

        {/* Live dot */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--col-public)', animation: 'glow-pulse 2s ease-in-out infinite' }} />
          LIVE
        </div>
      </div>
    </header>
  );
}
