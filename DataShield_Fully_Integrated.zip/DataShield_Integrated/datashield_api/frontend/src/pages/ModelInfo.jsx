// pages/ModelInfo.jsx
import React, { useEffect, useState } from 'react';
import TopBar from '../components/TopBar';
import { fetchModelInfo } from '../utils/api';
import { Activity, CheckCircle, AlertTriangle } from 'lucide-react';

const HARD_THRESHOLDS = {
  f1_macro:               { min: 0.88,  label: 'F1-Macro',               unit: '' },
  precision_restricted:   { min: 0.95,  label: 'Precision (Restricted)',  unit: '' },
  recall_restricted:      { min: 0.97,  label: 'Recall (Restricted)',      unit: '' },
  precision_confidential: { min: 0.90,  label: 'Precision (Confidential)', unit: '' },
  latency_p95_ms:         { max: 200,   label: 'P95 Latency',              unit: 'ms' },
};

function MetricRow({ label, value, threshold }) {
  const { min, max, unit = '' } = threshold || {};
  const passing = min !== undefined ? value >= min : max !== undefined ? value <= max : true;
  const targetLabel = min !== undefined ? `≥ ${min}` : max !== undefined ? `≤ ${max}${unit}` : '—';

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--border-dim)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {threshold
          ? passing
            ? <CheckCircle size={14} color="var(--col-public)" />
            : <AlertTriangle size={14} color="var(--col-restricted)" />
          : <Activity size={14} color="var(--text-muted)" />
        }
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.78rem', color: 'var(--text-secondary)' }}>{label}</span>
      </div>
      <div style={{ display: 'flex', align: 'center', gap: 16 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.78rem', color: threshold ? (passing ? 'var(--col-public)' : 'var(--col-restricted)') : 'var(--text-primary)' }}>
          {typeof value === 'number' ? (unit === 'ms' ? `${value} ms` : value.toFixed(3)) : value ?? '—'}
        </span>
        {threshold && (
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)', minWidth: 60, textAlign: 'right' }}>
            target {targetLabel}
          </span>
        )}
      </div>
    </div>
  );
}

export default function ModelInfo() {
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchModelInfo()
      .then(setInfo)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const allPassing = info ? Object.entries(HARD_THRESHOLDS).every(([key, thr]) => {
    const val = info.metrics?.[key];
    if (val == null) return true;
    if (thr.min !== undefined) return val >= thr.min;
    if (thr.max !== undefined) return val <= thr.max;
    return true;
  }) : null;

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <TopBar title="Champion Model" subtitle="Current production model details and compliance metrics" />
      <div style={{ flex: 1, overflowY: 'auto', padding: 24, maxWidth: 680, width: '100%' }}>

        {loading && (
          <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 200 }}>
            <span className="spinner" style={{ display: 'inline-block', width: 24, height: 24, border: '2px solid var(--border-mid)', borderTopColor: 'var(--accent)', borderRadius: '50%' }} />
          </div>
        )}

        {info && (
          <>
            {/* Identity card */}
            <div className="card animate-fade-up" style={{ marginBottom: 16, position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: -30, right: -30, width: 120, height: 120, borderRadius: '50%', background: allPassing ? 'var(--col-public)' : 'var(--col-restricted)', opacity: 0.06, filter: 'blur(32px)' }} />
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.3rem', color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
                    {info.model_name}
                  </div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 2 }}>
                    Version {info.version} · {info.stage}
                  </div>
                </div>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  fontFamily: 'var(--font-mono)', fontSize: '0.72rem',
                  padding: '6px 14px', borderRadius: 'var(--radius-sm)',
                  background: allPassing ? 'var(--col-public-dim)' : 'var(--col-restricted-dim)',
                  border: `1px solid ${allPassing ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.3)'}`,
                  color: allPassing ? 'var(--col-public)' : 'var(--col-restricted)',
                }}>
                  {allPassing ? <CheckCircle size={12} /> : <AlertTriangle size={12} />}
                  {allPassing ? 'All thresholds passing' : 'Threshold failure'}
                </div>
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>
                {info.description}
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)', marginTop: 10 }}>
                Registered: {info.registered_at}
              </div>
            </div>

            {/* Hard threshold metrics */}
            <div className="card animate-fade-up delay-1" style={{ marginBottom: 16 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 4 }}>
                PS-01 Hard Thresholds
              </div>
              {Object.entries(HARD_THRESHOLDS).map(([key, thr]) => (
                <MetricRow key={key} label={thr.label} value={info.metrics?.[key]} threshold={thr} />
              ))}
            </div>

            {/* All metrics */}
            <div className="card animate-fade-up delay-2">
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 4 }}>
                All Metrics
              </div>
              {Object.entries(info.metrics || {}).map(([key, val]) => (
                <MetricRow key={key} label={key} value={val} threshold={HARD_THRESHOLDS[key]} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
