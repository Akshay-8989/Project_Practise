// pages/Dashboard.jsx
import React, { useState, useEffect } from 'react';
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis,
  Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { fetchModelInfo } from '../utils/api';
import TopBar from '../components/TopBar';
import StatCard from '../components/StatCard';
import { Shield, Zap, AlertTriangle, CheckCircle, TrendingUp, Clock } from 'lucide-react';

// Simulated session stats (in a real app these come from the API or a store)
const LABEL_DATA = [
  { name: 'Public',       value: 31, color: 'var(--col-public)' },
  { name: 'Internal',     value: 38, color: 'var(--col-internal)' },
  { name: 'Confidential', value: 22, color: 'var(--col-confidential)' },
  { name: 'Restricted',   value: 9,  color: 'var(--col-restricted)' },
];

const WEEKLY_DATA = [
  { day: 'Mon', Public: 42, Internal: 58, Confidential: 30, Restricted: 8 },
  { day: 'Tue', Public: 55, Internal: 70, Confidential: 41, Restricted: 12 },
  { day: 'Wed', Public: 38, Internal: 52, Confidential: 28, Restricted: 7 },
  { day: 'Thu', Public: 61, Internal: 80, Confidential: 55, Restricted: 15 },
  { day: 'Fri', Public: 47, Internal: 63, Confidential: 39, Restricted: 10 },
  { day: 'Sat', Public: 20, Internal: 28, Confidential: 14, Restricted: 3 },
  { day: 'Sun', Public: 15, Internal: 22, Confidential: 10, Restricted: 2 },
];

const LATENCY_DATA = [
  { bucket: '<50ms', count: 18 },
  { bucket: '50-100', count: 45 },
  { bucket: '100-150', count: 27 },
  { bucket: '150-200', count: 7 },
  { bucket: '>200ms', count: 3 },
];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: 'var(--bg-raised)', border: '1px solid var(--border-mid)',
      borderRadius: 8, padding: '10px 14px',
    }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: 6 }}>{label}</div>
      {payload.map(p => (
        <div key={p.name} style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: p.color || p.fill, marginBottom: 2 }}>
          {p.name}: <strong>{p.value}</strong>
        </div>
      ))}
    </div>
  );
};

export default function Dashboard() {
  const [modelInfo, setModelInfo] = useState(null);

  useEffect(() => {
    fetchModelInfo().then(setModelInfo).catch(() => {});
  }, []);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <TopBar title="Dashboard" subtitle="Real-time classification metrics · PS-01" />

      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>

        {/* Stat cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 24 }}>
          <StatCard label="Total Classified" value="1,284" sub="This session" icon={Shield} color="var(--col-internal)" delay={0} />
          <StatCard label="Restricted Found" value="116" sub="9.0% of total" icon={AlertTriangle} color="var(--col-restricted)" delay={0.05} />
          <StatCard label="Avg Latency" value="112ms" sub="p95 = 178ms" icon={Clock} color="var(--col-public)" delay={0.10} />
          <StatCard label="Override Rate" value="3.2%" sub="Target < 5%" icon={CheckCircle} color="var(--col-confidential)" delay={0.15} />
          <StatCard label="Model F1-Macro" value="0.913" sub="Champion v1.0.0" icon={TrendingUp} color="var(--accent)" delay={0.20} />
          <StatCard label="Corrections" value="41" sub="3.2% correction rate" icon={Zap} color="var(--col-public)" delay={0.25} />
        </div>

        {/* Charts row */}
        <div style={{ display: 'grid', gridTemplateColumns: '340px 1fr', gap: 16, marginBottom: 16 }}>

          {/* Pie chart */}
          <div className="card animate-fade-up delay-3">
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 16 }}>
              Label Distribution
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={LABEL_DATA} dataKey="value" cx="50%" cy="50%" outerRadius={80} innerRadius={48} paddingAngle={3}>
                  {LABEL_DATA.map((entry, i) => (
                    <Cell key={i} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend
                  formatter={(value) => (
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-secondary)' }}>{value}</span>
                  )}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Weekly bar chart */}
          <div className="card animate-fade-up delay-4">
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 16 }}>
              Weekly Volume by Class
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={WEEKLY_DATA} barSize={8} barGap={2}>
                <XAxis dataKey="day" tick={{ fontFamily: 'var(--font-mono)', fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontFamily: 'var(--font-mono)', fontSize: 10, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                <Bar dataKey="Public"       fill="var(--col-public)"       radius={[2,2,0,0]} />
                <Bar dataKey="Internal"     fill="var(--col-internal)"     radius={[2,2,0,0]} />
                <Bar dataKey="Confidential" fill="var(--col-confidential)" radius={[2,2,0,0]} />
                <Bar dataKey="Restricted"   fill="var(--col-restricted)"   radius={[2,2,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Latency + Model info */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 16 }}>

          {/* Latency histogram */}
          <div className="card animate-fade-up delay-5">
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 16 }}>
              Latency Distribution
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={LATENCY_DATA} barSize={32}>
                <XAxis dataKey="bucket" tick={{ fontFamily: 'var(--font-mono)', fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontFamily: 'var(--font-mono)', fontSize: 10, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                <Bar dataKey="count" radius={[4,4,0,0]}>
                  {LATENCY_DATA.map((entry, i) => (
                    <Cell key={i} fill={entry.bucket === '>200ms' ? 'var(--col-restricted)' : 'var(--accent)'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Model info card */}
          <div className="card animate-fade-up delay-5">
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 14 }}>
              Champion Model
            </div>
            {modelInfo ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  ['Name', modelInfo.model_name],
                  ['Version', modelInfo.version],
                  ['Stage', modelInfo.stage],
                  ['F1-Macro', modelInfo.metrics?.f1_macro?.toFixed(3)],
                  ['Recall (Restricted)', modelInfo.metrics?.recall_restricted?.toFixed(3)],
                  ['Precision (Restricted)', modelInfo.metrics?.precision_restricted?.toFixed(3)],
                  ['P95 Latency', `${modelInfo.metrics?.latency_p95_ms} ms`],
                ].map(([k, v]) => (
                  <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 8, borderBottom: '1px solid var(--border-dim)' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-muted)' }}>{k}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-primary)' }}>{v}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-muted)' }}>Loading…</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
