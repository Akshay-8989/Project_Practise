// pages/Feedback.jsx
import React, { useState } from 'react';
import TopBar from '../components/TopBar';
import { submitFeedback } from '../utils/api';
import { getLabelClass } from '../utils/api';
import { MessageSquare, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';

const LABELS = ['Public', 'Internal', 'Confidential', 'Restricted'];

const INPUT_STYLE = {
  width: '100%', background: 'var(--bg-raised)',
  border: '1px solid var(--border-mid)', borderRadius: 'var(--radius-md)',
  padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: '0.8rem',
  color: 'var(--text-primary)', outline: 'none', transition: 'border-color 0.15s',
};

export default function Feedback() {
  const [docId, setDocId]               = useState('');
  const [originalLabel, setOriginal]    = useState('');
  const [correctedLabel, setCorrected]  = useState('');
  const [reason, setReason]             = useState('');
  const [submitting, setSubmitting]     = useState(false);
  const [submitted, setSubmitted]       = useState(false);

  const valid = docId.trim() && originalLabel && correctedLabel && originalLabel !== correctedLabel;

  const handleSubmit = async () => {
    if (!valid) return;
    setSubmitting(true);
    try {
      await submitFeedback({ doc_id: docId.trim(), original_label: originalLabel, corrected_label: correctedLabel, reason });
      setSubmitted(true);
      toast.success('Correction submitted successfully!');
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Submission failed');
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => { setDocId(''); setOriginal(''); setCorrected(''); setReason(''); setSubmitted(false); };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <TopBar title="Submit Feedback" subtitle="Human-in-the-loop correction for active learning" />
      <div style={{ flex: 1, overflowY: 'auto', padding: 24, maxWidth: 560, width: '100%' }}>

        {submitted ? (
          <div className="card animate-fade-up" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, padding: 40, textAlign: 'center' }}>
            <CheckCircle size={40} color="var(--col-public)" />
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.1rem', color: 'var(--text-primary)' }}>
              Correction Recorded
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.78rem', color: 'var(--text-muted)', maxWidth: 360 }}>
              Your correction for <code style={{ color: 'var(--text-accent)' }}>{docId}</code> has been logged.
              It will be included in the next retraining cycle.
            </div>
            <button onClick={reset} style={{
              marginTop: 8, fontFamily: 'var(--font-mono)', fontSize: '0.8rem',
              color: 'var(--text-accent)', background: 'var(--accent-dim)',
              border: '1px solid rgba(59,130,246,0.2)', borderRadius: 'var(--radius-md)',
              padding: '9px 20px', cursor: 'pointer',
            }}>
              Submit Another
            </button>
          </div>
        ) : (
          <div className="card animate-fade-up">
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 20 }}>
              <MessageSquare size={11} style={{ display: 'inline', marginRight: 6 }} />
              Correction Form
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)', marginBottom: 6 }}>Document ID *</div>
                <input value={docId} onChange={e => setDocId(e.target.value)} placeholder="UUID or custom doc_id" style={INPUT_STYLE}
                  onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }} onBlur={e => { e.target.style.borderColor = 'var(--border-mid)'; }} />
              </div>

              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)', marginBottom: 8 }}>Original Label (what the model predicted) *</div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {LABELS.map(l => (
                    <button key={l} onClick={() => setOriginal(l)} className={`label-badge ${getLabelClass(l)}`}
                      style={{ cursor: 'pointer', border: originalLabel === l ? '2px solid currentColor' : '1px solid rgba(255,255,255,0.15)', opacity: originalLabel && originalLabel !== l ? 0.45 : 1 }}>
                      {l}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)', marginBottom: 8 }}>Corrected Label (what it should be) *</div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {LABELS.filter(l => l !== originalLabel).map(l => (
                    <button key={l} onClick={() => setCorrected(l)} className={`label-badge ${getLabelClass(l)}`}
                      style={{ cursor: 'pointer', border: correctedLabel === l ? '2px solid currentColor' : '1px solid rgba(255,255,255,0.15)', opacity: correctedLabel && correctedLabel !== l ? 0.45 : 1 }}>
                      {l}
                    </button>
                  ))}
                  {!originalLabel && <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--text-muted)' }}>Select original label first</span>}
                </div>
              </div>

              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)', marginBottom: 6 }}>Reason (optional)</div>
                <textarea value={reason} onChange={e => setReason(e.target.value)} placeholder="Explain why the label is incorrect…" rows={3} style={{ ...INPUT_STYLE, resize: 'vertical' }}
                  onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }} onBlur={e => { e.target.style.borderColor = 'var(--border-mid)'; }} />
              </div>

              <button onClick={handleSubmit} disabled={!valid || submitting} style={{
                fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.9rem',
                color: 'white', background: valid ? 'linear-gradient(135deg, #1d4ed8, #3b82f6)' : 'var(--bg-hover)',
                border: 'none', borderRadius: 'var(--radius-md)', padding: '12px 0',
                cursor: valid ? 'pointer' : 'not-allowed',
                opacity: submitting ? 0.7 : 1,
                boxShadow: valid ? '0 0 20px var(--accent-glow)' : 'none',
                transition: 'all 0.2s',
              }}>
                {submitting ? 'Submitting…' : 'Submit Correction'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
