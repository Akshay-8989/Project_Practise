// pages/AuditLog.jsx
import React, { useState } from 'react';
import TopBar from '../components/TopBar';
import { fetchAudit } from '../utils/api';
import { getLabelClass, getActionClass } from '../utils/api';
import { FileSearch, Search, AlertTriangle, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';

const INPUT_STYLE = {
  flex: 1, background: 'var(--bg-raised)',
  border: '1px solid var(--border-mid)', borderRadius: 'var(--radius-md)',
  padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: '0.8rem',
  color: 'var(--text-primary)', outline: 'none',
};

function AuditField({ label, value, mono = true }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 0', borderBottom: '1px solid var(--border-dim)' }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-muted)' }}>{label}</span>
      <span style={{ fontFamily: mono ? 'var(--font-mono)' : 'var(--font-display)', fontSize: '0.78rem', color: 'var(--text-primary)', textAlign: 'right', maxWidth: '60%', wordBreak: 'break-all' }}>{value}</span>
    </div>
  );
}

export default function AuditLog() {
  const [docId, setDocId] = useState('');
  const [entry, setEntry] = useState(null);
  const [loading, setLoading] = useState(false);
  const [notFound, setNotFound] = useState(false);

  const lookup = async () => {
    if (!docId.trim()) { toast.error('Enter a document ID'); return; }
    setLoading(true); setNotFound(false); setEntry(null);
    try {
      const data = await fetchAudit(docId.trim());
      setEntry(data);
    } catch (err) {
      if (err.response?.status === 404) setNotFound(true);
      else toast.error('Lookup failed: ' + (err.message || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <TopBar title="Audit Log" subtitle="Compliance trail — retrieve classification records by document ID" />

      <div style={{ flex: 1, overflowY: 'auto', padding: 24, maxWidth: 680, width: '100%' }}>

        {/* Search bar */}
        <div className="card" style={{ marginBottom: 20 }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 10 }}>
            Document ID Lookup
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <input
              value={docId}
              onChange={e => { setDocId(e.target.value); setEntry(null); setNotFound(false); }}
              onKeyDown={e => { if (e.key === 'Enter') lookup(); }}
              placeholder="Enter doc_id (UUID or custom ID)…"
              style={INPUT_STYLE}
              onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }}
              onBlur={e => { e.target.style.borderColor = 'var(--border-mid)'; }}
            />
            <button
              onClick={lookup}
              disabled={loading}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                fontFamily: 'var(--font-mono)', fontSize: '0.8rem',
                color: 'white', background: 'var(--accent)',
                border: 'none', borderRadius: 'var(--radius-md)',
                padding: '10px 20px', cursor: loading ? 'not-allowed' : 'pointer',
                flexShrink: 0, opacity: loading ? 0.7 : 1,
              }}
            >
              {loading
                ? <span className="spinner" style={{ display: 'inline-block', width: 14, height: 14, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: 'white', borderRadius: '50%' }} />
                : <><Search size={14} />Lookup</>}
            </button>
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', marginTop: 8 }}>
            Tip: Use the doc_id returned from a /classify call, or try "audit-test-001" after running tests.
          </div>
        </div>

        {/* Not found */}
        {notFound && (
          <div className="card animate-fade-up" style={{ display: 'flex', alignItems: 'center', gap: 12, background: 'var(--col-restricted-dim)', border: '1px solid rgba(239,68,68,0.25)' }}>
            <AlertTriangle size={20} color="var(--col-restricted)" />
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.9rem', color: 'var(--col-restricted)' }}>Not Found</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 2 }}>
                No audit record found for <code style={{ color: 'var(--col-restricted)' }}>{docId}</code>
              </div>
            </div>
          </div>
        )}

        {/* Entry */}
        {entry && (
          <div className="card animate-fade-up">
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18, paddingBottom: 14, borderBottom: '1px solid var(--border-dim)' }}>
              <CheckCircle size={18} color="var(--col-public)" />
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.95rem', color: 'var(--text-primary)' }}>
                Audit Record Found
              </div>
              <span className={`label-badge ${getLabelClass(entry.predicted_label)}`} style={{ marginLeft: 'auto' }}>
                {entry.predicted_label}
              </span>
              <span className={`label-badge ${getActionClass(entry.policy_action)}`}>
                {entry.policy_action}
              </span>
            </div>

            {/* Fields */}
            <AuditField label="doc_id" value={entry.doc_id} />
            <AuditField label="predicted_label" value={entry.predicted_label} />
            <AuditField label="policy_action" value={entry.policy_action} />
            <AuditField label="confidence" value={`${(entry.confidence * 100).toFixed(2)}%`} />
            <AuditField label="model_version" value={entry.model_version} />
            <AuditField label="source_system" value={entry.source_system || '—'} />
            <AuditField label="pii_detected" value={entry.pii_detected?.join(', ') || 'none'} />
            <AuditField label="policy_override" value={entry.policy_override ? 'YES ⚠' : 'No'} />
            <AuditField label="classified_at" value={entry.classified_at} />
            <AuditField label="requested_by" value={entry.requested_by} />

            {entry.policy_override && (
              <div style={{
                marginTop: 14, padding: '10px 14px',
                background: 'var(--col-restricted-dim)', border: '1px solid rgba(239,68,68,0.25)',
                borderRadius: 'var(--radius-sm)',
                display: 'flex', alignItems: 'center', gap: 8,
              }}>
                <AlertTriangle size={14} color="var(--col-restricted)" />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--col-restricted)' }}>
                  Policy engine rule override was applied — model label was overridden.
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
