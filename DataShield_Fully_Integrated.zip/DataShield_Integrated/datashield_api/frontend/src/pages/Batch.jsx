// pages/Batch.jsx
import React, { useState } from 'react';
import TopBar from '../components/TopBar';
import { useClassify } from '../hooks/useClassify';
import { getLabelClass, getActionClass } from '../utils/api';
import { GitBranch, Plus, Trash2, Zap } from 'lucide-react';
import toast from 'react-hot-toast';

const INPUT_STYLE = {
  width: '100%', background: 'var(--bg-raised)',
  border: '1px solid var(--border-mid)', borderRadius: 'var(--radius-md)',
  padding: '8px 12px', fontFamily: 'var(--font-mono)', fontSize: '0.78rem',
  color: 'var(--text-primary)', outline: 'none', resize: 'vertical',
};

export default function Batch() {
  const { loading, error, classifyMany } = useClassify();
  const [docs, setDocs] = useState([{ text: '', source_system: '' }, { text: '', source_system: '' }]);
  const [batchResult, setBatchResult] = useState(null);

  const addDoc = () => {
    if (docs.length >= 100) { toast.error('Maximum 100 documents per batch'); return; }
    setDocs(d => [...d, { text: '', source_system: '' }]);
  };

  const removeDoc = (i) => setDocs(d => d.filter((_, idx) => idx !== i));

  const updateDoc = (i, field, val) =>
    setDocs(d => d.map((doc, idx) => idx === i ? { ...doc, [field]: val } : doc));

  const handleBatch = async () => {
    const valid = docs.filter(d => d.text.trim());
    if (!valid.length) { toast.error('Add at least one document'); return; }
    const result = await classifyMany(valid);
    if (result) {
      setBatchResult(result);
      toast.success(`Classified ${result.successful} / ${result.total_documents} documents`);
    }
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <TopBar title="Batch Classification" subtitle="Classify up to 100 documents simultaneously" />

      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>

          {/* Left: Input */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                Documents ({docs.length}/100)
              </div>
              <button onClick={addDoc} style={{
                display: 'flex', alignItems: 'center', gap: 5,
                fontFamily: 'var(--font-mono)', fontSize: '0.72rem',
                color: 'var(--text-accent)', background: 'var(--accent-dim)',
                border: '1px solid rgba(59,130,246,0.2)', borderRadius: 'var(--radius-sm)',
                padding: '5px 12px', cursor: 'pointer',
              }}>
                <Plus size={12} /> Add
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {docs.map((doc, i) => (
                <div key={i} className="card animate-fade-up" style={{ padding: 14, animationDelay: `${i * 0.04}s` }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
                      Doc {i + 1}
                    </span>
                    {docs.length > 1 && (
                      <button onClick={() => removeDoc(i)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', alignItems: 'center' }}>
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                  <textarea
                    value={doc.text}
                    onChange={e => updateDoc(i, 'text', e.target.value)}
                    placeholder="Document text…"
                    rows={3}
                    style={{ ...INPUT_STYLE, marginBottom: 8 }}
                    onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }}
                    onBlur={e => { e.target.style.borderColor = 'var(--border-mid)'; }}
                  />
                  <input
                    value={doc.source_system}
                    onChange={e => updateDoc(i, 'source_system', e.target.value)}
                    placeholder="source_system (optional)"
                    style={{ ...INPUT_STYLE, resize: 'none' }}
                    onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }}
                    onBlur={e => { e.target.style.borderColor = 'var(--border-mid)'; }}
                  />
                </div>
              ))}
            </div>

            <button
              onClick={handleBatch}
              disabled={loading}
              style={{
                marginTop: 16,
                display: 'flex', alignItems: 'center', gap: 8,
                fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.9rem',
                color: 'white',
                background: loading ? 'var(--bg-hover)' : 'linear-gradient(135deg, #1d4ed8, #3b82f6)',
                border: 'none', borderRadius: 'var(--radius-md)',
                padding: '11px 24px', cursor: loading ? 'not-allowed' : 'pointer',
                boxShadow: loading ? 'none' : '0 0 20px var(--accent-glow)',
                transition: 'all 0.2s',
              }}
            >
              {loading
                ? <><span className="spinner" style={{ display: 'inline-block', width: 14, height: 14, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: 'white', borderRadius: '50%' }} />Running…</>
                : <><GitBranch size={15} />Run Batch</>}
            </button>
          </div>

          {/* Right: Results */}
          <div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 14 }}>
              Results
            </div>

            {!batchResult && (
              <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 200, flexDirection: 'column', gap: 8 }}>
                <GitBranch size={28} color="var(--text-muted)" />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  Batch results will appear here
                </span>
              </div>
            )}

            {batchResult && (
              <div className="animate-fade-up">
                {/* Summary bar */}
                <div className="card" style={{ marginBottom: 12, display: 'flex', gap: 20 }}>
                  {[
                    ['Total', batchResult.total_documents, 'var(--text-primary)'],
                    ['Successful', batchResult.successful, 'var(--col-public)'],
                    ['Errors', batchResult.errors?.length || 0, 'var(--col-restricted)'],
                    ['Latency', `${batchResult.batch_latency_ms?.toFixed(0)}ms`, 'var(--col-internal)'],
                  ].map(([k, v, c]) => (
                    <div key={k} style={{ textAlign: 'center' }}>
                      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '1.4rem', color: c }}>{v}</div>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>{k}</div>
                    </div>
                  ))}
                </div>

                {/* Result rows */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {batchResult.results?.map((r, i) => (
                    <div key={i} className="card animate-fade-up" style={{ padding: '12px 16px', animationDelay: `${i * 0.04}s` }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--text-muted)' }}>
                          Doc {i + 1}
                        </span>
                        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                          <span className={`label-badge ${getLabelClass(r.predicted_label)}`}>{r.predicted_label}</span>
                          <span className={`label-badge ${getActionClass(r.policy_action)}`}>{r.policy_action}</span>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
                            {(r.confidence_scores?.[r.predicted_label] * 100).toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {error && (
              <div style={{
                padding: '12px 16px', marginTop: 12,
                background: 'var(--col-restricted-dim)', border: '1px solid rgba(239,68,68,0.3)',
                borderRadius: 'var(--radius-md)', fontFamily: 'var(--font-mono)', fontSize: '0.8rem',
                color: 'var(--col-restricted)',
              }}>
                {error}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
