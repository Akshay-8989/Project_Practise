// pages/Classify.jsx
import React, { useState } from 'react';
import TopBar from '../components/TopBar';
import ResultCard from '../components/ResultCard';
import { useClassify } from '../hooks/useClassify';
import { Zap, ChevronDown, ChevronUp, RotateCcw } from 'lucide-react';
import toast from 'react-hot-toast';

const SAMPLE_TEXTS = [
  { label: 'Public', text: 'Acme Corp announces record Q1 revenue of $2.3 billion, exceeding analyst expectations by 12%.' },
  { label: 'Internal', text: 'Internal memo: Q4 team offsite scheduled for December 10th at the Bangalore office. Please confirm attendance by Friday.' },
  { label: 'Confidential', text: 'Employee compensation review 2026. Base salary bands: L3 ₹18–22 LPA, L4 ₹26–34 LPA. Not for external distribution.' },
  { label: 'Restricted', text: 'RESTRICTED: Customer PAN card 4111-1111-1111-1111, SSN 123-45-6789. Transaction reconciliation for Visa audit.' },
];

const INPUT_STYLE = {
  width: '100%',
  background: 'var(--bg-raised)',
  border: '1px solid var(--border-mid)',
  borderRadius: 'var(--radius-md)',
  padding: '10px 14px',
  fontFamily: 'var(--font-mono)',
  fontSize: '0.8rem',
  color: 'var(--text-primary)',
  outline: 'none',
  transition: 'border-color 0.15s',
};

export default function Classify() {
  const { result, loading, error, classify, clearResult } = useClassify();
  const [text, setText] = useState('');
  const [showMeta, setShowMeta] = useState(false);
  const [meta, setMeta] = useState({ source_system: '', file_type: '', department: '', doc_id: '' });

  const handleClassify = async () => {
    if (!text.trim()) { toast.error('Please enter document text'); return; }
    const payload = { text };
    Object.entries(meta).forEach(([k, v]) => { if (v) payload[k] = v; });
    await classify(text, payload);
  };

  const handleSample = (sample) => {
    setText(sample.text);
    clearResult();
    toast(`Loaded ${sample.label} sample`, { icon: '📄' });
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <TopBar title="Classify Document" subtitle="Single document sensitivity analysis" />

      <div style={{ flex: 1, overflowY: 'auto', padding: 24, maxWidth: 860, width: '100%' }}>

        {/* Sample buttons */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>
            Load Sample
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {SAMPLE_TEXTS.map(s => (
              <button
                key={s.label}
                onClick={() => handleSample(s)}
                className={`label-badge label-${s.label.toLowerCase()}`}
                style={{ cursor: 'pointer', border: '1px solid currentColor', background: 'transparent' }}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Text input */}
        <div className="card">
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 10 }}>
            Document Text
          </div>
          <textarea
            value={text}
            onChange={e => { setText(e.target.value); clearResult(); }}
            placeholder="Paste or type the document content to classify…"
            rows={8}
            style={{
              ...INPUT_STYLE,
              resize: 'vertical',
              lineHeight: 1.7,
            }}
            onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }}
            onBlur={e => { e.target.style.borderColor = 'var(--border-mid)'; }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
            <span>{text.length} chars</span>
            <span>max 500,000</span>
          </div>
        </div>

        {/* Optional metadata */}
        <div style={{ marginTop: 12 }}>
          <button
            onClick={() => setShowMeta(m => !m)}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              fontFamily: 'var(--font-mono)', fontSize: '0.72rem',
              color: 'var(--text-muted)', background: 'transparent', border: 'none',
              cursor: 'pointer', padding: '4px 0',
            }}
          >
            {showMeta ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            Optional Metadata
          </button>
          {showMeta && (
            <div className="card animate-fade-up" style={{ marginTop: 10, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {[
                ['doc_id', 'Document ID', 'auto-generated if empty'],
                ['source_system', 'Source System', 'e.g. jira, hr_portal'],
                ['file_type', 'File Type', 'e.g. pdf, email'],
                ['department', 'Department', 'e.g. Finance, Legal'],
              ].map(([key, label, placeholder]) => (
                <div key={key}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', marginBottom: 5 }}>{label}</div>
                  <input
                    value={meta[key]}
                    onChange={e => setMeta(m => ({ ...m, [key]: e.target.value }))}
                    placeholder={placeholder}
                    style={INPUT_STYLE}
                    onFocus={e => { e.target.style.borderColor = 'var(--accent)'; }}
                    onBlur={e => { e.target.style.borderColor = 'var(--border-mid)'; }}
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
          <button
            onClick={handleClassify}
            disabled={loading || !text.trim()}
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: '0.9rem',
              color: 'white',
              background: loading ? 'var(--bg-hover)' : 'linear-gradient(135deg, #1d4ed8, #3b82f6)',
              border: 'none', borderRadius: 'var(--radius-md)',
              padding: '11px 24px', cursor: loading ? 'not-allowed' : 'pointer',
              opacity: !text.trim() ? 0.5 : 1,
              transition: 'all 0.2s',
              boxShadow: loading ? 'none' : '0 0 20px var(--accent-glow)',
            }}
          >
            {loading
              ? <><span className="spinner" style={{ display: 'inline-block', width: 14, height: 14, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: 'white', borderRadius: '50%' }} />Classifying…</>
              : <><Zap size={15} /> Classify</>
            }
          </button>
          {(text || result) && (
            <button
              onClick={() => { setText(''); clearResult(); }}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                fontFamily: 'var(--font-mono)', fontSize: '0.8rem',
                color: 'var(--text-muted)', background: 'transparent',
                border: '1px solid var(--border-dim)', borderRadius: 'var(--radius-md)',
                padding: '11px 18px', cursor: 'pointer',
              }}
            >
              <RotateCcw size={13} /> Clear
            </button>
          )}
        </div>

        {/* Error */}
        {error && (
          <div className="animate-fade-up" style={{
            marginTop: 16, padding: '12px 16px',
            background: 'var(--col-restricted-dim)', border: '1px solid rgba(239,68,68,0.3)',
            borderRadius: 'var(--radius-md)', fontFamily: 'var(--font-mono)', fontSize: '0.8rem',
            color: 'var(--col-restricted)',
          }}>
            {error}
          </div>
        )}

        {/* Result */}
        <ResultCard result={result} />
      </div>
    </div>
  );
}
