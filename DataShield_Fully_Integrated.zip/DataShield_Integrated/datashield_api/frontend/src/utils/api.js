// utils/api.js
// ─────────────────────────────────────────────────────────
// Axios-based API client for the DataShield backend.
// All backend calls go through this module.
// Base URL is proxied via package.json "proxy" field in dev.
// ─────────────────────────────────────────────────────────

import axios from 'axios';

const BASE = process.env.REACT_APP_API_URL || '';

// Axios instance with default headers
const client = axios.create({
  baseURL: BASE,
  headers: {
    'Content-Type': 'application/json',
    // Token stored in localStorage under key 'ds_token'
    // Updated dynamically by the interceptor below
  },
  timeout: 15000,
});

// Inject auth token on every request
client.interceptors.request.use(cfg => {
  const token = localStorage.getItem('ds_token') || 'dev-token-001';
  cfg.headers['Authorization'] = `Bearer ${token}`;
  return cfg;
});

// ── Health ─────────────────────────────────────────
export const fetchHealth  = ()  => client.get('/health').then(r => r.data);
export const fetchReady   = ()  => client.get('/ready').then(r => r.data);

// ── Model info ─────────────────────────────────────
export const fetchModelInfo = () => client.get('/model/info').then(r => r.data);

// ── Classification ──────────────────────────────────
export const classifyDocument = (payload) =>
  client.post('/classify', payload).then(r => r.data);

export const classifyBatch = (documents) =>
  client.post('/classify/batch', { documents }).then(r => r.data);

// ── Feedback ────────────────────────────────────────
export const submitFeedback = (payload) =>
  client.post('/feedback', payload).then(r => r.data);

// ── Audit ───────────────────────────────────────────
export const fetchAudit = (docId) =>
  client.get(`/audit/${docId}`).then(r => r.data);

// ── Helpers ─────────────────────────────────────────
export const getLabelColor = (label) => ({
  Public:       'var(--col-public)',
  Internal:     'var(--col-internal)',
  Confidential: 'var(--col-confidential)',
  Restricted:   'var(--col-restricted)',
}[label] || 'var(--text-secondary)');

export const getLabelClass = (label) =>
  `label-${label?.toLowerCase()}`;

export const getActionClass = (action) =>
  `action-${action?.toLowerCase()}`;
