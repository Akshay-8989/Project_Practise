# DataShield — Frontend

React dashboard for the PS-01 Data Sensitivity Classification Engine.

## Stack
- **React 18** — UI framework
- **React Router v6** — client-side routing (6 pages)
- **Recharts** — dashboard charts (pie, bar, histogram)
- **Axios** — HTTP client for FastAPI calls
- **react-hot-toast** — notifications
- **Lucide React** — icons
- **Google Fonts** — Syne + DM Mono + Instrument Serif

## Pages
| Route | Page | Purpose |
|---|---|---|
| `/` | Dashboard | Charts, stats, model metrics |
| `/classify` | Classify | Single document classification |
| `/batch` | Batch | Up to 100 documents |
| `/audit` | Audit Log | Look up audit records by doc_id |
| `/feedback` | Feedback | Submit human corrections |
| `/model` | Model Info | Champion model details & threshold status |

## Setup

```bash
cd frontend
npm install
npm start         # dev server at http://localhost:3000
```

The frontend proxies `/classify`, `/batch`, `/model/info`, etc. to `http://localhost:8000`
(configured in package.json `"proxy"` field).

Make sure the FastAPI backend is running first:
```bash
# from project root
python scripts/run_server.py
```

## Build for production
```bash
npm run build
# Static files in frontend/build/
# Serve with: npx serve -s build
```

## Auth
The API token is read from `localStorage` key `ds_token`.
Default: `dev-token-001`.
To change: `localStorage.setItem('ds_token', 'your-token')` in browser console.
