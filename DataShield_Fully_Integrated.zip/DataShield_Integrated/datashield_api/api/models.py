"""datashield_api/api/models.py — Pydantic request/response schemas."""
from __future__ import annotations
from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class ClassifyRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=500_000)
    doc_id: Optional[str] = None
    source_system: Optional[str] = None
    file_type: Optional[str] = None
    department: Optional[str] = None
    author: Optional[str] = None
    creation_date: Optional[str] = None
    language: Optional[str] = "en"
    region: Optional[str] = None

    model_config = {"json_schema_extra": {"example": {
        "text": "Employee SSN: 123-45-6789. Salary: $145,000.",
        "source_system": "hr_portal", "department": "HR",
    }}}


class BatchClassifyRequest(BaseModel):
    documents: List[ClassifyRequest] = Field(..., min_length=1, max_length=100)


class FeedbackRequest(BaseModel):
    doc_id: str
    original_label: str = Field(..., pattern="^(Public|Internal|Confidential|Restricted)$")
    corrected_label: str = Field(..., pattern="^(Public|Internal|Confidential|Restricted)$")
    reason: Optional[str] = None


class ClassifyResponse(BaseModel):
    doc_id: str
    predicted_label: str
    confidence_scores: Dict[str, float]
    evidence_tokens: List[str]
    policy_action: str
    policy_override: bool
    model_version: str
    language: str
    pii_types_detected: List[str]
    total_latency_ms: float
    classified_at: str


class BatchClassifyResponse(BaseModel):
    results: List[ClassifyResponse]
    errors: List[dict]
    total_documents: int
    successful: int
    batch_latency_ms: float


class FeedbackResponse(BaseModel):
    doc_id: str
    accepted: bool
    message: str


class HealthResponse(BaseModel):
    status: str
    timestamp: str


class ModelInfoResponse(BaseModel):
    model_name: str
    version: str
    stage: str
    registered_at: str
    metrics: Dict[str, float]
    description: str


class AuditEntry(BaseModel):
    doc_id: str
    predicted_label: str
    policy_action: str
    confidence: float
    model_version: str
    source_system: Optional[str]
    pii_detected: List[str]
    policy_override: bool
    classified_at: str
    requested_by: str
