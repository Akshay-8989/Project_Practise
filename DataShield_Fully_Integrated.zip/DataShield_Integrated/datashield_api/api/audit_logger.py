"""datashield_api/api/audit_logger.py — Compliance audit trail."""
from __future__ import annotations
import json, logging, threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from .models import AuditEntry

logger = logging.getLogger(__name__)

class AuditLogger:
    def __init__(self, log_dir: str = "audit_logs"):
        self._lock = threading.Lock()
        self._records: dict[str, AuditEntry] = {}
        self._corrections: list[dict] = []
        self._log_dir = Path(log_dir)
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._log_file = self._log_dir / "classifications.jsonl"
        self._corrections_file = self._log_dir / "corrections.jsonl"

    def log(self, entry: AuditEntry) -> None:
        with self._lock:
            self._records[entry.doc_id] = entry
            self._write(entry.model_dump(), self._log_file)
        logger.info("Audit: doc_id=%s label=%s action=%s", entry.doc_id, entry.predicted_label, entry.policy_action)

    def log_correction(self, doc_id, original_label, corrected_label, corrected_by, reason):
        record = {"doc_id": doc_id, "original_label": original_label,
                  "corrected_label": corrected_label, "corrected_by": corrected_by,
                  "reason": reason, "corrected_at": datetime.now(timezone.utc).isoformat()}
        with self._lock:
            self._corrections.append(record)
            self._write(record, self._corrections_file)

    def get(self, doc_id: str) -> Optional[AuditEntry]:
        with self._lock:
            return self._records.get(doc_id)

    def flush(self):
        logger.info("AuditLogger flushed. Total: %d", len(self._records))

    def _write(self, record: dict, path: Path):
        try:
            with path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record) + "\n")
        except OSError as e:
            logger.error("Audit write failed: %s", e)
