"""
datashield_api/api/main.py
===========================
FastAPI application. All routes call integration_bridge.classify_document()
which internally calls:
  - Teammate A's PreprocessingPipeline
  - Teammate B's SensitivityClassifier
  - Our AuditLogger and ModelRegistry
"""
from __future__ import annotations
import time, uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, Security, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .models import (
    AuditEntry, BatchClassifyRequest, BatchClassifyResponse,
    ClassifyRequest, ClassifyResponse, FeedbackRequest, FeedbackResponse,
    HealthResponse, ModelInfoResponse,
)
from .audit_logger import AuditLogger
from ..mlops.model_registry import ModelRegistry
from ..integration_bridge import classify_document

# ── Singletons ────────────────────────────────────────────────────────────────
_model_registry: ModelRegistry = None
_audit_logger: AuditLogger = None
_bearer = HTTPBearer(auto_error=False)

VALID_TOKENS = {"dev-token-001", "payments-client-token"}

@asynccontextmanager
async def lifespan(app: FastAPI):
    global _model_registry, _audit_logger
    _model_registry = ModelRegistry()
    _model_registry.load_champion()
    _audit_logger = AuditLogger()
    yield
    _audit_logger.flush()

app = FastAPI(
    title="DataShield — Data Sensitivity Classification API",
    description="PS-01 | Integrated with Teammate A (Preprocessing) and Teammate B (Classification)",
    version="2.0.0",
    lifespan=lifespan,
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Auth ──────────────────────────────────────────────────────────────────────
def verify_token(credentials: HTTPAuthorizationCredentials = Security(_bearer)):
    if credentials is None or credentials.credentials not in VALID_TOKENS:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing token.")
    return credentials.credentials

# ── Core helper ───────────────────────────────────────────────────────────────
def _run_and_audit(request: ClassifyRequest, token: str) -> ClassifyResponse:
    metadata = {
        "doc_id":        request.doc_id or str(uuid.uuid4()),
        "source_system": request.source_system,
        "file_type":     request.file_type,
        "department":    request.department,
        "author":        request.author,
        "creation_date": request.creation_date,
        "language":      request.language or "en",
        "region":        request.region,
    }

    result = classify_document(request.text, metadata)

    response = ClassifyResponse(
        doc_id             = result["doc_id"],
        predicted_label    = result["predicted_label"],
        confidence_scores  = result["confidence_scores"],
        evidence_tokens    = result["evidence_tokens"],
        policy_action      = result["policy_action"],
        policy_override    = result["policy_override"],
        model_version      = result["model_version"],
        language           = result["language"],
        pii_types_detected = result["pii_types_detected"],
        total_latency_ms   = result["total_latency_ms"],
        classified_at      = result["classified_at"],
    )

    _audit_logger.log(AuditEntry(
        doc_id          = response.doc_id,
        predicted_label = response.predicted_label,
        policy_action   = response.policy_action,
        confidence      = response.confidence_scores.get(response.predicted_label, 0.0),
        model_version   = response.model_version,
        source_system   = request.source_system,
        pii_detected    = response.pii_types_detected,
        policy_override = response.policy_override,
        classified_at   = response.classified_at,
        requested_by    = token[:8] + "***",
    ))
    return response

# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/health", response_model=HealthResponse, tags=["Ops"])
def health():
    return HealthResponse(status="ok", timestamp=datetime.now(timezone.utc).isoformat())

@app.get("/ready", response_model=HealthResponse, tags=["Ops"])
def readiness():
    if _model_registry is None or not _model_registry.is_ready():
        raise HTTPException(status_code=503, detail="Model not loaded.")
    return HealthResponse(status="ready", timestamp=datetime.now(timezone.utc).isoformat())

@app.get("/model/info", response_model=ModelInfoResponse, tags=["Model"])
def model_info(token: str = Depends(verify_token)):
    return ModelInfoResponse(**_model_registry.get_champion_info())

@app.post("/classify", response_model=ClassifyResponse, tags=["Classification"])
def classify(request: ClassifyRequest, token: str = Depends(verify_token)):
    return _run_and_audit(request, token)

@app.post("/classify/batch", response_model=BatchClassifyResponse, tags=["Classification"])
def classify_batch(request: BatchClassifyRequest, token: str = Depends(verify_token)):
    if len(request.documents) > 100:
        raise HTTPException(status_code=422, detail="Batch size must not exceed 100.")
    t0 = time.perf_counter()
    results: List[ClassifyResponse] = []
    errors: List[dict] = []
    for doc in request.documents:
        try:
            results.append(_run_and_audit(doc, token))
        except Exception as e:
            errors.append({"doc_id": doc.doc_id, "error": str(e)})
    return BatchClassifyResponse(
        results=results, errors=errors,
        total_documents=len(request.documents), successful=len(results),
        batch_latency_ms=round((time.perf_counter() - t0) * 1000, 2),
    )

@app.post("/feedback", response_model=FeedbackResponse, tags=["Human-in-Loop"])
def submit_feedback(request: FeedbackRequest, token: str = Depends(verify_token)):
    _audit_logger.log_correction(
        request.doc_id, request.original_label, request.corrected_label,
        token[:8] + "***", request.reason,
    )
    return FeedbackResponse(doc_id=request.doc_id, accepted=True,
                            message="Correction recorded for next retraining cycle.")

@app.get("/audit/{doc_id}", response_model=AuditEntry, tags=["Audit"])
def get_audit(doc_id: str, token: str = Depends(verify_token)):
    entry = _audit_logger.get(doc_id)
    if not entry:
        raise HTTPException(status_code=404, detail=f"No audit entry for doc_id={doc_id}")
    return entry
