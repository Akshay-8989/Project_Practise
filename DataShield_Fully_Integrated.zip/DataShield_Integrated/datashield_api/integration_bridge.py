"""
datashield_api/integration_bridge.py
Connects our API to Teammate A (Preprocessing) and Teammate B (Classification).
No Kafka needed — uses pipeline.py directly, not app.py/consumer.py.
Falls back gracefully to heuristics if either pipeline is unavailable.
"""
from __future__ import annotations
import sys, os, uuid, logging, time, re
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)

_THIS_DIR     = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
_TEAM_A_DIR   = os.path.join(_PROJECT_ROOT, "enterprise_platform", "preprocessing")
_TEAM_B_DIR   = os.path.join(_PROJECT_ROOT, "classification_module")

for _p in [_TEAM_A_DIR, _TEAM_B_DIR]:
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

_TEAM_A_OK = False
try:
    from pipeline import run_pipeline as _run_preprocessing_pipeline
    _TEAM_A_OK = True
    logger.info("Teammate A preprocessing imported OK.")
except ImportError as e:
    logger.warning("Teammate A not available: %s", e)

_classifier_instance = None

def _load_classifier():
    global _classifier_instance
    if _classifier_instance is not None:
        return _classifier_instance
    try:
        from pipeline import SensitivityClassifier as _SC
        clf = _SC(
            artifacts_dir=os.path.join(_TEAM_B_DIR, "artifacts"),
            model_config =os.path.join(_TEAM_B_DIR, "configs", "model.yaml"),
            policy_config=os.path.join(_TEAM_B_DIR, "configs", "policy.yaml"),
        )
        _classifier_instance = clf
        logger.info("Teammate B SensitivityClassifier loaded OK.")
        return clf
    except Exception as e:
        logger.warning("Teammate B not available: %s", e)
        return None


def classify_document(raw_text: str, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    t0 = time.perf_counter()
    metadata = metadata or {}
    if not metadata.get("doc_id"):
        metadata["doc_id"] = str(uuid.uuid4())

    preprocessed = _do_preprocessing(raw_text, metadata)
    clf_result   = _do_classification(preprocessed, metadata)

    label        = clf_result.get("label") or clf_result.get("predicted_label", "Internal")
    conf_scores  = clf_result.get("class_probabilities") or {}
    evidence_tokens = _extract_evidence_tokens(clf_result.get("evidence") or [], raw_text)
    policy_trace = clf_result.get("policy_trace") or {}
    policy_action   = policy_trace.get("action") or _label_to_action(label)
    policy_override = bool(policy_trace.get("override", False))
    model_version   = (clf_result.get("audit") or {}).get("model_version", "unknown")
    pii_types    = _extract_pii_types(preprocessed)
    lang_code    = preprocessed.get("_lang_code", "en")

    return {
        "doc_id":             metadata["doc_id"],
        "predicted_label":    label,
        "confidence_scores":  conf_scores,
        "evidence_tokens":    evidence_tokens,
        "policy_action":      policy_action,
        "policy_override":    policy_override,
        "model_version":      model_version,
        "language":           lang_code,
        "pii_types_detected": pii_types,
        "total_latency_ms":   round((time.perf_counter() - t0) * 1000, 2),
        "classified_at":      datetime.now(timezone.utc).isoformat(),
    }


def _do_preprocessing(raw_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
    if _TEAM_A_OK:
        try:
            payload = {
                "doc_id":   metadata.get("doc_id", str(uuid.uuid4())),
                "raw_text": raw_text,
                "event_id": str(uuid.uuid4()),
                "business_metadata": {
                    "source_system": metadata.get("source_system", "api_direct"),
                    "department":    metadata.get("department", "UNKNOWN"),
                    "business_unit": "UNKNOWN",
                    "region":        metadata.get("region", "UNKNOWN"),
                    "owner":         metadata.get("author", "UNKNOWN"),
                    "document_type": metadata.get("file_type", "general"),
                    "client_name":   "UNKNOWN",
                    "source_channel":"rest_api",
                },
                "technical_metadata": {
                    "ingest_id":        metadata.get("doc_id", str(uuid.uuid4())),
                    "ingest_timestamp": datetime.now(timezone.utc).isoformat(),
                    "file_name":        metadata.get("file_name", "api_upload.txt"),
                    "file_size_bytes":  len(raw_text.encode()),
                    "mime_type":        "text/plain",
                    "checksum_sha256":  "",
                    "parser_used":      "api_direct",
                    "structure_type":   "single",
                    "data_category":    "unstructured",
                },
            }
            result = _run_preprocessing_pipeline(payload, source_topic="api_direct")
            if result.status == "success" and result.documents:
                pdoc = result.documents[0]
                return {
                    "masked_text":     pdoc.masked_text,
                    "clean_text":      pdoc.clean_text,
                    "tokens":          pdoc.tokens,
                    "sentence_chunks": pdoc.sentence_chunks,
                    "_lang_code":      pdoc.language.code if pdoc.language else "en",
                    "_pii_entities":   pdoc.pii_entities.model_dump() if pdoc.pii_entities else {},
                    "_pii_hint":       pdoc.pii_policy_hint,
                    "_status":         "ok",
                }
            logger.warning("Preprocessing non-success: %s / %s", result.status, result.failure_reason)
        except Exception as e:
            logger.error("Teammate A error: %s", e)
    return _fallback_preprocessing(raw_text, metadata)


def _do_classification(preprocessed: Dict[str, Any], metadata: Dict[str, Any]) -> Dict[str, Any]:
    clf = _load_classifier()
    if clf is not None:
        try:
            text = preprocessed.get("masked_text") or preprocessed.get("clean_text", "")
            clf_meta = {
                "source_system": metadata.get("source_system", "UNKNOWN"),
                "department":    metadata.get("department", "UNKNOWN"),
                "file_type":     metadata.get("file_type", "general"),
                "author":        metadata.get("author", "UNKNOWN"),
                "region":        metadata.get("region", "UNKNOWN"),
            }
            return clf.predict(text, clf_meta)
        except Exception as e:
            logger.error("Teammate B error: %s", e)
    return _fallback_classification(preprocessed)


def _fallback_preprocessing(raw_text: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
    _PII = [
        ("SSN",r"\b\d{3}-\d{2}-\d{4}\b"), ("CREDIT_CARD",r"\b\d{4}[- ]\d{4}[- ]\d{4}[- ]\d{4}\b"),
        ("IBAN",r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7,}\b"), ("PAN",r"\b[A-Z]{5}[0-9]{4}[A-Z]\b"),
        ("AADHAAR",r"\b\d{4}\s\d{4}\s\d{4}\b"), ("EMAIL",r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"),
    ]
    pii_found, masked = {}, raw_text
    for pii_type, pattern in _PII:
        ms = re.findall(pattern, masked)
        if ms:
            pii_found[pii_type] = len(ms)
            masked = re.sub(pattern, f"<{pii_type}>", masked)
    tokens = [t for t in re.split(r'\W+', masked.lower()) if len(t) > 2]
    hint = "Quarantine" if any(k in pii_found for k in ["SSN","PAN","CREDIT_CARD","AADHAAR","IBAN"]) else (
           "Encrypt" if "EMAIL" in pii_found else "Allow")
    return {"masked_text":masked,"clean_text":raw_text,"tokens":tokens[:128],
            "sentence_chunks":[raw_text],"_lang_code":"en","_pii_entities":pii_found,
            "_pii_hint":hint,"_status":"fallback"}


def _fallback_classification(preprocessed: Dict[str, Any]) -> Dict[str, Any]:
    text = (preprocessed.get("masked_text") or "").lower()
    pii  = preprocessed.get("_pii_entities", {})
    hint = preprocessed.get("_pii_hint", "Allow")
    if hint == "Quarantine" or any(pii.get(k,0) > 0 for k in ["SSN","PAN","CREDIT_CARD","AADHAAR","IBAN"]):
        label,probs,action = "Restricted",{"Public":0.02,"Internal":0.05,"Confidential":0.10,"Restricted":0.83},"Quarantine"
    elif hint == "Encrypt" or any(pii.get(k,0) > 0 for k in ["EMAIL","PHONE"]):
        label,probs,action = "Confidential",{"Public":0.05,"Internal":0.15,"Confidential":0.70,"Restricted":0.10},"Encrypt"
    elif any(w in text for w in ["internal","memo","confidential","restricted"]):
        label,probs,action = "Internal",{"Public":0.10,"Internal":0.72,"Confidential":0.15,"Restricted":0.03},"Allow"
    else:
        label,probs,action = "Public",{"Public":0.78,"Internal":0.15,"Confidential":0.05,"Restricted":0.02},"Allow"
    tokens_raw = preprocessed.get("tokens", text.split())
    evidence = [{"token":t,"weight":0.5,"source":"heuristic"} for t in tokens_raw[:5] if len(t)>3]
    return {"label":label,"confidence":probs[label],"class_probabilities":probs,"evidence":evidence,
            "policy_trace":{"action":action,"override":hint=="Quarantine","rules_fired":[]},
            "audit":{"model_version":"heuristic-fallback-v1","ensemble_used":"none",
                     "active_models":[],"runtime_mode":"fallback"}}


def _extract_evidence_tokens(evidence_raw: List, raw_text: str) -> List[str]:
    tokens = [ev.get("token","") if isinstance(ev,dict) else str(ev) for ev in evidence_raw]
    tokens = [t for t in tokens if t]
    if len(tokens) < 3:
        for w in raw_text.split():
            if len(w) > 3 and w not in tokens:
                tokens.append(w)
            if len(tokens) >= 3:
                break
    return tokens[:8]


def _extract_pii_types(preprocessed: Dict[str, Any]) -> List[str]:
    pii = preprocessed.get("_pii_entities", {})
    return [k for k, v in pii.items() if isinstance(v, int) and v > 0] if isinstance(pii, dict) else []


def _label_to_action(label: str) -> str:
    return {"Public":"Allow","Internal":"Allow","Confidential":"Encrypt","Restricted":"Quarantine"}.get(label,"Allow")
