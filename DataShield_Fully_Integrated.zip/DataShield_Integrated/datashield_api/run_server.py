"""
datashield_api/run_server.py
==============================
Starts the DataShield API server.

Usage:
    python datashield_api/run_server.py
    python datashield_api/run_server.py --host 0.0.0.0 --port 8000 --reload

Auth: Authorization: Bearer dev-token-001
Docs: http://localhost:8000/docs
"""
import sys, os, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import uvicorn

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host",    default="127.0.0.1")
    parser.add_argument("--port",    type=int, default=8000)
    parser.add_argument("--reload",  action="store_true")
    parser.add_argument("--workers", type=int, default=1)
    args = parser.parse_args()

    print(f"\n🔐 DataShield Classification API (Integrated)")
    print(f"   URL:  http://{args.host}:{args.port}")
    print(f"   Docs: http://{args.host}:{args.port}/docs")
    print(f"   Auth: Bearer dev-token-001\n")

    uvicorn.run(
        "datashield_api.api.main:app",
        host=args.host, port=args.port,
        reload=args.reload,
        workers=args.workers if not args.reload else 1,
        log_level="info",
    )

if __name__ == "__main__":
    main()
