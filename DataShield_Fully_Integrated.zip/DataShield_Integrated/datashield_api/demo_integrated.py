"""
datashield_api/demo_integrated.py
===================================
Runs the FULL integrated pipeline without starting the HTTP server.
Tests that all three sub-teams' code works together end-to-end.

Usage:
    python datashield_api/demo_integrated.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datashield_api.integration_bridge import classify_document

SAMPLES = [
    ("Public press release: Acme Corp Q1 revenue $2.3B, exceeding analyst expectations.",
     {"source_system": "cms", "department": "Marketing"}),

    ("Internal memo: Team offsite scheduled December 10th Bangalore. Attendance mandatory.",
     {"source_system": "intranet", "department": "Engineering"}),

    ("Employee compensation review 2026. Base: $145,000. Bonus target: 20%. Confidential — HR only.",
     {"source_system": "hr_portal", "department": "HR", "file_type": "pdf"}),

    ("RESTRICTED: Customer PAN 4111-1111-1111-1111, SSN 123-45-6789. Visa audit reconciliation.",
     {"source_system": "payments", "department": "Finance"}),

    ("Contract with Vendor X. Total value: $2.4M. IBAN: GB29NWBK60161331926819. Legal hold.",
     {"source_system": "legal_dms", "department": "Legal"}),
]

def main():
    print("=" * 65)
    print("  DataShield — Integrated End-to-End Demo")
    print("  Teammate A (Preprocessing) + Teammate B (Classification)")
    print("=" * 65)

    for i, (text, meta) in enumerate(SAMPLES, 1):
        print(f"\n[Doc {i}] {text[:70]}...")
        result = classify_document(text, meta)
        print(f"  Label      : {result['predicted_label']}")
        print(f"  Action     : {result['policy_action']}")
        print(f"  Confidence : {result['confidence_scores'].get(result['predicted_label'], 0):.1%}")
        print(f"  Evidence   : {result['evidence_tokens'][:3]}")
        print(f"  PII found  : {result['pii_types_detected'] or 'none'}")
        print(f"  Override   : {result['policy_override']}")
        print(f"  Latency    : {result['total_latency_ms']:.1f}ms")
        print(f"  Model      : {result['model_version']}")

    print("\n" + "=" * 65)
    print("  Demo complete.")
    print("=" * 65)

if __name__ == "__main__":
    main()
