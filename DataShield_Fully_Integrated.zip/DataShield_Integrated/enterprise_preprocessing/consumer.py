"""
consumer.py
============
Kafka Consumer for the Enterprise Preprocessing Layer.
AUTO LOCAL-MODE FALLBACK: if Kafka is unavailable, reads from
logs/local_queue/ (written by the ingestion local producer).
"""

from __future__ import annotations

import json, os, signal, time
from typing import Dict

from config import CONFIG
from logger import get_logger
from producer import PreprocessingProducer
from pipeline import run_pipeline
from schema import ProcessingStatus

log = get_logger("consumer")

_LOCAL_MODE = os.environ.get("LOCAL_MODE", "false").lower() in ("true", "1", "yes")

try:
    from kafka import KafkaConsumer
    from kafka.errors import NoBrokersAvailable
    _KAFKA_LIB = True
except ImportError:
    _KAFKA_LIB = False
    _LOCAL_MODE = True


def _deser(data: bytes) -> Dict:
    try:
        return json.loads(data.decode("utf-8")) if data else {}
    except Exception:
        return {}


class PreprocessingConsumer:
    def __init__(self):
        self._running = True
        self._producer = None
        self._consumer = None
        self._stats = {"received": 0, "success": 0, "failed": 0, "chunks": 0}
        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)

    def run(self):
        self._producer = PreprocessingProducer()
        if _LOCAL_MODE or not _KAFKA_LIB:
            self._run_local()
        else:
            self._run_kafka()

    def _run_local(self):
        """Process JSON files from logs/local_queue/ (no Kafka needed)."""
        ingestion_queue = os.path.join("..", "ingestion_project", "logs", "local_queue")
        topics = ["single_entity_docs", "multi_entity_docs", "raw_documents"]
        log.info("LOCAL MODE: polling %s for topics %s", ingestion_queue, topics)
        processed_files = set()
        try:
            while self._running:
                found = False
                for topic in topics:
                    topic_dir = os.path.join(ingestion_queue, topic)
                    if not os.path.isdir(topic_dir):
                        continue
                    for fname in sorted(os.listdir(topic_dir)):
                        fpath = os.path.join(topic_dir, fname)
                        if fpath in processed_files or not fname.endswith(".json"):
                            continue
                        try:
                            with open(fpath, "r", encoding="utf-8") as f:
                                payload = json.load(f)
                            self._handle_payload(payload, topic)
                            processed_files.add(fpath)
                            found = True
                        except Exception as exc:
                            log.error("Error reading %s: %s", fpath, exc)
                if not found:
                    time.sleep(2)
        finally:
            self._producer.close()
            log.info("Local consumer stopped | stats=%s", self._stats)

    def _run_kafka(self):
        try:
            self._consumer = KafkaConsumer(
                *CONFIG.topics.input_topics,
                value_deserializer=_deser,
                key_deserializer=lambda k: k.decode("utf-8") if k else None,
                **CONFIG.kafka.consumer_kwargs(),
            )
        except Exception as exc:
            log.warning("Kafka unavailable (%s) — switching to LOCAL MODE", exc)
            self._run_local()
            return

        log.info("Kafka consumer started | topics=%s", CONFIG.topics.input_topics)
        try:
            for msg in self._consumer:
                if not self._running:
                    break
                self._handle_payload(msg.value, msg.topic)
                self._consumer.commit()
        finally:
            self._consumer.close()
            self._producer.close()

    def _handle_payload(self, raw_payload: Dict, source_topic: str):
        self._stats["received"] += 1
        result = run_pipeline(raw_payload, source_topic=source_topic)
        if result.status in (ProcessingStatus.SUCCESS.value, ProcessingStatus.PARTIAL.value):
            self._stats["success"] += 1
            self._stats["chunks"] += result.chunks_produced
            for pdoc in result.documents:
                self._producer.send_preprocessed(pdoc.model_dump())
            if result.audit:
                self._producer.send_audit(result.audit.model_dump())
            log.info("Processed: %s", result)
        else:
            self._stats["failed"] += 1
            if result.dlr:
                self._producer.send_dlq(result.dlr.model_dump())
            if result.audit:
                self._producer.send_audit(result.audit.model_dump())
            log.warning("Failed: %s", result)

    def _handle_shutdown(self, *_):
        log.info("Shutdown signal.")
        self._running = False
