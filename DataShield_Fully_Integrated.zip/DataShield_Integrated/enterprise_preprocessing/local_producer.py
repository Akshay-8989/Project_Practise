"""
local_producer.py
==================
File-based fallback for PreprocessingProducer when Kafka is unavailable.
Writes messages to logs/local_queue/<topic>/<timestamp>.json
"""
import json, os, time
from typing import Any, Dict, Optional


class LocalPreprocessingProducer:
    def __init__(self, queue_dir: str = "logs/local_queue"):
        self._queue_dir = queue_dir
        os.makedirs(queue_dir, exist_ok=True)
        print(f"[LocalPreprocessingProducer] LOCAL MODE — writing to {queue_dir}/")

    def _write(self, topic: str, key: Optional[str], data: Dict):
        d = os.path.join(self._queue_dir, topic)
        os.makedirs(d, exist_ok=True)
        ts = int(time.time() * 1000)
        safe_key = (key or "nokey").replace("/", "_")[:40]
        with open(os.path.join(d, f"{ts}_{safe_key}.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, default=str, ensure_ascii=False, indent=2)

    def send_preprocessed(self, payload: Dict): self._write("preprocessed_documents", payload.get("doc_id"), payload)
    def send_audit(self, entry: Dict): self._write("preprocessing_audit_logs", entry.get("preprocess_id"), entry)
    def send_retry(self, entry: Dict): self._write("preprocessing_retry_queue", entry.get("retry_id"), entry)
    def send_dlq(self, record: Dict): self._write("preprocessing_dead_letter_queue", record.get("doc_id", "unknown"), record)
    def flush(self, timeout: int = 30): pass
    def close(self): print(f"[LocalPreprocessingProducer] Closed.")
    def __enter__(self): return self
    def __exit__(self, *_): self.close()
