"""
producer.py
============
Kafka producer for the Preprocessing Layer.
AUTO LOCAL-MODE FALLBACK: if Kafka is unreachable, falls back to
writing JSON files in logs/local_queue/. Set LOCAL_MODE=true to force.
"""
import json, os
from typing import Any, Dict, Optional

from config import CONFIG
from logger import get_logger
from local_producer import LocalPreprocessingProducer

log = get_logger("producer")

_LOCAL_MODE = os.environ.get("LOCAL_MODE", "false").lower() in ("true", "1", "yes")

try:
    from kafka import KafkaProducer
    from kafka.errors import KafkaError
    _KAFKA_LIB = True
except ImportError:
    _KAFKA_LIB = False
    _LOCAL_MODE = True
    log.warning("kafka-python not installed — LOCAL MODE")

def _ser(obj: Any) -> bytes:
    return json.dumps(obj, default=str, ensure_ascii=False).encode("utf-8")

def _key(k: Optional[str]) -> Optional[bytes]:
    return k.encode("utf-8") if k else None


class PreprocessingProducer:
    def __init__(self):
        self._local = None
        self._p = None
        if _LOCAL_MODE or not _KAFKA_LIB:
            self._local = LocalPreprocessingProducer()
            return
        try:
            self._p = KafkaProducer(value_serializer=_ser, key_serializer=_key, **CONFIG.kafka.producer_kwargs())
            log.info("Producer connected | broker=%s", CONFIG.kafka.bootstrap_servers)
        except Exception as exc:
            log.warning("Kafka not reachable (%s) — LOCAL MODE", exc)
            self._local = LocalPreprocessingProducer()

    def __enter__(self): return self
    def __exit__(self, *_): self.close()

    def send_preprocessed(self, payload: Dict):
        if self._local: self._local.send_preprocessed(payload)
        else: self._send(CONFIG.topics.preprocessed, payload.get("doc_id"), payload)

    def send_audit(self, entry: Dict):
        if self._local: self._local.send_audit(entry)
        else: self._send(CONFIG.topics.audit_logs, entry.get("preprocess_id"), entry)

    def send_retry(self, entry: Dict):
        if self._local: self._local.send_retry(entry)
        else: self._send(CONFIG.topics.retry_queue, entry.get("retry_id"), entry)

    def send_dlq(self, record: Dict):
        if self._local: self._local.send_dlq(record)
        else: self._send(CONFIG.topics.dlq, record.get("doc_id", "unknown"), record)

    def flush(self, timeout: int = 30):
        if self._local: pass
        elif self._p: self._p.flush(timeout=timeout)

    def close(self):
        self.flush()
        if self._local: self._local.close()
        elif self._p: self._p.close(); log.info("Producer closed.")

    def _send(self, topic, key, data):
        try:
            (self._p.send(topic, key=key, value=data)
             .add_callback(lambda m: log.debug("Delivered → %s", m.topic))
             .add_errback(lambda e: log.error("Kafka error: %s", e)))
        except Exception as exc:
            log.error("Send failed → %s: %s", topic, exc)
