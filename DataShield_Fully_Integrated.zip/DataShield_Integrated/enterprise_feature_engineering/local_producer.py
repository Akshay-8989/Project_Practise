"""local_producer.py — file-based fallback for FeatureProducer when Kafka is unavailable."""
import json, os, time
from typing import Dict, Optional

class LocalFeatureProducer:
    def __init__(self, queue_dir: str = "logs/local_queue"):
        self._queue_dir = queue_dir
        os.makedirs(queue_dir, exist_ok=True)
        print(f"[LocalFeatureProducer] LOCAL MODE — writing to {queue_dir}/")

    def _write(self, topic, key, data):
        d = os.path.join(self._queue_dir, topic)
        os.makedirs(d, exist_ok=True)
        ts = int(time.time() * 1000)
        safe_key = (key or "nokey").replace("/", "_")[:40]
        with open(os.path.join(d, f"{ts}_{safe_key}.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, default=str, ensure_ascii=False, indent=2)

    def send_features(self, payload: Dict): self._write("engineered_features", payload.get("doc_id"), payload)
    def send_training(self, payload: Dict): self._write("training_store", payload.get("doc_id"), payload)
    def send_realtime(self, payload: Dict): self._write("realtime_store", payload.get("doc_id"), payload)
    def send_audit(self, entry: Dict): self._write("feature_audit_logs", entry.get("feature_run_id"), entry)
    def send_retry(self, entry: Dict): self._write("feature_retry_queue", entry.get("retry_id"), entry)
    def send_dlq(self, record: Dict): self._write("feature_dlq", record.get("doc_id", "unknown"), record)
    def flush(self, timeout: int = 30): pass
    def close(self): print("[LocalFeatureProducer] Closed.")
    def __enter__(self): return self
    def __exit__(self, *_): self.close()
