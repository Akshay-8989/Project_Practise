"""
consumer.py — Feature Engineering Layer Consumer.
AUTO LOCAL-MODE FALLBACK: reads from preprocessing local_queue if Kafka unavailable.
"""
from __future__ import annotations
import json, os, signal, time
from typing import Dict

from config import CONFIG
from logger import get_logger
from producer import FeatureProducer
from pipeline import run_pipeline
from schema import ProcessingStatus

log = get_logger("consumer")
_LOCAL_MODE = os.environ.get("LOCAL_MODE", "false").lower() in ("true", "1", "yes")
try:
    from kafka import KafkaConsumer
    _KAFKA_LIB = True
except ImportError:
    _KAFKA_LIB = False; _LOCAL_MODE = True

def _deser(data: bytes) -> Dict:
    try: return json.loads(data.decode("utf-8")) if data else {}
    except: return {}


class FeatureEngineeringConsumer:
    def __init__(self):
        self._running = True
        self._producer = None
        self._stats = {"received": 0, "success": 0, "failed": 0}
        signal.signal(signal.SIGINT, self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

    def run(self):
        self._producer = FeatureProducer()
        if _LOCAL_MODE or not _KAFKA_LIB:
            self._run_local()
        else:
            self._run_kafka()

    def _run_local(self):
        preprocessing_queue = os.path.join("..", "enterprise_preprocessing", "logs", "local_queue")
        topic_dir = os.path.join(preprocessing_queue, "preprocessed_documents")
        log.info("LOCAL MODE: polling %s", topic_dir)
        processed = set()
        try:
            while self._running:
                found = False
                if os.path.isdir(topic_dir):
                    for fname in sorted(os.listdir(topic_dir)):
                        fpath = os.path.join(topic_dir, fname)
                        if fpath in processed or not fname.endswith(".json"): continue
                        try:
                            with open(fpath, "r", encoding="utf-8") as f:
                                payload = json.load(f)
                            self._handle_payload(payload, "preprocessed_documents")
                            processed.add(fpath)
                            found = True
                        except Exception as exc:
                            log.error("Error reading %s: %s", fpath, exc)
                if not found: time.sleep(2)
        finally:
            self._producer.close()

    def _run_kafka(self):
        try:
            consumer = KafkaConsumer(
                CONFIG.topics.preprocessed,
                value_deserializer=_deser,
                key_deserializer=lambda k: k.decode("utf-8") if k else None,
                **CONFIG.kafka.consumer_kwargs(),
            )
        except Exception as exc:
            log.warning("Kafka unavailable (%s) — LOCAL MODE", exc)
            self._run_local(); return
        log.info("Kafka consumer started | topic=%s | mode=%s", CONFIG.topics.preprocessed, CONFIG.mode)
        try:
            for msg in consumer:
                if not self._running: break
                self._handle_payload(msg.value, msg.topic)
                consumer.commit()
        finally:
            consumer.close(); self._producer.close()

    def _handle_payload(self, raw: Dict, source_topic: str):
        self._stats["received"] += 1
        result = run_pipeline(raw, source_topic=source_topic)
        if result.status in (ProcessingStatus.SUCCESS.value, ProcessingStatus.PARTIAL.value):
            self._stats["success"] += 1
            payload = result.feature_set.model_dump()
            self._producer.send_features(payload)
            if CONFIG.is_training_mode: self._producer.send_training(payload)
            if result.audit: self._producer.send_audit(result.audit.model_dump())
            log.info("Engineered: %s", result)
        else:
            self._stats["failed"] += 1
            if result.dlr: self._producer.send_dlq(result.dlr.model_dump())
            if result.audit: self._producer.send_audit(result.audit.model_dump())
            log.warning("Failed: %s", result)

    def _shutdown(self, *_):
        log.info("Shutdown signal."); self._running = False
