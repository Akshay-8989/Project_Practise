# How to Run DataShield — Complete Step-by-Step Guide
# No Kafka required. Works on any laptop.

---

## What you need before starting
- Python 3.9, 3.10, or 3.11 (3.12+ works for FAST mode but avoid for FULL mode)
- pip
- Node.js 18+ (only if you want the React frontend)
- No Kafka, no Docker, no database

---

## Step 1 — Go into the project folder

```bash
cd DataShield_Integrated
```

---

## Step 2 — Create a virtual environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python -m venv venv
source venv/bin/activate
```

You'll see (venv) in your terminal prompt. Keep this active for all steps.

---

## Step 3 — Install dependencies (FAST mode — no PyTorch needed)

```bash
pip install -r requirements.txt
```

This installs everything for the API, MLOps, and classification in FAST mode
(Logistic Regression + XGBoost + Stacking ensemble). No transformer download.
Total size: ~150 MB. Takes 2–5 minutes.

---

## Step 4 — Train the models (MUST do this before running the API)

The trained .joblib files already exist in classification_module/artifacts/.
If they are there, SKIP this step. If not:

```bash
cd classification_module
python -m scripts.train_all --sample 500
cd ..
```

This trains English + Hindi models in FAST mode. Takes ~30 seconds.

To verify artifacts exist:
```bash
# Should show logistic.joblib, xgboost.joblib, stacker.joblib in each folder
ls classification_module/artifacts/en/
ls classification_module/artifacts/hi/
```

---

## Step 5 — Test that the integration works (no server needed)

```bash
python datashield_api/demo_integrated.py
```

Expected output:
```
=================================================================
  DataShield — Integrated End-to-End Demo
  Teammate A (Preprocessing) + Teammate B (Classification)
=================================================================

[Doc 1] Public press release: Acme Corp Q1 revenue $2.3B...
  Label      : Public
  Action     : Allow
  Confidence : 78.0%
  Evidence   : ['revenue', 'corp', 'acme']
  PII found  : none
  Latency    : 45.3ms

[Doc 4] RESTRICTED: Customer PAN 4111-1111-1111-1111...
  Label      : Restricted
  Action     : Quarantine
  Confidence : 83.0%
  PII found  : ['CREDIT_CARD', 'SSN']
  Override   : True
```

If you see labels and evidence tokens, the full pipeline is working.

---

## Step 6 — Start the API server

```bash
python datashield_api/run_server.py
```

You'll see:
```
🔐 DataShield Classification API (Integrated)
   URL:  http://127.0.0.1:8000
   Docs: http://127.0.0.1:8000/docs
   Auth: Bearer dev-token-001
```

Leave this terminal running. Open a browser and go to:
http://127.0.0.1:8000/docs  ← interactive Swagger UI

---

## Step 7 — Test the API

Open a new terminal (keep the server running in the first one).

### Health check (no auth needed)
```bash
curl http://localhost:8000/health
```
Expected: `{"status":"ok","timestamp":"..."}`

### Classify a document
```bash
curl -X POST http://localhost:8000/classify \
  -H "Authorization: Bearer dev-token-001" \
  -H "Content-Type: application/json" \
  -d "{\"text\": \"Employee SSN: 123-45-6789. Salary: $145,000.\", \"source_system\": \"hr_portal\", \"department\": \"HR\"}"
```

### Get model info
```bash
curl http://localhost:8000/model/info \
  -H "Authorization: Bearer dev-token-001"
```

### Batch classify
```bash
curl -X POST http://localhost:8000/classify/batch \
  -H "Authorization: Bearer dev-token-001" \
  -H "Content-Type: application/json" \
  -d "{\"documents\": [{\"text\": \"Public announcement\"}, {\"text\": \"SSN: 123-45-6789\"}]}"
```

---

## Step 8 — Start the frontend dashboard (optional)

Requires Node.js 18+. Open a third terminal:

```bash
cd datashield_api/frontend
npm install      # first time only — takes 1–2 minutes
npm start        # starts at http://localhost:3000
```

The dashboard talks to the API at localhost:8000 automatically.
Open http://localhost:3000 in your browser.

Pages:
- / Dashboard — charts and model metrics
- /classify — classify a document, see confidence bars and evidence tokens
- /batch — classify multiple documents
- /audit — look up a past classification by doc_id
- /feedback — submit a correction
- /model — champion model metrics with PS-01 threshold status

---

## Troubleshooting

### "ModuleNotFoundError: No module named 'pipeline'"
The preprocessing or classification module is not on the path.
Run the server from the project root:
```bash
cd DataShield_Integrated
python datashield_api/run_server.py   # not from inside datashield_api/
```

### "No such file: artifacts/en/logistic.joblib"
Models not trained yet. Run:
```bash
cd classification_module
python -m scripts.train_all --sample 500
cd ..
```

### "401 Unauthorized"
Add the header: -H "Authorization: Bearer dev-token-001"

### "422 Unprocessable Entity"
Your request body failed Pydantic validation. Check:
- text field must not be empty (min 1 character)
- batch must not exceed 100 documents

### Import errors about langdetect, sklearn, xgboost
Run: pip install -r requirements.txt  (inside the venv)

### "address already in use" on port 8000
Another process is using 8000. Either kill it or use a different port:
```bash
python datashield_api/run_server.py --port 8001
```
Then update the frontend proxy in datashield_api/frontend/package.json:
change "proxy": "http://localhost:8000" → "http://localhost:8001"

### Teammate A or B showing "fallback" mode
The integration bridge will say "using fallback" in the logs if it can't
import a teammate pipeline. The API still works — it uses heuristics.
Check that:
- You are running from DataShield_Integrated/ (not from inside datashield_api/)
- enterprise_platform/preprocessing/pipeline.py and classification_module/pipeline.py exist
- All pip packages are installed: pip install -r requirements.txt

---

## Running on a fresh machine (Antigravity / any cloud VM)

```bash
# 1. Clone / upload the project
cd DataShield_Integrated

# 2. Python setup
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Train models if artifacts missing
ls classification_module/artifacts/en/logistic.joblib || (
  cd classification_module && python -m scripts.train_all --sample 500 && cd ..
)

# 4. Start API (bind to all interfaces so it's accessible externally)
python datashield_api/run_server.py --host 0.0.0.0 --port 8000

# 5. Frontend (optional, separate terminal)
cd datashield_api/frontend && npm install && npm start
```

If running on Antigravity/cloud, replace localhost with your server IP:
- API: http://<your-ip>:8000
- Frontend: http://<your-ip>:3000
- Swagger docs: http://<your-ip>:8000/docs

If using Antigravity's tunnel/proxy, set the REACT_APP_API_URL env var:
```bash
REACT_APP_API_URL=http://<your-ip>:8000 npm start
```

---

## What each terminal does

| Terminal | Command | What it runs |
|----------|---------|-------------|
| 1 | python datashield_api/run_server.py | FastAPI + Uvicorn API server |
| 2 | cd datashield_api/frontend && npm start | React dashboard |
| 3 | (free for curl / testing) | |

---

## Summary — minimum commands to get everything running

```bash
cd DataShield_Integrated
python -m venv venv && source venv/bin/activate   # (use venv\Scripts\activate on Windows)
pip install -r requirements.txt
python datashield_api/demo_integrated.py           # verify it works
python datashield_api/run_server.py                # start API
```

That's it. No Kafka. No Docker. No database.
