"""
synthetic_generator.py
----------------------
Generates a bilingual synthetic labeled dataset for the 4-class sensitivity
taxonomy, in English and Hindi.

Per problem statement: "Language detection → route to language-specific
model." So we need training data in each supported language.

Output: data/synthetic_dataset.csv with columns:
    text, label, language, source_system, department, file_type, author

language is 'en' or 'hi'. Pipeline uses this to train two model sets and
route documents at inference time.

Size: N_PER_CLASS samples per class per language = 4 classes × 2 langs × N.
Default N_PER_CLASS = 2500 → 20,000 total rows.
"""
import csv
import os
import random
from pathlib import Path

SEED = 42
random.seed(SEED)

N_PER_CLASS = 2500   # per class, per language

# ================================================================
# ENGLISH TEMPLATES
# ================================================================

EN_PUBLIC_TEMPLATES = [
    "Our company announced {event} at the {venue} today. Visit our website for details.",
    "Press release: {company} launches new {product} for the {region} market.",
    "Job posting: We are hiring a {role} to join our {team} team. Apply at careers page.",
    "Blog post: {num} tips for {topic} in {year}.",
    "Public FAQ: How do I reset my account password? Click forgot password on login.",
    "Marketing email: Check out our latest {product} on sale this week only.",
    "Public filing: {company} reports {metric} growth in quarterly earnings call.",
    "Event invite: Join our webinar on {topic} next Tuesday at 3pm EST.",
    "News article: Industry leaders gather to discuss {topic} trends.",
    "Company blog: Why {topic} matters for {industry} in {year}.",
]

EN_INTERNAL_TEMPLATES = [
    "Team meeting notes: We discussed the {project} roadmap and agreed on next milestones.",
    "Internal memo: Office will be closed on {date} for the holiday.",
    "IT update: Please install the latest {software} patch by end of week.",
    "Onboarding doc: New hires should complete {training} training in first 30 days.",
    "Internal wiki: The {project} project uses {tech} as its main framework.",
    "All-hands summary: CEO talked about {topic} and Q{num} priorities.",
    "Process doc: How to submit a purchase order through the internal portal.",
    "Engineering standup: Blocker on {project}, need review from {team} team.",
    "Ticket update: Deployment of {project} pushed to next sprint per team lead.",
    "Department newsletter: {team} welcomes three new members this month.",
]

EN_CONFIDENTIAL_TEMPLATES = [
    "Performance review for employee: meets expectations on {project}, needs improvement on communication. Salary band adjustment pending.",
    "Compensation summary: employee base salary {currency} {amount}, bonus target {num} percent, equity grant under review.",
    "Termination letter draft: Effective {date}, employment is terminated due to performance. HR to process final pay.",
    "Merger negotiation notes: {company} acquisition target valuation {currency} {amount} million. Non-public.",
    "Source code review: proprietary algorithm for {product}, contains trade secret implementation details.",
    "Internal financial forecast: Q{num} revenue projection {currency} {amount} million, margin {num} percent. Do not share externally.",
    "Legal case file: pending litigation with {company} regarding {topic}. Attorney-client privileged.",
    "Strategy deck: market expansion into {region} planned for {year}. Competitive intelligence attached.",
    "Board memo: discussion of potential acquisition of {company}. Strictly confidential until announced.",
    "Employee disciplinary record: written warning issued for policy violation on {date}.",
    "Vendor contract: {company} agrees to pricing of {currency} {amount} per unit. Non-disclosure applies.",
    "HR investigation notes: complaint filed against {name} regarding workplace conduct. Confidential.",
]

EN_RESTRICTED_TEMPLATES = [
    "Customer onboarding form: SSN {ssn}, DOB {dob}, full legal name {name}, address on file.",
    "Payment processing log: card number {card}, CVV on file, cardholder {name}, transaction amount {currency} {amount}.",
    "Bank transfer record: IBAN {iban}, beneficiary {name}, amount {currency} {amount}, reference {project}.",
    "Medical intake form: patient {name} DOB {dob}, SSN {ssn}, diagnosis code {topic}, treatment plan attached.",
    "Background check result: candidate {name} SSN {ssn}, criminal record: clean. Credit score: {num}.",
    "Wire transfer instruction: beneficiary account {iban}, routing details, amount {currency} {amount}, urgent.",
    "Loan application: applicant {name}, SSN {ssn}, annual income {currency} {amount}, DOB {dob}.",
    "KYC document: customer {name}, PAN {pan}, Aadhaar {aadhaar}, address proof attached.",
    "Insurance claim: policy holder {name}, SSN {ssn}, claim amount {currency} {amount}, incident on {dob}.",
    "Tax filing: taxpayer {name}, SSN {ssn}, AGI {currency} {amount}, filing status single.",
    "Credit card application: {name}, DOB {dob}, SSN {ssn}, requested limit {currency} {amount}.",
    "Account statement: account holder {name}, account ending {num}, balance {currency} {amount}, SSN on file {ssn}.",
]

# ================================================================
# HINDI TEMPLATES (Devanagari script)
# ================================================================

HI_PUBLIC_TEMPLATES = [
    "हमारी कंपनी ने आज {venue} पर {event} की घोषणा की। विस्तृत जानकारी के लिए हमारी वेबसाइट देखें।",
    "प्रेस विज्ञप्ति: {company} ने {region} बाज़ार के लिए नया {product} लॉन्च किया।",
    "नौकरी की सूचना: हम {team} टीम में शामिल होने के लिए {role} की भर्ती कर रहे हैं।",
    "ब्लॉग पोस्ट: {year} में {topic} के लिए {num} सुझाव।",
    "सार्वजनिक सामान्य प्रश्न: मैं अपने खाते का पासवर्ड कैसे रीसेट करूं?",
    "मार्केटिंग ईमेल: इस सप्ताह हमारे नवीनतम {product} पर विशेष छूट पाएं।",
    "तिमाही रिपोर्ट: {company} ने {metric} वृद्धि दर्ज की।",
    "कार्यक्रम आमंत्रण: अगले मंगलवार दोपहर तीन बजे {topic} पर हमारे वेबिनार में शामिल हों।",
    "समाचार लेख: उद्योग जगत के नेता {topic} रुझानों पर चर्चा करने के लिए एकत्रित हुए।",
    "कंपनी ब्लॉग: {year} में {industry} के लिए {topic} क्यों महत्वपूर्ण है।",
]

HI_INTERNAL_TEMPLATES = [
    "टीम मीटिंग नोट्स: हमने {project} रोडमैप पर चर्चा की और अगले मील के पत्थरों पर सहमति बनी।",
    "आंतरिक ज्ञापन: {date} को अवकाश के कारण कार्यालय बंद रहेगा।",
    "आईटी अद्यतन: कृपया सप्ताह के अंत तक नवीनतम {software} पैच स्थापित करें।",
    "ऑनबोर्डिंग दस्तावेज़: नए कर्मचारियों को पहले तीस दिनों में {training} प्रशिक्षण पूरा करना होगा।",
    "आंतरिक विकी: {project} परियोजना मुख्य फ्रेमवर्क के रूप में {tech} का उपयोग करती है।",
    "सर्व-कर्मचारी सारांश: सीईओ ने {topic} और तिमाही प्राथमिकताओं पर बात की।",
    "प्रक्रिया दस्तावेज़: आंतरिक पोर्टल के माध्यम से खरीद आदेश कैसे प्रस्तुत करें।",
    "इंजीनियरिंग स्टैंडअप: {project} पर रुकावट है, {team} टीम से समीक्षा चाहिए।",
    "टिकट अद्यतन: टीम लीड के अनुसार {project} की तैनाती अगले स्प्रिंट तक टाल दी गई।",
    "विभाग समाचार पत्र: {team} इस महीने तीन नए सदस्यों का स्वागत करती है।",
]

HI_CONFIDENTIAL_TEMPLATES = [
    "कर्मचारी की प्रदर्शन समीक्षा: {project} पर अपेक्षाओं को पूरा करता है, संचार में सुधार की आवश्यकता है। वेतन समायोजन लंबित।",
    "वेतन सारांश: कर्मचारी का मूल वेतन {currency} {amount}, बोनस लक्ष्य {num} प्रतिशत, इक्विटी अनुदान समीक्षाधीन।",
    "सेवा समाप्ति पत्र का मसौदा: {date} से प्रदर्शन के कारण रोजगार समाप्त। मानव संसाधन अंतिम वेतन की प्रक्रिया करेगा।",
    "विलय वार्ता नोट्स: {company} अधिग्रहण लक्ष्य मूल्यांकन {currency} {amount} मिलियन। गैर-सार्वजनिक।",
    "स्रोत कोड समीक्षा: {product} के लिए मालिकाना एल्गोरिथम, व्यापार रहस्य कार्यान्वयन विवरण शामिल हैं।",
    "आंतरिक वित्तीय पूर्वानुमान: तिमाही राजस्व अनुमान {currency} {amount} मिलियन, मार्जिन {num} प्रतिशत। बाहरी रूप से साझा न करें।",
    "कानूनी मामले की फ़ाइल: {topic} के संबंध में {company} के साथ लंबित मुकदमा। अटॉर्नी-क्लाइंट विशेषाधिकार।",
    "रणनीति दस्तावेज़: {year} में {region} में बाज़ार विस्तार की योजना है। प्रतिस्पर्धी आसूचना संलग्न।",
    "बोर्ड ज्ञापन: {company} के संभावित अधिग्रहण पर चर्चा। घोषणा तक सख्ती से गोपनीय।",
    "कर्मचारी अनुशासनात्मक रिकॉर्ड: {date} को नीति उल्लंघन के लिए लिखित चेतावनी जारी।",
    "विक्रेता अनुबंध: {company} प्रति इकाई {currency} {amount} की कीमत पर सहमत है। गैर-प्रकटीकरण लागू।",
    "मानव संसाधन जांच नोट्स: {name} के विरुद्ध कार्यस्थल आचरण के संबंध में शिकायत दर्ज। गोपनीय।",
]

HI_RESTRICTED_TEMPLATES = [
    "ग्राहक ऑनबोर्डिंग फ़ॉर्म: आधार {aadhaar}, पैन {pan}, जन्म तिथि {dob}, पूरा नाम {name}, पता फ़ाइल में।",
    "भुगतान प्रसंस्करण लॉग: कार्ड नंबर {card}, कार्डधारक {name}, लेनदेन राशि {currency} {amount}।",
    "बैंक स्थानांतरण रिकॉर्ड: खाता {iban}, लाभार्थी {name}, राशि {currency} {amount}, संदर्भ {project}।",
    "चिकित्सा फ़ॉर्म: रोगी {name}, जन्म तिथि {dob}, आधार {aadhaar}, निदान कोड {topic}, उपचार योजना संलग्न।",
    "पृष्ठभूमि जांच परिणाम: उम्मीदवार {name}, पैन {pan}, आपराधिक रिकॉर्ड: साफ़। क्रेडिट स्कोर {num}।",
    "वायर स्थानांतरण निर्देश: लाभार्थी खाता {iban}, रूटिंग विवरण, राशि {currency} {amount}, तत्काल।",
    "ऋण आवेदन: आवेदक {name}, पैन {pan}, वार्षिक आय {currency} {amount}, जन्म तिथि {dob}।",
    "केवाईसी दस्तावेज़: ग्राहक {name}, पैन {pan}, आधार {aadhaar}, पता प्रमाण संलग्न।",
    "बीमा दावा: पॉलिसी धारक {name}, आधार {aadhaar}, दावा राशि {currency} {amount}, घटना {dob} को।",
    "कर विवरणी: करदाता {name}, पैन {pan}, समायोजित सकल आय {currency} {amount}।",
    "क्रेडिट कार्ड आवेदन: {name}, जन्म तिथि {dob}, पैन {pan}, अनुरोधित सीमा {currency} {amount}।",
    "खाता विवरण: खाता धारक {name}, खाता {num} पर समाप्त, शेष राशि {currency} {amount}, आधार फ़ाइल में {aadhaar}।",
]

# ================================================================
# Fillers
# ================================================================
EVENTS = ['the product launch', 'our Q1 earnings', 'a community meetup', 'the annual conference', 'the charity drive']
VENUES = ['headquarters', 'Madison Square Garden', 'the Javits Center', 'our campus', 'the Marriott']
COMPANIES = ['Acme Corp', 'Globex', 'Initech', 'Umbrella Inc', 'Stark Industries', 'Wayne Enterprises', 'Cyberdyne']
PRODUCTS = ['payment gateway', 'analytics platform', 'mobile app', 'cloud service', 'data pipeline']
REGIONS = ['APAC', 'EMEA', 'NAM', 'LATAM', 'India', 'Europe']
ROLES = ['Software Engineer', 'Data Scientist', 'Product Manager', 'Designer', 'DevOps Engineer']
TEAMS = ['Platform', 'Growth', 'Infrastructure', 'Risk', 'Compliance', 'Data']
TOPICS = ['machine learning', 'cybersecurity', 'fintech', 'cloud migration', 'data governance', 'AI']
YEARS = ['2024', '2025', '2026']
PROJECTS = ['Phoenix', 'Titan', 'Nova', 'Orion', 'Atlas']
SOFTWARES = ['VPN client', 'antivirus', 'Zoom', 'Slack', 'Office 365']
TRAININGS = ['security awareness', 'GDPR', 'PCI DSS', 'code of conduct', 'harassment prevention']
TECHS = ['Python', 'Kubernetes', 'React', 'Kafka', 'Spark']
DATES = ['2026-05-15', '2026-06-01', '2026-07-04', '2026-09-10', '2026-12-25']
CURRENCIES = ['$', '€', '₹', '£']
INDUSTRIES = ['banking', 'healthcare', 'retail', 'insurance', 'fintech']
NAMES = ['John Smith', 'Jane Doe', 'Raj Kumar', 'Li Wei', 'Maria Garcia', 'Priya Sharma', 'Alex Johnson']

SOURCE_SYSTEMS = ['JIRA', 'ServiceNow', 'Confluence', 'Workday', 'Salesforce', 'Gmail', 'SharePoint']
DEPARTMENTS = ['Engineering', 'HR', 'Finance', 'Legal', 'Sales', 'Marketing', 'Operations']
FILE_TYPES = ['txt', 'email', 'ticket', 'doc', 'note']


def _ssn():
    return f"{random.randint(100, 999)}-{random.randint(10, 99)}-{random.randint(1000, 9999)}"


def _card():
    groups = [str(random.randint(1000, 9999)) for _ in range(4)]
    return '-'.join(groups)


def _iban():
    return f"GB{random.randint(10, 99)}ABCD{random.randint(10000000, 99999999)}{random.randint(1000, 9999)}"


def _pan():
    letters = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=5))
    digits = ''.join(random.choices('0123456789', k=4))
    last = random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    return f"{letters}{digits}{last}"


def _aadhaar():
    return f"{random.randint(1000, 9999)} {random.randint(1000, 9999)} {random.randint(1000, 9999)}"


def _dob():
    return f"{random.randint(1, 12):02d}/{random.randint(1, 28):02d}/{random.randint(1950, 2005)}"


def _fill(template: str) -> str:
    return template.format(
        event=random.choice(EVENTS),
        venue=random.choice(VENUES),
        company=random.choice(COMPANIES),
        product=random.choice(PRODUCTS),
        region=random.choice(REGIONS),
        role=random.choice(ROLES),
        team=random.choice(TEAMS),
        topic=random.choice(TOPICS),
        num=random.randint(3, 50),
        year=random.choice(YEARS),
        project=random.choice(PROJECTS),
        software=random.choice(SOFTWARES),
        training=random.choice(TRAININGS),
        tech=random.choice(TECHS),
        date=random.choice(DATES),
        currency=random.choice(CURRENCIES),
        amount=f"{random.randint(1000, 999999):,}",
        metric=random.choice(['revenue', 'margin', 'user', 'transaction']),
        industry=random.choice(INDUSTRIES),
        name=random.choice(NAMES),
        ssn=_ssn(),
        card=_card(),
        iban=_iban(),
        pan=_pan(),
        aadhaar=_aadhaar(),
        dob=_dob(),
    )


def _row(label: str, language: str, templates):
    template = random.choice(templates)
    # Occasionally concatenate 2 templates for more variety
    if random.random() < 0.25:
        template = template + ' ' + random.choice(templates)
    text = _fill(template)
    return {
        'text': text,
        'label': label,
        'language': language,
        'source_system': random.choice(SOURCE_SYSTEMS),
        'department': random.choice(DEPARTMENTS),
        'file_type': random.choice(FILE_TYPES),
        'author': random.choice(NAMES),
    }


EN_BY_CLASS = {
    'Public':       EN_PUBLIC_TEMPLATES,
    'Internal':     EN_INTERNAL_TEMPLATES,
    'Confidential': EN_CONFIDENTIAL_TEMPLATES,
    'Restricted':   EN_RESTRICTED_TEMPLATES,
}
HI_BY_CLASS = {
    'Public':       HI_PUBLIC_TEMPLATES,
    'Internal':     HI_INTERNAL_TEMPLATES,
    'Confidential': HI_CONFIDENTIAL_TEMPLATES,
    'Restricted':   HI_RESTRICTED_TEMPLATES,
}


def generate(output_path: str = 'data/synthetic_dataset.csv'):
    Path(os.path.dirname(output_path)).mkdir(parents=True, exist_ok=True)
    rows = []
    for _ in range(N_PER_CLASS):
        for label in ['Public', 'Internal', 'Confidential', 'Restricted']:
            rows.append(_row(label, 'en', EN_BY_CLASS[label]))
            rows.append(_row(label, 'hi', HI_BY_CLASS[label]))

    random.shuffle(rows)

    fieldnames = ['text', 'label', 'language', 'source_system', 'department', 'file_type', 'author']
    with open(output_path, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    en_count = sum(1 for r in rows if r['language'] == 'en')
    hi_count = sum(1 for r in rows if r['language'] == 'hi')
    print(f"[OK] Wrote {len(rows)} rows to {output_path}")
    print(f"     Per class per language: {N_PER_CLASS} samples")
    print(f"     English: {en_count}   Hindi: {hi_count}")


if __name__ == '__main__':
    generate()
