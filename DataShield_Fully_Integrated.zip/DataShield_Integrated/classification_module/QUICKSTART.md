# QUICKSTART — Bilingual Pipeline

## 1. Open in PyCharm

File → Open → select the `classification_module` folder.

## 2. Create a virtual environment

**Settings → Project → Python Interpreter → Add Interpreter → Add Local Interpreter → Virtualenv**.
Use Python 3.10 or 3.11 (3.12 also works).

## 3. Install dependencies

In PyCharm's terminal (Alt+F12), with `(.venv)` active:

```bash
pip install -r requirements.txt
```

The slim requirements file has only 11 packages — installs in under a minute.

## 4. Generate bilingual training data

```bash
python -m data.synthetic_generator
```

Expected output:
```
[OK] Wrote 20000 rows to data/synthetic_dataset.csv
     Per class per language: 2500 samples
     English: 10000   Hindi: 10000
```

## 5. Train both language model sets

**Fast dev run (~1 minute):**
```bash
python -m scripts.train_all --sample 500
```

**Full training (~5 minutes):**
```bash
python -m scripts.train_all
```

**Only one language:**
```bash
python -m scripts.train_all --only-language hi
```

The script prints per-language metrics:
```
[train] FINAL COMPARISON (macro-F1 by language)
language   test_n   LR       XGB      Stacker
en         400      1.0000   1.0000   1.0000
hi         400      1.0000   0.9975   0.9975
```

Artifacts land in `artifacts/en/` and `artifacts/hi/`.

## 6. Run prediction — on any language

**English restricted sample:**
```bash
python -m scripts.predict_cli --input data/sample_docs/ticket_restricted.txt --pretty
```

**Hindi restricted sample** (with Aadhaar + PAN + credit card):
```bash
python -m scripts.predict_cli --input data/sample_docs/ticket_hindi_restricted.txt --pretty
```

The output will include a `"language"` block showing:
```json
"language": {
  "detected": "hi",
  "detected_label": "Hindi",
  "routed_to": "hi"
}
```

## 7. Run on a folder of mixed-language docs

```bash
python -m scripts.predict_cli --input data/sample_docs/ --output logs/results.jsonl
```

Each doc in the JSONL output will show which language model handled it.

## 8. Run tests

```bash
python -m pytest tests/ -v
```

Expected: **45 passed**
```
tests/test_policy_engine.py ...........   [17 passed]
tests/test_ensemble.py ....               [7 passed]
tests/test_language_detector.py ...       [12 passed]
tests/test_end_to_end.py ....             [9 passed — bilingual]
```

## Common issues

| Issue | Fix |
|---|---|
| `ModuleNotFoundError: pipeline` | Run from the `classification_module/` root, not from inside a subfolder. |
| Hindi characters show as boxes in terminal | Windows terminal font issue — the data is correct, only display is off. Use PyCharm's terminal or enable UTF-8. |
| `[pipeline] INCOMPLETE` for a language | That language's artifacts weren't trained. Run `python -m scripts.train_all --only-language hi`. |
| Tests hang on end-to-end | First run trains real models (~15–30 s). That's expected. |

## Files your teammates depend on (stable contract)

- `pipeline.SensitivityClassifier.predict(text, metadata) → dict`
- `pipeline.SensitivityClassifier.predict_batch(texts, metadatas) → list[dict]`

The JSON response shape is documented in `README.md` section 4.
