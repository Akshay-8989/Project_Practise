"""
test_language_detector.py
-------------------------
Unit tests for utils/language_detector.py.

The detector must:
  - Correctly identify English text (mostly Latin script)
  - Correctly identify Hindi text (Devanagari script)
  - Return 'unknown' for empty / gibberish / other scripts
  - Be robust to mixed-script text (route to majority)
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.language_detector import detect_language, language_label


# ------------------------------------------------------------
# English
# ------------------------------------------------------------
def test_english_plain():
    assert detect_language('This is a plain English sentence about fintech.') == 'en'


def test_english_with_numbers_and_punct():
    assert detect_language('SSN 123-45-6789 on file, amount $5,000.') == 'en'


def test_english_long_document():
    text = ('Press release: Acme Corp announced its Q3 earnings today. '
            'Revenue grew by 12 percent year over year. The CEO highlighted '
            'strong performance in the APAC region.')
    assert detect_language(text) == 'en'


# ------------------------------------------------------------
# Hindi (Devanagari)
# ------------------------------------------------------------
def test_hindi_plain():
    assert detect_language('यह हिंदी में एक साधारण वाक्य है।') == 'hi'


def test_hindi_with_pii_placeholders():
    text = 'ग्राहक का आधार 1234 5678 9012 और पैन ABCDE1234F है।'
    assert detect_language(text) == 'hi'


def test_hindi_long_document():
    text = ('प्रेस विज्ञप्ति: एक्मे कॉर्प ने आज अपनी तिमाही आय की घोषणा की। '
            'राजस्व में पिछले वर्ष की तुलना में बारह प्रतिशत की वृद्धि हुई।')
    assert detect_language(text) == 'hi'


def test_hindi_mixed_with_english_numbers():
    # Hindi with Latin digits/acronyms should still route as Hindi
    text = 'आधार: 1234 5678 9012 और PAN: ABCDE1234F'
    assert detect_language(text) == 'hi'


# ------------------------------------------------------------
# Unknown / edge cases
# ------------------------------------------------------------
def test_empty_string_is_unknown():
    assert detect_language('') == 'unknown'


def test_whitespace_only_is_unknown():
    assert detect_language('   \n\t  ') == 'unknown'


def test_digits_only_is_unknown():
    assert detect_language('12345 67890') == 'unknown'


def test_non_latin_non_devanagari_script():
    # Japanese - should be 'unknown' (we only support en + hi)
    assert detect_language('これは日本語のテキストです。' * 5) == 'unknown'


# ------------------------------------------------------------
# Labels
# ------------------------------------------------------------
def test_language_label_maps():
    assert language_label('en') == 'English'
    assert language_label('hi') == 'Hindi'
    assert language_label('unknown') == 'Unknown'
    assert language_label('xx') == 'Unknown'
