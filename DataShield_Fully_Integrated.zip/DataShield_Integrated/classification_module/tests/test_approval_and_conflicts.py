"""
test_approval_and_conflicts.py
------------------------------
Tests for the new dual-approval gate and rule conflict resolution.

Covers:
  - Approval gate for each label (Public/Internal/Confidential/Restricted)
  - Dual-approval workflow (Legal + DataGovernance)
  - Rejection blocks approval
  - Unauthorized approver ignored
  - Conflict resolution: highest priority wins
  - Conflict resolution: sensitivity breaks ties
  - Full PolicyEngine integration with new fields
"""
import os
import sys
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from policy_engine.approval import (
    ApprovalGate,
    ApprovalStatus,
    build_approval_gate,
    ResolvedRule,
    resolve_conflicts,
    SENSITIVITY_ORDER,
)
from policy_engine.rules import PolicyEngine


CONFIG_PATH = os.path.join(os.path.dirname(__file__), '..', 'configs', 'policy.yaml')


# ============================================================
# Approval Gate tests
# ============================================================

class TestApprovalGate:
    def test_public_auto_approved(self):
        gate = build_approval_gate('Public')
        assert gate.status == ApprovalStatus.NOT_REQUIRED
        assert gate.is_fully_approved is True
        assert gate.pending_approvers == []

    def test_internal_auto_approved(self):
        gate = build_approval_gate('Internal')
        assert gate.status == ApprovalStatus.NOT_REQUIRED
        assert gate.is_fully_approved is True

    def test_confidential_needs_legal(self):
        gate = build_approval_gate('Confidential')
        assert gate.status == ApprovalStatus.PENDING
        assert gate.required_approvers == ['Legal']
        assert gate.is_fully_approved is False
        assert gate.pending_approvers == ['Legal']

    def test_restricted_needs_dual_approval(self):
        gate = build_approval_gate('Restricted')
        assert gate.status == ApprovalStatus.PENDING
        assert set(gate.required_approvers) == {'Legal', 'DataGovernance'}
        assert gate.is_fully_approved is False

    def test_restricted_partial_approval(self):
        gate = build_approval_gate('Restricted')
        gate.record_approval('Legal', 'approved')
        assert gate.is_fully_approved is False
        assert 'DataGovernance' in gate.pending_approvers

    def test_restricted_full_approval(self):
        gate = build_approval_gate('Restricted')
        gate.record_approval('Legal', 'approved')
        gate.record_approval('DataGovernance', 'approved')
        assert gate.is_fully_approved is True
        assert gate.status == ApprovalStatus.APPROVED

    def test_rejection_blocks_approval(self):
        gate = build_approval_gate('Restricted')
        gate.record_approval('Legal', 'approved')
        gate.record_approval('DataGovernance', 'rejected')
        assert gate.is_fully_approved is False
        assert gate.status == ApprovalStatus.REJECTED

    def test_unauthorized_approver_ignored(self):
        gate = build_approval_gate('Restricted')
        result = gate.record_approval('RandomPerson', 'approved')
        assert result is False
        assert 'RandomPerson' not in gate.approvals_received

    def test_gate_to_dict(self):
        gate = build_approval_gate('Restricted')
        gate.record_approval('Legal', 'approved')
        d = gate.to_dict()
        assert 'required_approvers' in d
        assert 'status' in d
        assert 'is_fully_approved' in d
        assert d['is_fully_approved'] is False


# ============================================================
# Conflict Resolution tests
# ============================================================

class TestConflictResolution:
    def test_highest_priority_wins(self):
        rules = [
            ResolvedRule('MODEL_PREDICTION', 20, 'Internal', 'Allow', 'Model said Internal'),
            ResolvedRule('PII_REGEX_HIGH', 100, 'Restricted', 'Quarantine', 'SSN found'),
        ]
        winner = resolve_conflicts(rules)
        assert winner.rule_name == 'PII_REGEX_HIGH'
        assert winner.outcome_label == 'Restricted'

    def test_sensitivity_breaks_tie(self):
        rules = [
            ResolvedRule('RULE_A', 50, 'Confidential', 'Encrypt', 'Rule A'),
            ResolvedRule('RULE_B', 50, 'Restricted', 'Quarantine', 'Rule B'),
        ]
        winner = resolve_conflicts(rules)
        assert winner.outcome_label == 'Restricted'

    def test_single_rule_no_conflict(self):
        rules = [
            ResolvedRule('MODEL_PREDICTION', 20, 'Public', 'Allow', 'Model prediction'),
        ]
        winner = resolve_conflicts(rules)
        assert winner.rule_name == 'MODEL_PREDICTION'

    def test_no_rules_returns_default(self):
        winner = resolve_conflicts([])
        assert winner.rule_name == 'DEFAULT'
        assert winner.outcome_label == 'Public'

    def test_conflict_annotation(self):
        rules = [
            ResolvedRule('PII_REGEX_HIGH', 100, 'Restricted', 'Quarantine', 'PII'),
            ResolvedRule('KEYWORD_CONFIDENTIAL', 60, 'Confidential', 'Encrypt', 'Keyword'),
            ResolvedRule('MODEL_PREDICTION', 20, 'Internal', 'Allow', 'Model'),
        ]
        winner = resolve_conflicts(rules)
        assert winner.rule_name == 'PII_REGEX_HIGH'
        # Should note the overridden conflicting rules
        assert 'Overrode' in winner.reason or winner.outcome_label == 'Restricted'


# ============================================================
# Full PolicyEngine integration tests
# ============================================================

class TestPolicyEngineIntegration:
    @pytest.fixture(scope='class')
    def engine(self):
        return PolicyEngine(CONFIG_PATH)

    def test_restricted_has_approval_gate(self, engine):
        probs = {'Public': 0.01, 'Internal': 0.01, 'Confidential': 0.01, 'Restricted': 0.97}
        decision = engine.apply('SSN 123-45-6789 on file', 'Restricted', probs)
        assert decision.approval_gate is not None
        assert decision.approval_gate.status == ApprovalStatus.PENDING
        assert 'Legal' in decision.approval_gate.required_approvers
        assert 'DataGovernance' in decision.approval_gate.required_approvers

    def test_public_has_no_approval_gate(self, engine):
        probs = {'Public': 0.95, 'Internal': 0.03, 'Confidential': 0.01, 'Restricted': 0.01}
        decision = engine.apply('Public announcement about product.', 'Public', probs)
        assert decision.approval_gate is not None
        assert decision.approval_gate.status == ApprovalStatus.NOT_REQUIRED

    def test_conflict_trace_present(self, engine):
        probs = {'Public': 0.01, 'Internal': 0.01, 'Confidential': 0.01, 'Restricted': 0.97}
        decision = engine.apply('SSN 123-45-6789', 'Restricted', probs)
        assert decision.conflict_trace is not None
        assert len(decision.conflict_trace) >= 1
        assert decision.winning_rule is not None

    def test_to_dict_has_new_fields(self, engine):
        import json
        probs = {'Public': 0.8, 'Internal': 0.1, 'Confidential': 0.05, 'Restricted': 0.05}
        decision = engine.apply('SSN 123-45-6789', 'Public', probs)
        d = decision.to_dict()
        assert 'approval' in d
        assert 'conflict_resolution' in d
        # Must be JSON-serializable
        json.dumps(d)

    def test_pii_overrides_model_with_conflict_trace(self, engine):
        """Model says Public, but PII regex forces Restricted. Conflict trace shows both."""
        probs = {'Public': 0.9, 'Internal': 0.05, 'Confidential': 0.03, 'Restricted': 0.02}
        decision = engine.apply('SSN 123-45-6789 in public text', 'Public', probs)
        assert decision.post_policy_label == 'Restricted'
        assert decision.winning_rule == 'PII_REGEX_HIGH'
        # Should have at least 2 rules: MODEL_PREDICTION and PII_REGEX_HIGH
        rule_names = [r['rule'] for r in decision.conflict_trace]
        assert 'MODEL_PREDICTION' in rule_names
        assert 'PII_REGEX_HIGH' in rule_names
