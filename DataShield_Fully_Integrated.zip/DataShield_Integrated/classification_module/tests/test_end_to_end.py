"""
test_end_to_end.py
------------------
Slow integration test (session-scoped) for the bilingual pipeline.

Flow:
  1. Generate a small bilingual synthetic dataset (100/class/lang = 800 rows)
  2. Train separate LR + XGBoost + Stacker for each language
  3. Save to tmp/artifacts/en/ and tmp/artifacts/hi/
  4. Load pipeline
  5. Predict on English AND Hindi sample docs
  6. Assert:
     - English Restricted doc → label Restricted + action Quarantine + routed to 'en'
     - Hindi Restricted doc → label Restricted + action Quarantine + routed to 'hi'
     - Public docs are not flagged as Restricted
     - Every prediction has >= 3 evidence tokens
     - Output schema includes the new `language` block
     - Language routing reflects the detected script

Run: `pytest tests/test_end_to_end.py -v -s`
"""
import json
import os
import sys
import pytest
import numpy as np
import pandas as pd
import yaml

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from models.logistic_model import LogisticModel
from models.xgboost_model import XGBoostModel
from ensemble.stacking import (
    StackingEnsemble,
    generate_oof_logistic,
    generate_oof_xgboost,
)
from pipeline import SensitivityClassifier
from data import synthetic_generator


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))


@pytest.fixture(scope='module')
def trained_pipeline(tmp_path_factory):
    """
    Build a bilingual pipeline in tmp. Trains small models for both languages
    so routing can actually be exercised end-to-end.
    """
    workdir = tmp_path_factory.mktemp('e2e')
    artifacts = workdir / 'artifacts'
    logs = workdir / 'logs'
    dataset = workdir / 'synthetic.csv'
    artifacts.mkdir()
    logs.mkdir()

    # 1. Small bilingual dataset (100 per class per language = 800 rows total)
    orig_n = synthetic_generator.N_PER_CLASS
    synthetic_generator.N_PER_CLASS = 100
    try:
        synthetic_generator.generate(str(dataset))
    finally:
        synthetic_generator.N_PER_CLASS = orig_n

    # 2. Load & redirect config
    with open(os.path.join(PROJECT_ROOT, 'configs', 'model.yaml')) as f:
        cfg = yaml.safe_load(f)
    cfg['paths']['artifacts_dir'] = str(artifacts)
    cfg['paths']['logs_dir'] = str(logs)
    cfg['paths']['dataset_csv'] = str(dataset)
    # Shrink XGB for speed
    cfg['xgboost']['n_estimators'] = 50
    cfg['xgboost']['max_depth'] = 4

    model_cfg_path = workdir / 'model.yaml'
    with open(model_cfg_path, 'w') as f:
        yaml.safe_dump(cfg, f)

    # 3. Train one model set per language
    df = pd.read_csv(dataset)
    classes = cfg['classes']

    for lang in cfg['languages']:
        df_lang = df[df['language'] == lang].reset_index(drop=True)
        texts = df_lang['text'].astype(str).tolist()
        labels = df_lang['label'].tolist()
        metadata = df_lang[['source_system', 'department', 'file_type', 'author']].to_dict('records')

        lang_dir = artifacts / lang
        lang_dir.mkdir(parents=True, exist_ok=True)

        lr = LogisticModel(cfg['logistic'], classes)
        lr.fit(texts, labels)
        lr.save(str(lang_dir / 'logistic.joblib'))

        xgb = XGBoostModel(cfg['xgboost'], classes)
        xgb.fit(texts, labels, metadata)
        xgb.save(str(lang_dir / 'xgboost.joblib'))

        oof_lr = generate_oof_logistic(LogisticModel, cfg['logistic'], classes,
                                       texts, labels, n_folds=3)
        oof_xgb = generate_oof_xgboost(XGBoostModel, cfg['xgboost'], classes,
                                       texts, labels, metadata, n_folds=3)
        label_to_idx = {c: i for i, c in enumerate(classes)}
        y = np.array([label_to_idx[l] for l in labels])

        stacker = StackingEnsemble(classes=classes, n_folds=3, meta='logistic_regression')
        stacker.fit_meta({'logistic': oof_lr, 'xgboost': oof_xgb}, y)
        stacker.save(str(lang_dir / 'stacker.joblib'))

    # 4. Build the pipeline
    clf = SensitivityClassifier(
        model_config=str(model_cfg_path),
        policy_config=os.path.join(PROJECT_ROOT, 'configs', 'policy.yaml'),
    )
    return clf


def _read_sample(name: str) -> str:
    path = os.path.join(PROJECT_ROOT, 'data', 'sample_docs', name)
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()


# ================================================================
# English tests
# ================================================================
def test_english_restricted_sample(trained_pipeline):
    text = _read_sample('ticket_restricted.txt')
    result = trained_pipeline.predict(text, metadata={'source_system': 'Salesforce',
                                                       'department': 'Operations',
                                                       'file_type': 'ticket'})
    assert result['label'] == 'Restricted'
    assert result['policy_trace']['action'] == 'Quarantine'
    assert result['language']['detected'] == 'en'
    assert result['language']['routed_to'] == 'en'


def test_english_public_sample_not_restricted(trained_pipeline):
    text = _read_sample('ticket_public.txt')
    result = trained_pipeline.predict(text, metadata={})
    assert result['label'] != 'Restricted'
    assert result['language']['detected'] == 'en'
    assert result['language']['routed_to'] == 'en'


# ================================================================
# Hindi tests - THE CORE OF THIS RELEASE
# ================================================================
def test_hindi_restricted_sample(trained_pipeline):
    """
    Hindi restricted doc with Aadhaar + PAN + credit card.
    Must be detected as Hindi, routed to Hindi model set, AND forced to
    Restricted by the regex policy engine (which runs on the raw text
    regardless of language).
    """
    text = _read_sample('ticket_hindi_restricted.txt')
    result = trained_pipeline.predict(text, metadata={'source_system': 'Salesforce',
                                                       'department': 'Operations',
                                                       'file_type': 'ticket'})
    assert result['language']['detected'] == 'hi', \
        f"expected Hindi, got {result['language']}"
    assert result['language']['routed_to'] == 'hi'
    # Regex-driven — PII is detected regardless of surrounding language
    assert result['label'] == 'Restricted'
    assert result['policy_trace']['action'] == 'Quarantine'
    # Must detect Aadhaar/PAN
    triggered = result['policy_trace']['triggered_rules']
    assert any('AADHAAR' in r or 'PAN' in r or 'CREDIT_CARD' in r for r in triggered), \
        f"expected AADHAAR/PAN/CREDIT_CARD hit; got {triggered}"


def test_hindi_public_sample_routes_hindi(trained_pipeline):
    text = _read_sample('ticket_hindi_public.txt')
    result = trained_pipeline.predict(text, metadata={})
    assert result['language']['detected'] == 'hi'
    assert result['language']['routed_to'] == 'hi'
    # Should not be Restricted (no PII)
    assert result['label'] != 'Restricted'


def test_hindi_confidential_sample_routes_hindi(trained_pipeline):
    text = _read_sample('ticket_hindi_confidential.txt')
    result = trained_pipeline.predict(text, metadata={})
    assert result['language']['routed_to'] == 'hi'
    # Hindi keyword "गोपनीय" / "वेतन" / "मुआवज़ा" should bump to Confidential
    # (may be Internal or Confidential depending on small training data).
    assert result['label'] in {'Internal', 'Confidential', 'Restricted'}


# ================================================================
# Schema & batch
# ================================================================
def test_output_schema_matches_contract(trained_pipeline):
    result = trained_pipeline.predict('A schema check in English.', metadata={})
    for key in ['doc_id', 'label', 'confidence', 'class_probabilities',
                'evidence', 'model_contributions', 'policy_trace', 'audit', 'language']:
        assert key in result, f'missing key {key} in output'

    # Language block
    for k in ['detected', 'routed_to', 'detected_label']:
        assert k in result['language'], f'missing language.{k}'

    # Class probabilities
    assert set(result['class_probabilities'].keys()) == {'Public', 'Internal', 'Confidential', 'Restricted'}
    assert abs(sum(result['class_probabilities'].values()) - 1.0) < 0.01

    # JSON-serializable
    json.dumps(result)


def test_every_prediction_has_min_3_evidence_tokens(trained_pipeline):
    """Compliance: >= 3 evidence tokens, including for Hindi docs."""
    samples = [
        'Press release about new product launch.',
        'SSN 123-45-6789 on file for customer.',
        'यह एक हिंदी वाक्य है।',
        'आधार 1234 5678 9012 पर ग्राहक।',
    ]
    for text in samples:
        result = trained_pipeline.predict(text, metadata={})
        assert len(result['evidence']) >= 3, \
            f"only {len(result['evidence'])} evidence tokens for: {text[:40]}"


def test_mixed_language_batch(trained_pipeline):
    """Batch with both languages - each doc should route independently."""
    texts = [
        _read_sample('ticket_public.txt'),           # English
        _read_sample('ticket_hindi_public.txt'),     # Hindi
        _read_sample('ticket_restricted.txt'),       # English with PII
        _read_sample('ticket_hindi_restricted.txt'), # Hindi with PII
    ]
    results = trained_pipeline.predict_batch(texts, [{}] * 4)
    routed = [r['language']['routed_to'] for r in results]
    assert routed == ['en', 'hi', 'en', 'hi'], f"routing wrong: {routed}"
    # Both Restricted samples must still fire the policy engine
    assert results[2]['label'] == 'Restricted'
    assert results[3]['label'] == 'Restricted'


def test_audit_log_written_and_masked(trained_pipeline):
    _ = trained_pipeline.predict('SSN 123-45-6789 test audit log', metadata={})
    _ = trained_pipeline.predict('आधार 1234 5678 9012 हिंदी ऑडिट', metadata={})
    log_path = os.path.join(trained_pipeline.logs_dir, 'audit.jsonl')
    assert os.path.exists(log_path)
    with open(log_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # Raw PII must not appear in the log
    assert '123-45-6789' not in content
    assert '1234 5678 9012' not in content
