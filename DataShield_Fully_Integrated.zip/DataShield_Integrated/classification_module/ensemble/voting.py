"""
voting.py
---------
Soft voting ensemble.

Each member model produces a (n, n_classes) probability matrix. We take
a weighted average.

If a model fails (returns None or uniform prior indicating fallback),
its weight is redistributed to the remaining models. This is the
"graceful fallback" requirement.
"""
from typing import Dict, List, Optional
import numpy as np


class SoftVotingEnsemble:
    def __init__(self, weights: Dict[str, float], classes: List[str]):
        """
        weights: e.g. {'logistic': 0.25, 'xgboost': 0.35, 'transformer': 0.40}
        """
        self.weights = dict(weights)
        self.classes = classes

    def _is_degenerate(self, probs: np.ndarray) -> bool:
        """Detect uniform-prior fallback from transformer (or bad model)."""
        if probs is None or probs.size == 0:
            return True
        uniform = np.full_like(probs, 1.0 / len(self.classes))
        return np.allclose(probs, uniform, atol=1e-6)

    def combine(self, model_probs: Dict[str, Optional[np.ndarray]]) -> np.ndarray:
        """
        model_probs: dict model_name → (n, n_classes) or None
        Returns (n, n_classes) combined probabilities.
        """
        active = {}
        for name, probs in model_probs.items():
            if probs is None or self._is_degenerate(probs):
                continue
            active[name] = probs

        if not active:
            # Everything failed — return uniform. Policy engine will catch low confidence.
            n = next(iter(p.shape[0] for p in model_probs.values() if p is not None), 1)
            return np.full((n, len(self.classes)), 1.0 / len(self.classes))

        # Normalize weights over active models only
        active_weight_sum = sum(self.weights.get(n, 0.0) for n in active)
        if active_weight_sum == 0:
            # Equal weight fallback
            norm_weights = {n: 1.0 / len(active) for n in active}
        else:
            norm_weights = {n: self.weights.get(n, 0.0) / active_weight_sum for n in active}

        combined = None
        for name, probs in active.items():
            w = norm_weights[name]
            combined = probs * w if combined is None else combined + probs * w

        # Renormalize to defend against numerical drift
        combined = combined / combined.sum(axis=1, keepdims=True)
        return combined

    def active_models(self, model_probs: Dict[str, Optional[np.ndarray]]) -> List[str]:
        return [n for n, p in model_probs.items() if p is not None and not self._is_degenerate(p)]
