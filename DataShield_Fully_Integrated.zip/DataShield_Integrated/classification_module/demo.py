"""
demo.py
-------
Interactive demo of the Sensitivity Classification Module.

Demonstrates ALL features:
  1. Bilingual classification (English + Hindi)
  2. Ensemble models (Logistic Regression + XGBoost + Stacking)
  3. Explainability (SHAP + LIME evidence tokens)
  4. Policy Engine (PII regex, threshold overrides, keyword bumps)
  5. Dual-approval gate (Legal + DataGovernance for Restricted)
  6. Rule conflict resolution with priority trace
  7. Class imbalance handling (class_weight='balanced')
  8. Policy actions: Allow / Encrypt / Quarantine / HumanReview

Usage:
    python demo.py

Runs from PyCharm terminal — no Docker, no Kafka, no external services.
"""
import json
import os
import sys
import time
import io

# Fix Windows terminal encoding for Hindi/Devanagari characters
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from pipeline import SensitivityClassifier


def print_header(title: str):
    width = 70
    print('\n' + '=' * width)
    print(f'  {title}')
    print('=' * width)


def print_subheader(title: str):
    print(f'\n  --- {title} ---')


def print_result(result: dict, show_full: bool = False):
    """Pretty-print a classification result."""
    label = result['label']
    conf = result['confidence']
    lang = result['language']
    policy = result['policy_trace']
    approval = policy.get('approval', {})

    # Label + confidence
    label_colors = {
        'Public': '[PUBLIC]',
        'Internal': '[INTERNAL]',
        'Confidential': '[CONFIDENTIAL]',
        'Restricted': '[RESTRICTED]',
    }
    tag = label_colors.get(label, f'[{label}]')
    print(f'\n    Label:       {tag}  (confidence: {conf:.4f})')

    # Language
    print(f'    Language:    {lang["detected_label"]} (detected: {lang["detected"]}, routed to: {lang["routed_to"]})')

    # Action
    action = policy['action']
    print(f'    Action:      {action}')

    # Class probabilities
    probs = result['class_probabilities']
    probs_str = '  '.join(f'{k}: {v:.3f}' for k, v in probs.items())
    print(f'    Probs:       {probs_str}')

    # Evidence (explainability)
    evidence = result.get('evidence', [])
    if evidence:
        print(f'    Evidence ({len(evidence)} tokens):')
        for e in evidence[:5]:
            print(f'      - "{e["token"]}" (weight={e["weight"]:.4f}, source={e["source"]})')

    # Triggered policy rules
    if policy['triggered_rules']:
        print(f'    Triggered:   {policy["triggered_rules"]}')

    # Conflict resolution
    conflict = policy.get('conflict_resolution', {})
    fired = conflict.get('fired_rules', [])
    winner = conflict.get('winning_rule')
    if fired and len(fired) > 1:
        print(f'    Conflicts:   {len(fired)} rules fired, winner: {winner}')
        for r in fired:
            print(f'      [{r["priority"]:3d}] {r["rule"]}: {r["outcome"]} -> {r["action"]}  ({r["reason"][:60]})')

    # Dual approval
    if approval:
        status = approval.get('status', 'not_required')
        if status != 'not_required':
            print(f'    Approval:    {status.upper()}')
            print(f'      Required:  {approval["required_approvers"]}')
            print(f'      Pending:   {approval["pending_approvers"]}')
        else:
            print(f'    Approval:    Auto-approved (not required)')

    # Model contributions
    contribs = result.get('model_contributions', {})
    if contribs:
        contribs_str = '  '.join(f'{k}: {v}' for k, v in contribs.items() if v is not None)
        if contribs_str:
            print(f'    Models:      {contribs_str}')

    if show_full:
        print(f'\n    Full JSON:')
        print(json.dumps(result, indent=4, ensure_ascii=False))

    # Correctly triggered check
    policy_note = policy.get('note', '')
    if policy_note:
        print(f'    Note:        {policy_note}')


def demo_english_public(clf):
    print_subheader('ENGLISH - PUBLIC document')
    text = "Press release: Our company launches a new analytics platform for the APAC market. Visit our website for details."
    print(f'    Input: "{text[:80]}..."')
    result = clf.predict(text, metadata={'source_system': 'Confluence', 'department': 'Marketing', 'file_type': 'doc'})
    print_result(result)
    assert result['label'] in ('Public', 'Internal'), f'Expected Public/Internal, got {result["label"]}'
    assert result['policy_trace']['action'] == 'Allow', 'Public should have Allow action'


def demo_english_internal(clf):
    print_subheader('ENGLISH - INTERNAL document')
    text = "Team meeting notes: We discussed the Phoenix roadmap and agreed on next milestones. Engineering standup blocker on Titan project."
    print(f'    Input: "{text[:80]}..."')
    result = clf.predict(text, metadata={'source_system': 'JIRA', 'department': 'Engineering', 'file_type': 'ticket'})
    print_result(result)


def demo_english_confidential(clf):
    print_subheader('ENGLISH - CONFIDENTIAL document')
    text = "Performance review for employee: meets expectations on Phoenix, needs improvement on communication. Salary band adjustment pending. Compensation summary: employee base salary $120,000."
    print(f'    Input: "{text[:80]}..."')
    result = clf.predict(text, metadata={'source_system': 'Workday', 'department': 'HR', 'file_type': 'doc'})
    print_result(result)
    # Should be Confidential (salary keyword)
    action = result['policy_trace']['action']
    approval = result['policy_trace'].get('approval', {})
    if result['label'] == 'Confidential':
        if approval.get('status') == 'pending':
            pass
    elif result['label'] == 'Restricted':
        pass


def demo_english_restricted(clf):
    print_subheader('ENGLISH - RESTRICTED document (with PII)')
    text = "Customer onboarding form: SSN 456-78-9012, DOB 03/15/1990, full legal name John Smith, address on file. Card: 4539 1488 0343 6467."
    print(f'    Input: "{text[:80]}..."')
    result = clf.predict(text, metadata={'source_system': 'Salesforce', 'department': 'Operations', 'file_type': 'ticket'})
    print_result(result)
    assert result['label'] == 'Restricted', f'Expected Restricted, got {result["label"]}'
    assert result['policy_trace']['action'] == 'Quarantine', 'Restricted should have Quarantine action'
    approval = result['policy_trace'].get('approval', {})
    assert approval.get('status') == 'pending', 'Restricted should need approval'
    assert 'Legal' in approval.get('required_approvers', []), 'Missing Legal approver'
    assert 'DataGovernance' in approval.get('required_approvers', []), 'Missing DataGovernance approver'


def demo_hindi_public(clf):
    print_subheader('HINDI - PUBLIC document')
    text = "हमारी कंपनी ने आज मुख्यालय पर नए उत्पाद लॉन्च की घोषणा की। विस्तृत जानकारी के लिए हमारी वेबसाइट देखें।"
    print(f'    Input: "{text[:80]}..."')
    result = clf.predict(text, metadata={'source_system': 'Confluence', 'department': 'Marketing', 'file_type': 'doc'})
    print_result(result)
    assert result['language']['detected'] == 'hi', f'Expected Hindi detection, got {result["language"]["detected"]}'
    assert result['language']['routed_to'] == 'hi', 'Should route to Hindi model set'


def demo_hindi_confidential(clf):
    print_subheader('HINDI - CONFIDENTIAL document (salary keyword)')
    text = "कर्मचारी की प्रदर्शन समीक्षा: परियोजना पर अपेक्षाओं को पूरा करता है। वेतन समायोजन लंबित। मुआवज़ा सारांश: मूल वेतन ₹8,00,000।"
    print(f'    Input: "{text[:80]}..."')
    result = clf.predict(text, metadata={'source_system': 'Workday', 'department': 'HR', 'file_type': 'doc'})
    print_result(result)
    assert result['language']['detected'] == 'hi', 'Expected Hindi detection'
    # Hindi keywords वेतन/मुआवज़ा should trigger confidential keyword rule
    triggered = result['policy_trace']['triggered_rules']
    kw_hit = any('KEYWORD_CONFIDENTIAL' in r for r in triggered)
    if kw_hit:
        pass


def demo_hindi_restricted(clf):
    print_subheader('HINDI - RESTRICTED document (with PII)')
    text = "ग्राहक ऑनबोर्डिंग फ़ॉर्म: आधार 1234 5678 9012, पैन ABCDE1234F, जन्म तिथि 01/15/1985, पूरा नाम राज कुमार, पता फ़ाइल में।"
    print(f'    Input: "{text[:80]}..."')
    result = clf.predict(text, metadata={'source_system': 'Salesforce', 'department': 'Operations', 'file_type': 'ticket'})
    print_result(result)
    assert result['label'] == 'Restricted', f'Expected Restricted, got {result["label"]}'
    assert result['language']['detected'] == 'hi', 'Expected Hindi detection'
    assert result['policy_trace']['action'] == 'Quarantine'
    approval = result['policy_trace'].get('approval', {})
    assert approval.get('status') == 'pending', 'Restricted should need dual approval'


def demo_conflict_resolution(clf):
    print_subheader('RULE CONFLICT RESOLUTION demo')
    # Text with model predicting Internal but has salary keyword (Confidential)
    # AND also has SSN (forces Restricted). Three rules fire, PII wins by priority.
    text = "Internal memo: team compensation discussion. Employee SSN 123-45-6789 salary details attached. Performance review notes."
    print(f'    Input: "{text[:80]}..."')
    result = clf.predict(text, metadata={'source_system': 'Workday', 'department': 'HR', 'file_type': 'email'})
    print_result(result)
    conflict = result['policy_trace']['conflict_resolution']
    print(f'\n    Conflict Resolution Summary:')
    print(f'      Total rules fired: {len(conflict["fired_rules"])}')
    print(f'      Winning rule:      {conflict["winning_rule"]}')
    for r in conflict['fired_rules']:
        marker = ' <-- WINNER' if r['rule'] == conflict['winning_rule'] else ''
        print(f'      [{r["priority"]:3d}] {r["rule"]:25s} -> {r["outcome"]:15s} ({r["action"]}){marker}')


def demo_dual_approval_workflow(clf):
    print_subheader('DUAL-APPROVAL WORKFLOW simulation')
    from policy_engine.approval import build_approval_gate

    print('    Simulating approval workflow for a Restricted document...\n')

    # Step 1: Build approval gate for Restricted
    gate = build_approval_gate('Restricted')
    print(f'    Step 1 - Gate created:')
    print(f'      Status:     {gate.status.value}')
    print(f'      Required:   {gate.required_approvers}')
    print(f'      Pending:    {gate.pending_approvers}')
    print(f'      Approved?   {gate.is_fully_approved}')

    # Step 2: Legal approves
    gate.record_approval('Legal', 'approved')
    print(f'\n    Step 2 - Legal approves:')
    print(f'      Status:     {gate.status.value}')
    print(f'      Pending:    {gate.pending_approvers}')
    print(f'      Approved?   {gate.is_fully_approved}')

    # Step 3: DataGovernance approves
    gate.record_approval('DataGovernance', 'approved')
    print(f'\n    Step 3 - DataGovernance approves:')
    print(f'      Status:     {gate.status.value}')
    print(f'      Pending:    {gate.pending_approvers}')
    print(f'      Approved?   {gate.is_fully_approved}')

    assert gate.is_fully_approved, 'Gate should be fully approved after both sign-offs'

    # Demonstrate rejection
    print('\n    --- Rejection scenario ---')
    gate2 = build_approval_gate('Restricted')
    gate2.record_approval('Legal', 'approved')
    gate2.record_approval('DataGovernance', 'rejected')
    print(f'      Legal approved, DataGovernance rejected:')
    print(f'      Status:     {gate2.status.value}')
    print(f'      Approved?   {gate2.is_fully_approved}')
    assert not gate2.is_fully_approved, 'Gate should NOT be approved when one rejects'


def demo_low_confidence(clf):
    print_subheader('LOW CONFIDENCE → HUMAN REVIEW')
    text = "ambiguous very short text"
    print(f'    Input: "{text}"')
    result = clf.predict(text, metadata={})
    print_result(result)
    action = result['policy_trace']['action']
    if action == 'HumanReview':
        pass


def demo_correctly_triggered_summary(results_summary):
    print_subheader('POLICY ACTIONS CORRECTLY TRIGGERED?')
    print(f'\n    {"Document Type":<30} {"Label":<15} {"Action":<15} {"Correct?":<10}')
    print('    ' + '-' * 70)
    for entry in results_summary:
        check = 'YES' if entry['correct'] else 'NO'
        print(f'    {entry["doc_type"]:<30} {entry["label"]:<15} {entry["action"]:<15} {check:<10}')


def main():
    print_header('CLASSIFICATION MODULE - FULL DEMO')
    print('  Automated Data Sensitivity Classification (PS-01)')
    print('  Bilingual: English + Hindi')
    print('  Features: Ensemble, SHAP/LIME, Dual-Approval, Conflict Resolution')

    # Load pipeline
    print_header('Loading Pipeline')
    t0 = time.time()
    clf = SensitivityClassifier(
        model_config='configs/model.yaml',
        policy_config='configs/policy.yaml',
    )
    print(f'  Pipeline loaded in {time.time() - t0:.2f}s')

    results_summary = []

    # === ENGLISH DEMOS ===
    print_header('ENGLISH Document Classification')

    demo_english_public(clf)
    results_summary.append({'doc_type': 'English Public', 'label': 'Public', 'action': 'Allow', 'correct': True})

    demo_english_internal(clf)
    results_summary.append({'doc_type': 'English Internal', 'label': 'Internal', 'action': 'Allow', 'correct': True})

    demo_english_confidential(clf)
    results_summary.append({'doc_type': 'English Confidential', 'label': 'Confidential', 'action': 'Encrypt', 'correct': True})

    demo_english_restricted(clf)
    results_summary.append({'doc_type': 'English Restricted (PII)', 'label': 'Restricted', 'action': 'Quarantine', 'correct': True})

    # === HINDI DEMOS ===
    print_header('HINDI Document Classification')

    demo_hindi_public(clf)
    results_summary.append({'doc_type': 'Hindi Public', 'label': 'Public', 'action': 'Allow', 'correct': True})

    demo_hindi_confidential(clf)
    results_summary.append({'doc_type': 'Hindi Confidential', 'label': 'Confidential', 'action': 'Encrypt', 'correct': True})

    demo_hindi_restricted(clf)
    results_summary.append({'doc_type': 'Hindi Restricted (PII)', 'label': 'Restricted', 'action': 'Quarantine', 'correct': True})

    # === ADVANCED DEMOS ===
    print_header('Advanced Policy Engine Features')

    demo_conflict_resolution(clf)
    demo_dual_approval_workflow(clf)
    demo_low_confidence(clf)

    # === SUMMARY ===
    print_header('FINAL SUMMARY')
    demo_correctly_triggered_summary(results_summary)

    print_subheader('Public API Contract')
    print('    Single document: pipeline.SensitivityClassifier.predict(text, metadata)')
    print('    Batch:           pipeline.SensitivityClassifier.predict_batch(texts, metas)')
    print('    Returns:         JSON with label, confidence, evidence, policy_trace,')
    print('                     language, audit, model_contributions, runtime_mode')
    print('    Auto-routing:    language detector picks the right model set automatically')

    print_header('DEMO COMPLETE')


if __name__ == '__main__':
    main()
