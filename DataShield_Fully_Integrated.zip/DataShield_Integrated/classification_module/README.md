# Automated Data Sensitivity Classification Engine
## Bilingual Edition (English + Hindi)

> **Scope owned by this module:**
> 1. Classification Ensemble (Logistic Regression + XGBoost)
> 2. Ensemble strategies (Soft Voting + Stacking meta-learner)
> 3. Explainability (SHAP for XGBoost, LIME for Logistic Regression)
> 4. Policy Engine (regex + Luhn + configurable thresholds, bilingual keywords)
> 5. Language detection + routing (English / Hindi / Unknown)
> 6. Synthetic bilingual training data
> 7. PII-safe audit logging

> **Out of scope (owned by teammates):**
> - Ingestion (Kafka, S3, Apache Tika)
> - Presidio PII masking service
> - MLOps infra (MLflow server, drift monitoring)
> - API serving / mTLS

---

## 1. What's new: language routing

Per problem statement requirement: *"Language detection → route to language-specific model."*

Documents are routed at inference time to a **per-language model set**:

```
artifacts/
├── en/                      ← English model set
│   ├── logistic.joblib
│   ├── xgboost.joblib
│   └── stacker.joblib
└── hi/                      ← Hindi model set
    ├── logistic.joblib
    ├── xgboost.joblib
    └── stacker.joblib
```

### Why per-language models (not one multilingual model)

- TF-IDF and HashingVectorizer tokenize on word boundaries. English (Latin) and Hindi (Devanagari) vocabularies don't share features — a single bag-of-words model would waste capacity on cells that are always zero.
- Per-language models are smaller, faster, easier to audit (each model's feature importances map to one vocabulary).
- The policy engine runs on raw text in any script — regex rules for SSN, credit card, IBAN, PAN, Aadhaar fire regardless of surrounding language.

### How routing works

`utils/language_detector.py` inspects the Unicode code points:
- Devanagari (U+0900–U+097F) ≥ 15% of letters → **Hindi** → `artifacts/hi/`
- Latin letters ≥ 85% of letters → **English** → `artifacts/en/`
- Otherwise → **Unknown** → falls back to `default_language` (English)

This is script-based, O(n) over characters, no ML model needed for detection. Deterministic and auditable.

---

## 2. Architecture

```
                    ┌─────────────────────────────┐
                    │  Upstream (teammate owns):  │
                    │  Kafka / S3 / REST ingest   │
                    └──────────────┬──────────────┘
                                   │  text + metadata
                                   ▼
        ┌──────────────────────────────────────────────────┐
        │              CLASSIFICATION MODULE                │
        │                                                   │
        │  ┌────────────────────────────────────────┐      │
        │  │  Language Detector                     │      │
        │  │    en → English model set              │      │
        │  │    hi → Hindi model set                │      │
        │  │    unknown → default (English)         │      │
        │  └────────────────────┬───────────────────┘      │
        │                       ▼                          │
        │  ┌──────────────┐  ┌──────────────┐              │
        │  │ Logistic Reg │  │   XGBoost    │              │
        │  │ (per lang)   │  │ (per lang)   │              │
        │  └──────┬───────┘  └──────┬───────┘              │
        │         └────────┬────────┘                      │
        │                  ▼                               │
        │      ┌────────────────────────┐                  │
        │      │  ENSEMBLE              │                  │
        │      │  Stacking (per lang)   │                  │
        │      └────────────┬───────────┘                  │
        │                   ▼                              │
        │      ┌────────────────────────┐                  │
        │      │  POLICY ENGINE         │                  │
        │      │  regex + Luhn          │                  │
        │      │  bilingual keywords    │                  │
        │      └────────────┬───────────┘                  │
        │                   ▼                              │
        │      ┌────────────────────────┐                  │
        │      │  EXPLAINABILITY        │                  │
        │      │  SHAP + LIME           │                  │
        │      └────────────┬───────────┘                  │
        │                   ▼                              │
        │   JSON: label, confidence, evidence,             │
        │         language, policy_trace, audit            │
        └───────────────────┬──────────────────────────────┘
                            │
                            ▼
        Downstream (teammate owns): DLP / CASB / catalog
```

---

## 3. Folder layout

```
classification_module/
├── models/
│   ├── logistic_model.py      # TF-IDF + class-weighted LR
│   └── xgboost_model.py       # Hashed features + metadata
├── ensemble/
│   ├── voting.py              # Soft voting with weight redistribution
│   └── stacking.py            # Meta-learner over OOF predictions
├── explainability/
│   ├── shap_explainer.py      # SHAP for XGBoost
│   └── lime_explainer.py      # LIME for Logistic Regression
├── policy_engine/
│   └── rules.py               # Regex + Luhn + thresholds
├── configs/
│   ├── policy.yaml            # Rules + bilingual keywords (EN + HI)
│   └── model.yaml             # Languages list + hyperparams
├── data/
│   ├── synthetic_generator.py # Bilingual dataset (5000 per class per lang)
│   └── sample_docs/           # 8 demo files (5 English + 3 Hindi)
├── utils/
│   ├── pii_masker.py
│   ├── audit_logger.py
│   ├── io_helpers.py
│   └── language_detector.py   # NEW: script-based detection
├── tests/                     # 45 tests, all passing
│   ├── test_policy_engine.py
│   ├── test_ensemble.py
│   ├── test_language_detector.py  # NEW: 12 tests for en/hi/unknown
│   └── test_end_to_end.py         # bilingual routing tests
├── scripts/
│   ├── train_all.py           # Trains one model set per language
│   └── predict_cli.py
├── pipeline.py                # Main SensitivityClassifier
├── requirements.txt
├── QUICKSTART.md
└── README.md
```

---

## 4. Output contract

```json
{
  "doc_id": "uuid",
  "label": "Restricted",
  "confidence": 0.9899,
  "class_probabilities": {"Public": 0.003, "Internal": 0.004, "Confidential": 0.003, "Restricted": 0.99},
  "evidence": [
    {"token": "45*****************", "weight": 1.0, "source": "policy:PII_REGEX_CREDIT_CARD"},
    {"token": "AB********",           "weight": 1.0, "source": "policy:PII_REGEX_PAN_INDIA"},
    {"token": "12************",       "weight": 1.0, "source": "policy:PII_REGEX_AADHAAR"},
    {"token": "हक",                   "weight": 0.11, "source": "LIME"}
  ],
  "model_contributions": {"logistic": 0.74, "xgboost": 0.99},
  "policy_trace": {
    "pre_policy_label": "Restricted",
    "post_policy_label": "Restricted",
    "triggered_rules": ["PII_REGEX_CREDIT_CARD", "PII_REGEX_IBAN", "PII_REGEX_PAN_INDIA", "PII_REGEX_AADHAAR"],
    "action": "Quarantine",
    "pii_hits": [...],
    "note": "High-severity PII detected — forced to Restricted per C1."
  },
  "language": {
    "detected": "hi",
    "routed_to": "hi",
    "detected_label": "Hindi"
  },
  "audit": {
    "model_version": "v2.0.0-bilingual",
    "ensemble_used": "stacking",
    "active_models": ["logistic", "xgboost"]
  }
}
```

---

## 5. How to run

See **[QUICKSTART.md](QUICKSTART.md)** for the PyCharm workflow.

Short version:
```bash
pip install -r requirements.txt
python -m data.synthetic_generator
python -m scripts.train_all --sample 500
python -m scripts.predict_cli --input data/sample_docs/ticket_hindi_restricted.txt --pretty
python -m pytest tests/ -v
```

Expected: `45 passed`.

---

## 6. Compliance posture

| Requirement | How we meet it |
|---|---|
| No raw PII stored | `pii_masker.py` masks before audit log; policy engine masks match values in trace |
| Auditable | Every prediction has ≥3 evidence tokens from SHAP/LIME/policy |
| Deterministic | Random seeds fixed (`SEED=42`), sorted JSON keys, stable class order |
| Bilingual support | English + Hindi model sets, script-based routing |
| Regex still fires across languages | Policy engine runs on raw text — PII patterns (SSN, Aadhaar, PAN, card) caught regardless of surrounding script |

### Verified results (last run)

| Language | Test size | LR F1 | XGB F1 | Stacker F1 |
|---|---|---|---|---|
| en | 400 | 1.0000 | 1.0000 | 1.0000 |
| hi | 400 | 1.0000 | 0.9975 | 0.9975 |

Mixed-language batch (8 sample docs): all routed correctly, both Restricted samples got Quarantine action.

Note: near-perfect F1 on synthetic data is expected — templates are learnable. Real-world documents will be noisier.

---

## 7. Integration points for teammates

- **Ingestion teammate**: `pipeline.SensitivityClassifier.predict(text, metadata)` — routing is automatic based on the text content.
- **API teammate**: wrap `SensitivityClassifier` — the `language` field in the response tells which model set handled the doc.
- **MLOps teammate**: register `artifacts/en/*` and `artifacts/hi/*` as separate models in MLflow. They can be retrained and versioned independently.
