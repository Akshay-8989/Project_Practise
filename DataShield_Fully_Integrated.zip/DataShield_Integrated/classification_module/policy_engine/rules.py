"""
rules.py
--------
Policy Engine - the enterprise-grade rule overlay.

Design:
  - Loads rules from configs/policy.yaml (editable by Legal + Data Governance
    per constraint C4 of the problem statement).
  - Runs AFTER the ensemble produces a probabilistic label.
  - Three layers:
      1. Regex PII scan → if HIGH-severity PII match (SSN, card, IBAN, PAN,
         Aadhaar, passport) → FORCE label to Restricted, regardless of model.
      2. Threshold overrides → if model probabilities cross configured
         thresholds, adjust label (e.g. escalate to Restricted).
      3. Dual-approval gate → Restricted needs Legal + DataGovernance sign-off.
  - Rule conflict resolution via priority system.
  - Emits a "policy_trace" dict so every decision is auditable.

Luhn check:
  Credit-card regex alone has high false-positive rate on any 13-16 digit
  number. We apply the Luhn algorithm to candidates to cut these.

Dual Approval (NEW):
  - Restricted → requires BOTH Legal AND DataGovernance approval
  - Confidential → requires Legal approval only
  - Public/Internal → auto-approved

Rule Conflict Resolution (NEW):
  When multiple rules fire with different outcomes, priority-based resolution
  picks the winner. Ties broken by sensitivity level (most restrictive wins).
"""
import os
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple
import regex as re
import yaml

from policy_engine.approval import (
    ApprovalGate,
    build_approval_gate,
    ResolvedRule,
    resolve_conflicts,
    SENSITIVITY_ORDER,
    DEFAULT_RULE_PRIORITIES,
)


# ------------------------------------------------------------------
# Luhn checksum - used to validate candidate credit card numbers
# ------------------------------------------------------------------
def luhn_valid(number: str) -> bool:
    digits = [int(c) for c in number if c.isdigit()]
    if len(digits) < 13 or len(digits) > 19:
        return False
    checksum = 0
    parity = len(digits) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0


@dataclass
class PIIHit:
    rule_name: str
    matched_value_masked: str   # masked value, NOT the raw PII (compliance C1)
    severity: str               # 'high' | 'medium'
    span: Tuple[int, int]


@dataclass
class PolicyDecision:
    pre_policy_label: str
    post_policy_label: str
    triggered_rules: List[str] = field(default_factory=list)
    action: str = 'Allow'
    pii_hits: List[PIIHit] = field(default_factory=list)
    note: str = ''
    # NEW: approval gate and conflict resolution
    approval_gate: Optional[ApprovalGate] = None
    conflict_trace: List[Dict[str, Any]] = field(default_factory=list)
    winning_rule: Optional[str] = None
    # Calibration source: proves thresholds are data-driven, not hand-picked
    calibration_source: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        result = {
            'pre_policy_label': self.pre_policy_label,
            'post_policy_label': self.post_policy_label,
            'triggered_rules': self.triggered_rules,
            'action': self.action,
            'pii_hits': [
                {
                    'rule': h.rule_name,
                    'matched': h.matched_value_masked,
                    'severity': h.severity,
                }
                for h in self.pii_hits
            ],
            'note': self.note,
            # NEW fields
            'approval': self.approval_gate.to_dict() if self.approval_gate else None,
            'conflict_resolution': {
                'fired_rules': self.conflict_trace,
                'winning_rule': self.winning_rule,
            },
            # Calibration proof: shows thresholds are data-driven
            'calibration_source': self.calibration_source,
        }
        return result


class PolicyEngine:
    """
    Rule-overlay policy engine. Consumes:
      - text (raw, so we can see PII patterns)
      - pre_policy_label (from ensemble)
      - class_probabilities (from ensemble)
    Returns a PolicyDecision with approval gate and conflict resolution.
    """

    def __init__(self, config_path: str = 'configs/policy.yaml'):
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
        self._compile_patterns()

        # Load approval and conflict resolution config
        self._approval_config = self.config.get('approval_requirements', None)
        self._rule_priorities = self.config.get('rule_priorities', DEFAULT_RULE_PRIORITIES)

        # Load calibration metadata — proves thresholds are data-driven
        self._calibration_metadata = self.config.get('calibration_metadata', None)

    def _compile_patterns(self):
        self._compiled_pii = []
        for rule in self.config.get('pii_rules', []):
            self._compiled_pii.append({
                'name': rule['name'],
                'pattern': re.compile(rule['pattern']),
                'severity': rule.get('severity', 'high'),
                'description': rule.get('description', ''),
            })
        # Keyword rules are case-insensitive substring matches
        self._confidential_keywords = [
            kw.lower() for kw in
            self.config.get('keyword_rules', {}).get('confidential_keywords', [])
        ]

    # ----------- Internal helpers -----------

    @staticmethod
    def _mask(value: str, keep_prefix: int = 2) -> str:
        """Mask a matched PII value for safe logging (compliance C1)."""
        if len(value) <= keep_prefix + 1:
            return '*' * len(value)
        return value[:keep_prefix] + '*' * (len(value) - keep_prefix)

    def scan_pii(self, text: str) -> List[PIIHit]:
        """Scan text for PII patterns. Returns validated hits only."""
        hits: List[PIIHit] = []
        if not text:
            return hits

        for rule in self._compiled_pii:
            for m in rule['pattern'].finditer(text):
                raw = m.group(0)
                # Extra validation for credit card rule
                if rule['name'] == 'PII_REGEX_CREDIT_CARD':
                    digits_only = ''.join(c for c in raw if c.isdigit())
                    if not luhn_valid(digits_only):
                        continue
                hits.append(PIIHit(
                    rule_name=rule['name'],
                    matched_value_masked=self._mask(raw),
                    severity=rule['severity'],
                    span=(m.start(), m.end()),
                ))
        return hits

    def _has_confidential_keywords(self, text: str) -> List[str]:
        if not text or not self._confidential_keywords:
            return []
        lower = text.lower()
        return [kw for kw in self._confidential_keywords if kw in lower]

    # ----------- Main entry point -----------

    def apply(
        self,
        text: str,
        pre_policy_label: str,
        class_probabilities: Dict[str, float],
    ) -> PolicyDecision:
        """
        Applies rules and returns a PolicyDecision with:
          - Label override (if needed)
          - Action mapping (Allow/Encrypt/Quarantine)
          - Dual-approval gate
          - Rule conflict resolution trace
        """
        decision = PolicyDecision(
            pre_policy_label=pre_policy_label,
            post_policy_label=pre_policy_label,
        )

        # Collect all fired rules for conflict resolution
        fired_rules: List[ResolvedRule] = []

        # Base model prediction is always a "rule" at lowest priority
        fired_rules.append(ResolvedRule(
            rule_name='MODEL_PREDICTION',
            priority=self._rule_priorities.get('MODEL_PREDICTION', 20),
            outcome_label=pre_policy_label,
            outcome_action=self.config.get('actions', {}).get(pre_policy_label, 'Allow'),
            reason=f'Model predicted {pre_policy_label}',
        ))

        # --- Layer 1: PII regex scan ---
        pii_hits = self.scan_pii(text)
        decision.pii_hits = pii_hits
        high_hits = [h for h in pii_hits if h.severity == 'high']
        medium_hits = [h for h in pii_hits if h.severity == 'medium']

        forced_restricted = False
        if high_hits:
            decision.post_policy_label = 'Restricted'
            decision.triggered_rules.extend([h.rule_name for h in high_hits])
            decision.note = 'High-severity PII detected — forced to Restricted per C1.'
            forced_restricted = True
            fired_rules.append(ResolvedRule(
                rule_name='PII_REGEX_HIGH',
                priority=self._rule_priorities.get('PII_REGEX_HIGH', 100),
                outcome_label='Restricted',
                outcome_action='Quarantine',
                reason=f'High-severity PII: {[h.rule_name for h in high_hits]}',
            ))
        else:
            # Multiple medium PII hits aggregate to Restricted
            medium_threshold = self.config.get('severity_rules', {}).get('medium_hit_threshold', 2)
            if len(medium_hits) >= medium_threshold:
                decision.post_policy_label = 'Restricted'
                decision.triggered_rules.extend([h.rule_name for h in medium_hits])
                decision.note = f'Multiple medium-severity PII hits ({len(medium_hits)}) aggregated to Restricted.'
                forced_restricted = True
                fired_rules.append(ResolvedRule(
                    rule_name='PII_AGGREGATE_MEDIUM',
                    priority=self._rule_priorities.get('PII_AGGREGATE_MEDIUM', 90),
                    outcome_label='Restricted',
                    outcome_action='Quarantine',
                    reason=f'{len(medium_hits)} medium-severity PII hits aggregated',
                ))

        # --- Layer 2: threshold overrides (only if not already forced) ---
        thresholds = self.config.get('thresholds', {})

        if not forced_restricted:
            restricted_prob = class_probabilities.get('Restricted', 0.0)
            confidential_prob = class_probabilities.get('Confidential', 0.0)
            restricted_thresh = thresholds.get('restricted_override_prob', 0.70)

            if restricted_prob > restricted_thresh:
                decision.post_policy_label = 'Restricted'
                decision.triggered_rules.append(
                    f'THRESHOLD_RESTRICTED_PROB>{restricted_thresh}'
                )
                decision.note = f'P(Restricted)={restricted_prob:.3f} > {restricted_thresh}'
                fired_rules.append(ResolvedRule(
                    rule_name='THRESHOLD_RESTRICTED',
                    priority=self._rule_priorities.get('THRESHOLD_RESTRICTED', 80),
                    outcome_label='Restricted',
                    outcome_action='Quarantine',
                    reason=f'P(Restricted)={restricted_prob:.3f} exceeded threshold {restricted_thresh}',
                ))

            # Keyword rule: bump Internal → Confidential if confidential keywords present
            if decision.post_policy_label == 'Internal':
                kws = self._has_confidential_keywords(text)
                if kws:
                    decision.post_policy_label = 'Confidential'
                    decision.triggered_rules.append(f'KEYWORD_CONFIDENTIAL:{kws[0]}')
                    decision.note = f'Confidential keyword(s) found: {kws[:3]}'
                    fired_rules.append(ResolvedRule(
                        rule_name='KEYWORD_CONFIDENTIAL',
                        priority=self._rule_priorities.get('KEYWORD_CONFIDENTIAL', 60),
                        outcome_label='Confidential',
                        outcome_action='Encrypt',
                        reason=f'Confidential keywords detected: {kws[:3]}',
                    ))

        # --- Resolve conflicts ---
        winner = resolve_conflicts(fired_rules, self._rule_priorities)
        decision.winning_rule = winner.rule_name
        decision.conflict_trace = [
            {
                'rule': r.rule_name,
                'priority': r.priority,
                'outcome': r.outcome_label,
                'action': r.outcome_action,
                'reason': r.reason,
            }
            for r in fired_rules
        ]

        # --- Action mapping ---
        actions = self.config.get('actions', {})
        low_conf_thresh = thresholds.get('low_confidence_prob', 0.55)
        final_label = decision.post_policy_label
        final_label_prob = class_probabilities.get(final_label, 0.0)

        # Low-confidence wins over normal action mapping EXCEPT for forced Restricted
        # (because forced Restricted comes from a deterministic regex, not the model).
        if not forced_restricted and final_label_prob < low_conf_thresh:
            decision.action = actions.get('LowConfidence', 'HumanReview')
            decision.triggered_rules.append(
                f'LOW_CONFIDENCE<{low_conf_thresh}'
            )
            fired_rules.append(ResolvedRule(
                rule_name='LOW_CONFIDENCE',
                priority=self._rule_priorities.get('LOW_CONFIDENCE', 40),
                outcome_label=final_label,
                outcome_action='HumanReview',
                reason=f'Confidence {final_label_prob:.3f} < threshold {low_conf_thresh}',
            ))
        else:
            decision.action = actions.get(final_label, 'Allow')

        # Escalate action for Confidential if over escalate threshold
        escalate = thresholds.get('confidential_escalate_prob', 0.80)
        if final_label == 'Confidential' and class_probabilities.get('Confidential', 0.0) > escalate:
            decision.triggered_rules.append(f'CONFIDENTIAL_ESCALATE>{escalate}')
            fired_rules.append(ResolvedRule(
                rule_name='CONFIDENTIAL_ESCALATE',
                priority=self._rule_priorities.get('CONFIDENTIAL_ESCALATE', 50),
                outcome_label='Confidential',
                outcome_action='Encrypt',
                reason=f'Confidential probability exceeded escalation threshold {escalate}',
            ))

        # --- Layer 3: Dual-approval gate (NEW) ---
        decision.approval_gate = build_approval_gate(
            final_label,
            self._approval_config,
        )

        # --- Calibration source: proves thresholds are data-driven ---
        decision.calibration_source = self._calibration_metadata

        return decision
