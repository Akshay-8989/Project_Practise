"""
ig_explainer.py
---------------
Integrated Gradients explanations for the Transformer model.

Approach:
  Integrated Gradients (Sundararajan et al., 2017) computes attributions by
  integrating the gradient of the output w.r.t. the input embeddings along a
  straight-line path from a baseline (zero embedding) to the actual input.

  Steps:
    1. Get the input token embeddings from the transformer.
    2. Create a baseline (all-zeros embedding of same shape).
    3. Interpolate `n_steps` points between baseline and input.
    4. Compute gradients of the predicted class score w.r.t. embeddings.
    5. Average the gradients and multiply by (input - baseline).
    6. Sum over the embedding dimension to get per-token attributions.
    7. Map back to tokens and return top-k as evidence.

  This is the standard approach for transformer explainability and is
  the recommended complement to SHAP (tree models) and LIME (linear models).

Graceful fallback:
  If torch is not available, returns empty evidence list.
"""
from typing import List, Dict, Any
import numpy as np

import subprocess
import sys


def _check_torch_safe() -> bool:
    try:
        result = subprocess.run(
            [sys.executable, '-c', 'import torch; print("ok")'],
            capture_output=True, text=True, timeout=15,
        )
        return result.returncode == 0 and 'ok' in result.stdout
    except Exception:
        return False


TORCH_AVAILABLE = _check_torch_safe()


class IntegratedGradientsExplainer:
    def __init__(self, transformer_model, top_k: int = 5, n_steps: int = 32):
        """
        transformer_model: instance of models.transformer_model.TransformerModel
        """
        self.model = transformer_model
        self.top_k = top_k
        self.n_steps = n_steps

    def explain(self, text: str, predicted_class: str) -> List[Dict[str, Any]]:
        """
        Returns a list of top-k evidence dicts:
            [{'token': 'salary', 'weight': 0.35, 'source': 'IntegratedGradients'}, ...]
        """
        if not TORCH_AVAILABLE:
            return []

        try:
            return self._compute_ig(text, predicted_class)
        except Exception as e:
            print(f'  [IG] explain failed: {e}')
            return []

    def _compute_ig(self, text: str, predicted_class: str) -> List[Dict[str, Any]]:
        import torch
        model = self.model
        class_idx = model.label_to_idx[predicted_class]
        device = model.device

        # Tokenize
        encoding = model.tokenizer(
            text,
            max_length=model.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt',
        )
        input_ids = encoding['input_ids'].to(device)
        attention_mask = encoding['attention_mask'].to(device)

        # Get actual token count (non-padding)
        actual_length = attention_mask.sum().item()
        tokens = model.tokenizer.convert_ids_to_tokens(input_ids[0][:int(actual_length)])

        # Get embedding layer
        model.encoder.eval()
        model.head.eval()

        # Get the word embeddings
        if hasattr(model.encoder, 'embeddings'):
            embed_layer = model.encoder.embeddings.word_embeddings
        elif hasattr(model.encoder, 'distilbert'):
            embed_layer = model.encoder.distilbert.embeddings.word_embeddings
        else:
            # Generic fallback: try to find embedding layer
            for name, module in model.encoder.named_modules():
                if 'word_embedding' in name.lower() or (
                    'embedding' in name.lower() and isinstance(module, torch.nn.Embedding)
                ):
                    embed_layer = module
                    break
            else:
                return []  # Can't find embeddings

        # Get input embeddings
        input_embeds = embed_layer(input_ids).detach()
        baseline_embeds = torch.zeros_like(input_embeds)

        # Integrated Gradients: interpolate and compute gradients
        scaled_inputs = []
        for step in range(self.n_steps + 1):
            alpha = step / self.n_steps
            scaled = baseline_embeds + alpha * (input_embeds - baseline_embeds)
            scaled_inputs.append(scaled)

        # Compute gradients for each interpolated input
        all_grads = []
        for scaled in scaled_inputs:
            scaled = scaled.detach().requires_grad_(True)
            outputs = model.encoder(
                inputs_embeds=scaled,
                attention_mask=attention_mask,
            )
            pooled = outputs.last_hidden_state[:, 0, :]
            logits = model.head(pooled)
            score = logits[0, class_idx]

            model.encoder.zero_grad()
            model.head.zero_grad()
            score.backward(retain_graph=False)

            all_grads.append(scaled.grad.detach().clone())

        # Average gradients and compute attributions
        avg_grads = torch.stack(all_grads).mean(dim=0)  # (1, seq_len, hidden)
        attributions = avg_grads * (input_embeds - baseline_embeds)  # (1, seq_len, hidden)

        # Sum over embedding dimension to get per-token attribution
        token_attrs = attributions.sum(dim=-1)[0]  # (seq_len,)
        token_attrs = token_attrs[:int(actual_length)].cpu().numpy()

        # Build evidence list from top-k tokens
        # Skip special tokens ([CLS], [SEP], [PAD])
        special_tokens = {'[CLS]', '[SEP]', '[PAD]', '<s>', '</s>', '<pad>'}
        evidence = []
        order = np.argsort(-np.abs(token_attrs))

        for idx in order:
            tok = tokens[idx]
            if tok in special_tokens:
                continue
            # Clean subword tokens (remove ## prefix for BERT)
            clean_tok = tok.replace('##', '').replace('▁', '')
            if not clean_tok:
                continue

            attr_val = float(token_attrs[idx])
            if attr_val <= 0:
                continue  # Only positive attributions

            evidence.append({
                'token': clean_tok,
                'weight': round(attr_val, 4),
                'source': 'IntegratedGradients',
            })
            if len(evidence) >= self.top_k:
                break

        return evidence
