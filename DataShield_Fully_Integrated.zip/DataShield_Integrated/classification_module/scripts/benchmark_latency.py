"""
benchmark_latency.py
--------------------
Benchmarks per-document classification latency and validates that
p95 is under 200ms.

How the latency fix works:
  When max_class_prob > 0.90 (configurable via lime_skip_confidence in
  model.yaml), the pipeline skips LIME's expensive perturbation-based
  explanation (~100-150ms) and uses the fast coefficient-based fallback
  (~0ms). SHAP and IG still run. Evidence ≥ 3 tokens is guaranteed.

Usage:
    cd classification_module
    python -m scripts.benchmark_latency
    python -m scripts.benchmark_latency --n 200 --warmup 10
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import yaml

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from pipeline import SensitivityClassifier

SEED = 42


def benchmark(clf: SensitivityClassifier, texts: list, metadatas: list,
              warmup: int = 5) -> dict:
    """
    Benchmark per-document latency.

    Returns:
        dict with p50, p95, p99, mean, min, max latencies in ms
    """
    # Warm-up runs (not counted)
    for i in range(min(warmup, len(texts))):
        clf.predict(texts[i], metadata=metadatas[i])

    # Timed runs
    latencies_ms = []
    for i, (text, meta) in enumerate(zip(texts, metadatas)):
        t0 = time.perf_counter()
        result = clf.predict(text, metadata=meta)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        latencies_ms.append(elapsed_ms)

        if (i + 1) % 50 == 0:
            print(f'  [{i + 1}/{len(texts)}] last={elapsed_ms:.1f}ms  '
                  f'running_mean={np.mean(latencies_ms):.1f}ms')

    arr = np.array(latencies_ms)
    return {
        'n_documents': len(arr),
        'mean_ms': round(float(np.mean(arr)), 2),
        'median_ms': round(float(np.median(arr)), 2),
        'p50_ms': round(float(np.percentile(arr, 50)), 2),
        'p95_ms': round(float(np.percentile(arr, 95)), 2),
        'p99_ms': round(float(np.percentile(arr, 99)), 2),
        'min_ms': round(float(np.min(arr)), 2),
        'max_ms': round(float(np.max(arr)), 2),
        'std_ms': round(float(np.std(arr)), 2),
    }


def main():
    parser = argparse.ArgumentParser(
        description='Benchmark per-document classification latency.',
    )
    parser.add_argument('--model-config', default='configs/model.yaml')
    parser.add_argument('--policy-config', default='configs/policy.yaml')
    parser.add_argument('--n', type=int, default=100,
                        help='Number of documents to benchmark')
    parser.add_argument('--warmup', type=int, default=5,
                        help='Number of warm-up predictions')
    args = parser.parse_args()

    print('=' * 60)
    print('  LATENCY BENCHMARK')
    print('  Target: p95 < 200ms')
    print('=' * 60)

    with open(args.model_config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    print('\nLoading pipeline...')
    clf = SensitivityClassifier(
        model_config=args.model_config,
        policy_config=args.policy_config,
    )

    # Load sample documents from dataset
    dataset_csv = cfg['paths']['dataset_csv']
    if os.path.exists(dataset_csv):
        df = pd.read_csv(dataset_csv)
        # Stratified sample
        sample_df = df.groupby('label', group_keys=False).apply(
            lambda g: g.sample(min(len(g), args.n // 4), random_state=SEED)
        ).reset_index(drop=True)
        texts = sample_df['text'].astype(str).tolist()[:args.n]
        metadatas = sample_df[['source_system', 'department', 'file_type', 'author']].to_dict('records')[:args.n]
    else:
        # Fallback: generate synthetic texts
        print(f'[bench] dataset not found at {dataset_csv}, using built-in samples')
        texts = [
            'Press release about new product launch in APAC market.',
            'Employee SSN 123-45-6789 salary $120,000 performance review.',
            'Internal team meeting notes for Phoenix project standup.',
            'Customer PAN ABCDE1234F Aadhaar 1234 5678 9012 KYC form.',
            'कर्मचारी की प्रदर्शन समीक्षा: वेतन समायोजन लंबित।',
            'हमारी कंपनी ने नए उत्पाद लॉन्च की घोषणा की।',
            'Quarterly revenue report for internal stakeholders only.',
            'Trade secret: proprietary algorithm for recommendation engine.',
        ] * (args.n // 8 + 1)
        texts = texts[:args.n]
        metadatas = [{'source_system': 'test', 'department': 'test',
                      'file_type': 'doc', 'author': 'bench'}] * len(texts)

    print(f'\n[bench] benchmarking {len(texts)} documents ({args.warmup} warm-up)...\n')

    stats = benchmark(clf, texts, metadatas, warmup=args.warmup)

    # Report
    print('\n' + '=' * 60)
    print('  LATENCY RESULTS')
    print('=' * 60)
    print(f'  Documents:   {stats["n_documents"]}')
    print(f'  Mean:        {stats["mean_ms"]:.1f} ms')
    print(f'  Median:      {stats["median_ms"]:.1f} ms')
    print(f'  p50:         {stats["p50_ms"]:.1f} ms')
    print(f'  p95:         {stats["p95_ms"]:.1f} ms')
    print(f'  p99:         {stats["p99_ms"]:.1f} ms')
    print(f'  Min:         {stats["min_ms"]:.1f} ms')
    print(f'  Max:         {stats["max_ms"]:.1f} ms')
    print(f'  Std:         {stats["std_ms"]:.1f} ms')

    # Validate
    target = 200.0
    passed = stats['p95_ms'] < target
    print(f'\n  TARGET: p95 < {target:.0f}ms')
    if passed:
        print(f'  RESULT: PASS (p95 = {stats["p95_ms"]:.1f}ms)')
    else:
        print(f'  RESULT: FAIL (p95 = {stats["p95_ms"]:.1f}ms, over by '
              f'{stats["p95_ms"] - target:.1f}ms)')

    print('=' * 60)
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
