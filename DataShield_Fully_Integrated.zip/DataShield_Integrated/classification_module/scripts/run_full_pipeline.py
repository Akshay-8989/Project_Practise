"""
run_full_pipeline.py
--------------------
Master script that runs the FULL compliance pipeline end-to-end:

  1. Generate synthetic dataset (if missing)
  2. Train ALL models (LR + XGBoost + DistilBERT + Stacker)
  3. Run compliance evaluation (16 checks)
  4. Run latency benchmark
  5. Run demo

This ensures everything works directly after checkout — one command to rule them all.

Usage:
    python -m scripts.run_full_pipeline                    # full pipeline
    python -m scripts.run_full_pipeline --sample 200       # dev mode (fast)
    python -m scripts.run_full_pipeline --skip-transformer # skip transformer
    python -m scripts.run_full_pipeline --train-only       # only train, no eval
    python -m scripts.run_full_pipeline --eval-only        # only eval, no train
"""
import argparse
import os
import sys
import subprocess
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


def _header(title: str):
    print(f'\n{"=" * 70}')
    print(f'  {title}')
    print(f'{"=" * 70}')


def _run(cmd: list, cwd: str = None) -> int:
    """Run a command and return exit code."""
    print(f'\n  > {" ".join(cmd)}')
    result = subprocess.run(cmd, cwd=cwd)
    return result.returncode


def check_dependencies():
    """Check if required packages are installed."""
    _header('STEP 0: Checking dependencies')
    missing = []
    for pkg in ['sklearn', 'xgboost', 'numpy', 'pandas', 'yaml', 'joblib', 'shap']:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)

    if missing:
        print(f'  Missing packages: {missing}')
        print(f'  Run: pip install -r requirements.txt')
        return False

    # Check torch (optional)
    try:
        subprocess.run(
            [sys.executable, '-c', 'import torch; import transformers; print("ok")'],
            capture_output=True, text=True, timeout=15,
        )
        print(f'  torch + transformers: INSTALLED')
    except Exception:
        print(f'  torch + transformers: NOT INSTALLED (transformer will be skipped)')
        print(f'  To install: pip install -r requirements-transformer.txt')

    print(f'  All core dependencies OK')
    return True


def generate_data():
    """Generate synthetic dataset if missing."""
    _header('STEP 1: Generating synthetic dataset')
    dataset_path = os.path.join('data', 'synthetic_dataset.csv')
    if os.path.exists(dataset_path):
        import pandas as pd
        df = pd.read_csv(dataset_path)
        print(f'  Dataset exists: {dataset_path} ({len(df)} rows)')
        return True

    print(f'  Dataset not found, generating...')
    rc = _run([sys.executable, '-m', 'data.synthetic_generator'])
    if rc != 0:
        print(f'  ERROR: data generation failed')
        return False
    return True


def train_models(sample: int = None, skip_transformer: bool = False):
    """Train all models."""
    _header('STEP 2: Training ALL models')
    cmd = [sys.executable, '-m', 'scripts.train_all']
    if sample:
        cmd.extend(['--sample', str(sample)])
    if skip_transformer:
        cmd.append('--skip-transformer')

    t0 = time.time()
    rc = _run(cmd)
    elapsed = time.time() - t0
    print(f'\n  Training completed in {elapsed:.1f}s (exit code: {rc})')
    return rc == 0


def run_evaluation(sample: int = 200):
    """Run compliance evaluation."""
    _header('STEP 3: Running compliance evaluation')
    cmd = [sys.executable, '-m', 'scripts.evaluate_compliance', '--sample', str(sample)]
    rc = _run(cmd)
    return rc == 0


def run_benchmark():
    """Run latency benchmark."""
    _header('STEP 4: Running latency benchmark')
    cmd = [sys.executable, '-m', 'scripts.benchmark_latency']
    rc = _run(cmd)
    return rc == 0


def run_tests():
    """Run pytest suite."""
    _header('STEP 5: Running tests')
    cmd = [sys.executable, '-m', 'pytest', 'tests/', '-v', '--tb=short']
    rc = _run(cmd)
    return rc == 0


def main():
    parser = argparse.ArgumentParser(description='Full compliance pipeline runner')
    parser.add_argument('--sample', type=int, default=None,
                        help='Subsample N per class for training (dev mode)')
    parser.add_argument('--eval-sample', type=int, default=200,
                        help='Subsample for evaluation (default: 200)')
    parser.add_argument('--skip-transformer', action='store_true',
                        help='Skip transformer training')
    parser.add_argument('--train-only', action='store_true',
                        help='Only train, skip evaluation')
    parser.add_argument('--eval-only', action='store_true',
                        help='Only evaluate, skip training')
    parser.add_argument('--no-tests', action='store_true',
                        help='Skip pytest suite')
    parser.add_argument('--no-benchmark', action='store_true',
                        help='Skip latency benchmark')
    args = parser.parse_args()

    _header('COMPLIANCE PIPELINE — FULL RUN')
    print(f'  Configuration:')
    print(f'    sample:           {args.sample or "full data"}')
    print(f'    skip_transformer: {args.skip_transformer}')
    print(f'    train_only:       {args.train_only}')
    print(f'    eval_only:        {args.eval_only}')
    t_global = time.time()

    results = {}

    # Step 0: Check dependencies
    if not check_dependencies():
        print('\n  ABORT: missing dependencies')
        sys.exit(1)

    # Step 1: Generate data
    if not generate_data():
        print('\n  ABORT: data generation failed')
        sys.exit(1)
    results['data'] = True

    # Step 2: Train models
    if not args.eval_only:
        results['train'] = train_models(args.sample, args.skip_transformer)
    else:
        print('\n  Skipping training (--eval-only)')
        results['train'] = None

    # Step 3: Evaluate
    if not args.train_only:
        results['eval'] = run_evaluation(args.eval_sample)
    else:
        print('\n  Skipping evaluation (--train-only)')
        results['eval'] = None

    # Step 4: Benchmark
    if not args.train_only and not args.no_benchmark:
        results['benchmark'] = run_benchmark()
    else:
        results['benchmark'] = None

    # Step 5: Tests
    if not args.no_tests:
        results['tests'] = run_tests()
    else:
        results['tests'] = None

    # Final summary
    _header('FINAL SUMMARY')
    total_time = time.time() - t_global
    for step, passed in results.items():
        if passed is None:
            status = 'SKIPPED'
        elif passed:
            status = 'PASS'
        else:
            status = 'FAIL'
        print(f'  {step:<20} {status}')

    print(f'\n  Total time: {total_time:.1f}s')

    failed = [k for k, v in results.items() if v is False]
    if failed:
        print(f'\n  FAILED steps: {failed}')
        sys.exit(1)
    else:
        print(f'\n  ALL STEPS PASSED')
        sys.exit(0)


if __name__ == '__main__':
    main()
