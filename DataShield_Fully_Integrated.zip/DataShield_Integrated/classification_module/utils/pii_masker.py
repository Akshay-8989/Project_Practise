"""
pii_masker.py
-------------
Defensive masking layer. The upstream pre-processing team owns the primary
Presidio-based masker (per problem statement). This is a *second* lightweight
layer that runs before anything enters our audit log, so raw PII can NEVER
be persisted by our module — even if upstream fails.

Design choice: we mask for LOGGING ONLY. The classifier and policy engine
operate on the original text (they need to see PII patterns to make correct
decisions). Masking happens at the write boundary.
"""
import regex as re
from typing import Tuple, List

# Patterns used ONLY for masking (simpler than policy rules - no Luhn etc.)
_MASK_PATTERNS = [
    (re.compile(r'\b\d{3}-\d{2}-\d{4}\b'), '[SSN]'),
    (re.compile(r'\b(?:\d[ -]*?){13,16}\b'), '[CARD]'),
    (re.compile(r'\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b'), '[IBAN]'),
    (re.compile(r'\b[A-Z]{5}\d{4}[A-Z]\b'), '[PAN]'),
    (re.compile(r'\b\d{4}\s?\d{4}\s?\d{4}\b'), '[AADHAAR]'),
    (re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'), '[EMAIL]'),
    (re.compile(r'\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b'), '[PHONE]'),
    (re.compile(r'\b(0[1-9]|1[0-2])[-/](0[1-9]|[12]\d|3[01])[-/](19|20)\d{2}\b'), '[DOB]'),
]


def mask_text(text: str) -> Tuple[str, List[str]]:
    """
    Returns masked text and a list of mask-tag names that fired.
    Does NOT return the original PII values (by design).
    """
    if text is None:
        return '', []
    masked = text
    hits: List[str] = []
    for pat, tag in _MASK_PATTERNS:
        if pat.search(masked):
            hits.append(tag.strip('[]'))
            masked = pat.sub(tag, masked)
    return masked, hits


def safe_snippet(text: str, max_len: int = 160) -> str:
    """Mask + truncate - safe to put in any log."""
    masked, _ = mask_text(text)
    if len(masked) > max_len:
        return masked[:max_len] + '...'
    return masked
