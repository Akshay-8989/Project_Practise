"""
xgboost_model.py
----------------
XGBoost classifier over:
  - HashingVectorizer features (cheap, deterministic, no vocab to persist)
    used as a dense proxy for word embeddings
  - Metadata features: source_system, department, file_type (one-hot)
  - Length-based features: num_chars, num_tokens, num_digits

Role in ensemble:
  - Captures non-linear interactions that LR misses
  - Uses metadata signals that LR ignores (TF-IDF only sees text)

Explainability: SHAP (see explainability/shap_explainer.py)
"""
import os
from typing import List, Dict, Any
import joblib
import numpy as np
import xgboost as xgb
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.preprocessing import LabelEncoder

# Metadata vocab (known at config time). Keep small & fixed for determinism.
SOURCE_SYSTEMS = ['JIRA', 'ServiceNow', 'Confluence', 'Workday', 'Salesforce', 'Gmail', 'SharePoint', 'UNKNOWN']
DEPARTMENTS = ['Engineering', 'HR', 'Finance', 'Legal', 'Sales', 'Marketing', 'Operations', 'UNKNOWN']
FILE_TYPES = ['txt', 'email', 'ticket', 'doc', 'note', 'csv', 'json', 'log', 'md', 'UNKNOWN']


def _onehot(value: str, vocab: List[str]) -> List[int]:
    v = value if value in vocab else 'UNKNOWN'
    return [1 if x == v else 0 for x in vocab]


def _numeric_features(text: str) -> List[float]:
    """Cheap global text stats."""
    if not text:
        return [0.0, 0.0, 0.0, 0.0]
    num_chars = len(text)
    num_tokens = len(text.split())
    num_digits = sum(ch.isdigit() for ch in text)
    digit_ratio = num_digits / max(num_chars, 1)
    return [float(num_chars), float(num_tokens), float(num_digits), float(digit_ratio)]


class XGBoostModel:
    def __init__(self, cfg: Dict[str, Any], classes: List[str]):
        self.classes = classes
        self.hash_features = cfg.get('hash_features', 512)
        self.hasher = HashingVectorizer(
            n_features=self.hash_features,
            alternate_sign=False,
            ngram_range=(1, 2),
            norm='l2',
        )
        self.label_encoder = LabelEncoder()
        self.label_encoder.fit(classes)
        self.clf = xgb.XGBClassifier(
            n_estimators=cfg.get('n_estimators', 300),
            max_depth=cfg.get('max_depth', 6),
            learning_rate=cfg.get('learning_rate', 0.1),
            subsample=cfg.get('subsample', 0.9),
            colsample_bytree=cfg.get('colsample_bytree', 0.9),
            min_child_weight=cfg.get('min_child_weight', 2),
            eval_metric=cfg.get('eval_metric', 'mlogloss'),
            tree_method=cfg.get('tree_method', 'hist'),
            objective='multi:softprob',
            num_class=len(classes),
            random_state=42,
            n_jobs=-1,
        )

    def _featurize(self, texts: List[str], metadata: List[Dict[str, Any]]) -> np.ndarray:
        # Hashed text features → dense
        text_feats = self.hasher.transform(texts).toarray()

        meta_feats = []
        for i, meta in enumerate(metadata):
            meta = meta or {}
            row = []
            row.extend(_onehot(meta.get('source_system', 'UNKNOWN'), SOURCE_SYSTEMS))
            row.extend(_onehot(meta.get('department', 'UNKNOWN'), DEPARTMENTS))
            row.extend(_onehot(meta.get('file_type', 'UNKNOWN'), FILE_TYPES))
            row.extend(_numeric_features(texts[i]))
            meta_feats.append(row)
        meta_feats = np.asarray(meta_feats, dtype=np.float32)

        return np.hstack([text_feats, meta_feats]).astype(np.float32)

    def fit(self, texts: List[str], labels: List[str], metadata: List[Dict[str, Any]]):
        X = self._featurize(texts, metadata)
        y = self.label_encoder.transform(labels)
        self.clf.fit(X, y)
        return self

    def predict_proba(self, texts: List[str], metadata: List[Dict[str, Any]]) -> np.ndarray:
        X = self._featurize(texts, metadata)
        probs = self.clf.predict_proba(X)
        # Reorder to canonical class order
        fitted_classes = list(self.label_encoder.classes_)
        reorder = [fitted_classes.index(c) for c in self.classes]
        return probs[:, reorder]

    def predict(self, texts: List[str], metadata: List[Dict[str, Any]]) -> List[str]:
        probs = self.predict_proba(texts, metadata)
        idx = np.argmax(probs, axis=1)
        return [self.classes[i] for i in idx]

    def get_feature_matrix(self, texts: List[str], metadata: List[Dict[str, Any]]) -> np.ndarray:
        """Expose for SHAP."""
        return self._featurize(texts, metadata)

    def save(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump({
            'hasher': self.hasher,
            'label_encoder': self.label_encoder,
            'clf': self.clf,
            'classes': self.classes,
            'hash_features': self.hash_features,
        }, path)

    @classmethod
    def load(cls, path: str, cfg: Dict[str, Any] = None) -> 'XGBoostModel':
        obj = joblib.load(path)
        inst = cls.__new__(cls)
        inst.hasher = obj['hasher']
        inst.label_encoder = obj['label_encoder']
        inst.clf = obj['clf']
        inst.classes = obj['classes']
        inst.hash_features = obj['hash_features']
        return inst
