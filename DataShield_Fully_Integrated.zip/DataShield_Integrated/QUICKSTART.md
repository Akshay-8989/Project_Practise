# Quick Start — Run This Project on Any Laptop

## Option 1: Automated (Recommended)
```bat
cd Compliance_Project
setup_and_run.bat
```
This will automatically:
- Create a Python virtual environment
- Install all dependencies (including PyTorch for DistilBERT)
- Train ALL models (Logistic Regression + XGBoost + DistilBERT + Stacking Ensemble)
- Run 16 compliance checks
- Run the full demo

**Total time: ~10-30 minutes** (depends on CPU speed — transformer training is the slow part)

---

## Option 2: Manual Step-by-Step

### Step 1: Create virtual environment
```bat
cd Compliance_Project
python -m venv venv
venv\Scripts\activate
```

### Step 2: Install dependencies
```bat
pip install -r classification_module\requirements.txt
pip install torch --index-url https://download.pytorch.org/whl/cpu
pip install transformers sentence-transformers
pip install kafka-python
```

### Step 3: Train all models
```bat
cd classification_module
python -m scripts.train_all --sample 500
```
This trains:
- **Logistic Regression** (TF-IDF + class-weighted LR)
- **XGBoost** (hashed text + metadata features)
- **DistilBERT Transformer** (fine-tuned [CLS] → classification head)
- **Stacking Ensemble** (meta-learner over all 3 models)

For both **English** and **Hindi** language models.

### Step 4: Run the demo
```bat
python demo.py
```

### Step 5: Run compliance evaluation
```bat
python -m scripts.evaluate_compliance --sample 200
```

### Step 6: Run latency benchmark
```bat
python -m scripts.benchmark_latency
```

### Step 7: Run tests
```bat
python -m pytest tests/ -v
```

---

## Kafka Integration (Optional)

The classification module integrates with Kafka through the enterprise platform.
If you want to test the full Kafka pipeline:

### Start Kafka
```bat
C:\kafka_2.13-3.7.1\bin\windows\zookeeper-server-start.bat C:\kafka_2.13-3.7.1\config\zookeeper.properties
C:\kafka_2.13-3.7.1\bin\windows\kafka-server-start.bat C:\kafka_2.13-3.7.1\config\server.properties
```

### Start all 4 pipeline layers
```bat
cd enterprise_platform
run_all_with_classification.bat
```

---

## What Each Module Does

| Module | Description |
|--------|-------------|
| `classification_module/` | Bilingual classifier (EN+HI), ensemble, explainability, policy engine |
| `enterprise_platform/` | Unified Kafka pipeline (Ingestion → Preprocessing → Feature Eng → Classification) |
| `enterprise_ingestion/` | Document ingestion (standalone) |
| `enterprise_preprocessing/` | Text cleaning, PII masking, chunking |
| `enterprise_feature_engineering/` | TF-IDF, embeddings (BERT/RoBERTa/DeBERTa), metadata encoding |

## Key Files

| File | Purpose |
|------|---------|
| `setup_and_run.bat` | One-click setup and run |
| `classification_module/demo.py` | Full interactive demo |
| `classification_module/pipeline.py` | Main classifier API |
| `classification_module/scripts/train_all.py` | Train all models including DistilBERT |
| `classification_module/scripts/evaluate_compliance.py` | 16 compliance checks |
| `classification_module/scripts/run_full_pipeline.py` | Master pipeline script |
| `classification_module/configs/model.yaml` | Model configuration |
| `classification_module/configs/policy.yaml` | Policy engine rules |
