# COMPLIANCE PROJECT — FULL TECHNICAL DOCUMENTATION
## Part 1: Problem Statement Alignment + Core Architecture

---

## 1. PROBLEM STATEMENT ALIGNMENT

### What the Problem Statement Says (PS-01)
The project is "Automated Data Sensitivity Classification Engine" requiring:
- Classify documents into: Public / Internal / Confidential / Restricted
- Bilingual support: English + Hindi
- Ensemble ML models (not a single model)
- PII detection (Aadhaar, PAN, SSN, credit card, IBAN)
- Explainability (why was this classified this way?)
- Policy engine (rules + thresholds)
- Kafka pipeline (real-time streaming)
- Dual-approval gate (Legal + DataGovernance for Restricted)
- Audit logging (no raw PII in logs)
- Latency: p95 < 200ms

---

## 2. ALIGNMENT CHECKLIST

| Requirement | Status | Where Implemented |
|---|---|---|
| 4-class classification (Public/Internal/Confidential/Restricted) | ✅ DONE | `pipeline.py`, `configs/model.yaml` |
| Bilingual: English + Hindi | ✅ DONE | `pipeline.py` (_LanguageModelSet), `utils/language_detector.py` |
| Ensemble (multi-model) | ✅ DONE | `models/`, `ensemble/voting.py`, `ensemble/stacking.py` |
| PII detection | ✅ DONE | `policy_engine/rules.py`, `configs/policy.yaml` |
| Explainability tokens | ✅ DONE | `explainability/shap_explainer.py`, `explainability/lime_explainer.py` |
| Policy engine with thresholds | ✅ DONE | `policy_engine/rules.py` |
| Data-driven thresholds (NOT hand-picked) | ✅ DONE (added) | `scripts/calibrate_thresholds.py`, `configs/policy.yaml` |
| Kafka streaming pipeline | ✅ DONE | `enterprise_platform/classification/consumer.py` |
| Dual-approval gate | ✅ DONE | `policy_engine/approval.py` |
| Audit logging (no raw PII) | ✅ DONE | `utils/audit_logger.py`, `utils/pii_masker.py` |
| Latency p95 < 200ms | ✅ DONE (added) | `pipeline.py` LIME skip, `scripts/benchmark_latency.py` |
| Rule conflict resolution | ✅ DONE | `policy_engine/approval.py` resolve_conflicts() |
| Defense-in-depth (upstream PII hint) | ✅ DONE | `enterprise_platform/classification/consumer.py` _choose_action() |
| Macro-F1 >= 0.85 | ✅ DONE | `scripts/evaluate_compliance.py` C1 check |
| Evidence tokens >= 3 | ✅ DONE | `pipeline.py` _gather_evidence() |

---

## 3. WHAT IS NOT FULLY ALIGNED

| Gap | Explanation | Fix |
|---|---|---|
| **Transformer model** | `transformer.joblib` not trained — artifacts missing. Config says distilbert but no training done | Run `train_all.py` with torch installed, or accept LR+XGB only |
| **mTLS / API layer** | Problem statement C5 requires mTLS for payments clients — this is Aditi's part, not in this module | Out of scope for classification layer |
| **Concurrent-load test** | No multi-worker Kafka consumption smoke test | Add pytest-xdist or locust test |
| **Real dataset** | Uses synthetic data only — real enterprise docs not trained on | Replace `data/synthetic_dataset.csv` with real labeled data |
| **Hindi model quality** | Hindi model produces lower confidence (0.57 for Internal) due to small synthetic training set | More Hindi training data needed |
| **Redis join cache** | `join_cache.py` uses in-memory dict — production should use Redis | Swap `DocJoinCache` for Redis backend |

---

## 4. UNNECESSARY / REMOVABLE THINGS

| Item | Why Possibly Unnecessary | Risk if Removed |
|---|---|---|
| `models/transformer_model.py` | Transformer never trained, always falls back to LR+XGB | Low — just cleaner code |
| `explainability/ig_explainer.py` | IG requires transformer which is never loaded | Low — dead code path |
| `ingestion_project/` folder | Duplicate of `enterprise_ingestion/` — original standalone | Low — docs say untouched |
| `{artifacts` folder in feature_engineering | Malformed folder name (brace in name) — likely accidental | Low — cleanup only |
| `demo.py` hardcoded assertions | `assert result['label'] == 'Restricted'` will fail if model changes | Medium — remove asserts or make soft |
| `lime_num_samples: 200` + LIME skip | With LIME skip at 0.90, LIME barely runs anyway | Very low — keep for low-confidence docs |

---

## 5. OVERALL ARCHITECTURE FLOW

```
[Document Source]
      |
      v
[Ingestion Layer] ──kafka──> normalized_documents
      |
      v
[Preprocessing Layer]
  - Language detection
  - PII masking (Presidio)
  - Text cleaning
  ──kafka──> preprocessed_documents (has clean_text + masked_text)
      |
      v
[Feature Engineering Layer]
  - TF-IDF features
  - Embeddings
  - Metadata encoding
  ──kafka──> engineered_features (has vectors + pii_policy_hint)
      |
      v
[Classification Layer] ← subscribes to BOTH topics, joins by doc_id
  - Language routing (en/hi)
  - LR model (TF-IDF)
  - XGBoost model (hashed features + metadata)
  - Stacking ensemble
  - Policy engine (PII regex + calibrated thresholds + keywords)
  - Dual-approval gate
  - Audit logging
  ──kafka──> classification_results
           > classification_audit
           > classification_dlr
      |
      v
[DLP / CASB / Data Catalog]
```

---
