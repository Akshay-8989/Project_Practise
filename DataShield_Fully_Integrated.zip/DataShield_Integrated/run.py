"""
run.py — Master Entry Point for Compliance Project
====================================================
Run this file directly from PyCharm (right-click → Run 'run').
No Docker, no Kafka, no external services required.

This script:
  1. Checks and installs missing dependencies
  2. Trains all ML models (LR + XGBoost + Transformer if torch is installed)
  3. Runs the full classification demo (English + Hindi)
  4. Shows compliance evaluation results

Usage in PyCharm:
  - Open this file → right-click → Run 'run'
  - Or: Run → Edit Configurations → Script = run.py

Modes:
  python run.py                        # full pipeline (train + demo)
  python run.py --demo-only            # skip training, just run demo
  python run.py --train-only           # train only
  python run.py --sample 500           # fast mode (train on 500 samples/class)
  python run.py --skip-transformer     # skip transformer (faster, LR+XGB only)
  python run.py --ingest path/to/file  # run ingestion on a single file
"""

import argparse
import os
import sys
import subprocess
import io

# ── Fix Windows PyCharm stdout for Hindi/Devanagari characters ───────────────
# Also forces line-buffered output so PyCharm shows logs in real time (fixes streaming issue)
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace", line_buffering=True)
else:
    # Force line buffering on Linux/Mac too (fixes PyCharm "streaming" delay)
    sys.stdout.reconfigure(line_buffering=True) if hasattr(sys.stdout, "reconfigure") else None

# ── Paths ─────────────────────────────────────────────────────────────────────
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
CLASSIFICATION_DIR = os.path.join(ROOT_DIR, "classification_module")
INGESTION_DIR = os.path.join(ROOT_DIR, "ingestion_project")


def _header(title: str):
    print(f"\n{'=' * 70}")
    print(f"  {title}")
    print(f"{'=' * 70}", flush=True)


def _run(cmd: list, cwd: str) -> int:
    """Run a subprocess and return exit code."""
    print(f"\n  > {' '.join(cmd)}", flush=True)
    result = subprocess.run(cmd, cwd=cwd)
    return result.returncode


# ─────────────────────────────────────────────────────────────────────────────
# STEP 0: Dependency check
# ─────────────────────────────────────────────────────────────────────────────

def check_and_install_deps():
    _header("STEP 0: Checking core dependencies")

    core_deps = {
        "sklearn": "scikit-learn==1.4.2",
        "xgboost": "xgboost==2.0.3",
        "numpy": "numpy==1.26.4",
        "pandas": "pandas==2.2.2",
        "yaml": "pyyaml==6.0.1",
        "joblib": "joblib==1.4.0",
        "shap": "shap==0.45.0",
        "lime": "lime==0.2.0.1",
        "regex": "regex==2024.4.16",
    }

    missing = []
    for import_name, pkg in core_deps.items():
        try:
            __import__(import_name)
            print(f"  ✓ {pkg}")
        except ImportError:
            print(f"  ✗ {pkg} — MISSING")
            missing.append(pkg)

    if missing:
        print(f"\n  Installing {len(missing)} missing packages...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install"] + missing,
            check=True,
        )
        print("  Installation complete.")
    else:
        print("\n  All core dependencies installed.")

    # Check transformer (optional)
    print("\n  Checking transformer (optional):")
    try:
        result = subprocess.run(
            [sys.executable, "-c", "import torch; import transformers; print('ok')"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and "ok" in result.stdout:
            print("  ✓ torch + transformers — INSTALLED (transformer will be included in ensemble)")
            return True
        else:
            print("  ✗ torch not installed — transformer will be SKIPPED (LR+XGB still gives 99%+ accuracy)")
            print("  To enable: pip install torch --index-url https://download.pytorch.org/whl/cpu")
            print("             pip install transformers>=4.30.0")
            return False
    except Exception:
        print("  ✗ torch check failed — transformer skipped")
        return False


# ─────────────────────────────────────────────────────────────────────────────
# STEP 1: Generate synthetic dataset
# ─────────────────────────────────────────────────────────────────────────────

def generate_dataset():
    _header("STEP 1: Generating synthetic dataset")
    dataset_path = os.path.join(CLASSIFICATION_DIR, "data", "synthetic_dataset.csv")
    if os.path.exists(dataset_path):
        import pandas as pd
        df = pd.read_csv(dataset_path)
        print(f"  Dataset already exists: {len(df)} rows — skipping generation.")
        return True
    rc = _run([sys.executable, "-m", "data.synthetic_generator"], cwd=CLASSIFICATION_DIR)
    return rc == 0


# ─────────────────────────────────────────────────────────────────────────────
# STEP 2: Train models
# ─────────────────────────────────────────────────────────────────────────────

def train_models(sample: int = None, skip_transformer: bool = False):
    _header("STEP 2: Training ML models (LR + XGBoost + Stacking)")
    if not skip_transformer:
        try:
            result = subprocess.run(
                [sys.executable, "-c", "import torch; print('ok')"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode != 0:
                skip_transformer = True
                print("  [INFO] torch not installed — transformer training skipped")
        except Exception:
            skip_transformer = True

    cmd = [sys.executable, "-m", "scripts.train_all"]
    if sample:
        cmd += ["--sample", str(sample)]
    if skip_transformer:
        cmd.append("--skip-transformer")

    rc = _run(cmd, cwd=CLASSIFICATION_DIR)
    if rc == 0:
        print("\n  ✓ Training complete. Artifacts saved to classification_module/artifacts/")
    else:
        print("\n  ✗ Training failed. Check output above.")
    return rc == 0


# ─────────────────────────────────────────────────────────────────────────────
# STEP 3: Run classification demo
# ─────────────────────────────────────────────────────────────────────────────

def run_demo():
    _header("STEP 3: Classification Demo (English + Hindi)")
    rc = _run([sys.executable, "demo.py"], cwd=CLASSIFICATION_DIR)
    return rc == 0


# ─────────────────────────────────────────────────────────────────────────────
# STEP 4: Run evaluation
# ─────────────────────────────────────────────────────────────────────────────

def run_evaluation(sample: int = 200):
    _header("STEP 4: Compliance Evaluation (16 checks)")
    rc = _run(
        [sys.executable, "-m", "scripts.evaluate_compliance", "--sample", str(sample)],
        cwd=CLASSIFICATION_DIR,
    )
    return rc == 0


# ─────────────────────────────────────────────────────────────────────────────
# STEP 5: Ingest a file (optional)
# ─────────────────────────────────────────────────────────────────────────────

def ingest_file(file_path: str):
    _header(f"INGESTION: {file_path}")
    abs_path = os.path.abspath(file_path)
    if not os.path.exists(abs_path):
        print(f"  ERROR: File not found: {abs_path}")
        return False
    # LOCAL_MODE=true ensures ingestion runs without Kafka
    env = os.environ.copy()
    env["LOCAL_MODE"] = "true"
    print("  [INFO] LOCAL_MODE=true — results will be written to ingestion_project/logs/local_queue/")
    result = subprocess.run(
        [sys.executable, "main.py", "--file", abs_path, "--source", "MANUAL_UPLOAD"],
        cwd=INGESTION_DIR,
        env=env,
    )
    return result.returncode == 0


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Compliance Project — one-click runner for PyCharm",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run.py                      # full pipeline (recommended first run)
  python run.py --demo-only          # just run the demo (models already trained)
  python run.py --train-only         # retrain models only
  python run.py --sample 500         # fast dev mode (500 samples/class, ~2 min)
  python run.py --skip-transformer   # skip transformer (LR+XGB only, fastest)
  python run.py --ingest file.pdf    # ingest a single file
        """,
    )
    parser.add_argument("--sample", type=int, default=None,
                        help="Train on N samples per class (dev mode, e.g. 500)")
    parser.add_argument("--skip-transformer", action="store_true",
                        help="Skip transformer training (LR+XGB only)")
    parser.add_argument("--demo-only", action="store_true",
                        help="Skip training, just run demo (models must already exist)")
    parser.add_argument("--train-only", action="store_true",
                        help="Train only, skip demo")
    parser.add_argument("--no-eval", action="store_true",
                        help="Skip compliance evaluation")
    parser.add_argument("--ingest", type=str, default=None,
                        help="Path to a file to ingest (runs ingestion pipeline)")
    args = parser.parse_args()

    _header("COMPLIANCE PROJECT — AUTOMATED DATA SENSITIVITY CLASSIFICATION")
    print("  Problem Statement: PS-01  |  Priority: HIGH")
    print("  Running in LOCAL MODE — no Kafka or Docker required")

    results = {}

    # ── Ingestion mode ──
    if args.ingest:
        results["ingest"] = ingest_file(args.ingest)
        _print_summary(results)
        return

    # ── Full / Train / Demo pipeline ──

    # Step 0: Deps
    torch_available = check_and_install_deps()
    skip_transformer = args.skip_transformer or not torch_available

    if not args.demo_only:
        # Step 1: Dataset
        results["dataset"] = generate_dataset()
        if not results["dataset"]:
            print("\n  ABORT: Dataset generation failed.")
            sys.exit(1)

        # Step 2: Train
        results["train"] = train_models(args.sample, skip_transformer)
        if not results["train"]:
            print("\n  ABORT: Training failed.")
            sys.exit(1)

    if not args.train_only:
        # Step 3: Demo
        results["demo"] = run_demo()

        # Step 4: Evaluation
        if not args.no_eval:
            results["eval"] = run_evaluation()

    _print_summary(results)

    failed = [k for k, v in results.items() if v is False]
    if failed:
        print(f"\n  FAILED: {failed}")
        sys.exit(1)


def _print_summary(results: dict):
    _header("SUMMARY")
    status_map = {True: "✓ PASS", False: "✗ FAIL", None: "— SKIP"}
    for step, passed in results.items():
        print(f"  {step:<20} {status_map.get(passed, str(passed))}")
    if all(v is not False for v in results.values()):
        print("\n  ALL STEPS PASSED ✓")


if __name__ == "__main__":
    main()
