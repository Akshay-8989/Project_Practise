# DataShield — PS-01 Fully Integrated Project

## Structure
- enterprise_ingestion/          → Teammate A: Ingestion
- enterprise_preprocessing/      → Teammate A: Preprocessing + PII
- enterprise_feature_engineering/ → Teammate A: Feature engineering
- classification_module/         → Teammate B: Models + policy engine
- datashield_api/                → Our team: API + MLOps + Frontend

## Quick Start
```bash
pip install -r requirements.txt
python datashield_api/demo_integrated.py      # full pipeline demo
python datashield_api/run_server.py           # API at localhost:8000
# cd datashield_api/frontend && npm install && npm start   # dashboard
```

## Integration
All integration happens in datashield_api/integration_bridge.py.
It calls Teammate A's PreprocessingPipeline then Teammate B's SensitivityClassifier.
Graceful fallback to heuristics if either is unavailable.

Auth: Authorization: Bearer dev-token-001
Docs: http://localhost:8000/docs
