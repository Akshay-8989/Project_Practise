"""
app.py
=======
Entry point for the Classification Layer.

Mirrors the entry-point pattern used by feature_engineering/app.py and
preprocessing/app.py so it slots cleanly into run_all.bat.

Modes:
  --consumer        Subscribe to Kafka topics, join by doc_id, classify, publish.
  --file <path>     Run on a single JSON file produced by the upstream layers.
                    The file may be either a serialised PreprocessedDocument
                    OR EngineeredFeatureSet OR a {"preprocessed":..., "engineered":...}
                    bundle (matched format from end-to-end tests).
  --folder <path>   Run --file on every *.json under <path>.

Used in two ways:
  1. As a Kafka consumer in the live platform (alongside ingestion,
     preprocessing, feature_engineering).
  2. As an offline classifier for unit/integration tests, where Kafka
     isn't running and you have JSON dumps from earlier stages.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any, Dict

# Logging needs to be configured before anything that imports kafka
logging.basicConfig(
    format="[%(asctime)s] %(levelname)-7s %(name)s :: %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)

logger = logging.getLogger("classification.app")


def _load_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _classify_local(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Classify a single payload that may take any of the supported shapes.
    Imports kept local so kafka-python isn't required for this path.
    """
    from .consumer import classify_pair

    if "engineered" in payload and "preprocessed" in payload:
        return classify_pair(
            engineered=payload["engineered"],
            preprocessed=payload["preprocessed"],
        )

    # Heuristic: an EngineeredFeatureSet has classical_features; a
    # PreprocessedDocument has clean_text or masked_text.
    if "classical_features" in payload:
        return classify_pair(engineered=payload, preprocessed=None)

    if "clean_text" in payload or "masked_text" in payload:
        # Build a minimal engineered envelope so the classifier still runs.
        # This is the offline-test path.
        engineered = {
            "doc_id":            payload.get("doc_id", "unknown"),
            "language":          payload.get("language", {}).get("code", "en") if isinstance(payload.get("language"), dict) else "en",
            "recommended_model": "english_classifier_v1",
            "pii_policy_hint":   payload.get("pii_policy_hint", "Allow"),
            "source_system":     payload.get("business_metadata", {}).get("source_system", "UNKNOWN"),
            "department":        payload.get("business_metadata", {}).get("department", "UNKNOWN"),
            "document_type":     payload.get("business_metadata", {}).get("document_type", "general"),
            "region":            payload.get("business_metadata", {}).get("region", "UNKNOWN"),
            "ingest_id":         payload.get("ingest_id", ""),
            "event_id":          payload.get("event_id", ""),
            "classical_features": {},
        }
        return classify_pair(engineered=engineered, preprocessed=payload)

    raise ValueError(
        "Unrecognised payload shape. Expected EngineeredFeatureSet, "
        "PreprocessedDocument, or a {'engineered':..., 'preprocessed':...} bundle."
    )


def main():
    parser = argparse.ArgumentParser(
        description="Classification Layer — Kafka consumer + offline runner.",
    )
    g = parser.add_mutually_exclusive_group(required=True)
    g.add_argument("--consumer", action="store_true",
                   help="Run as Kafka consumer (production mode)")
    g.add_argument("--file", type=str, help="Classify a single JSON payload")
    g.add_argument("--folder", type=str, help="Classify every *.json in folder")

    parser.add_argument("--out", type=str, default=None,
                        help="(--file/--folder) JSONL output path")
    args = parser.parse_args()

    if args.consumer:
        from .consumer import run_consumer
        run_consumer()
        return

    out_path_abs = Path(args.out).resolve() if args.out else None

    out_lines = []
    if args.file:
        # Resolve before any chdir
        file_path_abs = Path(args.file).resolve()
        payload = _load_json(file_path_abs)
        result = _classify_local(payload)
        if out_path_abs:
            out_lines.append(result)
        else:
            print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))

    elif args.folder:
        folder = Path(args.folder).resolve()
        files = sorted(folder.rglob("*.json"))
        # Resolve to absolute BEFORE the first classify call (which chdir's
        # process cwd to the classification_module).
        files = [fp.resolve() for fp in files]
        logger.info("classifying %d files under %s", len(files), folder)
        for fp in files:
            try:
                payload = _load_json(fp)
                result = _classify_local(payload)
                result["_source_file"] = str(fp)
                out_lines.append(result)
                logger.info("  %s → %s (%.3f) action=%s",
                            fp.name, result["label"], result["confidence"],
                            result["final_action"])
            except Exception as e:
                logger.exception("failed on %s: %s", fp, e)

    if out_path_abs:
        out_path_abs.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path_abs, "w", encoding="utf-8") as f:
            for r in out_lines:
                f.write(json.dumps(r, sort_keys=True, ensure_ascii=False) + "\n")
        logger.info("wrote %d results to %s", len(out_lines), out_path_abs)


if __name__ == "__main__":
    main()
