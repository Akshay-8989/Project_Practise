"""
config.py
==========
Environment-driven configuration for the Classification Layer.

Mirrors the style used by feature_engineering/config.py so it slots into
run_all.bat alongside the other consumers.
"""
import os
from dataclasses import dataclass, field
from typing import List, Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def _e(k: str, d: str = "") -> str:        return os.environ.get(k, d)
def _eb(k: str, d: bool = False) -> bool:  return _e(k, str(d)).lower() in ("true", "1", "yes")
def _ei(k: str, d: int = 0) -> int:
    try: return int(_e(k, str(d)))
    except: return d


@dataclass
class KafkaConfig:
    bootstrap_servers:  str = field(default_factory=lambda: _e("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"))
    security_protocol:  str = field(default_factory=lambda: _e("KAFKA_SECURITY_PROTOCOL", "PLAINTEXT"))
    ssl_cafile:    Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_CAFILE") or None)
    ssl_certfile:  Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_CERTFILE") or None)
    ssl_keyfile:   Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_KEYFILE") or None)
    group_id:           str = field(default_factory=lambda: _e("KAFKA_CONSUMER_GROUP", "classification_service_v1"))
    auto_offset_reset:  str = field(default_factory=lambda: _e("KAFKA_AUTO_OFFSET_RESET", "earliest"))
    max_poll_records:   int = field(default_factory=lambda: _ei("KAFKA_MAX_POLL_RECORDS", 10))
    session_timeout_ms: int = field(default_factory=lambda: _ei("KAFKA_SESSION_TIMEOUT_MS", 60000))
    acks:               str = field(default_factory=lambda: _e("KAFKA_ACKS", "all"))
    retries:            int = field(default_factory=lambda: _ei("KAFKA_RETRIES", 3))
    compression_type:   str = field(default_factory=lambda: _e("KAFKA_COMPRESSION", "gzip"))


@dataclass
class TopicConfig:
    # Subscribe to BOTH so we can join by doc_id
    in_preprocessed:    str = field(default_factory=lambda: _e("KAFKA_TOPIC_PREPROCESSED", "preprocessed_documents"))
    in_engineered:      str = field(default_factory=lambda: _e("KAFKA_TOPIC_ENGINEERED",   "engineered_features"))
    out_results:        str = field(default_factory=lambda: _e("KAFKA_TOPIC_RESULTS",      "classification_results"))
    out_audit:          str = field(default_factory=lambda: _e("KAFKA_TOPIC_AUDIT",        "classification_audit"))
    out_dlr:            str = field(default_factory=lambda: _e("KAFKA_TOPIC_DLR",          "classification_dlr"))


@dataclass
class ClassifierConfig:
    # Path is relative to the unified project root (set when the consumer starts).
    # If not set, the consumer falls back to <repo_root>/classification_module
    classification_module_path: str = field(
        default_factory=lambda: _e("CLASSIFICATION_MODULE_PATH", "")
    )
    model_config_yaml: str = field(default_factory=lambda: _e("MODEL_CONFIG", "configs/model.yaml"))
    policy_config_yaml: str = field(default_factory=lambda: _e("POLICY_CONFIG", "configs/policy.yaml"))
    join_ttl_seconds: int = field(default_factory=lambda: _ei("JOIN_TTL_SECONDS", 300))
    # If True, skip the join and run with engineered-only (degraded LR)
    allow_engineered_only: bool = field(default_factory=lambda: _eb("ALLOW_ENGINEERED_ONLY", False))


@dataclass
class ServiceConfig:
    log_level:        str = field(default_factory=lambda: _e("LOG_LEVEL", "INFO"))
    audit_log_path:   str = field(default_factory=lambda: _e("CLASS_AUDIT_LOG_PATH", "logs/classification_audit.jsonl"))
    health_port:      int = field(default_factory=lambda: _ei("HEALTH_PORT", 0))


@dataclass
class Config:
    kafka:      KafkaConfig      = field(default_factory=KafkaConfig)
    topics:     TopicConfig      = field(default_factory=TopicConfig)
    classifier: ClassifierConfig = field(default_factory=ClassifierConfig)
    service:    ServiceConfig    = field(default_factory=ServiceConfig)


CONFIG = Config()
