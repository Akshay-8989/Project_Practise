@echo off
REM ===========================================================================
REM  Set up the Classification Layer's virtual environment.
REM  Mirrors enterprise_platform\scripts\setup_env.bat for the other layers.
REM ===========================================================================

cd /d "%~dp0"

if not exist venv (
    echo Creating venv...
    python -m venv venv
)

echo Installing classification-layer dependencies...
venv\Scripts\python -m pip install --upgrade pip

REM Consumer-side deps
venv\Scripts\python -m pip install kafka-python python-dotenv pydantic

REM Pull in the classification_module's own deps. classification_module is
REM expected to live one directory up: ..\..\classification_module
venv\Scripts\python -m pip install -r ..\..\classification_module\requirements.txt

echo.
echo Done. To verify:
echo   venv\Scripts\python -m classification.app --file ..\feature_engineering\sample_inputs\hr_record_preprocessed.json
