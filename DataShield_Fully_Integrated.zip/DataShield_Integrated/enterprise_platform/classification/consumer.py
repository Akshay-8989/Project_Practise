"""
consumer.py
============
Kafka consumer for the Classification Layer.

Subscribes to:
  - preprocessed_documents (carries clean_text / masked_text)
  - engineered_features    (carries vectors, metadata, pii_policy_hint)

Joins the two halves by doc_id (small in-memory cache), then invokes the
SensitivityClassifier from Shikha's classification_module. Output is a
ClassificationResult that gets published to:
  - classification_results (the main output topic; downstream DLP/CASB)
  - classification_audit   (per-prediction audit record)
  - classification_dlr     (failures)

Failure handling:
  Anything that goes wrong during a single message produces a DLR record
  rather than killing the consumer loop. We have to keep running.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

# Kafka is an optional dependency at import time so the same module can run
# in --file mode without the broker being up.
try:
    from kafka import KafkaConsumer, KafkaProducer
    from kafka.errors import KafkaError
    KAFKA_AVAILABLE = True
except ImportError:
    KAFKA_AVAILABLE = False

from .config import CONFIG
from .adapter import build_classifier_input, normalize_policy_hint
from .join_cache import DocJoinCache


logger = logging.getLogger("classification.consumer")


# --------------------------------------------------------------------------
# Lazy classifier load
# --------------------------------------------------------------------------
_classifier = None


def _resolve_classification_module_path() -> str:
    """
    Find Shikha's classification_module on disk so we can import it.

    Resolution order:
      1. CLASSIFICATION_MODULE_PATH env var
      2. <repo_root>/classification_module          (this integration's layout)
      3. ../../classification_module                (sibling layout)
    """
    explicit = CONFIG.classifier.classification_module_path
    if explicit and Path(explicit).exists():
        return str(Path(explicit).resolve())

    # repo root: this file is at <root>/enterprise_platform/classification/consumer.py
    here = Path(__file__).resolve()
    repo_root = here.parents[2]
    candidate = repo_root / "classification_module"
    if candidate.exists():
        return str(candidate)

    sibling = here.parents[3] / "classification_module"
    if sibling.exists():
        return str(sibling)

    raise FileNotFoundError(
        "classification_module not found. Set CLASSIFICATION_MODULE_PATH or "
        "place classification_module/ next to enterprise_platform/."
    )


_classifier_cwd: Optional[str] = None


def get_classifier():
    """Lazy-load the SensitivityClassifier exactly once per process."""
    global _classifier, _classifier_cwd
    if _classifier is not None:
        return _classifier

    cm_path = _resolve_classification_module_path()
    if cm_path not in sys.path:
        sys.path.insert(0, cm_path)

    # Pin process cwd to classification_module so relative paths in
    # configs/model.yaml (artifacts/, logs/) resolve correctly for both
    # init AND every subsequent predict() call.
    os.chdir(cm_path)
    _classifier_cwd = cm_path

    from pipeline import SensitivityClassifier
    _classifier = SensitivityClassifier(
        model_config=CONFIG.classifier.model_config_yaml,
        policy_config=CONFIG.classifier.policy_config_yaml,
    )

    logger.info("[classifier] loaded from %s", cm_path)
    return _classifier


# --------------------------------------------------------------------------
# Result builder
# --------------------------------------------------------------------------
def build_result_payload(
    classifier_output: Dict[str, Any],
    engineered: Dict[str, Any],
    upstream_hint: str,
) -> Dict[str, Any]:
    """
    Wraps the classifier's prediction in a Kafka-publishable envelope.
    The envelope copies forward upstream lineage IDs so the DLP/CASB
    layer can correlate end to end.
    """
    return {
        # Lineage (carried straight from upstream)
        "doc_id":        engineered.get("doc_id"),
        "parent_doc_id": engineered.get("parent_doc_id"),
        "event_id":      engineered.get("event_id", ""),
        "ingest_id":     engineered.get("ingest_id", ""),
        # Classification result
        "label":              classifier_output["label"],
        "confidence":         classifier_output["confidence"],
        "class_probabilities": classifier_output["class_probabilities"],
        "evidence":           classifier_output.get("evidence", []),
        "policy_trace":       classifier_output.get("policy_trace", {}),
        "language":           classifier_output.get("language", {}),
        "audit":              classifier_output.get("audit", {}),
        "model_contributions": classifier_output.get("model_contributions", {}),
        # Final action (preferring upstream hint when stricter)
        "final_action": _choose_action(
            classifier_output.get("policy_trace", {}).get("action", "Allow"),
            upstream_hint,
        ),
        # Provenance
        "classification_run_id": str(uuid.uuid4()),
        "classification_timestamp": datetime.now(timezone.utc).isoformat(),
        "source_topics": [
            CONFIG.topics.in_preprocessed,
            CONFIG.topics.in_engineered,
        ],
    }


# Sensitivity ordering — the more restrictive action wins
_ACTION_RANK = {"Allow": 0, "HumanReview": 1, "Encrypt": 2, "Quarantine": 3}


def _choose_action(model_action: str, upstream_hint: str) -> str:
    """
    Pick the stricter of (policy engine action, upstream pii_policy_hint).
    Defense-in-depth: if Presidio upstream said Quarantine, we Quarantine
    regardless of what our model thought.
    """
    upstream_normalized = normalize_policy_hint(upstream_hint)
    if _ACTION_RANK.get(upstream_normalized, 0) > _ACTION_RANK.get(model_action, 0):
        return upstream_normalized
    return model_action


# --------------------------------------------------------------------------
# Audit + DLR
# --------------------------------------------------------------------------
def _ensure_dir(p: str):
    Path(os.path.dirname(p) or ".").mkdir(parents=True, exist_ok=True)


def write_audit_record(result: Dict[str, Any]):
    """Append a JSON line to the audit log. Masking already done by classifier."""
    p = CONFIG.service.audit_log_path
    _ensure_dir(p)
    audit = {
        "audit_id":             str(uuid.uuid4()),
        "timestamp":            datetime.now(timezone.utc).isoformat(),
        "doc_id":               result.get("doc_id"),
        "ingest_id":            result.get("ingest_id"),
        "label":                result.get("label"),
        "confidence":           result.get("confidence"),
        "final_action":         result.get("final_action"),
        "policy_triggered":     result.get("policy_trace", {}).get("triggered_rules", []),
        "language_routed_to":   result.get("language", {}).get("routed_to"),
        "evidence_token_count": len(result.get("evidence", [])),
        "model_version":        result.get("audit", {}).get("model_version"),
    }
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(audit, sort_keys=True, ensure_ascii=False) + "\n")


def build_dlr(doc_id: str, stage: str, reason: str,
              detail: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    return {
        "dlr_id":         str(uuid.uuid4()),
        "doc_id":         doc_id,
        "failure_stage":  stage,
        "failure_reason": reason,
        "failure_detail": detail,
        "failed_at":      datetime.now(timezone.utc).isoformat(),
        "original_payload": payload,
    }


# --------------------------------------------------------------------------
# Single-document classification (used by both consumer and --file mode)
# --------------------------------------------------------------------------
def classify_pair(engineered: Dict[str, Any],
                  preprocessed: Optional[Dict[str, Any]] = None
                  ) -> Dict[str, Any]:
    """
    Run the classifier on a joined (engineered, preprocessed) pair.
    Returns the result envelope (NOT yet published to Kafka).
    """
    text, metadata = build_classifier_input(engineered, preprocessed)
    upstream_hint = engineered.get("pii_policy_hint", "Allow")

    # XGBoost expects flat metadata keys; we strip the _upstream_hints sub-dict
    # before passing it in, but keep it locally for the action override.
    upstream_hints = metadata.pop("_upstream_hints", {})

    clf = get_classifier()
    out = clf.predict(text, metadata=metadata)

    return build_result_payload(out, engineered, upstream_hint)


# --------------------------------------------------------------------------
# Kafka loop
# --------------------------------------------------------------------------
def _make_consumer(topics):
    kc = CONFIG.kafka
    return KafkaConsumer(
        *topics,
        bootstrap_servers=kc.bootstrap_servers,
        security_protocol=kc.security_protocol,
        group_id=kc.group_id,
        auto_offset_reset=kc.auto_offset_reset,
        enable_auto_commit=False,
        max_poll_records=kc.max_poll_records,
        session_timeout_ms=kc.session_timeout_ms,
        value_deserializer=lambda m: json.loads(m.decode("utf-8")),
    )


def _make_producer():
    kc = CONFIG.kafka
    return KafkaProducer(
        bootstrap_servers=kc.bootstrap_servers,
        security_protocol=kc.security_protocol,
        acks=kc.acks,
        retries=kc.retries,
        compression_type=kc.compression_type,
        value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode("utf-8"),
    )


def run_consumer():
    """
    Main consumer loop. Reads from both upstream topics, joins by doc_id,
    runs classifier, publishes results.
    """
    if not KAFKA_AVAILABLE:
        raise RuntimeError(
            "kafka-python is not installed. `pip install kafka-python` "
            "or run with --file for offline classification."
        )

    logger.info("[classifier] warming up (loading models)")
    get_classifier()

    cache = DocJoinCache(ttl_seconds=CONFIG.classifier.join_ttl_seconds)
    consumer = _make_consumer([
        CONFIG.topics.in_preprocessed,
        CONFIG.topics.in_engineered,
    ])
    producer = _make_producer()

    topic_pp = CONFIG.topics.in_preprocessed
    topic_fe = CONFIG.topics.in_engineered

    logger.info("[classifier] subscribed to %s, %s", topic_pp, topic_fe)

    try:
        for msg in consumer:
            try:
                payload = msg.value or {}
                doc_id = payload.get("doc_id")
                if not doc_id:
                    logger.warning("message without doc_id on %s — skipping", msg.topic)
                    consumer.commit()
                    continue

                joined = None
                if msg.topic == topic_pp:
                    joined = cache.add_preprocessed(doc_id, payload)
                elif msg.topic == topic_fe:
                    joined = cache.add_engineered(doc_id, payload)
                else:
                    logger.warning("unexpected topic %s", msg.topic)
                    consumer.commit()
                    continue

                if joined is None:
                    # Need the other half. Hold off committing until we close
                    # the join (avoids losing the data on a restart) but do
                    # commit *this* topic's offset so we don't replay it.
                    consumer.commit()
                    continue

                # Both halves present — classify
                t0 = time.time()
                result = classify_pair(
                    engineered=joined["engineered"],
                    preprocessed=joined["preprocessed"],
                )
                elapsed_ms = (time.time() - t0) * 1000

                producer.send(CONFIG.topics.out_results, value=result)
                producer.send(CONFIG.topics.out_audit, value={
                    **{k: v for k, v in result.items()
                       if k in ("doc_id", "ingest_id", "label", "confidence",
                                "final_action", "language", "classification_run_id",
                                "classification_timestamp")},
                    "elapsed_ms": round(elapsed_ms, 2),
                })
                write_audit_record(result)
                consumer.commit()
                logger.info("[classifier] doc=%s label=%s action=%s conf=%.3f time=%.0fms",
                            doc_id, result["label"], result["final_action"],
                            result["confidence"], elapsed_ms)

            except Exception as e:
                doc_id = (msg.value or {}).get("doc_id", "unknown") if msg.value else "unknown"
                dlr = build_dlr(doc_id, "classification", type(e).__name__,
                                str(e), msg.value)
                try:
                    producer.send(CONFIG.topics.out_dlr, value=dlr)
                except Exception:
                    pass
                logger.exception("[classifier] failed on doc_id=%s", doc_id)
                consumer.commit()  # don't replay poison messages

    finally:
        try: producer.flush(timeout=10)
        except Exception: pass
        try: consumer.close()
        except Exception: pass
        try: producer.close(timeout=10)
        except Exception: pass
