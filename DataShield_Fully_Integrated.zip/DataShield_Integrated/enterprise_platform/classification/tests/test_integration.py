"""
test_integration.py
====================
Smoke test for the classification integration layer.

Runs WITHOUT requiring Kafka — uses the offline `--file` code path.

Verifies:
  - Adapter correctly maps EngineeredFeatureSet + PreprocessedDocument
    into the format Shikha's classifier expects
  - `classify_pair` produces a complete result envelope
  - Upstream `pii_policy_hint` is honored as a stricter override
  - Joining by doc_id works (both halves arriving in either order)
  - Engineered-only path (no preprocessed) still classifies (degraded)

Run from repo root:
    python -m pytest enterprise_platform/classification/tests/test_integration.py -v
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT))


from enterprise_platform.classification.adapter import (
    build_classifier_input,
    build_metadata,
    normalize_policy_hint,
)
from enterprise_platform.classification.join_cache import DocJoinCache
from enterprise_platform.classification.consumer import (
    _choose_action,
    classify_pair,
)


# --------------------------------------------------------
# Adapter unit tests
# --------------------------------------------------------
class TestAdapter:
    def test_metadata_uses_document_type_as_file_type(self):
        eng = {
            "source_system": "HRMS",
            "department":    "HR",
            "document_type": "joining_form",
            "region":        "IN",
            "doc_id":        "X1",
            "language":      "en",
            "pii_policy_hint": "Allow",
            "classical_features": {},
        }
        m = build_metadata(eng)
        assert m["source_system"] == "HRMS"
        assert m["file_type"] == "joining_form"
        assert m["department"] == "HR"
        assert "_upstream_hints" in m
        assert m["_upstream_hints"]["language"] == "en"
        assert m["_upstream_hints"]["pii_policy_hint"] == "Allow"

    def test_metadata_handles_missing_fields(self):
        m = build_metadata({"doc_id": "X1"})
        assert m["source_system"] == "UNKNOWN"
        assert m["department"] == "UNKNOWN"
        assert m["file_type"] == "UNKNOWN"

    def test_classifier_input_prefers_masked_text(self):
        eng = {"doc_id": "X", "classical_features": {}}
        pp = {"clean_text": "hello world", "masked_text": "[MASKED]"}
        text, _ = build_classifier_input(eng, pp)
        assert text == "[MASKED]"

    def test_classifier_input_falls_back_to_clean_text(self):
        eng = {"doc_id": "X", "classical_features": {}}
        pp = {"clean_text": "hello world", "masked_text": ""}
        text, _ = build_classifier_input(eng, pp)
        assert text == "hello world"

    def test_classifier_input_no_preprocessed_uses_top_features(self):
        eng = {
            "doc_id": "X",
            "classical_features": {
                "tfidf": {"top_features": {"salary": 0.8, "termination": 0.7}}
            },
        }
        text, _ = build_classifier_input(eng, None)
        assert "salary" in text
        assert "termination" in text


# --------------------------------------------------------
# Action override tests
# --------------------------------------------------------
class TestActionOverride:
    def test_upstream_quarantine_beats_model_encrypt(self):
        assert _choose_action("Encrypt", "Quarantine") == "Quarantine"

    def test_model_quarantine_beats_upstream_allow(self):
        assert _choose_action("Quarantine", "Allow") == "Quarantine"

    def test_upstream_restrict_normalizes_to_quarantine(self):
        # PS uses "Restrict"; we normalize to our "Quarantine"
        assert normalize_policy_hint("Restrict") == "Quarantine"

    def test_model_humanreview_beats_upstream_allow(self):
        assert _choose_action("HumanReview", "Allow") == "HumanReview"

    def test_unknown_upstream_hint_falls_back_to_allow(self):
        # Unknown hints decay to Allow (least restrictive)
        assert _choose_action("Encrypt", "FlibbleBlat") == "Encrypt"


# --------------------------------------------------------
# Join cache tests
# --------------------------------------------------------
class TestJoinCache:
    def test_preprocessed_first_then_engineered(self):
        cache = DocJoinCache()
        first = cache.add_preprocessed("DOC1", {"clean_text": "hi"})
        assert first is None
        second = cache.add_engineered("DOC1", {"doc_id": "DOC1"})
        assert second is not None
        assert second["preprocessed"]["clean_text"] == "hi"
        assert second["engineered"]["doc_id"] == "DOC1"

    def test_engineered_first_then_preprocessed(self):
        cache = DocJoinCache()
        first = cache.add_engineered("DOC2", {"doc_id": "DOC2"})
        assert first is None
        second = cache.add_preprocessed("DOC2", {"clean_text": "ok"})
        assert second is not None
        assert second["engineered"]["doc_id"] == "DOC2"

    def test_two_docs_dont_cross_pollinate(self):
        cache = DocJoinCache()
        cache.add_preprocessed("A", {"clean_text": "alpha"})
        cache.add_preprocessed("B", {"clean_text": "beta"})
        a = cache.add_engineered("A", {"doc_id": "A"})
        assert a is not None
        assert a["preprocessed"]["clean_text"] == "alpha"
        b = cache.add_engineered("B", {"doc_id": "B"})
        assert b is not None
        assert b["preprocessed"]["clean_text"] == "beta"


# --------------------------------------------------------
# End-to-end classification tests (use Shikha's real classifier)
# --------------------------------------------------------
@pytest.fixture(scope="module")
def hr_payload():
    p = REPO_ROOT / "enterprise_platform/feature_engineering/sample_inputs/hr_record_preprocessed.json"
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


@pytest.fixture(scope="module")
def fin_payload():
    p = REPO_ROOT / "enterprise_platform/feature_engineering/sample_inputs/financial_report_preprocessed.json"
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def _make_eng_envelope(pp):
    """Synthesize an EngineeredFeatureSet-shaped dict from a PreprocessedDocument."""
    return {
        "doc_id":            pp["doc_id"],
        "event_id":          pp.get("event_id", ""),
        "ingest_id":         pp.get("ingest_id", ""),
        "language":          pp.get("language", {}).get("code", "en") if isinstance(pp.get("language"), dict) else "en",
        "recommended_model": pp.get("recommended_model", "english_classifier_v1"),
        "pii_policy_hint":   pp.get("pii_policy_hint", "Allow"),
        "source_system":     pp.get("business_metadata", {}).get("source_system", "UNKNOWN"),
        "department":        pp.get("business_metadata", {}).get("department", "UNKNOWN"),
        "document_type":     pp.get("business_metadata", {}).get("document_type", "general"),
        "region":            pp.get("business_metadata", {}).get("region", "UNKNOWN"),
        "classical_features": {},
    }


class TestClassifyEndToEnd:
    def test_hr_record_classifies(self, hr_payload):
        eng = _make_eng_envelope(hr_payload)
        result = classify_pair(eng, hr_payload)
        # Schema
        for key in ("doc_id", "label", "confidence", "evidence",
                    "policy_trace", "language", "final_action"):
            assert key in result, f"missing key {key}"
        # Result substance
        assert result["label"] in ("Confidential", "Restricted")
        assert result["language"]["routed_to"] == "en"
        # Defense in depth: upstream said Quarantine → final must be Quarantine
        assert result["final_action"] == "Quarantine"
        # Evidence requirement
        assert len(result["evidence"]) >= 3

    def test_financial_classifies_as_restricted(self, fin_payload):
        eng = _make_eng_envelope(fin_payload)
        result = classify_pair(eng, fin_payload)
        assert result["label"] in ("Confidential", "Restricted")
        assert result["language"]["routed_to"] == "en"
        # Both should have a policy_trace with a winning_rule
        cr = result["policy_trace"].get("conflict_resolution", {})
        assert "winning_rule" in cr

    def test_lineage_carries_through(self, hr_payload):
        eng = _make_eng_envelope(hr_payload)
        result = classify_pair(eng, hr_payload)
        assert result["doc_id"] == hr_payload["doc_id"]
        assert result["event_id"] == hr_payload.get("event_id", "")
        assert result["ingest_id"] == hr_payload.get("ingest_id", "")
        assert "preprocessed_documents" in result["source_topics"]
        assert "engineered_features"    in result["source_topics"]

    def test_engineered_only_still_classifies(self, hr_payload):
        """Even without preprocessed text, the classifier should produce a result."""
        eng = _make_eng_envelope(hr_payload)
        result = classify_pair(eng, preprocessed=None)
        assert "label" in result
        assert "final_action" in result
        # Upstream Quarantine still wins
        assert result["final_action"] == "Quarantine"
