"""
schema.py
==========
Output schemas for the Classification Layer.

Matches the Pydantic-based contract used elsewhere in the platform
(feature_engineering/schema.py, preprocessing/schema.py).

ClassificationResult is what we publish to the `classification_results`
Kafka topic — downstream DLP / CASB / data catalog services read this.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

try:
    from pydantic import BaseModel, Field
    PYDANTIC_OK = True
except ImportError:
    PYDANTIC_OK = False
    BaseModel = object       # type: ignore
    def Field(default=None, **kwargs):  # type: ignore
        return default


if PYDANTIC_OK:
    class LanguageRouting(BaseModel):
        detected:       str = "unknown"
        routed_to:      str = "en"
        detected_label: str = "Unknown"


    class EvidenceToken(BaseModel):
        token:  str
        weight: float = 0.0
        source: str   = ""


    class PolicyTrace(BaseModel):
        pre_policy_label:  str = ""
        post_policy_label: str = ""
        action:            str = "Allow"
        triggered_rules:   List[str] = Field(default_factory=list)
        pii_hits:          List[Dict[str, Any]] = Field(default_factory=list)
        note:              str = ""
        approval:          Optional[Dict[str, Any]] = None
        conflict_resolution: Optional[Dict[str, Any]] = None


    class ClassificationResult(BaseModel):
        # Lineage
        doc_id:        str
        parent_doc_id: Optional[str] = None
        event_id:      str = ""
        ingest_id:     str = ""
        # Result
        label:        str
        confidence:   float
        class_probabilities: Dict[str, float] = Field(default_factory=dict)
        evidence:     List[Dict[str, Any]]    = Field(default_factory=list)
        policy_trace: Dict[str, Any]          = Field(default_factory=dict)
        language:     Dict[str, str]          = Field(default_factory=dict)
        audit:        Dict[str, Any]          = Field(default_factory=dict)
        model_contributions: Dict[str, Any]   = Field(default_factory=dict)
        # Final action — incorporates upstream pii_policy_hint
        final_action: str = "Allow"
        # Provenance
        classification_run_id:    str = Field(default_factory=lambda: str(uuid.uuid4()))
        classification_timestamp: str = Field(
            default_factory=lambda: datetime.now(timezone.utc).isoformat()
        )
        source_topics: List[str] = Field(default_factory=list)
