"""
adapter.py
==========
Translates the teammate's EngineeredFeatureSet (Pydantic) and
PreprocessedDocument into the inputs expected by my SensitivityClassifier.

Why this adapter exists:
  - My pipeline.predict(text, metadata) takes raw text + a metadata dict.
  - The teammate publishes TWO upstream topics:
      preprocessed_documents  → has clean_text / masked_text
      engineered_features     → has classical_features / risk / metadata
                                BUT does NOT carry the original text
  - For TF-IDF (Logistic Regression), I need text. For XGBoost+SHAP,
    I'd ideally use the upstream combined_vector, but the model was
    trained on its own hashed-features layout — so we keep using my
    pipeline's internal featurizer and just map metadata + text across.

Strategy:
  - Subscribe to BOTH topics in classification_consumer.py
  - Join by doc_id with a small TTL cache
  - Build the metadata dict from EngineeredFeatureSet (richer than ours)
  - Pass clean_text / masked_text from PreprocessedDocument as the text
  - Forward the upstream pii_policy_hint as a fast-path signal that the
    policy engine can use (so we don't double-pay for PII detection)

Compliance note (C1 — no raw PII stored):
  We prefer masked_text over clean_text whenever available, so by the time
  the document reaches our classifier the high-confidence PII has already
  been masked by the upstream Presidio layer. Our regex policy engine still
  scans for things Presidio might have missed (Aadhaar, Hindi PII).
"""
from __future__ import annotations

from typing import Dict, Any, Optional, Tuple


# Map upstream pii_policy_hint values → our policy engine action vocabulary
# Upstream uses: Allow / Encrypt / Restrict / Quarantine
# We use:        Allow / Encrypt / Quarantine / HumanReview
_POLICY_HINT_PASSTHROUGH = {
    "Allow": "Allow",
    "Encrypt": "Encrypt",
    "Restrict": "Quarantine",   # treat upstream "Restrict" as Quarantine
    "Quarantine": "Quarantine",
}


def _safe_get(d: Dict[str, Any], path: str, default=None):
    """dict.get('a.b.c') -> nested lookup."""
    cur = d
    for key in path.split("."):
        if not isinstance(cur, dict):
            return default
        if key not in cur:
            return default
        cur = cur[key]
    return cur if cur is not None else default


def build_metadata(efs_dict: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build the metadata dict my XGBoost expects from the upstream
    EngineeredFeatureSet (already a dict — Kafka has deserialized it).

    My XGBoost recognizes these keys:
      source_system, department, file_type, author

    Upstream provides (richer):
      source_system, department, document_type, region

    We map document_type → file_type since they overlap semantically.
    """
    return {
        "source_system": efs_dict.get("source_system", "UNKNOWN"),
        "department":    efs_dict.get("department", "UNKNOWN"),
        "file_type":     efs_dict.get("document_type", "UNKNOWN"),
        "author":        "UNKNOWN",  # upstream does not propagate this field
        # extra signals for the policy engine to consume (but not the model)
        "_upstream_hints": {
            "language":            efs_dict.get("language", "en"),
            "recommended_model":   efs_dict.get("recommended_model", ""),
            "pii_policy_hint":     efs_dict.get("pii_policy_hint", "Allow"),
            "ingest_id":           efs_dict.get("ingest_id", ""),
            "event_id":            efs_dict.get("event_id", ""),
            "doc_id":              efs_dict.get("doc_id", ""),
            "region":              efs_dict.get("region", "UNKNOWN"),
            # risk features for fast-path overrides
            "risk_features": _safe_get(
                efs_dict, "classical_features.risk_features", {}
            ) or {},
        },
    }


def get_text_from_preprocessed(pp_dict: Dict[str, Any]) -> str:
    """
    Pick the best text representation from a PreprocessedDocument dict.
    Prefer masked_text (PII already masked) → clean_text → empty.
    """
    masked = pp_dict.get("masked_text", "") or ""
    if masked.strip():
        return masked
    clean = pp_dict.get("clean_text", "") or ""
    return clean


def normalize_policy_hint(hint: str) -> str:
    """Translate upstream policy hint vocabulary into our action vocabulary."""
    return _POLICY_HINT_PASSTHROUGH.get(hint, "Allow")


def build_classifier_input(
    engineered: Dict[str, Any],
    preprocessed: Optional[Dict[str, Any]] = None,
) -> Tuple[str, Dict[str, Any]]:
    """
    Top-level adapter call.

    engineered   : dict from `engineered_features` topic (required)
    preprocessed : dict from `preprocessed_documents` topic (optional but preferred)

    Returns (text, metadata) ready to pass to SensitivityClassifier.predict().
    """
    if preprocessed is None:
        # fallback — try to recover SOME text from inlined tfidf top features
        # This will produce degraded LR predictions but XGBoost is unaffected.
        top_terms = _safe_get(
            engineered, "classical_features.tfidf.top_features", {}
        ) or {}
        text = " ".join(sorted(top_terms.keys(), key=lambda k: -top_terms[k]))
    else:
        text = get_text_from_preprocessed(preprocessed)

    metadata = build_metadata(engineered)
    return text, metadata
