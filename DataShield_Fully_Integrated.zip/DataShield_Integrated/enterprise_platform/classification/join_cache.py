"""
join_cache.py
=============
A small in-memory cache to join messages arriving on two Kafka topics
(preprocessed_documents and engineered_features) by doc_id.

Why this is needed:
  - The teammate's preprocessing layer publishes to `preprocessed_documents`
  - The teammate's feature_engineering layer reads that topic and publishes
    to `engineered_features`
  - The feature engineering output does NOT carry clean_text / masked_text
  - My LR (TF-IDF) needs the text. So I subscribe to BOTH topics and
    pair them up by doc_id before invoking the classifier.

How it works:
  - When preprocessing arrives first, we stash it keyed by doc_id.
  - When engineering arrives, we pop the matching preprocessing entry and
    fire the classifier.
  - If engineering arrives first (uncommon — feature engineering takes
    longer than preprocessing), we stash that and wait.
  - Either way, when both halves are present the classifier runs.
  - Entries older than TTL_SECONDS get pruned to avoid leaks if an
    upstream stage crashes.

This is a SMALL cache — typically holds tens of in-flight docs, not
millions. For a production-scale deployment, swap this for Redis with
the same key-value semantics.
"""
from __future__ import annotations

import time
import threading
from typing import Any, Dict, Optional, Tuple


class DocJoinCache:
    def __init__(self, ttl_seconds: int = 300):
        """
        ttl_seconds: how long to keep half-joined entries before evicting.
                     5 minutes is generous — preprocessing → feature
                     engineering normally takes < 5 seconds end-to-end.
        """
        self._preprocessed: Dict[str, Tuple[float, Dict[str, Any]]] = {}
        self._engineered:   Dict[str, Tuple[float, Dict[str, Any]]] = {}
        self._lock = threading.Lock()
        self.ttl = ttl_seconds
        # Stats for /metrics endpoint or audit
        self.stats = {
            "preprocessed_received": 0,
            "engineered_received":   0,
            "joins_completed":       0,
            "evictions":             0,
        }

    # --------------------------------------------------------
    def add_preprocessed(self, doc_id: str, payload: Dict[str, Any]
                         ) -> Optional[Dict[str, Any]]:
        """
        Store a preprocessed-document record. If the matching engineered
        record is already present, return BOTH halves merged for the
        classifier; otherwise return None.
        """
        with self._lock:
            self.stats["preprocessed_received"] += 1
            now = time.time()
            other = self._engineered.pop(doc_id, None)
            if other is not None:
                self.stats["joins_completed"] += 1
                return {"preprocessed": payload, "engineered": other[1]}
            self._preprocessed[doc_id] = (now, payload)
            self._evict_expired_locked(now)
            return None

    def add_engineered(self, doc_id: str, payload: Dict[str, Any]
                       ) -> Optional[Dict[str, Any]]:
        """Mirror of add_preprocessed for the engineered_features topic."""
        with self._lock:
            self.stats["engineered_received"] += 1
            now = time.time()
            other = self._preprocessed.pop(doc_id, None)
            if other is not None:
                self.stats["joins_completed"] += 1
                return {"preprocessed": other[1], "engineered": payload}
            self._engineered[doc_id] = (now, payload)
            self._evict_expired_locked(now)
            return None

    # --------------------------------------------------------
    def _evict_expired_locked(self, now: float):
        """Caller must already hold self._lock."""
        cutoff = now - self.ttl
        for store in (self._preprocessed, self._engineered):
            stale = [k for k, (t, _) in store.items() if t < cutoff]
            for k in stale:
                store.pop(k, None)
                self.stats["evictions"] += 1

    def size(self) -> Dict[str, int]:
        with self._lock:
            return {
                "preprocessed_pending": len(self._preprocessed),
                "engineered_pending":   len(self._engineered),
            }
