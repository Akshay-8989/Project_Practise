# Classification Layer (Layer 4)

Bridges the upstream platform (Ingestion → Preprocessing → Feature Engineering)
to Shikha's bilingual `classification_module`.

## Files

| File | Lines | Purpose |
|---|---|---|
| `app.py` | 108 | CLI entry: `--consumer` / `--file` / `--folder` modes |
| `consumer.py` | 312 | Kafka loop; subscribes to two topics, joins, classifies, publishes |
| `adapter.py` | 122 | Translates `EngineeredFeatureSet` + `PreprocessedDocument` → classifier input |
| `join_cache.py` | 90 | Small TTL cache to join two topics by `doc_id` |
| `config.py` | 85 | Env-driven config (matches `feature_engineering/config.py`) |
| `schema.py` | 74 | Output Pydantic schema for `classification_results` |

## Modes

```bat
REM Production: subscribe to Kafka topics, classify, publish
venv\Scripts\python -m classification.app --consumer

REM Offline test: classify a single saved payload
venv\Scripts\python -m classification.app --file ..\feature_engineering\sample_inputs\hr_record_preprocessed.json

REM Batch: classify every JSON in a folder
venv\Scripts\python -m classification.app --folder my_payloads\ --out classified.jsonl
```

## How it joins two topics

Subscribes to BOTH `preprocessed_documents` (carries text) and
`engineered_features` (carries vectors + metadata). Either can arrive first.
A small in-memory cache (`join_cache.py`) holds the half that arrived,
keyed by `doc_id`. When the matching half arrives, the pair is classified
and committed.

## Output

Publishes to:
- `classification_results` → main output, consumed by DLP/CASB
- `classification_audit` → per-prediction audit envelope
- `classification_dlr` → failures (poison messages, classifier errors)

Plus appends to:
- `enterprise_platform/logs/classification_audit.jsonl` (consumer-level audit)
- `classification_module/logs/audit.jsonl` (classifier-level audit, masked PII)

## Action override logic

The upstream `pii_policy_hint` and the classifier's `policy_trace.action`
are compared, and the **stricter** is published as `final_action`.
Ranking: `Allow < HumanReview < Encrypt < Quarantine`.
This is defense-in-depth — neither layer can downgrade the other's decision.

## Config

All knobs in `.env`. See `..\configs\classification.env` for the canonical
template.

| Var | Default | Meaning |
|---|---|---|
| `KAFKA_BOOTSTRAP_SERVERS` | `localhost:9092` | Kafka broker |
| `KAFKA_TOPIC_PREPROCESSED` | `preprocessed_documents` | Input #1 |
| `KAFKA_TOPIC_ENGINEERED` | `engineered_features` | Input #2 |
| `KAFKA_TOPIC_RESULTS` | `classification_results` | Main output |
| `JOIN_TTL_SECONDS` | `300` | Drop unmatched halves older than this |
| `CLASSIFICATION_MODULE_PATH` | (auto) | Where to find the classifier |
| `MODEL_CONFIG` | `configs/model.yaml` | Classifier model config |
| `POLICY_CONFIG` | `configs/policy.yaml` | Classifier policy config |
