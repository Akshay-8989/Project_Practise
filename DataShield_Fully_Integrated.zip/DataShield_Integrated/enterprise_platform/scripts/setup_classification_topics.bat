@echo off
REM ===========================================================================
REM  Create Kafka topics for the Classification Layer.
REM  Run once after setup_topics.bat on a fresh Kafka install.
REM ===========================================================================

set KAFKA=C:\kafka_2.13-3.7.1
set BS=localhost:9092

echo Creating classification topics on %BS% ...

%KAFKA%\bin\windows\kafka-topics.bat --create --if-not-exists --bootstrap-server %BS% ^
    --topic classification_results --partitions 3 --replication-factor 1

%KAFKA%\bin\windows\kafka-topics.bat --create --if-not-exists --bootstrap-server %BS% ^
    --topic classification_audit --partitions 3 --replication-factor 1

%KAFKA%\bin\windows\kafka-topics.bat --create --if-not-exists --bootstrap-server %BS% ^
    --topic classification_dlr --partitions 1 --replication-factor 1

echo.
echo Done. Topics:
%KAFKA%\bin\windows\kafka-topics.bat --list --bootstrap-server %BS% | findstr classification
