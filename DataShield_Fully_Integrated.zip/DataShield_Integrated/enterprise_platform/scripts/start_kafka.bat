@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — Start Kafka + Zookeeper
REM  Opens two separate Command Prompt windows.
REM  Wait for both to say "started" before running setup_topics.bat
REM ===========================================================================

set KAFKA_HOME=C:\kafka
REM  Change above to your Kafka installation path.

if not exist "%KAFKA_HOME%\bin\windows\zookeeper-server-start.bat" (
    echo [ERROR] Kafka not found at %KAFKA_HOME%
    echo         Download from: https://kafka.apache.org/downloads
    echo         Extract to C:\kafka and re-run this script.
    pause
    exit /b 1
)

echo ============================================================
echo  Starting Zookeeper in a new window...
echo  Wait for: "binding to port 0.0.0.0/0.0.0.0:2181"
echo ============================================================
start "Zookeeper" cmd /k "%KAFKA_HOME%\bin\windows\zookeeper-server-start.bat %KAFKA_HOME%\config\zookeeper.properties"

echo Waiting 8 seconds for Zookeeper to initialise...
timeout /t 8 /nobreak > nul

echo ============================================================
echo  Starting Kafka Broker in a new window...
echo  Wait for: "started (kafka.server.KafkaServer)"
echo ============================================================
start "Kafka Broker" cmd /k "%KAFKA_HOME%\bin\windows\kafka-server-start.bat %KAFKA_HOME%\config\server.properties"

echo Waiting 10 seconds for Kafka to initialise...
timeout /t 10 /nobreak > nul

echo.
echo ============================================================
echo  Kafka should be running now.
echo  If you see errors, check the Zookeeper/Kafka windows.
echo.
echo  Next steps:
echo    1. Run: scripts\setup_topics.bat     (first time only)
echo    2. Run: run_all.bat
echo ============================================================
pause
