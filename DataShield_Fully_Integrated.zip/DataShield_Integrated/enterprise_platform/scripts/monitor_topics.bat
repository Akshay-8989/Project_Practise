@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — Monitor Kafka Topics
REM  Opens separate windows for each key output topic.
REM ===========================================================================

set KAFKA_HOME=C:\kafka
set BROKER=localhost:9092
set KAFKA_CON=%KAFKA_HOME%\bin\windows\kafka-console-consumer.bat

echo Opening topic monitors...

start "MONITOR: normalized_documents" cmd /k "%KAFKA_CON% --topic normalized_documents --from-beginning --bootstrap-server %BROKER% --property print.timestamp=true"

timeout /t 1 /nobreak > nul

start "MONITOR: preprocessed_documents" cmd /k "%KAFKA_CON% --topic preprocessed_documents --from-beginning --bootstrap-server %BROKER% --property print.timestamp=true"

timeout /t 1 /nobreak > nul

start "MONITOR: engineered_features" cmd /k "%KAFKA_CON% --topic engineered_features --from-beginning --bootstrap-server %BROKER% --property print.timestamp=true"

timeout /t 1 /nobreak > nul

start "MONITOR: dead_letter_queue" cmd /k "%KAFKA_CON% --topic dead_letter_queue --from-beginning --bootstrap-server %BROKER%"

start "MONITOR: preprocessing_dead_letter_queue" cmd /k "%KAFKA_CON% --topic preprocessing_dead_letter_queue --from-beginning --bootstrap-server %BROKER%"

echo.
echo 5 topic monitor windows opened.
echo Close them manually when done.
