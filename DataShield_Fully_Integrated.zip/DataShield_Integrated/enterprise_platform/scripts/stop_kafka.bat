@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — Stop Kafka + Zookeeper
REM ===========================================================================

set KAFKA_HOME=C:\kafka

echo Stopping Kafka Broker...
call "%KAFKA_HOME%\bin\windows\kafka-server-stop.bat"
timeout /t 5 /nobreak > nul

echo Stopping Zookeeper...
call "%KAFKA_HOME%\bin\windows\zookeeper-server-stop.bat"
timeout /t 3 /nobreak > nul

echo Done. All Kafka processes stopped.
pause
