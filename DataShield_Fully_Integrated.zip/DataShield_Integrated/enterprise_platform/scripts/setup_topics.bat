@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — Kafka Topic Setup
REM  Run this ONCE after Kafka starts, before running any layer.
REM  Requires Kafka to be running (start_kafka.bat first).
REM ===========================================================================

REM ── CONFIGURE THIS PATH ────────────────────────────────────────────────────
set KAFKA_HOME=C:\kafka
REM  Change above to your Kafka installation path if different.
REM ───────────────────────────────────────────────────────────────────────────

set BROKER=localhost:9092
set KAFKA_BIN=%KAFKA_HOME%\bin\windows\kafka-topics.bat

if not exist "%KAFKA_BIN%" (
    echo [ERROR] Kafka not found at %KAFKA_HOME%
    echo         Edit KAFKA_HOME in this file to your Kafka path.
    echo         Download Kafka from: https://kafka.apache.org/downloads
    pause
    exit /b 1
)

echo ============================================================
echo  Creating Kafka Topics for Enterprise Platform
echo ============================================================
echo.

REM ── INGESTION LAYER TOPICS ─────────────────────────────────────────────────
echo [INGESTION TOPICS]

call "%KAFKA_BIN%" --create --if-not-exists --topic ingest_requests ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   ingest_requests           created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic raw_documents ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   raw_documents             created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic normalized_documents ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   normalized_documents      created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic single_entity_docs ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   single_entity_docs        created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic multi_entity_docs ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   multi_entity_docs         created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic audit_logs ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   audit_logs                created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic retry_queue ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   retry_queue               created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic dead_letter_queue ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   dead_letter_queue         created/verified

echo.

REM ── PREPROCESSING LAYER TOPICS ─────────────────────────────────────────────
echo [PREPROCESSING TOPICS]

call "%KAFKA_BIN%" --create --if-not-exists --topic preprocessed_documents ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   preprocessed_documents       created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic preprocessing_audit_logs ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   preprocessing_audit_logs     created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic preprocessing_retry_queue ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   preprocessing_retry_queue    created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic preprocessing_dead_letter_queue ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   preprocessing_dead_letter_queue created/verified

echo.

REM ── FEATURE ENGINEERING TOPICS ─────────────────────────────────────────────
echo [FEATURE ENGINEERING TOPICS]

call "%KAFKA_BIN%" --create --if-not-exists --topic engineered_features ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   engineered_features          created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic feature_audit_logs ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   feature_audit_logs           created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic feature_retry_queue ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   feature_retry_queue          created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic feature_dead_letter_queue ^
  --bootstrap-server %BROKER% --partitions 1 --replication-factor 1
echo   feature_dead_letter_queue    created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic training_feature_store ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   training_feature_store       created/verified

call "%KAFKA_BIN%" --create --if-not-exists --topic realtime_feature_store ^
  --bootstrap-server %BROKER% --partitions 3 --replication-factor 1
echo   realtime_feature_store       created/verified

echo.
echo ============================================================
echo  All topics created. Verifying...
echo ============================================================
call "%KAFKA_BIN%" --list --bootstrap-server %BROKER%
echo.
echo  Done. You can now run: run_all.bat
pause
