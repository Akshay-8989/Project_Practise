@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — Ingest a Single Document
REM  Usage:  scripts\ingest_document.bat path\to\file.pdf HRMS HR
REM  Args:   %1 = file path   %2 = source system   %3 = department
REM ===========================================================================

set FILE=%1
set SOURCE=%2
set DEPT=%3

if "%FILE%"=="" (
    echo Usage: scripts\ingest_document.bat path\to\file.pdf [SOURCE_SYSTEM] [DEPARTMENT]
    echo.
    echo Examples:
    echo   scripts\ingest_document.bat sample_data\payroll_report.pdf HRMS HR
    echo   scripts\ingest_document.bat sample_data\contract.docx ERP Legal
    pause
    exit /b 1
)

if "%SOURCE%"=="" set SOURCE=MANUAL
if "%DEPT%"=="" set DEPT=Unknown

echo ============================================================
echo  Ingesting document: %FILE%
echo  Source: %SOURCE%   Department: %DEPT%
echo ============================================================

cd ingestion
venv\Scripts\python main.py file --uri "..\%FILE%" --source %SOURCE% --department %DEPT%
cd ..

echo.
echo Done. Check logs\ingestion_run.log for details.
