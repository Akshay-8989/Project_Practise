@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — First-Time Environment Setup
REM  Run this ONCE before anything else.
REM ===========================================================================

echo ============================================================
echo  Enterprise Platform — First-Time Setup
echo ============================================================
echo.

REM ── Step 1: Create all required directories ──────────────────────────────────
echo [1/5] Creating required directories...

mkdir ingestion\logs        2>nul
mkdir ingestion\uploads     2>nul
mkdir ingestion\metadata    2>nul
mkdir preprocessing\logs    2>nul
mkdir preprocessing\sample_outputs 2>nul
mkdir feature_engineering\logs 2>nul
mkdir feature_engineering\sample_outputs 2>nul
mkdir feature_engineering\artifacts\vectorizers 2>nul
mkdir feature_engineering\artifacts\encoders 2>nul
mkdir feature_engineering\artifacts\embedding_cache 2>nul
mkdir feature_engineering\artifacts\keyword_dicts 2>nul
mkdir feature_engineering\artifacts\training_store 2>nul
mkdir logs 2>nul
mkdir sample_data\uploads 2>nul
echo   Done.

REM ── Step 2: Copy .env files into each layer ───────────────────────────────────
echo.
echo [2/5] Installing .env files...

if not exist ingestion\.env (
    copy configs\ingestion.env ingestion\.env > nul
    echo   ingestion\.env        installed
) else (
    echo   ingestion\.env        already exists (skipped)
)

if not exist preprocessing\.env (
    copy configs\preprocessing.env preprocessing\.env > nul
    echo   preprocessing\.env    installed
) else (
    echo   preprocessing\.env    already exists (skipped)
)

if not exist feature_engineering\.env (
    copy configs\feature_engineering.env feature_engineering\.env > nul
    echo   feature_engineering\.env  installed
) else (
    echo   feature_engineering\.env  already exists (skipped)
)

REM ── Step 3: Create Python virtual environments ───────────────────────────────
echo.
echo [3/5] Creating Python virtual environments...

if not exist ingestion\venv (
    python -m venv ingestion\venv
    echo   ingestion\venv        created
) else (
    echo   ingestion\venv        already exists (skipped)
)

if not exist preprocessing\venv (
    python -m venv preprocessing\venv
    echo   preprocessing\venv    created
) else (
    echo   preprocessing\venv    already exists (skipped)
)

if not exist feature_engineering\venv (
    python -m venv feature_engineering\venv
    echo   feature_engineering\venv  created
) else (
    echo   feature_engineering\venv  already exists (skipped)
)

REM ── Step 4: Install dependencies ─────────────────────────────────────────────
echo.
echo [4/5] Installing Python dependencies (this takes a few minutes)...

echo   Installing ingestion dependencies...
call ingestion\venv\Scripts\pip install -q -r ingestion\requirements.txt
echo   ingestion: Done

echo   Installing preprocessing dependencies...
call preprocessing\venv\Scripts\pip install -q -r preprocessing\requirements.txt
echo   preprocessing: Done

echo   Installing feature_engineering dependencies...
call feature_engineering\venv\Scripts\pip install -q -r feature_engineering\requirements.txt
echo   feature_engineering: Done

REM ── Step 5: Download NLTK data ───────────────────────────────────────────────
echo.
echo [5/5] Downloading NLTK data for preprocessing...
call preprocessing\venv\Scripts\python -c "import nltk; nltk.download('punkt', quiet=True); nltk.download('punkt_tab', quiet=True); nltk.download('wordnet', quiet=True); nltk.download('stopwords', quiet=True); print('NLTK data downloaded')"

echo.
echo ============================================================
echo  Setup complete!
echo.
echo  NEXT STEPS:
echo    1. Install Java 11+  (if not installed)
echo       Download: https://adoptium.net/
echo    2. Install Kafka  (if not installed)
echo       Download: https://kafka.apache.org/downloads
echo       Extract to: C:\kafka
echo    3. Run: scripts\start_kafka.bat
echo    4. Run: scripts\setup_topics.bat   (first time only)
echo    5. Run: run_all.bat
echo ============================================================
pause
