@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — Start All Four Layers (with Classification)
REM  Starts: Ingestion → Preprocessing → Feature Engineering → Classification
REM
REM  Prerequisites (run these first if not done):
REM    scripts\start_kafka.bat
REM    scripts\setup_topics.bat
REM    scripts\setup_env.bat
REM    scripts\setup_classification_topics.bat   (one-time: creates result topics)
REM ===========================================================================

echo ============================================================
echo  ENTERPRISE SENSITIVITY CLASSIFICATION PLATFORM
echo  Starting all FOUR pipeline layers...
echo ============================================================
echo.

REM -- Reuse the same checks from run_all.bat for layers 1-3 --
if not exist ingestion\venv\Scripts\python.exe (
    echo [ERROR] ingestion\venv not found.   Run: scripts\setup_env.bat first
    pause
    exit /b 1
)
if not exist preprocessing\venv\Scripts\python.exe (
    echo [ERROR] preprocessing\venv not found.   Run: scripts\setup_env.bat first
    pause
    exit /b 1
)
if not exist feature_engineering\venv\Scripts\python.exe (
    echo [ERROR] feature_engineering\venv not found.   Run: scripts\setup_env.bat first
    pause
    exit /b 1
)

REM -- New: classification layer venv check --
if not exist classification\venv\Scripts\python.exe (
    echo [WARN] classification\venv not found.
    echo        Run: classification\setup_env.bat (one-time)
    echo        Or: cd classification ^&^& python -m venv venv ^&^& venv\Scripts\pip install -r requirements.txt
    pause
    exit /b 1
)

REM -- .env autocopy --
if not exist ingestion\.env (
    copy configs\ingestion.env ingestion\.env > nul
    echo [AUTO] Installed ingestion\.env from configs\
)
if not exist preprocessing\.env (
    copy configs\preprocessing.env preprocessing\.env > nul
    echo [AUTO] Installed preprocessing\.env from configs\
)
if not exist feature_engineering\.env (
    copy configs\feature_engineering.env feature_engineering\.env > nul
    echo [AUTO] Installed feature_engineering\.env from configs\
)
if not exist classification\.env (
    if exist configs\classification.env (
        copy configs\classification.env classification\.env > nul
        echo [AUTO] Installed classification\.env from configs\
    )
)

REM -- Layer 1: Ingestion --
echo [1/4] Starting Ingestion Layer (folder watcher mode)...
start "PLATFORM - Ingestion Layer" cmd /k "cd ingestion && venv\Scripts\python main.py watch --interval 3 --source MANUAL 2>&1 | tee ..\logs\ingestion_run.log"
timeout /t 4 /nobreak > nul

REM -- Layer 2: Preprocessing --
echo [2/4] Starting Preprocessing Layer (Kafka consumer mode)...
start "PLATFORM - Preprocessing Layer" cmd /k "cd preprocessing && venv\Scripts\python app.py --consumer 2>&1 | tee ..\logs\preprocessing_run.log"
timeout /t 4 /nobreak > nul

REM -- Layer 3: Feature Engineering --
echo [3/4] Starting Feature Engineering Layer (Kafka consumer mode)...
start "PLATFORM - Feature Engineering" cmd /k "cd feature_engineering && venv\Scripts\python app.py --consumer 2>&1 | tee ..\logs\feature_run.log"
timeout /t 4 /nobreak > nul

REM -- Layer 4: Classification (NEW) --
echo [4/4] Starting Classification Layer (Kafka consumer mode)...
echo       Reading from: preprocessed_documents, engineered_features
echo       Writing to:   classification_results, classification_audit, classification_dlr
echo.
start "PLATFORM - Classification" cmd /k "venv\Scripts\python -m classification.app --consumer 2>&1 | tee ..\logs\classification_run.log"

echo.
echo ============================================================
echo  All 4 layers are starting in separate windows.
echo.
echo  TO INGEST A DOCUMENT:
echo    Copy any PDF/DOCX/TXT/CSV to:  ingestion\uploads\
echo    The platform will classify it automatically.
echo.
echo  CLASSIFICATION OUTPUT:
echo    Kafka topic: classification_results
echo    Audit log:   classification_module\logs\audit.jsonl
echo                  + logs\classification_audit.jsonl (consumer-level)
echo.
echo  TO MONITOR:
echo    Logs:   logs\ingestion_run.log
echo            logs\preprocessing_run.log
echo            logs\feature_run.log
echo            logs\classification_run.log
echo    Health: python shared\health_check.py
echo.
echo  TO STOP:
echo    Run: stop_all.bat
echo ============================================================
