@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — Stop All Pipeline Layers
REM ===========================================================================

echo ============================================================
echo  Stopping Enterprise Platform layers...
echo ============================================================
echo.

REM Close the layer windows by title
taskkill /FI "WINDOWTITLE eq PLATFORM - Ingestion Layer" /F > nul 2>&1
echo   Ingestion layer stopped.

taskkill /FI "WINDOWTITLE eq PLATFORM - Preprocessing Layer" /F > nul 2>&1
echo   Preprocessing layer stopped.

taskkill /FI "WINDOWTITLE eq PLATFORM - Feature Engineering" /F > nul 2>&1
echo   Feature Engineering layer stopped.

echo.
echo ============================================================
echo  All layers stopped.
echo  Kafka is still running (stop it with scripts\stop_kafka.bat)
echo ============================================================
pause
