"""
shared/health_check.py
========================
Platform health check utility.
Run before starting any layer to verify Kafka is up and all topics exist.

Usage:
    python shared/health_check.py
    python shared/health_check.py --broker localhost:9092
"""

import argparse
import sys
import os


ALL_TOPICS = [
    # Ingestion outputs
    "ingest_requests",
    "raw_documents",
    "normalized_documents",
    "single_entity_docs",
    "multi_entity_docs",
    "audit_logs",
    "retry_queue",
    "dead_letter_queue",
    # Preprocessing outputs
    "preprocessed_documents",
    "preprocessing_audit_logs",
    "preprocessing_retry_queue",
    "preprocessing_dead_letter_queue",
    # Feature Engineering outputs
    "engineered_features",
    "feature_audit_logs",
    "feature_retry_queue",
    "feature_dead_letter_queue",
    "training_feature_store",
    "realtime_feature_store",
]

LAYER_TOPICS = {
    "ingestion":    ["ingest_requests", "raw_documents", "normalized_documents",
                     "single_entity_docs", "multi_entity_docs", "audit_logs",
                     "retry_queue", "dead_letter_queue"],
    "preprocessing":["normalized_documents", "single_entity_docs", "multi_entity_docs",
                     "preprocessed_documents", "preprocessing_audit_logs",
                     "preprocessing_retry_queue", "preprocessing_dead_letter_queue"],
    "feature":      ["preprocessed_documents", "engineered_features",
                     "feature_audit_logs", "feature_retry_queue",
                     "feature_dead_letter_queue", "training_feature_store"],
}


def check_kafka(broker: str = "localhost:9092") -> bool:
    """Check if Kafka broker is reachable."""
    try:
        from kafka import KafkaAdminClient
        admin = KafkaAdminClient(bootstrap_servers=broker, client_id="health_check",
                                 request_timeout_ms=5000)
        admin.close()
        print(f"  [OK]  Kafka broker reachable at {broker}")
        return True
    except ImportError:
        print("  [WARN] kafka-python not installed — cannot check Kafka")
        return False
    except Exception as exc:
        print(f"  [FAIL] Kafka broker NOT reachable at {broker}: {exc}")
        print("         Start Kafka first: scripts/start_kafka.bat")
        return False


def check_topics(broker: str = "localhost:9092") -> dict:
    """Check which topics exist. Returns {topic: exists}."""
    results = {}
    try:
        from kafka import KafkaAdminClient
        admin = KafkaAdminClient(bootstrap_servers=broker, client_id="health_check",
                                 request_timeout_ms=5000)
        existing = set(admin.list_topics())
        admin.close()
        for topic in ALL_TOPICS:
            results[topic] = topic in existing
    except Exception as exc:
        print(f"  [FAIL] Could not list topics: {exc}")
        for topic in ALL_TOPICS:
            results[topic] = False
    return results


def check_python_deps(layer: str = "all") -> bool:
    """Check if required Python packages are installed."""
    deps = {
        "kafka-python":  "kafka",
        "pydantic":      "pydantic",
        "python-dotenv": "dotenv",
    }
    optional = {
        "pdfplumber":           "pdfplumber",
        "python-docx":          "docx",
        "pandas":               "pandas",
        "nltk":                 "nltk",
        "langdetect":           "langdetect",
        "scikit-learn":         "sklearn",
        "numpy":                "numpy",
        "sentence-transformers":"sentence_transformers",
    }
    all_ok = True
    print("\n  Core dependencies:")
    for pkg, mod in deps.items():
        try:
            __import__(mod)
            print(f"    [OK]  {pkg}")
        except ImportError:
            print(f"    [MISS] {pkg}  →  pip install {pkg}")
            all_ok = False

    print("\n  Optional dependencies:")
    for pkg, mod in optional.items():
        try:
            __import__(mod)
            print(f"    [OK]  {pkg}")
        except ImportError:
            print(f"    [--]  {pkg} not installed (install if needed)")
    return all_ok


def check_folders() -> bool:
    """Check that required folders exist."""
    required = [
        "ingestion/uploads",
        "ingestion/logs",
        "ingestion/metadata",
        "preprocessing/logs",
        "feature_engineering/logs",
        "feature_engineering/artifacts/vectorizers",
        "feature_engineering/artifacts/encoders",
        "feature_engineering/artifacts/embedding_cache",
        "logs",
    ]
    all_ok = True
    for folder in required:
        if os.path.isdir(folder):
            print(f"  [OK]  {folder}/")
        else:
            try:
                os.makedirs(folder, exist_ok=True)
                print(f"  [FIX] Created: {folder}/")
            except Exception as exc:
                print(f"  [FAIL] Cannot create {folder}/: {exc}")
                all_ok = False
    return all_ok


def check_env_files() -> bool:
    """Check that .env files exist in each layer directory."""
    env_files = [
        ("ingestion/.env",          "configs/ingestion.env"),
        ("preprocessing/.env",      "configs/preprocessing.env"),
        ("feature_engineering/.env","configs/feature_engineering.env"),
    ]
    all_ok = True
    for target, source in env_files:
        if os.path.isfile(target):
            print(f"  [OK]  {target}")
        else:
            print(f"  [MISS] {target}  →  copy from {source}")
            all_ok = False
    return all_ok


def main():
    parser = argparse.ArgumentParser(description="Enterprise Platform Health Check")
    parser.add_argument("--broker", default="localhost:9092", help="Kafka bootstrap server")
    parser.add_argument("--layer",  default="all",
                        choices=["all", "ingestion", "preprocessing", "feature"],
                        help="Check specific layer only")
    args = parser.parse_args()

    print("=" * 65)
    print("  ENTERPRISE PLATFORM — HEALTH CHECK")
    print("=" * 65)

    # 1. Kafka connectivity
    print("\n[1] Kafka Broker")
    kafka_ok = check_kafka(args.broker)

    # 2. Topics
    print("\n[2] Kafka Topics")
    if kafka_ok:
        topic_results = check_topics(args.broker)
        topics_to_check = (LAYER_TOPICS.get(args.layer, ALL_TOPICS)
                           if args.layer != "all" else ALL_TOPICS)
        missing = []
        for topic in topics_to_check:
            exists = topic_results.get(topic, False)
            status = "[OK] " if exists else "[MISS]"
            print(f"  {status} {topic}")
            if not exists:
                missing.append(topic)
        if missing:
            print(f"\n  Run scripts/setup_topics.bat to create {len(missing)} missing topics.")
    else:
        print("  Skipped — Kafka not reachable")

    # 3. Python dependencies
    print("\n[3] Python Dependencies")
    deps_ok = check_python_deps()

    # 4. Folders
    print("\n[4] Required Folders")
    folders_ok = check_folders()

    # 5. .env files
    print("\n[5] Environment Files (.env)")
    env_ok = check_env_files()

    # Summary
    print("\n" + "=" * 65)
    all_ok = kafka_ok and deps_ok and folders_ok and env_ok
    if all_ok:
        print("  STATUS: ALL CHECKS PASSED — system ready to run")
        print("  Next step: run_all.bat")
    else:
        print("  STATUS: ISSUES FOUND — fix above before running")
        print("  See README.md Section 3 for setup instructions")
    print("=" * 65)


if __name__ == "__main__":
    main()
