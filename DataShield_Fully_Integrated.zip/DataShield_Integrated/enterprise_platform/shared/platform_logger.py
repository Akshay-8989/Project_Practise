"""
shared/platform_logger.py
===========================
Centralised platform-level logger.
Writes to logs/platform.log and per-layer log files.
Import this in any layer with:
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))
    from platform_logger import get_platform_logger
"""

import logging
import os
import sys
from logging.handlers import RotatingFileHandler


def get_platform_logger(name: str = "platform", log_file: str = "logs/platform.log") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    level = getattr(logging, os.environ.get("LOG_LEVEL", "INFO").upper(), logging.INFO)
    logger.setLevel(level)
    logger.propagate = False

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)-30s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    try:
        os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)
        fh = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=5, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except Exception:
        pass

    return logger
