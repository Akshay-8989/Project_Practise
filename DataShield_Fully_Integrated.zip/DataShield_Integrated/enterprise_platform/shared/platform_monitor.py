"""
shared/platform_monitor.py
===========================
Live console monitor showing messages flowing through the platform.
Displays a dashboard of counts per topic in real-time.

Run:  python shared/platform_monitor.py
      python shared/platform_monitor.py --broker localhost:9092 --interval 3
"""

import argparse
import json
import os
import sys
import time
from collections import defaultdict
from datetime import datetime
from threading import Thread

TOPICS_TO_MONITOR = [
    ("INGESTION   OUT", "normalized_documents"),
    ("INGESTION   OUT", "single_entity_docs"),
    ("INGESTION   OUT", "multi_entity_docs"),
    ("INGESTION   ERR", "dead_letter_queue"),
    ("PREPROCESS  OUT", "preprocessed_documents"),
    ("PREPROCESS  AUD", "preprocessing_audit_logs"),
    ("PREPROCESS  ERR", "preprocessing_dead_letter_queue"),
    ("FEATURE ENG OUT", "engineered_features"),
    ("FEATURE ENG AUD", "feature_audit_logs"),
    ("FEATURE ENG ERR", "feature_dead_letter_queue"),
]


class TopicMonitor:
    def __init__(self, broker: str, refresh_interval: int = 5):
        self.broker   = broker
        self.interval = refresh_interval
        self.counts: dict = defaultdict(int)
        self.latest_doc_ids: dict = {}
        self.running  = True
        self._threads = []

    def start(self):
        print(f"\nStarting monitor | broker={self.broker} | refresh={self.interval}s")
        print("Press Ctrl+C to stop.\n")

        for layer, topic in TOPICS_TO_MONITOR:
            t = Thread(target=self._consume_topic, args=(topic,), daemon=True)
            t.start()
            self._threads.append(t)

        try:
            while self.running:
                self._render()
                time.sleep(self.interval)
        except KeyboardInterrupt:
            self.running = False
            print("\nMonitor stopped.")

    def _consume_topic(self, topic: str):
        try:
            from kafka import KafkaConsumer
            consumer = KafkaConsumer(
                topic,
                bootstrap_servers   = self.broker,
                group_id            = f"platform_monitor_{topic}",
                auto_offset_reset   = "latest",
                enable_auto_commit  = True,
                value_deserializer  = lambda d: json.loads(d.decode("utf-8")) if d else {},
                consumer_timeout_ms = 1000,
            )
            while self.running:
                for msg in consumer:
                    self.counts[topic] += 1
                    payload = msg.value or {}
                    doc_id  = (payload.get("doc_id") or
                               payload.get("ingest_id") or "?")
                    self.latest_doc_ids[topic] = doc_id[:24]
        except Exception as exc:
            self.counts[f"_error_{topic}"] = str(exc)

    def _render(self):
        os.system("cls" if os.name == "nt" else "clear")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print("=" * 70)
        print(f"  ENTERPRISE PLATFORM MONITOR    {now}")
        print(f"  Broker: {self.broker}")
        print("=" * 70)
        print(f"  {'LAYER':<18} {'TOPIC':<38} {'MSGS':>6}  LAST DOC ID")
        print(f"  {'-'*17} {'-'*37} {'-'*6}  {'-'*24}")

        for layer, topic in TOPICS_TO_MONITOR:
            count   = self.counts.get(topic, 0)
            last_id = self.latest_doc_ids.get(topic, "—")
            marker  = "ERR" if "dead_letter" in topic or "ERR" in layer else "   "
            flag    = " !" if count > 0 and "ERR" in layer else "  "
            print(f"  {layer:<18} {topic:<38} {count:>6}{flag} {last_id}")

        print("=" * 70)
        total = sum(v for k, v in self.counts.items() if not k.startswith("_error"))
        errors= sum(v for k, v in self.counts.items()
                    if "dead_letter" in k and isinstance(v, int))
        print(f"  Total messages seen: {total}  |  Errors/DLQ: {errors}")
        print(f"  Next refresh in {self.interval}s  |  Ctrl+C to stop")


def main():
    parser = argparse.ArgumentParser(description="Enterprise Platform Monitor")
    parser.add_argument("--broker",   default="localhost:9092")
    parser.add_argument("--interval", type=int, default=5,
                        help="Refresh interval in seconds")
    args = parser.parse_args()

    try:
        from kafka import KafkaConsumer
    except ImportError:
        print("[ERROR] kafka-python not installed.")
        print("        Run: pip install kafka-python")
        sys.exit(1)

    monitor = TopicMonitor(broker=args.broker, refresh_interval=args.interval)
    monitor.start()


if __name__ == "__main__":
    main()
