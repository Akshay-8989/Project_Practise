@echo off
REM ===========================================================================
REM  ENTERPRISE PLATFORM — Start All Three Layers
REM  Starts: Ingestion → Preprocessing → Feature Engineering
REM
REM  Prerequisites (run these first if not done):
REM    scripts\start_kafka.bat
REM    scripts\setup_topics.bat
REM    scripts\setup_env.bat
REM ===========================================================================

echo ============================================================
echo  ENTERPRISE SENSITIVITY CLASSIFICATION PLATFORM
echo  Starting all pipeline layers...
echo ============================================================
echo.

REM ── Check that virtual environments exist ────────────────────────────────────
if not exist ingestion\venv\Scripts\python.exe (
    echo [ERROR] ingestion\venv not found.
    echo         Run: scripts\setup_env.bat first
    pause
    exit /b 1
)
if not exist preprocessing\venv\Scripts\python.exe (
    echo [ERROR] preprocessing\venv not found.
    echo         Run: scripts\setup_env.bat first
    pause
    exit /b 1
)
if not exist feature_engineering\venv\Scripts\python.exe (
    echo [ERROR] feature_engineering\venv not found.
    echo         Run: scripts\setup_env.bat first
    pause
    exit /b 1
)

REM ── Check that .env files exist ───────────────────────────────────────────────
if not exist ingestion\.env (
    copy configs\ingestion.env ingestion\.env > nul
    echo [AUTO] Installed ingestion\.env from configs\
)
if not exist preprocessing\.env (
    copy configs\preprocessing.env preprocessing\.env > nul
    echo [AUTO] Installed preprocessing\.env from configs\
)
if not exist feature_engineering\.env (
    copy configs\feature_engineering.env feature_engineering\.env > nul
    echo [AUTO] Installed feature_engineering\.env from configs\
)

REM ── Layer 1: Ingestion Consumer ───────────────────────────────────────────────
echo [1/3] Starting Ingestion Layer (folder watcher mode)...
echo       Watching: ingestion\uploads\ for new documents
echo       Writing to: normalized_documents, single_entity_docs, multi_entity_docs
echo.
start "PLATFORM - Ingestion Layer" cmd /k "cd ingestion && venv\Scripts\python main.py watch --interval 3 --source MANUAL 2>&1 | tee ..\logs\ingestion_run.log"

REM Wait for ingestion to initialise
timeout /t 4 /nobreak > nul

REM ── Layer 2: Preprocessing Consumer ──────────────────────────────────────────
echo [2/3] Starting Preprocessing Layer (Kafka consumer mode)...
echo       Reading from: normalized_documents, single_entity_docs, multi_entity_docs
echo       Writing to:   preprocessed_documents
echo.
start "PLATFORM - Preprocessing Layer" cmd /k "cd preprocessing && venv\Scripts\python app.py --consumer 2>&1 | tee ..\logs\preprocessing_run.log"

REM Wait for preprocessing to initialise
timeout /t 4 /nobreak > nul

REM ── Layer 3: Feature Engineering Consumer ─────────────────────────────────────
echo [3/3] Starting Feature Engineering Layer (Kafka consumer mode)...
echo       Reading from: preprocessed_documents
echo       Writing to:   engineered_features
echo.
start "PLATFORM - Feature Engineering" cmd /k "cd feature_engineering && venv\Scripts\python app.py --consumer 2>&1 | tee ..\logs\feature_run.log"

echo.
echo ============================================================
echo  All 3 layers are starting in separate windows.
echo.
echo  TO INGEST A DOCUMENT:
echo    Copy any PDF/DOCX/TXT/CSV to:  ingestion\uploads\
echo    The platform will process it automatically.
echo.
echo  TO MONITOR:
echo    Logs:   logs\ingestion_run.log
echo            logs\preprocessing_run.log
echo            logs\feature_run.log
echo    Health: python shared\health_check.py
echo.
echo  TO STOP:
echo    Run: stop_all.bat
echo ============================================================
