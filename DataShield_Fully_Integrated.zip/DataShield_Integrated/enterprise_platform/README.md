# Enterprise Sensitivity Classification Platform
## Complete Integration Guide — v2.0

---

## Section 1 — Deep Codebase Analysis

### What Each File Does

#### Ingestion Layer (`ingestion/`)
| File | Purpose |
|---|---|
| `main.py` | CLI entry point — `watch`, `folder`, `consumer`, `file`, `api` modes |
| `app.py` | Pipeline orchestrator — wires all ingestion steps |
| `config.py` | Environment-driven config — Kafka, topics, file limits |
| `schema.py` | `NormalizedDocument`, `IngestEvent`, `BusinessMetadata`, `TechnicalMetadata` |
| `parser.py` | Multi-format text extractor — PDF, DOCX, TXT, CSV, JSON, EML, ZIP |
| `splitter.py` | Single vs Multi entity detector (regex heuristics) |
| `metadata_handler.py` | Resolves metadata from inline/sidecar/embedded sources |
| `validator.py` | Schema + business rule validation |
| `producer.py` | Kafka producer — writes to 5 output topics |
| `consumer.py` | `IngestRequestConsumer` (ingest_requests) + `RetryConsumer` (retry_queue) |
| `retry_handler.py` | Exponential backoff retry with DLQ escalation |
| `api.py` | FastAPI endpoints for HTTP-based ingestion (optional) |
| `logger.py` | Rotating file + console logger |

**Ingestion starts with:** `python main.py watch` (folder watcher) or `python main.py consumer` (Kafka-driven)

#### Preprocessing Layer (`preprocessing/`)
| File | Purpose |
|---|---|
| `app.py` | Entry point — `--consumer`, `--file`, `--folder` modes |
| `pipeline.py` | 8-step orchestrator: validate→clean→language→PII→tokenize→chunk→stats→risk |
| `config.py` | Environment config + topic names |
| `schema.py` | `IngestionDocument` (input), `PreprocessedDocument` (output) |
| `cleaner.py` | HTML removal, OCR artifacts, Unicode normalisation, boilerplate strip |
| `pii_masker.py` | 10 PII types: PAN, Aadhaar, SSN, IBAN, CC, email, phone, DOB, emp_id, bank |
| `language_detector.py` | langdetect → langid → Unicode script → default |
| `tokenizer.py` | NLTK (default) or spaCy — lemmatisation, stopword removal |
| `chunker.py` | Sentence-aware overlapping chunks (512 tokens, 64 overlap) |
| `enricher.py` | Text stats, risk signals, preprocessing metadata |
| `validator.py` | Validates IngestionDocument schema before processing |
| `producer.py` | Kafka producer — writes to preprocessed_documents + audit |
| `consumer.py` | Reads from `normalized_documents`, `single_entity_docs`, `multi_entity_docs` |
| `retry_handler.py` | Retry with backoff |

**Preprocessing starts with:** `python app.py --consumer`

#### Feature Engineering Layer (`feature_engineering/`)
| File | Purpose |
|---|---|
| `app.py` | Entry point — `--consumer`, `--file`, `--folder`, `--fit-tfidf` modes |
| `pipeline.py` | 9-step orchestrator: validate→stats→metadata→risk→tfidf→embed→combine→drift→audit |
| `config.py` | Environment config + embedding model aliases |
| `schema.py` | `PreprocessedDocument` (input), `EngineeredFeatureSet` (output) |
| `stats_features.py` | 16 statistical text features (entropy, TTR, uppercase_ratio, etc.) |
| `metadata_encoder.py` | OneHot/Frequency/Hash encoding for categorical metadata |
| `keyword_features.py` | 100+ domain keywords across 5 tiers + PII risk vector |
| `tfidf_engine.py` | TF-IDF with artifact persistence, top-N inline, SHAP feature names |
| `embedding_engine.py` | SentenceTransformer (MiniLM/BERT/RoBERTa) with content-hash cache |
| `chunk_aggregator.py` | Mean/max pooling across multi-chunk document embeddings |
| `feature_registry.py` | Feature name registry for SHAP + rolling drift detection |
| `serializer.py` | Save/load artifacts — joblib, npz, parquet |
| `validator.py` | Validates PreprocessedDocument before processing |
| `producer.py` | Kafka producer — writes to engineered_features + audit |
| `consumer.py` | Reads from `preprocessed_documents` |

**Feature Engineering starts with:** `python app.py --consumer`

---

## Section 2 — How All 3 Layers Connect

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    SOURCE SYSTEMS                                       │
│         HRMS / ERP / CRM / Email / SharePoint / Manual Upload          │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
                    Drop file to:
                    ingestion/uploads/
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│                 LAYER 1: INGESTION                                      │
│                 ingestion/main.py watch                                 │
│                                                                         │
│  parse → split → validate → metadata → Kafka publish                   │
│                                                                         │
│  WRITES TO:                                                             │
│    normalized_documents    ← ALL valid docs                             │
│    single_entity_docs      ← single-entity docs (contract, report)     │
│    multi_entity_docs       ← each segment of multi-entity docs         │
│    audit_logs              ← every file attempted                       │
│    dead_letter_queue       ← failed files                               │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
         reads: normalized_documents
                single_entity_docs
                multi_entity_docs
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│                 LAYER 2: PREPROCESSING                                  │
│                 preprocessing/app.py --consumer                         │
│                                                                         │
│  clean → language → PII mask → tokenize → chunk → stats                │
│                                                                         │
│  WRITES TO:                                                             │
│    preprocessed_documents         ← clean, masked, tokenised docs       │
│    preprocessing_audit_logs       ← every document processed           │
│    preprocessing_dead_letter_queue← failed documents                   │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
              reads: preprocessed_documents
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│                 LAYER 3: FEATURE ENGINEERING                            │
│                 feature_engineering/app.py --consumer                   │
│                                                                         │
│  stats → metadata_encode → risk/keywords → tfidf → embed → combine     │
│                                                                         │
│  WRITES TO:                                                             │
│    engineered_features            ← ML-ready feature vectors            │
│    feature_audit_logs             ← every document processed           │
│    feature_dead_letter_queue      ← failed documents                   │
│    training_feature_store         ← training mode only                 │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
              reads: engineered_features
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│                 LAYER 4: CLASSIFICATION (FUTURE)                        │
│                 Labels: Public / Internal / Confidential / Restricted   │
└─────────────────────────────────────────────────────────────────────────┘
```

### Canonical Schema at Each Boundary

**Ingestion → Preprocessing** (`normalized_documents` topic):
```json
{
  "doc_id": "uuid",
  "raw_text": "full extracted document text",
  "structure_type": "single" or "multi",
  "data_category": "unstructured",
  "business_metadata": { "source_system": "HRMS", "department": "HR", ... },
  "technical_metadata": { "ingest_id": "...", "file_name": "...", "checksum_sha256": "...", ... }
}
```

**Preprocessing → Feature Engineering** (`preprocessed_documents` topic):
```json
{
  "doc_id": "uuid",
  "clean_text": "normalised text",
  "masked_text": "text with <PAN> <EMAIL> placeholders",
  "tokens": ["word1", "word2", ...],
  "sentence_chunks": ["sentence 1.", "sentence 2.", ...],
  "language": {"code": "en", "recommended_model": "english_classifier_v1"},
  "pii_entities": {"PAN": 1, "EMAIL": 0, ...},
  "pii_policy_hint": "Quarantine",
  "stats": {"token_count": 44, "entropy": 4.78, ...},
  "business_metadata": { ... }
}
```

**Feature Engineering → Classification** (`engineered_features` topic):
```json
{
  "doc_id": "uuid",
  "classical_features": {
    "combined_vector": [44.0, 0.86, 4.78, ...],
    "combined_feature_names": ["stat_token_count", "meta_dept_HR", "risk_pii_pan", ...],
    "risk_features": {"total_pii_count": 6, "high_risk_pii_flag": 1, ...},
    "tfidf": {"top_features": {"restricted": 0.48, "payroll": 0.39, ...}}
  },
  "embedding_features": {"vector": [0.041, -0.083, ...], "dimension": 384},
  "recommended_model": "english_classifier_v1",
  "pii_policy_hint": "Quarantine"
}
```

---

## Section 3 — Windows Local Run Guide (No Docker)

### Step 1: Install Python 3.11

Download: https://www.python.org/downloads/release/python-3110/
- Choose: **Windows installer (64-bit)**
- Check: ✅ "Add Python to PATH"

Verify:
```cmd
python --version
```
Expected: `Python 3.11.x`

### Step 2: Install Java 11+

Download: https://adoptium.net/
- Choose: Java 11 LTS, Windows x64 installer
- Install with defaults

Verify:
```cmd
java -version
```
Expected: `openjdk version "11.x.x"`

### Step 3: Install Kafka

1. Download Kafka from: https://kafka.apache.org/downloads
   - Choose: `kafka_2.13-3.7.0.tgz`
2. Extract to `C:\kafka\`
3. Your folder should look like: `C:\kafka\bin\windows\kafka-server-start.bat`

### Step 4: Clone / Extract This Project

Ensure your folder looks like:
```
enterprise_platform\
  ingestion\
  preprocessing\
  feature_engineering\
  shared\
  configs\
  scripts\
  run_all.bat
  stop_all.bat
  README.md
```

Open Command Prompt **as Administrator** in the `enterprise_platform\` folder.

### Step 5: Run First-Time Setup

```cmd
scripts\setup_env.bat
```

This will:
- Create all required directories
- Install `.env` files in each layer
- Create Python virtual environments
- Install all dependencies
- Download NLTK data

### Step 6: Start Kafka

```cmd
scripts\start_kafka.bat
```

Two new windows will open (Zookeeper and Kafka Broker).
Wait until you see `started (kafka.server.KafkaServer)` in the Kafka window.

### Step 7: Create Kafka Topics (first time only)

```cmd
scripts\setup_topics.bat
```

### Step 8: Verify Everything is Ready

```cmd
python shared\health_check.py
```

Should show all green `[OK]` for Kafka, topics, folders, and .env files.

### Step 9: Start All Layers

```cmd
run_all.bat
```

Three windows will open (one per layer). Give them 10 seconds to initialise.

### Step 10: Ingest a Document

**Option A — Copy to uploads folder:**
```cmd
copy sample_data\payroll_report.txt ingestion\uploads\
```

**Option B — Use ingest script:**
```cmd
scripts\ingest_document.bat sample_data\payroll_report.txt HRMS HR
```

Watch the documents flow through all three layer windows.

### Step 11: Monitor Topics (optional)

```cmd
scripts\monitor_topics.bat
```

Or run the live dashboard:
```cmd
python shared\platform_monitor.py
```

---

## Section 4 — Kafka Topics Reference

| Topic | Direction | Partitions | Description |
|---|---|---|---|
| `ingest_requests` | IN → Ingestion | 3 | Kafka-triggered ingest events from source systems |
| `raw_documents` | Ingestion → | 3 | Every parsed document (unfiltered archive) |
| `normalized_documents` | Ingestion → | 3 | All valid docs → Preprocessing reads this |
| `single_entity_docs` | Ingestion → | 3 | Single-entity docs → Preprocessing also reads this |
| `multi_entity_docs` | Ingestion → | 3 | Multi-entity segments → Preprocessing also reads this |
| `audit_logs` | Ingestion → | 1 | Every ingestion attempt with status |
| `retry_queue` | Ingestion ↔ | 1 | Failed docs within retry limit |
| `dead_letter_queue` | Ingestion → | 1 | Failed docs past retry limit |
| `preprocessed_documents` | Preprocessing → | 3 | Clean, masked, tokenised docs → FE reads this |
| `preprocessing_audit_logs` | Preprocessing → | 1 | Every preprocessing attempt |
| `preprocessing_retry_queue` | Preprocessing ↔ | 1 | Failed preprocessing within retry |
| `preprocessing_dead_letter_queue` | Preprocessing → | 1 | Failed preprocessing (exhausted) |
| `engineered_features` | FE → | 3 | ML-ready feature vectors → Classification reads this |
| `feature_audit_logs` | FE → | 1 | Every feature engineering attempt |
| `feature_retry_queue` | FE ↔ | 1 | Failed FE within retry |
| `feature_dead_letter_queue` | FE → | 1 | Failed FE (exhausted) |
| `training_feature_store` | FE → | 3 | Training mode: all features for model training |
| `realtime_feature_store` | FE → | 3 | Inference mode: real-time feature store |

---

## Section 5 — Bugs Found and Fixed

### Bug 1 — `ingestion/config.py`: `consumer_kwargs` signature mismatch
**Problem:** `consumer_kwargs(self, topics: list)` requires a `topics` argument, but preprocessing and feature engineering call `consumer_kwargs()` with no arguments. This causes a `TypeError` if the ingestion consumer ever uses the shared config.
**Fix Applied:** Changed to `consumer_kwargs(self, topics: list = None)` — default parameter makes it compatible.

### Bug 2 — Missing `.env` files
**Problem:** All three layers had only `.env.example` files — not the actual `.env` files that `python-dotenv` reads. Without `.env`, all `os.environ.get()` calls fall back to hardcoded defaults which may be wrong for your setup.
**Fix Applied:** `configs/ingestion.env`, `configs/preprocessing.env`, `configs/feature_engineering.env` created. `scripts/setup_env.bat` copies them automatically.

### Bug 3 — Topic name `TOPIC_AUDIT_LOGS` conflict
**Problem:** Ingestion uses `TOPIC_AUDIT_LOGS=audit_logs`, but if preprocessing tried to use the same env variable it would write to the wrong topic.
**Fix Applied:** Each layer's `.env` uses its own audit topic name (`audit_logs`, `preprocessing_audit_logs`, `feature_audit_logs`). The `configs/platform.env` documents the authoritative registry.

### Bug 4 — Missing required directories
**Problem:** `ingestion/logs/`, `ingestion/uploads/`, `feature_engineering/artifacts/vectorizers/`, etc. don't exist until created. The code calls `os.makedirs(exist_ok=True)` in some places but not all — particularly `ingestion/metadata/` is referenced in `metadata_handler.py` but never auto-created.
**Fix Applied:** `scripts/setup_env.bat` creates all required directories before first run.

### Bug 5 — Feature Engineering TF-IDF cold start
**Problem:** On first run, `tfidf_engine.py` logs a warning and returns empty TF-IDF refs because no vectorizer has been fitted. The `min_df=2` setting means you need at least 2 documents with the same token before any feature appears.
**Fix Applied:** `scripts/setup_env.bat` note added. Use `python app.py --fit-tfidf corpus.txt` before starting the consumer. The `sample_data/` folder serves as a corpus source.

### Bug 6 — `ingestion/consumer.py` passes `topics` list to `consumer_kwargs`
**Problem:** `CONFIG.kafka.consumer_kwargs([CONFIG.topics.ingest_requests])` passes the topics list as a positional argument, but `KafkaConsumer` doesn't accept topics via `consumer_kwargs` — topics are positional args to the `KafkaConsumer` constructor directly.
**Status:** This is architecturally fine — the ingestion consumer passes topics to the `KafkaConsumer(topic, **kwargs)` constructor, not inside kwargs. The fix was making the default `None` so the method is callable both ways.

---

## Section 6 — End-to-End Sample Execution

See `sample_data/end_to_end_payloads.json` for complete JSON at each stage.

**Document:** `payroll_report.txt` (HR payroll with PAN, Aadhaar, salary)

**Layer 1 Output** (normalized_documents):
- `raw_text`: Full extracted text (1842 chars)
- `structure_type`: `"single"` (one payroll = one entity)
- `business_metadata.department`: `"HR"`
- `technical_metadata.checksum_sha256`: SHA-256 of file bytes

**Layer 2 Output** (preprocessed_documents):
- `masked_text`: PAN → `<PAN>`, Aadhaar → `<AADHAAR>`, email → `<EMAIL>`, phone → `<PHONE>`, bank → `<BANK_ACCOUNT>`, DOB → `<DOB>`, emp_id → `<EMPLOYEE_ID>`
- `pii_entities`: `{PAN:1, AADHAAR:1, DOB:1, EMAIL:1, PHONE:1, BANK_ACCOUNT:1, EMPLOYEE_ID:1}`
- `pii_policy_hint`: `"Quarantine"` (high-severity PII found)
- `language.code`: `"en"`
- `tokens`: 44 tokens after lemmatisation
- Processing time: ~48ms

**Layer 3 Output** (engineered_features):
- `classical_features.combined_vector`: 63-dim dense array
- `embedding_features.vector`: 384-dim MiniLM embedding
- `risk_features.total_pii_count`: 6
- `risk_features.high_risk_pii_flag`: 1
- `risk_features.restricted_kw_count`: 4 (restricted, confidential, pci dss, compliance)
- `tfidf.top_features`: `{restricted: 0.48, payroll: 0.39, confidential: 0.41, ...}`
- Expected classification: **RESTRICTED**

---

## Section 7 — Centralised Logging

All logs are written to:
```
logs/
  ingestion_run.log      ← from run_all.bat
  preprocessing_run.log  ← from run_all.bat
  feature_run.log        ← from run_all.bat
  platform.log           ← from shared/platform_logger.py

ingestion/logs/ingestion.log         ← rotating, 10MB × 5
preprocessing/logs/preprocessing.log ← rotating, 10MB × 5
feature_engineering/logs/feature_engineering.log
```

Log format (all layers):
```
2026-04-18 10:30:15 | INFO     | pipeline                       | [DOC-HRMS-001] Pipeline start | source=HRMS | dept=HR | tokens=44
2026-04-18 10:30:15 | INFO     | pii_masker                     | [DOC-HRMS-001] PII masked: total=6 | types={'PAN':1,'AADHAAR':1,...}
2026-04-18 10:30:16 | INFO     | pipeline                       | [DOC-HRMS-001] Pipeline complete | chunks=1 | time=48ms | status=success
```

---

## Section 8 — How to Present to Faculty

### Architecture Explanation
*"We built a 3-layer event-driven pipeline using Apache Kafka as the messaging backbone. Each layer is independently deployable, horizontally scalable, and communicates only through Kafka topics — no direct API calls between layers."*

### Why Kafka?
- **Decoupling**: Each layer runs independently. If preprocessing is slow, ingestion doesn't block.
- **Replay**: Any layer can re-read from the beginning (`auto_offset_reset=earliest`) to reprocess documents after a bug fix.
- **Audit trail**: Every message ever produced is retained — full lineage.
- **Scale**: Add more preprocessing consumers as volume grows — no code changes.
- **Enterprise standard**: Used by LinkedIn, Uber, Netflix, every major bank for exactly this kind of data pipeline.

### Why Multiple Layers?
The PS explicitly calls out this architecture. Each layer has a single responsibility:
- Ingestion: "accept dirty data from any source"
- Preprocessing: "make it clean and safe (PII-masked)"
- Feature Engineering: "make it numerical for ML models"
This separation means: changing the embedding model requires zero changes to ingestion or preprocessing.

### Why Preprocessing Separated from Feature Engineering?
Preprocessing (cleaning, PII masking) must run before ANY storage or logging. Feature Engineering (TF-IDF, embeddings) runs after — and needs fitted models. Separating them means:
1. PII-masked text can be audited independently before ML touches it
2. Feature engineering can be re-run without re-doing PII detection
3. Constraint C1 from PS: "No raw PII stored post-classification — masking mandatory before persistence"

### Enterprise Value
- **Compliance**: Every document gets an audit record with doc_id, timestamp, PII types found, processing status. Required for GDPR/DPDP Act 2023/PCI DSS audits.
- **Security**: PAN, Aadhaar, IBAN are masked before any ML model sees the data.
- **Scalability**: Add Kafka partitions + consumer instances to scale any single layer independently.
- **Explainability**: Feature names are preserved (SHAP-ready) so the Classification Layer can explain why a document was labelled Restricted.

---

## Section 9 — Classification Layer (Next Steps)

### How to Build It

**Consumes from:** `engineered_features` topic

**Input schema fields it needs:**
```python
features["classical_features"]["combined_vector"]       # 63-dim for LR/XGBoost
features["classical_features"]["combined_feature_names"]# SHAP explainability
features["embedding_features"]["vector"]                # 384-dim for BERT head
features["classical_features"]["risk_features"]["high_risk_pii_flag"]  # rule overlay
features["recommended_model"]                           # which model to load
```

**Architecture:**
```
Ensemble:
  Logistic Regression (baseline, interpretable)     → 30% weight
  XGBoost (handles mixed features well)             → 40% weight
  Fine-tuned transformer head on MiniLM embeddings  → 30% weight

Final label = argmax(weighted_average(probabilities))

Policy Engine rule overlay (from PS Section 3):
  IF risk_features.high_risk_pii_flag == 1
  OR risk_features.restricted_kw_count > 0
  → override label to "Restricted" regardless of model score

Output topic: sensitivity_predictions
```

**Training:**
1. Run ingestion + preprocessing + feature engineering on labelled docs
2. Collect `training_feature_store` messages
3. Train: `lr.fit(X_combined, y_labels)`, `xgb.fit(X_combined, y_labels)`
4. Fine-tune transformer on masked_text
5. Evaluate: F1-macro ≥ 0.88, Recall(Restricted) ≥ 0.97 (from PS Section 4)
6. Save models to `classification/artifacts/models/`

**Output schema:**
```json
{
  "doc_id": "...",
  "label": "Restricted",
  "confidence": 0.94,
  "label_probabilities": {"Public": 0.01, "Internal": 0.02, "Confidential": 0.03, "Restricted": 0.94},
  "evidence_tokens": ["restricted", "payroll", "<PAN>", "confidential"],
  "policy_action": "Quarantine",
  "model_used": "ensemble_v1",
  "classified_at": "2026-04-18T10:30:18"
}
```

---

## Project Structure

```
enterprise_platform/
│
├── run_all.bat              ← START everything
├── stop_all.bat             ← STOP everything
├── README.md                ← This file
│
├── ingestion/               ← Ingestion Layer source code
│   ├── .env                 ← (auto-installed by setup_env.bat)
│   ├── main.py              ← Start: python main.py watch
│   ├── uploads/             ← Drop documents here
│   └── logs/
│
├── preprocessing/           ← Preprocessing Layer source code
│   ├── .env
│   ├── app.py               ← Start: python app.py --consumer
│   └── logs/
│
├── feature_engineering/     ← Feature Engineering Layer source code
│   ├── .env
│   ├── app.py               ← Start: python app.py --consumer
│   ├── artifacts/           ← TF-IDF vectorizer, encoders, embeddings
│   └── logs/
│
├── shared/                  ← Cross-layer utilities
│   ├── health_check.py      ← python shared\health_check.py
│   ├── platform_monitor.py  ← python shared\platform_monitor.py
│   └── platform_logger.py
│
├── configs/                 ← Authoritative configuration files
│   ├── platform.env         ← Master topic/config registry
│   ├── ingestion.env        ← Ingestion .env template
│   ├── preprocessing.env    ← Preprocessing .env template
│   └── feature_engineering.env
│
├── scripts/
│   ├── setup_env.bat        ← FIRST-TIME SETUP (run once)
│   ├── start_kafka.bat      ← Start Zookeeper + Kafka
│   ├── stop_kafka.bat       ← Stop Kafka
│   ├── setup_topics.bat     ← Create all 18 Kafka topics
│   ├── monitor_topics.bat   ← Open topic consumer windows
│   └── ingest_document.bat  ← Quick document ingestion
│
├── logs/                    ← Platform-level logs
│
└── sample_data/
    ├── payroll_report.txt         ← Sample HR payroll document
    ├── payroll_report.meta.json   ← Sidecar metadata
    └── end_to_end_payloads.json   ← Complete sample at each stage
```
