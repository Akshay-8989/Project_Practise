@echo off
chcp 65001 >nul 2>&1
REM ============================================================
REM  COMPLIANCE PROJECT — ONE-CLICK SETUP AND RUN
REM  Run this on any Windows laptop to set up and run everything.
REM  No venv needed — this script creates one for you.
REM ============================================================
echo.
echo ============================================================
echo   COMPLIANCE PROJECT - AUTOMATED SETUP AND RUN
echo   PS-01: Automated Data Sensitivity Classification Engine
echo ============================================================
echo.

REM Step 0: Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found. Install Python 3.9+ from python.org first.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do echo [OK] Python %%v found

REM Step 1: Create venv if not exists
if not exist "venv" (
    echo.
    echo [SETUP] Creating virtual environment...
    python -m venv venv
    echo [OK] Virtual environment created
) else (
    echo [OK] Virtual environment exists
)
call venv\Scripts\activate.bat

REM Step 2: Upgrade pip
echo.
echo [SETUP] Upgrading pip...
python -m pip install --upgrade pip --quiet 2>nul
echo [OK] pip upgraded

REM Step 3: Install core dependencies
echo.
echo [SETUP] Installing core ML dependencies...
pip install --quiet scikit-learn==1.4.2 xgboost==2.0.3 numpy==1.26.4 pandas==2.2.2 scipy==1.13.0 joblib==1.4.0 2>nul
pip install --quiet shap==0.45.0 lime==0.2.0.1 2>nul
pip install --quiet pyyaml==6.0.1 regex==2024.4.16 pytest==8.1.1 2>nul
echo [OK] Core dependencies installed

REM Step 4: Install transformer dependencies (CPU-only torch)
echo.
echo [SETUP] Installing PyTorch (CPU) + Transformers...
echo         This may take 5-10 minutes on first run...
pip install --quiet torch --index-url https://download.pytorch.org/whl/cpu 2>nul
pip install --quiet transformers>=4.30.0 sentence-transformers>=2.2.0 2>nul
if %errorlevel% neq 0 (
    echo [WARN] Transformer install may have issues - will try to continue
) else (
    echo [OK] Transformer dependencies installed
)

REM Step 5: Install Kafka dependency
echo.
pip install --quiet kafka-python 2>nul
echo [OK] kafka-python installed

REM Step 6: Generate synthetic data if missing
echo.
echo ============================================================
echo   TRAINING PIPELINE
echo ============================================================
cd classification_module
if not exist "data\synthetic_dataset.csv" (
    echo.
    echo [DATA] Generating synthetic training data (20,000 samples)...
    python -m data.synthetic_generator
    echo [OK] Dataset generated
) else (
    echo [OK] Synthetic dataset already exists
)

REM Step 7: Train ALL models
echo.
echo [TRAIN] Training all models...
echo         Logistic Regression + XGBoost + DistilBERT + Stacker
echo         For both English and Hindi
echo         This takes ~5-20 minutes depending on your CPU...
echo.
python -m scripts.train_all --sample 500
if %errorlevel% neq 0 (
    echo.
    echo [WARN] Training completed with issues - check output above
    echo [WARN] Retrying without transformer...
    python -m scripts.train_all --sample 500 --skip-transformer
)
echo.
echo [OK] Model training complete

REM Step 8: Verify artifacts
echo.
echo ============================================================
echo   ARTIFACT VERIFICATION
echo ============================================================
echo.
set ARTIFACTS_OK=1
for %%L in (en hi) do (
    for %%M in (logistic.joblib xgboost.joblib stacker.joblib) do (
        if exist "artifacts\%%L\%%M" (
            echo   [OK] artifacts\%%L\%%M
        ) else (
            echo   [MISS] artifacts\%%L\%%M
            set ARTIFACTS_OK=0
        )
    )
    if exist "artifacts\%%L\transformer.joblib" (
        echo   [OK] artifacts\%%L\transformer.joblib [DistilBERT]
    ) else (
        echo   [--] artifacts\%%L\transformer.joblib [not trained - torch may be missing]
    )
)

REM Step 9: Run compliance evaluation
echo.
echo ============================================================
echo   COMPLIANCE EVALUATION (16 checks)
echo ============================================================
echo.
python -m scripts.evaluate_compliance --sample 200

REM Step 10: Run demo
echo.
echo ============================================================
echo   DEMO - FULL CLASSIFICATION PIPELINE
echo ============================================================
echo.
python demo.py

REM Step 11: Run tests
echo.
echo ============================================================
echo   RUNNING TESTS
echo ============================================================
echo.
python -m pytest tests/ -v --tb=short 2>nul

REM Done
cd ..
echo.
echo ============================================================
echo   SETUP COMPLETE - PROJECT IS READY
echo ============================================================
echo.
echo   Commands you can run:
echo     venv\Scripts\activate
echo     cd classification_module
echo     python demo.py                              Run demo
echo     python -m scripts.evaluate_compliance       Compliance checks
echo     python -m scripts.benchmark_latency         Latency benchmark
echo     python -m pytest tests/ -v                  Run tests
echo     python -m scripts.train_all                 Retrain models
echo.
echo   Kafka (requires Kafka installed separately):
echo     cd enterprise_platform
echo     run_all_with_classification.bat              Start full pipeline
echo.
pause
