# Ingestion Layer — Data Sensitivity Classification System
### Final Year Project | Python | Local Machine | No Docker

---

## What This Layer Does

Accepts documents from multiple sources + incoming metadata signals,
parses them, detects their structure (single vs multi entity), validates
schema, normalises metadata, and streams clean payloads to Kafka.

**No classification happens here.** Labels (Public / Internal / Confidential / Restricted)
are assigned by the ML Classification Layer built later.

---

## Full Pipeline

```
Source Systems (HRMS / CRM / ERP / Email / Manual Upload)
  + Incoming Metadata Signals (source_system, author, department, etc.)
            │
            ▼
    [1] File Type Detection
    (extension check, size check)
            │
            ▼
    [2] Text Extraction
    pdfplumber (PDF) | python-docx (DOCX) | pandas (CSV)
    stdlib (TXT/JSON/EML) | recursive (ZIP)
            │
            ▼
    [3] Metadata Load + Validate + Normalise
    inline dict | paired JSON file | defaults
            │
            ▼
    [4] Single vs Multi Entity Detection
    (rule-based: email headers, separators, entity blocks)
            │
       ┌────┴────┐
    SINGLE     MULTI
       │      (split N segments)
       └────┬────┘
            │
    [5] Schema Validation
    (required fields, type checks, text length)
            │
    [6] Kafka Publish
            │
    ┌───────┼────────────┬──────────────┐
    │       │            │              │
 single  multi_entity  raw_documents  audit_logs
 _docs   _docs
    │       │
  (fails go to dead_letter_queue)
```

---

## Kafka Topics

| Topic | Content |
|---|---|
| `single_entity_docs` | One logical document (contract, report, invoice) → ONE classification later |
| `multi_entity_docs` | One segment from a composite doc → its OWN classification later |
| `raw_documents` | All documents (full history, unfiltered) |
| `audit_logs` | Every file: status, structure type, segment count, metadata, timestamp |
| `dead_letter_queue` | Files that failed: parse error, schema violation, unsupported format |

### Why single vs multi?

A financial report is **SINGLE** → one classification.

An email thread has N emails — each is a separate entity with potentially
different sensitivity. They must each be classified independently.
A Public cover email attached to a Restricted HR record cannot get a single label.

**Final label for MULTI document** (assigned later by Classification Layer):
`max severity( all segment labels )`
where: `Public < Internal < Confidential < Restricted`

---

## Metadata as INPUT

Metadata is received FROM the source system, NOT generated here.
Example metadata JSON:

```json
{
  "source_system": "HRMS",
  "file_type": "pdf",
  "author": "Finance Team",
  "department": "Finance",
  "creation_date": "2026-04-18",
  "region": "India",
  "business_unit": "Financial Services",
  "client_name": "Acme Corp",
  "source_channel": "direct_upload"
}
```

Ingestion layer only: validates required fields, normalises formats (dates, enums).

---

## Project Structure

```
ingestion_project/
├── main.py                  ← CLI entry point
├── app.py                   ← Pipeline orchestrator
├── config.py                ← All settings
├── parser.py                ← Text extraction (PDF/DOCX/TXT/CSV/JSON/EML/ZIP)
├── splitter.py              ← Single vs Multi detection + splitting
├── validator.py             ← Schema validation
├── metadata_handler.py      ← Metadata load + validate + normalise
├── producer.py              ← Kafka producer wrapper
├── logger.py                ← Rotating file + console logger
├── requirements.txt
├── uploads/                 ← Drop files here
├── metadata/                ← Paired metadata JSON files go here
├── logs/                    ← ingestion.log written here
├── sample_docs/             ← Example documents to test with
└── sample_metadata/         ← Example metadata JSON files
```

---

## Windows — Kafka Setup (No Docker)

### Step 1: Install Java
Kafka requires Java 11+.
Download from: https://adoptium.net/
Verify: `java -version`

### Step 2: Download Kafka
Download Kafka binary from: https://kafka.apache.org/downloads
Choose: `kafka_2.13-3.7.0.tgz`

Extract to: `C:\kafka\`

Your folder should look like:
```
C:\kafka\
  bin\
  config\
  libs\
  logs\
```

### Step 3: Start Zookeeper
Open a new Command Prompt window:
```
cd C:\kafka
.\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties
```
Leave this window open.

### Step 4: Start Kafka Broker
Open another new Command Prompt window:
```
cd C:\kafka
.\bin\windows\kafka-server-start.bat .\config\server.properties
```
Leave this window open.

### Step 5: Create Topics
Open a third Command Prompt window:
```
cd C:\kafka

.\bin\windows\kafka-topics.bat --create --topic raw_documents --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic single_entity_docs --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic multi_entity_docs --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic audit_logs --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic dead_letter_queue --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
```

Verify topics created:
```
.\bin\windows\kafka-topics.bat --list --bootstrap-server localhost:9092
```

### Step 6: Install Python Dependencies
```
pip install -r requirements.txt
```

---

## How to Run

### Batch — Process all files in uploads/
```
python main.py
```

### Single file
```
python main.py --file uploads/contract.pdf
```

### Single file with metadata
```
python main.py --file uploads/report.pdf --source ERP --department Finance --author "Priya Nair"
```

### Single file with full metadata JSON
```
python main.py --file uploads/quarterly_report.txt --meta metadata/quarterly_report.json
```

### Live folder watcher (processes new files as they appear)
```
python main.py --watch
python main.py --watch --interval 3   # check every 3 seconds
```

### Specific folder
```
python main.py --folder C:\docs\hr_batch --source HRMS
```

### Debug mode
```
python main.py --log-level DEBUG
```

---

## Sample Metadata JSON Files

Place these in the `metadata/` folder, named to match the document:
- `metadata/report.json` pairs with `uploads/report.pdf`
- `metadata/contract.json` pairs with `uploads/contract.docx`

Example (`metadata/hr_record.json`):
```json
{
  "source_system": "HRMS",
  "file_type": "pdf",
  "author": "Anita Rao",
  "department": "HR",
  "creation_date": "2026-04-15",
  "region": "India",
  "business_unit": "People Operations",
  "client_name": "Internal",
  "source_channel": "hrms_export"
}
```

---

## Kafka Payload Schema (what every message looks like)

```json
{
  "doc_id": "uuid",
  "ingest_id": "uuid",
  "parent_doc_id": null,
  "file_name": "contract.pdf",
  "raw_text": "extracted text content...",
  "char_count": 4521,
  "word_count": 812,
  "metadata": {
    "source_system": "ERP",
    "file_type": "pdf",
    "author": "Legal Team",
    "department": "Legal",
    "creation_date": "2026-04-18",
    "region": "India",
    "business_unit": "Contracts",
    "client_name": "Acme Corp",
    "source_channel": "direct_upload",
    "upload_timestamp": "2026-04-18T10:30:00",
    "metadata_complete": true,
    "metadata_issues": []
  },
  "structure_type": "single",
  "segment_index": null,
  "total_segments": null,
  "segment_type": "full_document",
  "structure_signals": [],
  "parser_used": "pdfplumber",
  "parse_warnings": [],
  "ingest_timestamp": "2026-04-18T10:30:15.123456",
  "ingestion_version": "1.0.0"
}
```

---

## Verify Messages in Kafka (Optional)

Read from a topic in terminal:
```
cd C:\kafka
.\bin\windows\kafka-console-consumer.bat --topic single_entity_docs --from-beginning --bootstrap-server localhost:9092
```

---

## Future Upgrade Path to Classification Layer

When you build the ML Classification Layer, it will:

1. **Consume** from `single_entity_docs` and `multi_entity_docs`
2. **Pre-process** raw_text: PII masking (Presidio), tokenisation, language detection
3. **Feature engineer**: TF-IDF + BERT/RoBERTa/DeBERTa embeddings
4. **Classify**: Ensemble (Logistic Regression + XGBoost + fine-tuned transformer)
5. **Explainability**: SHAP / LIME evidence tokens per prediction
6. **Policy Engine**: Rule overlay — if Restricted token detected, override to Restricted regardless of model score
7. **Output**: Publish to `classified_documents` topic with label + confidence + evidence + action
8. **Audit**: Timestamped classification record for compliance trail

The ingestion payload already includes all signals the Classification Layer needs:
- `raw_text` — content to classify
- `metadata.department` — source signal
- `metadata.source_system` — source signal
- `structure_type` — single vs multi
- `segment_type` — email vs contract vs invoice etc.

No changes needed to the ingestion layer when you add classification.

---

## Constraints Implemented

| Constraint | Status |
|---|---|
| No Docker | ✅ Pure local Kafka binary + Python |
| No classification | ✅ Zero ML code in this layer |
| Modular code | ✅ One file per concern |
| Windows compatible | ✅ No Unix-only dependencies |
| Metadata as input | ✅ Loaded from caller / paired JSON |
| Dead Letter Queue | ✅ All failures routed to DLQ |
| Audit logging | ✅ Every file gets an audit entry |
| Multiple file types | ✅ PDF, DOCX, TXT, CSV, JSON, EML, ZIP |
