"""
local_producer.py
==================
Drop-in replacement for IngestionProducer when Kafka is not available.

In LOCAL mode (no Kafka broker running), messages are written to
  logs/local_queue/<topic>/<timestamp>.json
instead of being sent to Kafka. This lets the full pipeline run in
PyCharm without Docker / Kafka.

Usage (automatic — handled by producer.py):
    Set LOCAL_MODE=true in your environment, OR
    Let the producer auto-detect Kafka unavailability.
"""

import json
import os
import time
from typing import Any


def _serialise(obj: Any) -> str:
    return json.dumps(obj, default=str, ensure_ascii=False, indent=2)


class LocalModeProducer:
    """
    Writes messages to logs/local_queue/<topic>/ as JSON files.
    Fully mimics the IngestionProducer interface.
    """

    def __init__(self, queue_dir: str = "logs/local_queue"):
        self._queue_dir = queue_dir
        os.makedirs(queue_dir, exist_ok=True)
        print(f"[LocalModeProducer] LOCAL MODE — writing to {queue_dir}/")

    def _write(self, topic: str, key: str | None, data: dict):
        topic_dir = os.path.join(self._queue_dir, topic)
        os.makedirs(topic_dir, exist_ok=True)
        ts = int(time.time() * 1000)
        safe_key = (key or "nokey").replace("/", "_").replace("\\", "_")[:40]
        fname = os.path.join(topic_dir, f"{ts}_{safe_key}.json")
        with open(fname, "w", encoding="utf-8") as f:
            f.write(_serialise(data))

    def send_single(self, payload: dict):
        self._write("single_entity_docs", payload.get("doc_id"), payload)

    def send_multi(self, payload: dict):
        self._write("multi_entity_docs", payload.get("doc_id"), payload)

    def send_raw(self, payload: dict):
        self._write("raw_documents", payload.get("doc_id"), payload)

    def send_audit(self, entry: dict):
        self._write("audit_logs", entry.get("ingest_id"), entry)

    def send_dlq(self, record: dict):
        self._write("dead_letter_queue", record.get("file_name", "unknown"), record)

    def flush(self, timeout: int = 30):
        pass  # nothing to flush in local mode

    def close(self):
        print(f"[LocalModeProducer] Closed. Queue: {self._queue_dir}/")

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
