"""
splitter.py
============
Single-entity vs Multi-entity detection and document splitting.

SINGLE entity — one logical document → one classification later
  Examples: financial report, contract, salary slip, invoice, HR form

MULTI entity — contains N logical sub-documents → each gets its own classification
  Examples: email thread, multiple customer forms, HR bundle, log dump, contract packet

Detection is purely rule-based heuristics — no ML used here.
Speed is important: this runs inside the ingestion pipeline synchronously.

After detection, MULTI documents are split into segments.
Each segment becomes its own Kafka payload.

Final sensitivity label for a MULTI document (assigned later by Classification Layer):
  max severity across all segment labels
  ( Public < Internal < Confidential < Restricted )
"""

import re
from dataclasses import dataclass, field
from typing import List, Tuple

import config
from logger import get_logger

log = get_logger("splitter")


# ─────────────────────────────────────────────────────────────────────────────
# Compiled patterns
# ─────────────────────────────────────────────────────────────────────────────

# Email header block (From / To / Subject / Date at line start)
_EMAIL_HDR = re.compile(
    r"(?:^|\n)(?:From|Date|To|Subject)\s*:.+",
    re.IGNORECASE,
)

# Forwarded / reply dividers
_FWD_SEP = re.compile(
    r"(?:^|\n)-{3,}.*?(?:Forwarded|Original Message|Begin forwarded).*?-{3,}",
    re.IGNORECASE,
)

# Horizontal separator bars (=====, -----, _____)
_BAR_SEP = re.compile(r"(?:^|\n)(?:={5,}|-{5,}|_{5,}|\*{5,})")

# Repeated entity record headers (HR / CRM bundles)
_ENTITY_BLOCK = re.compile(
    r"(?:^|\n)(?:Employee|Staff|Client|Customer|Record|Account|Case|Entry)"
    r"\s*(?:ID|No|#|Number|Ref)?\s*[:\-#]\s*\S+",
    re.IGNORECASE,
)

# Dense timestamped log lines
_LOG_LINE = re.compile(r"(?:^|\n)\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")

# Form-feed / explicit page-break markers
_PAGE_BREAK = re.compile(r"\f|---\s*[Pp]age\s+\d+\s*---")

# Contract exhibits / schedules / appendices
_EXHIBIT = re.compile(
    r"(?:^|\n)(?:Exhibit|Schedule|Annex|Appendix|Attachment)\s+[A-Z0-9]+",
    re.IGNORECASE,
)


# ─────────────────────────────────────────────────────────────────────────────
# Result dataclasses
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Segment:
    """One logical sub-document extracted from a MULTI entity document."""
    segment_id:    int
    text:          str
    segment_type:  str = "general_segment"   # informational label
    char_start:    int = 0
    char_end:      int = 0
    word_count:    int = 0

    def __post_init__(self):
        self.word_count = len(self.text.split())


@dataclass
class StructureResult:
    """Returned by detect_structure() for every document."""
    structure_type: str                      # "single" or "multi"
    segments:       List[Segment]            = field(default_factory=list)
    signals:        List[str]               = field(default_factory=list)

    @property
    def segment_count(self) -> int:
        return len(self.segments)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def detect_structure(
    text:      str,
    source:    str = "",
    file_type: str = "",
) -> StructureResult:
    """
    Analyse text and decide: SINGLE entity or MULTI entity.

    Returns a StructureResult with:
      - structure_type: "single" or "multi"
      - segments:       list of Segment objects (always at least 1)
      - signals:        human-readable list of why MULTI was decided
    """
    signals:         List[str] = []
    split_positions: List[int] = []

    # ── Signal 1: Email header blocks ─────────────────────────────────────
    email_blocks = list(_EMAIL_HDR.finditer(text))
    if len(email_blocks) >= config.EMAIL_HEADER_THRESHOLD:
        signals.append(f"email_headers_found:{len(email_blocks)}")
        for m in email_blocks[1:]:   # first = current message; rest = thread
            split_positions.append(m.start())

    # ── Signal 2: Forwarded / reply separators ────────────────────────────
    fwd_matches = list(_FWD_SEP.finditer(text))
    if fwd_matches:
        signals.append(f"forwarded_separators:{len(fwd_matches)}")
        for m in fwd_matches:
            split_positions.append(m.start())

    # ── Signal 3: Horizontal separator bars ───────────────────────────────
    bar_matches = list(_BAR_SEP.finditer(text))
    if len(bar_matches) >= 2:
        signals.append(f"separator_bars:{len(bar_matches)}")
        for m in bar_matches:
            split_positions.append(m.start())

    # ── Signal 4: Entity record headers ───────────────────────────────────
    entity_matches = list(_ENTITY_BLOCK.finditer(text))
    if len(entity_matches) >= config.ENTITY_BLOCK_THRESHOLD:
        signals.append(f"entity_blocks:{len(entity_matches)}")
        for m in entity_matches:
            split_positions.append(m.start())

    # ── Signal 5: Dense log entries (>5 timestamps) ───────────────────────
    log_lines = list(_LOG_LINE.finditer(text))
    if len(log_lines) > 5:
        signals.append(f"log_entries:{len(log_lines)}")
        for m in log_lines[5::5]:   # new segment every 5 log lines
            split_positions.append(m.start())

    # ── Signal 6: Page-break markers ──────────────────────────────────────
    pb_matches = list(_PAGE_BREAK.finditer(text))
    if len(pb_matches) >= 2:
        signals.append(f"page_breaks:{len(pb_matches)}")
        for m in pb_matches:
            split_positions.append(m.start())

    # ── Signal 7: Contract exhibit / schedule headers ─────────────────────
    exhibit_matches = list(_EXHIBIT.finditer(text))
    if len(exhibit_matches) >= 2:
        signals.append(f"contract_exhibits:{len(exhibit_matches)}")
        for m in exhibit_matches:
            split_positions.append(m.start())

    # ── Decision ──────────────────────────────────────────────────────────
    if not signals:
        return _as_single(text)

    segments = _build_segments(text, split_positions)

    if len(segments) < 2:
        # Signals fired but splitting yielded only 1 valid chunk → treat as single
        return _as_single(text, signals)

    log.info(
        "MULTI detected: %d segments | signals: %s",
        len(segments), signals,
    )
    return StructureResult(
        structure_type="multi",
        segments=segments,
        signals=signals,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _as_single(text: str, signals: List[str] = None) -> StructureResult:
    return StructureResult(
        structure_type="single",
        segments=[Segment(
            segment_id=0,
            text=text,
            segment_type="full_document",
            char_start=0,
            char_end=len(text),
        )],
        signals=signals or [],
    )


def _build_segments(text: str, raw_positions: List[int]) -> List[Segment]:
    """
    Convert raw split positions into clean non-overlapping Segments.
    Filters out tiny fragments below MIN_SEGMENT_CHARS.
    """
    boundaries = sorted(set([0] + raw_positions + [len(text)]))
    segments   = []
    idx        = 0

    for i in range(len(boundaries) - 1):
        start = boundaries[i]
        end   = boundaries[i + 1]
        chunk = text[start:end].strip()

        if len(chunk) < config.MIN_SEGMENT_CHARS:
            continue

        segments.append(Segment(
            segment_id   = idx,
            text         = chunk,
            segment_type = _infer_type(chunk),
            char_start   = start,
            char_end     = end,
        ))
        idx += 1

    return segments


def _infer_type(chunk: str) -> str:
    """
    Lightweight heuristic label for a segment (informational only).
    Not used for classification — just helps humans reading audit logs.
    """
    lower = chunk.lower()
    if re.search(r"^from\s*:", lower, re.MULTILINE):
        return "email_message"
    if re.search(r"employee|emp_id|staff_id", lower):
        return "employee_record"
    if re.search(r"client|customer|account_no|account number", lower):
        return "customer_record"
    if re.search(r"\d{4}-\d{2}-\d{2}[t ]\d{2}:\d{2}", lower):
        return "log_entry_block"
    if re.search(r"exhibit|schedule|annex|appendix", lower):
        return "contract_exhibit"
    if re.search(r"invoice|total|amount due|bill to", lower):
        return "invoice"
    if re.search(r"salary|payslip|payroll|compensation", lower):
        return "salary_record"
    return "general_segment"
