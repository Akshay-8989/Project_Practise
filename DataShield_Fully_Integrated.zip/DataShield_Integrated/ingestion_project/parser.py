"""
parser.py
==========
Text extraction layer.

Supported formats and their parsers:
  PDF   → pdfplumber (primary), PyMuPDF (fallback), Apache Tika (exotic)
  DOCX  → python-docx
  TXT   → native Python (handles multiple encodings)
  CSV   → pandas
  JSON  → json stdlib
  EML   → email stdlib (handles headers + body + inline text)
  ZIP   → recursive: each inner file is parsed independently
  MSG   → fallback via Tika or basic extraction

Returns a ParseResult per file (or list of ParseResult for ZIP).
"""

import csv
import email
import json
import os
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Union

import config
from logger import get_logger

log = get_logger("parser")


# ─────────────────────────────────────────────────────────────────────────────
# Result dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ParseResult:
    """Holds extracted text and parse metadata for one file."""
    file_name:      str
    file_type:      str
    raw_text:       str
    page_count:     Optional[int]  = None
    parser_used:    str            = "unknown"
    warnings:       List[str]      = field(default_factory=list)
    success:        bool           = True
    error:          Optional[str]  = None


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def parse_file(
    file_path: str,
    file_name: Optional[str] = None,
) -> Union[ParseResult, List[ParseResult]]:
    """
    Main dispatcher. Routes to the correct parser based on extension.

    Returns:
      ParseResult         for single-file formats
      List[ParseResult]   for ZIP (one result per inner file)
    """
    fname = file_name or os.path.basename(file_path)
    ext   = Path(fname).suffix.lower().lstrip(".")

    log.debug("Parsing %s (type=%s)", fname, ext)

    try:
        if ext == "pdf":
            return _parse_pdf(file_path, fname)
        elif ext == "docx":
            return _parse_docx(file_path, fname)
        elif ext in ("txt", "text"):
            return _parse_txt(file_path, fname)
        elif ext == "csv":
            return _parse_csv(file_path, fname)
        elif ext == "json":
            return _parse_json(file_path, fname)
        elif ext in ("eml", "msg"):
            return _parse_eml(file_path, fname)
        elif ext == "zip":
            return _parse_zip(file_path, fname)
        elif config.TIKA_ENABLED:
            log.info("Using Apache Tika fallback for %s", fname)
            return _parse_tika(file_path, fname)
        else:
            return ParseResult(
                file_name=fname, file_type=ext, raw_text="",
                success=False, error=f"Unsupported file type: .{ext}",
            )
    except Exception as exc:
        log.error("Unexpected parse error for %s: %s", fname, exc, exc_info=True)
        return ParseResult(
            file_name=fname, file_type=ext, raw_text="",
            success=False, error=str(exc),
        )


# ─────────────────────────────────────────────────────────────────────────────
# PDF
# ─────────────────────────────────────────────────────────────────────────────

def _parse_pdf(file_path: str, fname: str) -> ParseResult:
    warnings = []

    # Primary: pdfplumber
    try:
        import pdfplumber
        pages_text = []
        page_count = 0
        with pdfplumber.open(file_path) as pdf:
            page_count = len(pdf.pages)
            for i, page in enumerate(pdf.pages):
                try:
                    t = page.extract_text()
                    if t:
                        pages_text.append(t)
                    else:
                        warnings.append(f"Page {i+1}: no text extracted (may be image-only)")
                except Exception as pe:
                    warnings.append(f"Page {i+1} error: {pe}")

        raw_text = "\n".join(pages_text)
        if not raw_text.strip():
            warnings.append("PDF returned no text — may require OCR")

        return ParseResult(
            file_name=fname, file_type="pdf",
            raw_text=_clean(raw_text), page_count=page_count,
            parser_used="pdfplumber", warnings=warnings,
        )

    except ImportError:
        log.warning("pdfplumber not installed, trying PyMuPDF")

    # Fallback: PyMuPDF (fitz)
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(file_path)
        pages_text = [page.get_text() for page in doc]
        page_count = len(pages_text)
        raw_text = "\n".join(pages_text)
        return ParseResult(
            file_name=fname, file_type="pdf",
            raw_text=_clean(raw_text), page_count=page_count,
            parser_used="pymupdf", warnings=warnings,
        )
    except ImportError:
        pass

    # Last resort: Tika
    if config.TIKA_ENABLED:
        return _parse_tika(file_path, fname)

    return ParseResult(
        file_name=fname, file_type="pdf", raw_text="",
        success=False,
        error="No PDF parser available. Install pdfplumber: pip install pdfplumber",
    )


# ─────────────────────────────────────────────────────────────────────────────
# DOCX
# ─────────────────────────────────────────────────────────────────────────────

def _parse_docx(file_path: str, fname: str) -> ParseResult:
    try:
        from docx import Document
    except ImportError:
        return ParseResult(
            file_name=fname, file_type="docx", raw_text="", success=False,
            error="python-docx not installed. Run: pip install python-docx",
        )

    warnings = []
    try:
        doc = Document(file_path)
        parts = []

        # Paragraphs
        for para in doc.paragraphs:
            if para.text.strip():
                parts.append(para.text)

        # Tables (important for contracts, HR forms, financial reports)
        for table in doc.tables:
            for row in table.rows:
                row_cells = [c.text.strip() for c in row.cells if c.text.strip()]
                if row_cells:
                    parts.append(" | ".join(row_cells))

        raw_text = "\n".join(parts)
        if not raw_text.strip():
            warnings.append("DOCX body appears empty")

        return ParseResult(
            file_name=fname, file_type="docx",
            raw_text=_clean(raw_text),
            parser_used="python-docx", warnings=warnings,
        )
    except Exception as exc:
        return ParseResult(
            file_name=fname, file_type="docx", raw_text="",
            success=False, error=f"DOCX parse failed: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# TXT
# ─────────────────────────────────────────────────────────────────────────────

def _parse_txt(file_path: str, fname: str) -> ParseResult:
    for encoding in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
        try:
            with open(file_path, "r", encoding=encoding) as f:
                raw_text = f.read()
            return ParseResult(
                file_name=fname, file_type="txt",
                raw_text=_clean(raw_text),
                parser_used=f"native_txt ({encoding})",
            )
        except (UnicodeDecodeError, LookupError):
            continue

    return ParseResult(
        file_name=fname, file_type="txt", raw_text="",
        success=False, error="Could not decode TXT file with any supported encoding",
    )


# ─────────────────────────────────────────────────────────────────────────────
# CSV
# ─────────────────────────────────────────────────────────────────────────────

def _parse_csv(file_path: str, fname: str) -> ParseResult:
    warnings = []
    try:
        import pandas as pd
        df = pd.read_csv(file_path, encoding="utf-8", on_bad_lines="warn")

        # Represent as text: header + each row as pipe-separated values
        header = " | ".join(str(c) for c in df.columns)
        rows   = df.astype(str).apply(lambda r: " | ".join(r.values), axis=1).tolist()

        if len(rows) > 10_000:
            warnings.append(f"CSV has {len(rows)} rows — consider chunking")

        raw_text = header + "\n" + "\n".join(rows)
        return ParseResult(
            file_name=fname, file_type="csv",
            raw_text=_clean(raw_text),
            parser_used="pandas", warnings=warnings,
        )
    except ImportError:
        # Fallback to stdlib csv
        rows = []
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f)
            for row in reader:
                rows.append(" | ".join(c.strip() for c in row if c.strip()))
        return ParseResult(
            file_name=fname, file_type="csv",
            raw_text=_clean("\n".join(rows)),
            parser_used="stdlib_csv",
        )
    except Exception as exc:
        return ParseResult(
            file_name=fname, file_type="csv", raw_text="",
            success=False, error=f"CSV parse failed: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# JSON
# ─────────────────────────────────────────────────────────────────────────────

def _parse_json(file_path: str, fname: str) -> ParseResult:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Pretty-print JSON as text so it can be tokenised downstream
        raw_text = json.dumps(data, indent=2, ensure_ascii=False)
        return ParseResult(
            file_name=fname, file_type="json",
            raw_text=raw_text,
            parser_used="stdlib_json",
        )
    except Exception as exc:
        return ParseResult(
            file_name=fname, file_type="json", raw_text="",
            success=False, error=f"JSON parse failed: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# EML / Email
# ─────────────────────────────────────────────────────────────────────────────

def _parse_eml(file_path: str, fname: str) -> ParseResult:
    import re as _re
    warnings = []
    parts = []

    try:
        with open(file_path, "rb") as f:
            msg = email.message_from_bytes(f.read())
    except Exception as exc:
        return ParseResult(
            file_name=fname, file_type="eml", raw_text="",
            success=False, error=f"EML parse failed: {exc}",
        )

    # Extract important headers
    for header in ("From", "To", "CC", "Subject", "Date"):
        val = msg.get(header)
        if val:
            parts.append(f"{header}: {val}")
    parts.append("")  # blank separator

    # Extract body
    if msg.is_multipart():
        for part in msg.walk():
            ct   = part.get_content_type()
            disp = str(part.get("Content-Disposition", ""))
            if "attachment" in disp:
                warnings.append(f"Skipped attachment: {part.get_filename()}")
                continue
            if ct in ("text/plain", "text/html"):
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    text = payload.decode(charset, errors="replace")
                    if ct == "text/html":
                        text = _re.sub(r"<[^>]+>", " ", text)
                    parts.append(text)
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            parts.append(payload.decode(charset, errors="replace"))

    return ParseResult(
        file_name=fname, file_type="eml",
        raw_text=_clean("\n".join(parts)),
        parser_used="stdlib_email", warnings=warnings,
    )


# ─────────────────────────────────────────────────────────────────────────────
# ZIP (recursive)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_zip(file_path: str, fname: str) -> List[ParseResult]:
    """Each file inside the ZIP is parsed independently → list of ParseResult."""
    results = []
    try:
        with zipfile.ZipFile(file_path, "r") as zf:
            for inner_name in zf.namelist():
                if inner_name.endswith("/"):
                    continue   # skip directories
                try:
                    tmp_path = os.path.join(
                        os.path.dirname(file_path),
                        f"_tmp_{os.path.basename(inner_name)}",
                    )
                    with zf.open(inner_name) as src, open(tmp_path, "wb") as dst:
                        dst.write(src.read())

                    result = parse_file(tmp_path, file_name=inner_name)
                    if isinstance(result, list):
                        results.extend(result)
                    else:
                        results.append(result)

                    os.remove(tmp_path)
                except Exception as inner_exc:
                    log.warning("ZIP inner file %s failed: %s", inner_name, inner_exc)
    except zipfile.BadZipFile as exc:
        return [ParseResult(
            file_name=fname, file_type="zip", raw_text="",
            success=False, error=f"Bad ZIP: {exc}",
        )]

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Apache Tika (optional fallback)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_tika(file_path: str, fname: str) -> ParseResult:
    """
    Requires a running Tika server:
      java -jar tika-server-standard-x.x.jar --port 9998
    """
    try:
        import requests
        with open(file_path, "rb") as f:
            resp = requests.put(
                f"{config.TIKA_SERVER_URL}/tika",
                data=f,
                headers={"Accept": "text/plain"},
                timeout=30,
            )
        if resp.status_code == 200:
            ext = Path(fname).suffix.lower().lstrip(".")
            return ParseResult(
                file_name=fname, file_type=ext,
                raw_text=_clean(resp.text),
                parser_used="apache_tika",
            )
        return ParseResult(
            file_name=fname, file_type="unknown", raw_text="",
            success=False, error=f"Tika returned HTTP {resp.status_code}",
        )
    except Exception as exc:
        return ParseResult(
            file_name=fname, file_type="unknown", raw_text="",
            success=False, error=f"Tika error: {exc}",
        )


# ─────────────────────────────────────────────────────────────────────────────
# Helper
# ─────────────────────────────────────────────────────────────────────────────

def _clean(text: str) -> str:
    """Normalise whitespace without destroying paragraph structure."""
    import re
    text = re.sub(r"[ \t]+", " ", text)       # collapse horizontal whitespace
    text = re.sub(r"\n{4,}", "\n\n\n", text)  # max 3 consecutive blank lines
    return text.strip()
