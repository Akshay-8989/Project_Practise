"""
main.py
========
CLI entry point.

Modes:
  python main.py                         → batch process uploads/ folder
  python main.py --file path/to/doc.pdf  → single file
  python main.py --watch                 → live folder watcher
  python main.py --source HRMS           → set source system
  python main.py --department Finance    → override department metadata
"""

import argparse
import json
import sys

import config
from logger import get_logger
from app import process_file, process_folder, watch_folder

log = get_logger("main")


def main():
    parser = argparse.ArgumentParser(
        description="Data Sensitivity Classification — Ingestion Layer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                                      # batch process uploads/
  python main.py --file uploads/contract.pdf          # single file
  python main.py --watch --interval 3                 # live watcher
  python main.py --source HRMS --department Finance   # with metadata
  python main.py --meta metadata/report.json          # metadata from file
        """,
    )

    # Input
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--file",   type=str, help="Path to a single file to ingest")
    group.add_argument("--folder", type=str, help="Path to folder (default: uploads/)")
    group.add_argument("--watch",  action="store_true", help="Live folder watcher mode")

    # Metadata inputs
    parser.add_argument("--source",       type=str, default="MANUAL_UPLOAD",
                        choices=config.ALLOWED_SOURCE_SYSTEMS,
                        help="Source system (default: MANUAL_UPLOAD)")
    parser.add_argument("--department",   type=str, help="Department override")
    parser.add_argument("--author",       type=str, help="Author override")
    parser.add_argument("--region",       type=str, help="Region (e.g. India, US)")
    parser.add_argument("--business-unit",type=str, help="Business unit")
    parser.add_argument("--meta",         type=str,
                        help="Path to a JSON file with full metadata dict")

    # Options
    parser.add_argument("--interval", type=float, default=5.0,
                        help="Watch mode poll interval in seconds (default: 5)")
    parser.add_argument("--log-level", default=config.LOG_LEVEL,
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])

    args = parser.parse_args()

    # Apply log level
    config.LOG_LEVEL = args.log_level

    # Build inline metadata from CLI args + optional JSON file
    inline_meta = {}

    if args.meta:
        try:
            with open(args.meta, "r", encoding="utf-8") as f:
                inline_meta = json.load(f)
            print(f"Metadata loaded from: {args.meta}")
        except Exception as exc:
            print(f"WARNING: Could not load metadata file {args.meta}: {exc}")

    # CLI flags override JSON file
    if args.source:
        inline_meta["source_system"] = args.source
    if args.department:
        inline_meta["department"] = args.department
    if args.author:
        inline_meta["author"] = args.author
    if args.region:
        inline_meta["region"] = args.region
    if getattr(args, "business_unit", None):
        inline_meta["business_unit"] = args.business_unit

    # ── Run ───────────────────────────────────────────────────────────────

    if args.file:
        print(f"\nIngesting single file: {args.file}")
        result = process_file(
            file_path   = args.file,
            source      = args.source,
            inline_meta = inline_meta or None,
        )
        print(f"\nResult: {result}")
        if not result.success:
            sys.exit(1)

    elif args.watch:
        folder = args.folder or config.UPLOAD_FOLDER
        print(f"\nWatching folder: {folder}  (interval={args.interval}s)")
        watch_folder(folder_path=folder, source=args.source,
                     poll_seconds=args.interval)

    else:
        folder = args.folder or config.UPLOAD_FOLDER
        print(f"\nBatch ingesting folder: {folder}")
        results = process_folder(
            folder_path = folder,
            source      = args.source,
            inline_meta = inline_meta or None,
        )
        ok   = sum(1 for r in results if r.success)
        fail = len(results) - ok
        print(f"\nSummary: {ok} succeeded, {fail} failed out of {len(results)} files")
        if fail:
            sys.exit(1)


if __name__ == "__main__":
    main()
