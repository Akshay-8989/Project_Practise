"""
logger.py
==========
Sets up a single shared logger used across all modules.
Writes to both console and a rotating log file.
"""

import logging
import os
from logging.handlers import RotatingFileHandler

import config


def get_logger(name: str = "ingestion") -> logging.Logger:
    """
    Returns a named logger.
    First call creates and configures it; subsequent calls return the same instance.
    """
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger   # already configured

    logger.setLevel(getattr(logging, config.LOG_LEVEL, logging.INFO))

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # ── Console handler ───────────────────────────────────────────────────
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # ── Rotating file handler ─────────────────────────────────────────────
    os.makedirs(os.path.dirname(config.LOG_FILE), exist_ok=True)
    fh = RotatingFileHandler(
        config.LOG_FILE,
        maxBytes=10 * 1024 * 1024,   # 10 MB per file
        backupCount=5,
        encoding="utf-8",
    )
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    return logger
