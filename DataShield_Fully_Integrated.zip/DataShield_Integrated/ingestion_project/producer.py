"""
producer.py
============
Kafka producer wrapper for the ingestion layer.

AUTO LOCAL-MODE FALLBACK:
  If Kafka is not running (or LOCAL_MODE=true env var is set), the producer
  automatically falls back to writing messages as JSON files in
  logs/local_queue/<topic>/. This lets the full pipeline run in PyCharm
  without Docker or Kafka.

To force Kafka mode: ensure KAFKA_BROKER is reachable and LOCAL_MODE != true.
To force local mode: set LOCAL_MODE=true in your environment or .env file.
"""

import json
import os
from typing import Any

import config
from logger import get_logger
from local_producer import LocalModeProducer

log = get_logger("producer")

# ── Kafka availability check ───────────────────────────────────────────────────
_LOCAL_MODE = os.environ.get("LOCAL_MODE", "false").lower() in ("true", "1", "yes")

try:
    from kafka import KafkaProducer
    from kafka.errors import KafkaError, NoBrokersAvailable
    _KAFKA_LIB_AVAILABLE = True
except ImportError:
    _KAFKA_LIB_AVAILABLE = False
    _LOCAL_MODE = True
    log.warning("kafka-python not installed — switching to LOCAL MODE automatically")


def _serialise(obj: Any) -> bytes:
    return json.dumps(obj, default=str, ensure_ascii=False).encode("utf-8")


class IngestionProducer:
    """
    Wraps KafkaProducer with convenience methods per topic.
    Automatically falls back to LocalModeProducer if Kafka is not available.

    Usage:
        producer = IngestionProducer()
        producer.send_single(payload_dict)
        producer.flush()
        producer.close()

    Or as context manager:
        with IngestionProducer() as p:
            p.send_single(payload)
    """

    def __init__(self):
        self._local: LocalModeProducer | None = None
        self._kafka_producer = None

        if _LOCAL_MODE or not _KAFKA_LIB_AVAILABLE:
            self._local = LocalModeProducer()
            log.info("LOCAL MODE: using file-based queue (no Kafka required)")
            return

        try:
            self._kafka_producer = KafkaProducer(
                bootstrap_servers   = config.KAFKA_BROKER,
                value_serializer    = _serialise,
                key_serializer      = lambda k: k.encode("utf-8") if k else None,
                acks                = config.KAFKA_PRODUCER_CONFIG["acks"],
                retries             = config.KAFKA_PRODUCER_CONFIG["retries"],
                compression_type    = config.KAFKA_PRODUCER_CONFIG["compression_type"],
            )
            log.info("Kafka producer connected to %s", config.KAFKA_BROKER)
        except Exception as exc:
            log.warning(
                "Kafka broker not available at %s (%s) — auto-switching to LOCAL MODE. "
                "Start Kafka or set LOCAL_MODE=true to suppress this warning.",
                config.KAFKA_BROKER, exc,
            )
            self._local = LocalModeProducer()

    # ── Context manager ───────────────────────────────────────────────────

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ── Topic senders ─────────────────────────────────────────────────────

    def send_single(self, payload: dict):
        """Validated single-entity document → single_entity_docs."""
        if self._local:
            self._local.send_single(payload)
        else:
            self._send(config.TOPICS["single"], key=payload.get("doc_id"), data=payload)

    def send_multi(self, payload: dict):
        """One segment of a multi-entity document → multi_entity_docs."""
        if self._local:
            self._local.send_multi(payload)
        else:
            self._send(config.TOPICS["multi"], key=payload.get("doc_id"), data=payload)

    def send_raw(self, payload: dict):
        """All documents also go to raw_documents for full history."""
        if self._local:
            self._local.send_raw(payload)
        else:
            self._send(config.TOPICS["raw"], key=payload.get("doc_id"), data=payload)

    def send_audit(self, entry: dict):
        """Audit record → audit_logs. Key = ingest_id."""
        if self._local:
            self._local.send_audit(entry)
        else:
            self._send(config.TOPICS["audit"], key=entry.get("ingest_id"), data=entry)

    def send_dlq(self, record: dict):
        """Failed records → dead_letter_queue. Key = file_name."""
        if self._local:
            self._local.send_dlq(record)
        else:
            self._send(config.TOPICS["dlq"], key=record.get("file_name", "unknown"), data=record)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def flush(self, timeout: int = 30):
        """Block until all pending messages are delivered."""
        if self._local:
            self._local.flush()
        elif self._kafka_producer:
            self._kafka_producer.flush(timeout=timeout)

    def close(self):
        self.flush()
        if self._local:
            self._local.close()
        elif self._kafka_producer:
            self._kafka_producer.close()
            log.info("Kafka producer closed.")

    # ── Internal ──────────────────────────────────────────────────────────

    def _send(self, topic: str, key: str | None, data: dict):
        try:
            (
                self._kafka_producer
                .send(topic, key=key, value=data)
                .add_callback(self._on_success)
                .add_errback(self._on_error)
            )
        except Exception as exc:
            log.error("Immediate send failure to %s: %s", topic, exc)

    @staticmethod
    def _on_success(meta):
        log.debug(
            "Delivered → topic=%s partition=%d offset=%d",
            meta.topic, meta.partition, meta.offset,
        )

    @staticmethod
    def _on_error(exc):
        log.error("Kafka delivery error: %s", exc)
