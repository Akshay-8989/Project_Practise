"""
config.py
==========
Central configuration for the Ingestion Layer.
All tunable knobs live here — nothing else needs to be touched.
"""

# ─────────────────────────────────────────────────────────────────────────────
# Kafka
# ─────────────────────────────────────────────────────────────────────────────

KAFKA_BROKER = "localhost:9092"

TOPICS = {
    "raw":    "raw_documents",
    "single": "single_entity_docs",
    "multi":  "multi_entity_docs",
    "audit":  "audit_logs",
    "dlq":    "dead_letter_queue",
}

KAFKA_PRODUCER_CONFIG = {
    "acks":             "all",        # wait for all replicas
    "retries":          3,
    "compression_type": "gzip",
}

# ─────────────────────────────────────────────────────────────────────────────
# File handling
# ─────────────────────────────────────────────────────────────────────────────

UPLOAD_FOLDER   = "uploads"
METADATA_FOLDER = "metadata"       # paired metadata JSON files live here
LOG_FOLDER      = "logs"

MAX_FILE_SIZE_MB = 50

SUPPORTED_EXTENSIONS = {
    ".pdf", ".docx", ".txt", ".csv",
    ".json", ".eml", ".msg", ".zip",
}

# ─────────────────────────────────────────────────────────────────────────────
# Metadata validation
# ─────────────────────────────────────────────────────────────────────────────

# Required metadata fields that MUST be present in every payload
REQUIRED_METADATA_FIELDS = [
    "source_system",
    "file_type",
    "author",
    "department",
    "creation_date",
]

# Optional metadata fields — accepted if present, not enforced
OPTIONAL_METADATA_FIELDS = [
    "region",
    "business_unit",
    "client_name",
    "source_channel",
    "upload_timestamp",
    "tags",
]

ALLOWED_DEPARTMENTS = [
    "Finance", "HR", "Legal", "IT",
    "Sales", "Support", "Operations", "Compliance",
]

ALLOWED_SOURCE_SYSTEMS = [
    "HRMS", "CRM", "ERP", "DMS", "EMAIL",
    "MANUAL_UPLOAD", "API", "S3", "DRIVE",
]

ALLOWED_FILE_TYPES = [
    "pdf", "docx", "txt", "csv", "json", "eml", "msg", "zip",
]

# ─────────────────────────────────────────────────────────────────────────────
# Schema validation
# ─────────────────────────────────────────────────────────────────────────────

MIN_TEXT_LENGTH =   10        # chars
MAX_TEXT_LENGTH = 500_000     # chars (~500 KB of text)

# ─────────────────────────────────────────────────────────────────────────────
# Structure detection thresholds
# ─────────────────────────────────────────────────────────────────────────────

# Minimum email-header blocks to flag a document as MULTI
EMAIL_HEADER_THRESHOLD = 2

# Minimum repeated entity blocks (Employee ID, Client No …) to flag MULTI
ENTITY_BLOCK_THRESHOLD = 2

# Minimum chars a split segment must have to be emitted as its own payload
MIN_SEGMENT_CHARS = 80

# ─────────────────────────────────────────────────────────────────────────────
# Apache Tika fallback (optional)
# ─────────────────────────────────────────────────────────────────────────────

TIKA_ENABLED    = False
TIKA_SERVER_URL = "http://localhost:9998"

# ─────────────────────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────────────────────

LOG_LEVEL = "INFO"
LOG_FILE  = "logs/ingestion.log"
