"""
metadata_handler.py
====================
Handles metadata as an INPUT signal from upstream source systems.

Metadata arrives alongside each document (from upload form, API header,
or a paired JSON file in the metadata/ folder).

This module:
  1. Loads metadata from multiple possible sources
  2. Validates required fields are present
  3. Normalises formats (dates, lowercase enums, etc.)
  4. Flags missing / invalid fields without blocking ingestion
     (missing optional fields are filled with "unknown")

IMPORTANT: Metadata is NOT generated here. It comes FROM the source system.
The ingestion layer only validates and normalises what it receives.
"""

import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

import config
from logger import get_logger

log = get_logger("metadata_handler")

# Matches YYYY-MM-DD or DD/MM/YYYY or DD-MM-YYYY
_DATE_PATTERNS = [
    r"^\d{4}-\d{2}-\d{2}$",           # ISO 8601 (preferred)
    r"^\d{2}/\d{2}/\d{4}$",           # DD/MM/YYYY
    r"^\d{2}-\d{2}-\d{4}$",           # DD-MM-YYYY
]


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def load_metadata(
    file_path: str,
    inline_meta: Optional[dict] = None,
) -> dict:
    """
    Load metadata for a document.

    Priority (highest → lowest):
      1. inline_meta   — passed directly by caller (API / programmatic)
      2. Paired JSON   — looks for uploads/doc.pdf → metadata/doc.json
      3. Empty dict    — no metadata provided; will flag missing fields

    Returns a validated, normalised metadata dict.
    """
    raw_meta = {}

    # ── Source 1: inline metadata (from API call / form upload) ──────────
    if inline_meta and isinstance(inline_meta, dict):
        raw_meta = dict(inline_meta)
        log.debug("Metadata loaded from inline input for %s", file_path)

    # ── Source 2: paired JSON file in metadata/ folder ────────────────────
    if not raw_meta:
        paired = _find_paired_metadata(file_path)
        if paired:
            raw_meta = paired
            log.debug("Metadata loaded from paired JSON for %s", file_path)

    if not raw_meta:
        log.warning("No metadata provided for %s — using defaults", file_path)

    # ── Validate and normalise ────────────────────────────────────────────
    return validate_and_normalise(raw_meta, file_path)


def validate_and_normalise(raw_meta: dict, file_path: str = "") -> dict:
    """
    Validate required fields, normalise values, fill missing optionals.
    Returns a clean metadata dict. Never raises — logs warnings instead.
    """
    meta = dict(raw_meta)
    issues = []

    # ── Required fields ───────────────────────────────────────────────────
    for field in config.REQUIRED_METADATA_FIELDS:
        if field not in meta or not meta[field]:
            meta[field] = "unknown"
            issues.append(f"missing required field: '{field}'")

    # ── Optional fields — fill with "unknown" if absent ──────────────────
    for field in config.OPTIONAL_METADATA_FIELDS:
        if field not in meta or not meta[field]:
            meta[field] = "unknown"

    # ── Normalise: source_system ──────────────────────────────────────────
    if meta.get("source_system") != "unknown":
        meta["source_system"] = meta["source_system"].upper().strip()
        if meta["source_system"] not in config.ALLOWED_SOURCE_SYSTEMS:
            log.warning(
                "%s — unknown source_system '%s' (allowed: %s)",
                file_path, meta["source_system"], config.ALLOWED_SOURCE_SYSTEMS,
            )
            # Accept it anyway — don't block ingestion

    # ── Normalise: department ─────────────────────────────────────────────
    if meta.get("department") != "unknown":
        meta["department"] = meta["department"].strip().title()
        if meta["department"] not in config.ALLOWED_DEPARTMENTS:
            log.warning(
                "%s — unknown department '%s' (allowed: %s)",
                file_path, meta["department"], config.ALLOWED_DEPARTMENTS,
            )

    # ── Normalise: file_type (lowercase, strip dot) ───────────────────────
    if meta.get("file_type") != "unknown":
        meta["file_type"] = meta["file_type"].lower().lstrip(".")
        if meta["file_type"] not in config.ALLOWED_FILE_TYPES:
            log.warning(
                "%s — unknown file_type '%s'", file_path, meta["file_type"],
            )

    # ── Normalise: creation_date → ISO 8601 ──────────────────────────────
    raw_date = meta.get("creation_date", "unknown")
    if raw_date != "unknown":
        normalised_date = _normalise_date(raw_date)
        if normalised_date:
            meta["creation_date"] = normalised_date
        else:
            issues.append(f"invalid creation_date format: '{raw_date}'")
            meta["creation_date"] = "unknown"

    # ── Normalise: author (strip extra whitespace) ────────────────────────
    if meta.get("author") != "unknown":
        meta["author"] = " ".join(meta["author"].split())

    # ── Add upload_timestamp if not provided ──────────────────────────────
    if meta.get("upload_timestamp") == "unknown":
        meta["upload_timestamp"] = datetime.utcnow().isoformat()

    # ── Attach validation issues for audit trail ──────────────────────────
    meta["_validation_issues"] = issues
    meta["_metadata_complete"] = len(issues) == 0

    if issues:
        log.warning("%s — metadata issues: %s", file_path, "; ".join(issues))
    else:
        log.debug("%s — metadata validated OK", file_path)

    return meta


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _find_paired_metadata(file_path: str) -> Optional[dict]:
    """
    Look for a JSON metadata file paired with the document.
    Convention: uploads/report.pdf  →  metadata/report.json
    """
    stem = Path(file_path).stem
    candidates = [
        os.path.join(config.METADATA_FOLDER, f"{stem}.json"),
        os.path.join(config.METADATA_FOLDER, f"{stem}.metadata.json"),
    ]
    for candidate in candidates:
        if os.path.isfile(candidate):
            try:
                with open(candidate, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as exc:
                log.error("Failed to read metadata file %s: %s", candidate, exc)
    return None


def _normalise_date(raw: str) -> Optional[str]:
    """Convert various date formats to ISO 8601 (YYYY-MM-DD). Returns None if unparseable."""
    raw = raw.strip()

    # Already ISO 8601
    if re.match(r"^\d{4}-\d{2}-\d{2}$", raw):
        return raw

    # DD/MM/YYYY or DD-MM-YYYY
    m = re.match(r"^(\d{2})[/\-](\d{2})[/\-](\d{4})$", raw)
    if m:
        d, mo, y = m.groups()
        return f"{y}-{mo}-{d}"

    # Try Python's datetime parser as fallback
    for fmt in ("%d %B %Y", "%B %d, %Y", "%d-%b-%Y"):
        try:
            return datetime.strptime(raw, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass

    return None
