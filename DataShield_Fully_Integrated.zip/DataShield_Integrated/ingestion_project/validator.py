"""
validator.py
=============
Schema validation for every payload before it is pushed to Kafka.

The canonical Kafka payload schema (from PS requirements):

{
    "doc_id":           str,          required
    "file_name":        str,          required
    "raw_text":         str,          required, min 10 chars
    "metadata": {
        "source_system": str,         required
        "file_type":     str,         required
        "author":        str,         required
        "department":    str,         required
        "creation_date": str,         required
        ... plus any optional fields
    },
    "structure_type":   str,          "single" | "multi"
    "ingest_timestamp": str           ISO 8601
}

Invalid records are routed to the Dead Letter Queue.
"""

from dataclasses import dataclass
from typing import Optional

import config
from logger import get_logger

log = get_logger("validator")

# Canonical set of required top-level payload keys
_REQUIRED_TOP_LEVEL = ["doc_id", "file_name", "raw_text", "metadata",
                       "structure_type", "ingest_timestamp"]

# Required keys inside the nested metadata object
_REQUIRED_META_KEYS = config.REQUIRED_METADATA_FIELDS   # from config


# ─────────────────────────────────────────────────────────────────────────────
# Result dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ValidationResult:
    success:        bool
    failure_reason: Optional[str] = None
    failure_detail: Optional[str] = None

    @classmethod
    def ok(cls) -> "ValidationResult":
        return cls(success=True)

    @classmethod
    def fail(cls, reason: str, detail: str = "") -> "ValidationResult":
        return cls(success=False, failure_reason=reason, failure_detail=detail)


# ─────────────────────────────────────────────────────────────────────────────
# Validator
# ─────────────────────────────────────────────────────────────────────────────

class PayloadValidator:
    """Validates a Kafka payload dict before it is sent."""

    def validate(self, payload: dict) -> ValidationResult:
        """
        Full validation pipeline.

        Checks (in order):
          1. Top-level required fields present and correct types
          2. Text length bounds
          3. Structure type valid
          4. Metadata block present and required fields populated
          5. doc_id non-empty
          6. ingest_timestamp non-empty
        """

        # ── 1. Top-level fields ───────────────────────────────────────────
        for key in _REQUIRED_TOP_LEVEL:
            if key not in payload:
                return ValidationResult.fail(
                    "MISSING_FIELD", f"Top-level field '{key}' is missing"
                )
            if not isinstance(payload[key], (str, dict)):
                return ValidationResult.fail(
                    "WRONG_TYPE",
                    f"Field '{key}' should be str or dict, got {type(payload[key]).__name__}",
                )

        # ── 2. Text length ────────────────────────────────────────────────
        raw_text = payload.get("raw_text", "").strip()
        if not raw_text:
            return ValidationResult.fail("EMPTY_TEXT", "raw_text is empty after stripping")

        if len(raw_text) < config.MIN_TEXT_LENGTH:
            return ValidationResult.fail(
                "TEXT_TOO_SHORT",
                f"raw_text has {len(raw_text)} chars; minimum is {config.MIN_TEXT_LENGTH}",
            )

        if len(raw_text) > config.MAX_TEXT_LENGTH:
            return ValidationResult.fail(
                "TEXT_TOO_LONG",
                f"raw_text has {len(raw_text)} chars; maximum is {config.MAX_TEXT_LENGTH}",
            )

        # ── 3. structure_type ─────────────────────────────────────────────
        stype = payload.get("structure_type", "")
        if stype not in ("single", "multi"):
            return ValidationResult.fail(
                "INVALID_STRUCTURE_TYPE",
                f"structure_type must be 'single' or 'multi', got '{stype}'",
            )

        # ── 4. Metadata block ─────────────────────────────────────────────
        meta = payload.get("metadata")
        if not isinstance(meta, dict):
            return ValidationResult.fail(
                "INVALID_METADATA", "metadata must be a dict object"
            )

        for key in _REQUIRED_META_KEYS:
            val = meta.get(key, "")
            if not val or (isinstance(val, str) and val.strip() == ""):
                return ValidationResult.fail(
                    "MISSING_METADATA_FIELD",
                    f"metadata.{key} is missing or empty",
                )

        # ── 5. doc_id ─────────────────────────────────────────────────────
        if not payload.get("doc_id", "").strip():
            return ValidationResult.fail("EMPTY_DOC_ID", "doc_id must not be empty")

        # ── 6. ingest_timestamp ───────────────────────────────────────────
        if not payload.get("ingest_timestamp", "").strip():
            return ValidationResult.fail(
                "EMPTY_TIMESTAMP", "ingest_timestamp must not be empty"
            )

        return ValidationResult.ok()


# Module-level singleton
_validator = PayloadValidator()


def validate(payload: dict) -> ValidationResult:
    """Module-level convenience function."""
    return _validator.validate(payload)
