# COMPLIANCE PROJECT — FULL TECHNICAL DOCUMENTATION
## Part 2: File-by-File Code Analysis

---

## FILE 1: `classification_module/pipeline.py`
**Role:** The central orchestrator. Every classification call goes through here.

### Line-by-line Explanation

```python
# Lines 1-40: Module docstring
# Explains language routing: detect → route → dispatch → policy → explainability
# Why separate models per language:
#   TF-IDF on Hindi Devanagari script vs English Latin are different vocabularies
#   One multilingual TF-IDF model wastes features on zero-valued cross-script cells
```

```python
# Lines 41-70: Imports
import numpy as np   # all probability arrays are numpy — fast vectorized ops
import yaml          # config-driven design, no hardcoded hyperparameters

# Transformer import is wrapped in try/except:
try:
    from models.transformer_model import TORCH_AVAILABLE
# WHY: torch has Windows DLL issues and is heavy (~1.5GB).
# The pipeline must start even without GPU/torch installed.
# Graceful fallback = LR + XGBoost only (still very good).
```

```python
# Line 72
MODEL_VERSION = 'v3.0.0-bilingual'
# WHY: Every audit log entry carries this. When a model is retrained,
# bump this version so historical audit records are traceable.
```

```python
# Lines 75-164: _LanguageModelSet class
# WHY a separate class per language:
#   - Keeps en and hi models completely isolated
#   - Adding a new language (e.g., Tamil) = create new artifacts/ta/ and add 'ta' to config
#   - No code change needed for new languages
#
# Key decision: self.ensemble_strategy falls back to 'voting' if stacker missing
# WHY: If someone deletes the stacker artifact, the pipeline still works
# (graceful degradation, not crash)
```

```python
# Line 111: self.voter = SoftVotingEnsemble(weights=cfg['ensemble']['voting_weights'])
# voting_weights: logistic=0.25, xgboost=0.35, transformer=0.40
# WHY these weights:
#   - XGBoost beats LR on non-linear patterns + metadata signals
#   - Transformer (if loaded) is strongest but heaviest
#   - LR is the fastest, lightest fallback
#   - If transformer missing, weights auto-renormalize to LR:XGB = 0.25:0.35 = 41%:59%
```

```python
# Lines 167-205: SensitivityClassifier.__init__()
# WHY load config from YAML, not hardcode:
#   Legal/DataGovernance must be able to edit thresholds WITHOUT a code deploy
#   YAML = auditable git diff when thresholds change

# Line 201-204: lime_skip_confidence (ADDED)
self.lime_skip_confidence = self.cfg.get('explainability', {}).get('lime_skip_confidence', 0.90)
# WHY: LIME perturbation costs 100-150ms. For high-confidence predictions,
# expensive perturbation adds no value — the model is sure.
# Fallback uses LR coefficients × TF-IDF weights (~0ms).
```

```python
# Lines 214-308: predict_batch()
# WHY batch, not just predict():
#   - Groups documents by language to avoid switching model sets per-doc
#   - One call to LR.predict_proba(batch) = 1 TF-IDF transform for all docs
#   - Kafka consumer processes poll batches — batch prediction fits naturally

# Line 253: max_class_prob = float(np.max(probs))
# WHY capture this here:
#   - Passed to _gather_evidence() to decide LIME skip
#   - Computed once from raw ensemble output before policy override
#   - Post-policy label might differ (e.g., PII forces Restricted) but we
#     want LIME skip based on MODEL confidence, not policy-overridden label
```

```python
# Lines 310-384: _gather_evidence()
# Evidence collection order (intentional priority):
#   1. Policy PII hits (highest confidence — regex is deterministic)
#   2. SHAP (tree-based, explains XGBoost — fast, reliable)
#   3. LIME/fallback (explains LR — expensive, gated by lime_skip_confidence)
#   4. IG (transformer only — rarely runs)
#
# WHY this order: PII hits are the most important for compliance auditors.
# "SSN detected" is more actionable than "token 'salary' weight 0.3"

# Lines 337-350: LIME skip (ADDED)
if max_class_prob > self.lime_skip_confidence:
    evidence.extend(ms.lime_explainer._fallback_explain(text, predicted_class))
else:
    evidence.extend(ms.lime_explainer.explain(text, predicted_class))
# WHY _fallback_explain vs .explain():
#   _fallback_explain = TF-IDF weight × LR coefficient for tokens in text
#   This is still meaningful evidence — just not perturbation-based
#   .explain() = full LIME: 200 random perturbations → local linear fit → top tokens
#   Both meet the ≥3 evidence tokens compliance requirement

# Lines 347-383: Deduplication + compliance padding
# WHY dedup by (token, source):
#   SHAP and LIME may both find "salary" — keep the one with higher weight
# WHY lexical_fallback at weight=0.01:
#   Compliance requires ≥3 tokens. If models produce <3, use raw text tokens
#   Weight=0.01 signals "low-confidence filler" to downstream audit readers
```

---

## FILE 2: `policy_engine/rules.py`
**Role:** Post-prediction rule overlay. Three layers: PII regex → thresholds → dual-approval.

### Why Three Layers?

The problem statement says "not rule-based" — meaning the CLASSIFICATION should not be purely rule-based. The policy engine sits AFTER the ML model, acting as a safety net. The ML model does the classification. The policy engine enforces hard constraints the ML might miss.

```python
# Lines 51-63: luhn_valid()
# WHY Luhn check:
#   Credit card regex '\\b(?:\\d[ -]*?){13,16}\\b' matches ANY 13-16 digit sequence
#   Invoice numbers, tracking numbers, zip codes all match
#   Luhn algorithm validates the checksum that real cards satisfy
#   Without it: massive false positive rate on financial documents
#   With it: only real credit card numbers are flagged
```

```python
# Lines 66-71: PIIHit dataclass
matched_value_masked: str   # masked value, NOT the raw PII (compliance C1)
# WHY store masked not raw:
#   The audit log must never contain raw PII (C1 requirement)
#   PIIHit is passed to pipeline.py and written to audit log
#   By masking at creation time, we can never accidentally log raw PII
```

```python
# Lines 74-113: PolicyDecision dataclass
# WHY a dataclass not a dict:
#   Type safety — caller knows exactly what fields exist
#   IDE autocomplete for audit code authors
#   to_dict() produces the Kafka-publishable JSON envelope

# Line 86-87: calibration_source (ADDED)
calibration_source: Optional[Dict[str, Any]] = None
# WHY: Prove to auditors that thresholds are data-driven.
# Every decision carries metadata about HOW the threshold was chosen.
# An auditor can trace: "why was this classified Restricted?"
# Answer: "P(Restricted)=0.71 > calibrated threshold 0.65
#          (calibrated 2026-04-29 via precision-recall sweep on 4000 docs)"
```

```python
# Lines 184-351: PolicyEngine.apply()
# Layer 1: PII regex (Lines 214-247)
# WHY regex FIRST before threshold checks:
#   PII is deterministic. If SSN is present, document IS Restricted.
#   No probability needed. Regex is O(n) over text.
#   This satisfies problem statement C2: "100% PII recall"

# Lines 220-247: High vs medium severity split
#   HIGH: SSN, credit card, IBAN, PAN, Aadhaar, passport → ALWAYS Restricted
#   MEDIUM: email, phone, DOB → alone they are Confidential
#   WHY split: a document with one email address is Confidential, not Restricted
#   A document with email + phone (2 medium hits) crosses a threshold → Restricted
#   This models real-world data classification policy behavior

# Layer 2: Threshold overrides (Lines 249-283)
# WHY use calibrated thresholds not hard rules:
#   Hard rule: "if text contains 'salary' → Confidential" — brittle, easily fooled
#   Threshold: "if P(Confidential) > 0.75 → escalate action" — model-driven
#   The ML model learned from thousands of documents what "Confidential" looks like
#   The threshold gates when we act on that learned signal
#   This is what the problem statement means by "not rule-based"

# Lines 271-284: Keyword bump (Internal → Confidential)
# WHY keep keyword rules at all if we have ML:
#   The ML model may be uncertain (e.g., P(Internal)=0.75, P(Confidential)=0.20)
#   If text contains "salary" — a compliance officer would always say Confidential
#   Keywords are a safety net for the ML model's uncertainty
#   They operate only on Internal→Confidential (not Confidential→Restricted)
#   The restricted threshold handles that escalation

# Lines 287-298: Conflict resolution
winner = resolve_conflicts(fired_rules, self._rule_priorities)
# WHY a priority system:
#   Multiple rules may fire on one document (PII + threshold + keyword)
#   Without resolution: ambiguous outcome
#   With priority: PII (100) > threshold (80) > keyword (60) > model (20)
#   Deterministic, auditable, configurable via policy.yaml
```

---

## FILE 3: `policy_engine/approval.py`
**Role:** Dual-approval gate model. Simulates Legal + DataGovernance workflow.

```python
# Lines 35-39: ApprovalStatus enum
class ApprovalStatus(Enum):
    NOT_REQUIRED = "not_required"  # Public, Internal
    PENDING = "pending"            # Restricted/Confidential — awaiting sign-off
    APPROVED = "approved"          # Both approvers signed
    REJECTED = "rejected"          # One approver rejected
# WHY enum not string:
#   Prevents typos ("approvd" vs "approved")
#   IDE can enumerate all valid states
#   JSON serialization via .value preserves human-readable string

# Lines 66-87: record_approval()
# WHY return bool (not raise exception):
#   The API layer (Aditi's work) calls this when an approver submits their decision
#   Returning False means "not fully approved yet" — normal, not an error
#   Raising exception would force try/except in every caller

# Lines 160-177: DEFAULT_RULE_PRIORITIES
# WHY these specific numbers:
#   100 = PII regex (absolute highest — deterministic, legally required)
#   90  = Multiple medium PII (aggregate signal, still very strong)
#   80  = Threshold restricted (model says restricted)
#   60  = Keyword confidential (weaker signal — just a keyword)
#   50  = Confidential escalation (above escalation threshold)
#   40  = Low confidence (uncertain — human review)
#   20  = Base model prediction (weakest — overridden by everything above)
#   Gaps of 10-20 allow new rules to be inserted without renumbering

# Lines 190-228: resolve_conflicts()
# WHY sort by (priority, sensitivity) not just priority:
#   Two rules at same priority → more restrictive label wins
#   Example: KEYWORD_CONFIDENTIAL(60) fires on same doc as THRESHOLD_RESTRICTED(80)
#   THRESHOLD_RESTRICTED wins (higher priority)
#   But if two rules both at priority 60: Restricted > Confidential > Internal > Public
```

---

## FILE 4: `models/logistic_model.py`
**Role:** Fast, interpretable baseline classifier using TF-IDF + Logistic Regression.

```python
# Lines 28-44: Pipeline construction
self.pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(
        ngram_range=(1, 2),     # unigrams + bigrams
        max_features=20000,     # vocabulary cap
        min_df=2,               # ignore very rare terms
        sublinear_tf=True,      # log(1+tf) — reduces dominance of frequent terms
        lowercase=True,
    )),
    ('clf', LogisticRegression(
        C=1.0,                  # regularization strength
        class_weight='balanced', # critical for Restricted class imbalance
        solver='liblinear',     # best for small-medium datasets
    )),
])

# WHY TF-IDF not word2vec/BERT for LR:
#   TF-IDF is sparse → LR coefficients are directly interpretable
#   "salary" token has coefficient X for Confidential class → LIME can show it
#   Dense embeddings lose token-level interpretability
#   BERT embedding → LR would work but LIME would be meaningless (400-dim latent space)

# WHY class_weight='balanced':
#   Restricted documents are rare in real enterprise data
#   Without balancing: model ignores Restricted (predicts majority class)
#   balanced = sklearn auto-computes weights inversely proportional to class frequency
#   Result: model penalizes Restricted misclassification more

# WHY ngram_range=(1,2):
#   "trade secret" → bigram captures compound meaning
#   "trade" alone could be neutral; "secret" alone could be neutral
#   Together they signal Restricted
#   Bigrams capture these legal/HR compound terms better than unigrams

# WHY min_df=2:
#   Terms appearing in only 1 document are noise (proper names, typos)
#   Removing them reduces vocabulary size and prevents overfitting

# Lines 50-56: predict_proba() reordering
reorder = [fitted_classes.index(c) for c in self.classes]
return probs[:, reorder]
# WHY reorder:
#   sklearn sorts classes alphabetically: Confidential, Internal, Public, Restricted
#   Our canonical order is: Public, Internal, Confidential, Restricted
#   The ensemble combine() assumes all models return probs in same order
#   Without reorder: wrong label gets wrong probability → silent classification error
```

---

## FILE 5: `models/xgboost_model.py`
**Role:** Non-linear classifier with text hashing + metadata features.

```python
# Lines 25-27: Fixed metadata vocabularies
SOURCE_SYSTEMS = ['JIRA', 'ServiceNow', 'Confluence', 'Workday', ...]
DEPARTMENTS = ['Engineering', 'HR', 'Finance', ...]
FILE_TYPES = ['txt', 'email', 'ticket', 'doc', ...]
# WHY fixed vocab (not dynamic):
#   If vocabulary is learned from training data, new values at inference time
#   (a new source system) would be mapped to 'UNKNOWN' anyway
#   Fixed vocab = deterministic one-hot encoding = artifact is portable
#   Dynamic vocab = need to save/load vocab alongside model

# Lines 50-55: HashingVectorizer
self.hasher = HashingVectorizer(
    n_features=512,        # hash space size
    alternate_sign=False,  # no negative values
    ngram_range=(1, 2),
    norm='l2',
)
# WHY HashingVectorizer for XGBoost (not TfidfVectorizer):
#   TfidfVectorizer requires saving/loading vocabulary (20k features)
#   HashingVectorizer is stateless — no vocabulary to save
#   XGBoost only needs "features that correlate with label" — exact token identity less important
#   Collisions at 512 features are acceptable (XGBoost handles noisy features well)
#   TF-IDF is used for LR (interpretability); Hashing for XGBoost (speed + no vocab)

# Lines 73-88: _featurize()
# Feature matrix = [hashed_text(512) | source_system_onehot(8) | department_onehot(8) | file_type_onehot(10) | numeric(4)]
# Total features per document: 512 + 8 + 8 + 10 + 4 = 542
# WHY include metadata:
#   An email from HR about "salary" is more likely Confidential than
#   an Engineering Jira ticket with "salary" in it (maybe a bug description)
#   Metadata features let XGBoost learn these context signals
#   LR (TF-IDF) cannot use metadata — XGBoost fills this gap

# Lines 36-43: _numeric_features()
[num_chars, num_tokens, num_digits, digit_ratio]
# WHY digit_ratio:
#   Documents with high digit density (account numbers, SSN patterns)
#   correlate strongly with Restricted label
#   XGBoost learns "digit_ratio > 0.15 AND department=Finance → likely Restricted"
```

---

## FILE 6: `ensemble/stacking.py`
**Role:** Meta-learner that learns how to combine LR and XGBoost predictions.

```python
# Lines 111-139: generate_oof_logistic / generate_oof_xgboost
# OOF = Out-Of-Fold predictions
# WHY OOF instead of just training set predictions:
#   If we train LR and ask it to predict its own training data → perfect predictions
#   Meta-learner learns "trust LR 100%" → overfits
#   OOF: train on 4 folds, predict fold 5, repeat → predictions on data model never saw
#   Meta-learner gets realistic base model outputs → fair learning

# Lines 62-86: predict_proba() with graceful fallback
if p is None:
    filled[name] = np.full((n, len(self.classes)), 1.0 / len(self.classes))
# WHY fill with uniform prior (not zeros or raise error):
#   Transformer fails to load → stacker still produces a prediction
#   Zeros would shift probabilities artificially
#   Uniform prior = "I don't know" signal → meta-learner learned to handle this
#   The stacking meta-learner (trained on OOF data) saw these uniform priors
#   during OOF generation when one model failed on a fold
```

---

## FILE 7: `ensemble/voting.py`
**Role:** Fallback ensemble when stacking is unavailable.

```python
# Lines 25-30: _is_degenerate()
uniform = np.full_like(probs, 1.0 / len(self.classes))
return np.allclose(probs, uniform, atol=1e-6)
# WHY detect uniform priors:
#   A failed model returns uniform [0.25, 0.25, 0.25, 0.25]
#   Including it in voting would drag all predictions toward uncertainty
#   Detecting and excluding it = dynamic weight renormalization

# Lines 48-54: Normalize weights over ACTIVE models only
active_weight_sum = sum(self.weights.get(n, 0.0) for n in active)
norm_weights = {n: self.weights.get(n, 0.0) / active_weight_sum for n in active}
# Example: transformer fails, logistic=0.25, xgboost=0.35
# active_weight_sum = 0.25 + 0.35 = 0.60
# norm_weights: logistic = 0.25/0.60 = 0.417, xgboost = 0.35/0.60 = 0.583
# Probabilities still sum to 1.0 — no distortion
```

---
