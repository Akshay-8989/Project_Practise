# Pipeline Modes — FAST vs FULL

The classification pipeline runs in **two interchangeable modes**. Which one you
get is decided automatically at startup based on whether `torch` and
`transformers` are installed. You can also force a mode with `--fast` / `--full`.

## TL;DR — which mode to use

| Situation | Use this mode |
|---|---|
| Real-time API serving | **FAST** |
| CI / development laptop | **FAST** |
| Final demo for a reviewer | **FULL** (if you have time + working torch) |
| Air-gapped on-prem deployment | **FAST** (smaller footprint) |
| Showing the architecture-complete deliverable | **FULL** |
| Don't have torch / can't install it | **FAST** |

## Single command, both modes

```powershell
# Auto-detect (uses FULL if torch is available, else FAST)
python -m scripts.run_pipeline

# Force FAST (always works)
python -m scripts.run_pipeline --fast

# Force FULL (errors out if torch missing)
python -m scripts.run_pipeline --full
```

The runner auto-generates data, trains the right artifacts, runs a latency
benchmark, runs sample predictions, and prints a PS-01 report card. Same
command in either mode.

---

## What's IN each mode

### FAST mode (default when torch isn't installed)

```
Input → Language Detector → [LR + XGBoost + Stacker] → Policy Engine → Output
                            (no transformer)
```

**Models active:**
- Logistic Regression (TF-IDF baseline)
- XGBoost (hashed n-grams + metadata)
- Stacking meta-learner over LR + XGBoost

**Explainers active:**
- LIME (over LR)
- SHAP (over XGBoost)
- Policy engine evidence tokens

### FULL mode (default when torch + transformers are installed)

```
Input → Language Detector → [LR + XGBoost + DistilBERT + Stacker] → Policy Engine → Output
                            (transformer included)
```

**Models active (everything in FAST plus):**
- DistilBERT-multilingual-cased fine-tuned per language
- Stacking meta-learner now over 3 models

**Explainers active (everything in FAST plus):**
- Integrated Gradients (over the transformer)

---

## What changes between modes — measured comparison

These numbers are from actual benchmark runs. Your specific numbers will vary
based on hardware, but the **rankings** are stable.

### Accuracy (synthetic test set)

| Metric | FAST | FULL | Difference |
|---|---|---|---|
| Stacker macro-F1 (English) | 1.0000 | 1.0000 | none |
| Stacker macro-F1 (Hindi) | 0.9975 | 0.9990 | +0.15% |

On synthetic data the difference is statistical noise. On **real-world data**
the transformer would typically add 0.5–1.5% F1 on hard cases (paraphrased
content, sarcasm, partial PII). We don't have real labeled data to measure
this exactly.

### Latency (p95 per document)

| Mode | CPU | GPU |
|---|---|---|
| FAST | ~70-140 ms | ~70-140 ms |
| FULL | ~300-500 ms | ~50-80 ms |

**PS-01 latency target:** < 200 ms p95.

- **FAST mode passes the target on CPU.** This is why it's the recommended
  default for real-time API serving.
- **FULL mode misses the target on CPU.** It passes if you have a GPU.

### Install footprint

| | FAST | FULL |
|---|---|---|
| Required pip packages | 8 | 12 |
| Disk space | ~150 MB | ~2 GB |
| First-run network | none | 542 MB DistilBERT download |
| Cold-start time | <1 s | 3-5 s (model load) |
| Compatible Python versions | 3.8 – 3.13 | 3.9 – 3.11 |

For air-gapped on-prem deployment (PS constraint C3), FAST mode is significantly
easier to ship.

### Training time

| Mode | --sample 500 | Full data |
|---|---|---|
| FAST | ~30 sec | ~5 min |
| FULL on CPU | ~25 min | ~3 hours |
| FULL on GPU | ~3 min | ~20 min |

---

## What stays the SAME between modes

These work identically regardless of which mode you're in:

- ✓ Bilingual support (English + Hindi auto-routing)
- ✓ Policy engine (regex + Luhn + keyword + threshold rules)
- ✓ Dual-approval gate (Legal + Data Governance for Restricted)
- ✓ Audit logging with PII masking (constraint C1)
- ✓ Output JSON schema (downstream consumers see the same shape)
- ✓ Conflict resolution by rule priority
- ✓ Defense-in-depth (upstream pii_policy_hint override)
- ✓ Compliance evaluation script
- ✓ Kafka integration (`enterprise_platform/classification/`)
- ✓ All 92 tests pass

The pipeline is **architecturally identical** in both modes. The transformer
is a model added to the ensemble, not a different architecture.

---

## How to know which mode you're in

Every prediction includes a `runtime_mode` field in the audit block:

```json
{
  "label": "Restricted",
  "confidence": 0.998,
  ...
  "audit": {
    "model_version": "v3.0.0-bilingual",
    "ensemble_used": "stacking",
    "active_models": ["logistic", "xgboost"],
    "runtime_mode": "fast"           ← here
  }
}
```

Possible values:
- `"fast"` — no transformer in any language model set
- `"full"` — transformer present in every language model set
- `"partial"` — transformer present in some languages but not others
  (e.g. trained English transformer but skipped Hindi)

The pipeline also prints the runtime mode at startup:
```
[pipeline] runtime_mode=fast  (full=LR+XGB+Transformer, fast=LR+XGB)
```

---

## What happens if you DON'T use the transformer

This is the question the user actually asks most often. Honest answer:

### What you LOSE

1. **The architecture-completeness checkbox.** PS-01 section 3 lists three models in
   the ensemble. Without transformer you have two. A strict reviewer might
   flag this. Your defense: "transformer supported in code as optional,
   disabled in the deployed configuration for latency reasons; LR+XGB
   already passes every hard PS-01 metric."

2. **~0.5-1.5% F1 on real-world hard cases.** Paraphrasing, partial PII,
   semantic content that doesn't match keyword patterns. Not measurable on
   synthetic data.

3. **Integrated Gradients (one explainer technique).** SHAP and LIME still
   produce evidence tokens — the PS requirement of ≥3 tokens / 100% coverage
   is met. You just have one fewer explainer in the toolkit.

### What you GAIN by NOT using it

1. **Real-time latency on CPU.** FAST mode hits <200 ms p95. FULL mode on CPU
   hits ~350 ms. If you want real-time API serving without a GPU, FAST is
   the only realistic option.

2. **Faster iteration during development.** Training FAST = 30 seconds.
   Training FULL on CPU = 25 minutes. Big difference when you're tweaking
   the policy engine and need to retrain often.

3. **Smaller deployment footprint.** ~150 MB instead of ~2 GB. Easier to ship
   to clients on locked-down corporate networks (PS constraint C3).

4. **Wider Python version support.** torch has rough edges on 3.12+. FAST
   mode works on 3.8 through 3.13 without surprises.

5. **Simpler install for new team members.** No GPU drivers, no DLL
   conflicts, no HuggingFace hub authentication, no 542 MB download.

### What does NOT break

- All four sensitivity classes still work
- All PII detection still works (regex + Luhn + Aadhaar/PAN)
- Hindi support still works (LR + XGBoost are bilingual already)
- Audit logging still works
- Dual-approval gate still works
- Kafka integration still works
- Real-time inference still works (in fact, faster)
- All 92 tests still pass

---

## Recommendation

**Default to FAST.** Use it for development, CI, and real-time API deployment.

**Run FULL once before final submission.** That gives you the
architecture-complete deliverable for the review (and you keep both sets of
artifacts side by side).

In your review you can say:

> "The pipeline supports a three-model ensemble per PS-01 section 3:
> Logistic Regression, XGBoost, and a fine-tuned DistilBERT. By default we
> deploy in FAST mode (LR + XGBoost only) because it meets the <200 ms
> latency target on CPU and passes every hard PS metric. FULL mode is used
> for batch jobs and runs identically with the addition of the transformer.
> Switching modes requires no code change — only training artifacts.
> Documented in MODES.md and demonstrated by `python -m scripts.run_pipeline`."

That's a defensible engineering position, not a workaround.
