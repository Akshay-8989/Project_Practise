# COMPLIANCE PROJECT — FULL TECHNICAL DOCUMENTATION
## Part 3: Explainability, Utils, Kafka Layer, Configs

---

## FILE 8: `explainability/shap_explainer.py`
**Role:** Produces token-level explanations for XGBoost predictions.

```python
# Lines 41-45: TreeExplainer initialization
self._explainer = shap.TreeExplainer(xgb_model.clf)
# WHY TreeExplainer (not KernelExplainer):
#   TreeExplainer is EXACT for tree models — computes true Shapley values
#   KernelExplainer is model-agnostic but approximate and SLOW (minutes per doc)
#   TreeExplainer runs in ~1-5ms for our XGBoost model size
#   This is why SHAP is always fast, even without the LIME skip

# Lines 47-67: _hash_inverse_mapping()
# The problem with HashingVectorizer + SHAP:
#   SHAP tells us: "hash bucket 237 has SHAP value 0.42 for Restricted"
#   But what token hashes to bucket 237?
#   We need to reverse-map: text → tokens → hash buckets
# Solution: re-run the same hasher analyzer on the input text, track which
#   tokens land in which buckets, then look up the SHAP-important buckets
# WHY not store the mapping:
#   The hasher is stateless — mapping depends on the INPUT text, not the model
#   Different documents have different tokens → different bucket-to-token mappings
#   Must be computed fresh per prediction

# Lines 102-103: Only positive SHAP values
if text_sv[idx] <= 0:
    break
# WHY skip negative SHAP:
#   Negative SHAP = "this feature pushed probability DOWN"
#   Evidence for human auditors = "why is it classified X"
#   Negative contributors = "despite these tokens it was still classified X"
#   Confusing for non-technical audit reviewers → only show positive contributors
```

---

## FILE 9: `explainability/lime_explainer.py`
**Role:** Produces token-level explanations for Logistic Regression.

```python
# Lines 37-41: LimeTextExplainer
self._explainer = LimeTextExplainer(
    class_names=logistic_model.classes,
    random_state=42,   # deterministic explanations
)
# WHY random_state=42:
#   LIME is stochastic — random perturbations of input text
#   Without fixed seed: same document gets different explanations each time
#   Audit requirement: explanations must be reproducible
#   With seed=42: deterministic for the same (text, predicted_class) pair

# Lines 52-58: explain_instance()
exp = self._explainer.explain_instance(
    text,
    self._predict_proba_for_lime,
    num_features=top_k,
    num_samples=self.num_samples,  # 200 (reduced from 500)
    labels=[class_idx],
)
# WHY num_samples=200 (not default 500):
#   Each sample = one text perturbation → one LR inference → ~0.5ms
#   500 samples = 250ms → exceeds latency budget
#   200 samples = 100ms → acceptable (before LIME skip)
#   With LIME skip at 0.90 confidence, most docs never reach this

# Lines 75-101: _fallback_explain()
# Direct coefficient × TF-IDF weight explanation
X = vec.transform([text])
coefs = clf.coef_[class_idx]
contrib = X.toarray()[0] * coefs
# WHY this is valid even without LIME:
#   LR is globally linear: decision = sum(feature_i × weight_i)
#   For the CURRENT document, feature_i = TF-IDF weight of token in THIS doc
#   contrib[i] = TF-IDF_weight × LR_coefficient for token i
#   This is the LOCAL contribution of each token to THIS prediction
#   It's not LIME (which fits a local surrogate) but it's still principled
#   And it runs in ~0ms — just a matrix multiplication
```

---

## FILE 10: `utils/language_detector.py`
**Role:** Determines whether a document is English or Hindi.

```python
# Lines 18-19: Unicode ranges
DEVANAGARI_START = 0x0900
DEVANAGARI_END   = 0x097F
# WHY script-based not model-based (langdetect, fasttext):
#   langdetect: probabilistic, non-deterministic (different result each call)
#   fasttext lid.176.bin: 900MB model, overkill for 2 languages
#   Our documents are either clearly Hindi OR clearly English
#   Devanagari vs Latin character counting is O(n) characters, ~0.1ms
#   Perfectly deterministic → auditable (same doc always gets same language)
#   Adding a third language = add its Unicode range

# Lines 39-59: detect_language() thresholds
dev_ratio >= 0.15 → 'hi'
latin_ratio >= 0.85 → 'en'
else → 'unknown'
# WHY 0.15 for Hindi (not 0.50):
#   Hindi business documents often contain English loanwords, numbers, codes
#   "Employee ID: EMP001, Salary: ₹8,00,000" — mostly Latin but core is Hindi
#   If threshold = 0.50: mixed documents miss Hindi routing
#   0.15 = "if at least 15% of letters are Devanagari, route to Hindi model"
#   This catches the mixed-script HR documents common in Indian enterprises

# WHY 0.85 for English:
#   Very short texts may have 60% Latin but are just metadata (dates, codes)
#   0.85 = "overwhelmingly Latin" → confident English
```

---

## FILE 11: `utils/audit_logger.py`
**Role:** Writes one JSON line per prediction to audit log.

```python
# Line 32: safe_snippet(input_text, max_len=160)
# WHY mask BEFORE writing:
#   Even though the policy engine already caught PII, the raw input text
#   is passed to AuditLogger. If we write raw text, SSN appears in log.
#   safe_snippet() = mask_text() + truncate to 160 chars
#   Compliance C10: "No raw PII in audit log" — met by masking at write boundary

# Lines 28-41: entry dict structure
entry = {
    'doc_id': ...,
    'timestamp_utc': ...,
    'model_version': ...,
    'input_snippet_masked': ...,  # masked text, not raw
    'label': ...,
    'confidence': ...,
    'class_probabilities': ...,
    'policy_trace': ...,          # includes calibration_source
    'model_contributions': ...,
    'evidence_count': ...,        # count, not the tokens (tokens logged separately)
}
# WHY log evidence_count not the tokens:
#   SHAP/LIME token strings may be partial PII ("SSN" → "ss") after masking
#   Just logging the COUNT satisfies the "≥3 evidence tokens" compliance check
#   Without exposing anything sensitive

# Line 41: sort_keys=True
json.dumps(entry, sort_keys=True)
# WHY sort_keys:
#   Makes log entries deterministic for diffing
#   If two logs are compared to detect anomalies, field order matters
#   Sorted keys = same field order every time = reliable grep/jq queries
```

---

## FILE 12: `utils/pii_masker.py`
**Role:** Second defensive masking layer before any log write.

```python
# Lines 17-26: _MASK_PATTERNS
# WHY a SEPARATE masker (not reuse policy_engine regex):
#   Policy engine regex includes Luhn validation for credit cards
#   The masker should catch ALL credit card shaped numbers (no Luhn check)
#   Better to mask too much than log raw PII
#   Also: policy engine patterns are for DETECTION, masker patterns are for SANITIZATION
#   Different purposes → separate implementations

# Lines 29-42: mask_text() returns (masked_text, hits) tuple
# WHY return hits list:
#   Caller can log what TYPES of PII were found without logging the values
#   audit_logger doesn't use hits — but the function is reusable for metadata
```

---

## FILE 13: `enterprise_platform/classification/consumer.py`
**Role:** Kafka consumer loop — the bridge between the pipeline and the streaming platform.

```python
# Lines 35-40: KAFKA_AVAILABLE flag
try:
    from kafka import KafkaConsumer, KafkaProducer
    KAFKA_AVAILABLE = True
except ImportError:
    KAFKA_AVAILABLE = False
# WHY conditional import:
#   The --file mode (offline testing) doesn't need kafka-python installed
#   The same consumer.py handles both modes: Kafka loop AND local file classification
#   Without this flag, `python -m classification.app --file sample.json` would fail
#   if kafka-python wasn't installed — but Kafka is clearly needed for production

# Lines 56-83: _resolve_classification_module_path()
# Resolution order:
#   1. Explicit env var CLASSIFICATION_MODULE_PATH
#   2. <repo_root>/classification_module
#   3. ../../classification_module (sibling layout)
# WHY multiple fallbacks:
#   The project can be cloned in different structures
#   Dev machine vs CI vs Docker may have different layouts
#   Env var = always wins (explicit beats implicit)
#   Fallback 2 = the integrated project layout (enterprise_platform + classification_module together)
#   Fallback 3 = the old separate repos layout

# Lines 89-112: get_classifier() — lazy load with chdir
os.chdir(cm_path)
# WHY chdir to classification_module:
#   SensitivityClassifier uses RELATIVE paths: 'configs/model.yaml', 'artifacts/'
#   These paths resolve relative to cwd at the time of __init__
#   The consumer.py lives at enterprise_platform/classification/ — wrong cwd
#   chdir pins cwd to classification_module so all relative paths work correctly
#   This is done ONCE (lazy load) not on every prediction

# Lines 118-155: build_result_payload()
# WHY copy forward lineage IDs (doc_id, parent_doc_id, event_id, ingest_id):
#   DLP/CASB downstream needs to correlate the classification result
#   with the original ingestion event and the preprocessed document
#   Without these IDs, the downstream cannot know WHICH document was classified
#   The full audit trail requires: ingest_id → event_id → doc_id → classification_run_id

# Lines 162-171: _choose_action() — defense in depth
def _choose_action(model_action: str, upstream_hint: str) -> str:
    upstream_normalized = normalize_policy_hint(upstream_hint)
    if _ACTION_RANK.get(upstream_normalized, 0) > _ACTION_RANK.get(model_action, 0):
        return upstream_normalized
    return model_action
# WHY take the stricter action:
#   Upstream Presidio may catch PII we missed → upstream says Quarantine
#   Our model says Allow (it didn't see the PII text directly)
#   Result: Quarantine wins (more restrictive)
#   Our model catches semantic Confidential that Presidio missed → we say Encrypt
#   Upstream says Allow → Encrypt wins
#   BOTH layers contribute to the final decision (defense-in-depth)

# Lines 241-266: Kafka consumer setup
enable_auto_commit=False
# WHY manual commit:
#   auto_commit = Kafka marks message as processed BEFORE our classifier runs
#   If classifier crashes mid-flight, message is lost
#   Manual commit = only after successful processing AND publish to output topic
#   This gives exactly-once-semantics for classification results

# Lines 295-319: The join logic
if msg.topic == topic_pp:
    joined = cache.add_preprocessed(doc_id, payload)
elif msg.topic == topic_fe:
    joined = cache.add_engineered(doc_id, payload)
if joined is None:
    consumer.commit()  # commit THIS topic's offset
    continue           # wait for other half
# WHY commit the partial message:
#   If we don't commit, on restart we re-read the same message
#   But the other half may be LOST (already consumed and in cache that was cleared)
#   Committing partial = "I received this half, stored it, waiting for the other"
#   The join cache holds the other half safely across message processing loops

# Lines 354-360: Cleanup in finally block
producer.flush(timeout=10)
consumer.close()
producer.close(timeout=10)
# WHY flush before close:
#   KafkaProducer batches messages for efficiency
#   If we close() before flush(), in-flight classification results are dropped
#   flush() waits up to 10 seconds for all buffered messages to be delivered
```

---

## FILE 14: `enterprise_platform/classification/join_cache.py`
**Role:** In-memory TTL cache joining two Kafka topic messages by doc_id.

```python
# Lines 43-45: Two separate dicts
self._preprocessed: Dict[str, Tuple[float, Dict]] = {}
self._engineered:   Dict[str, Tuple[float, Dict]] = {}
# WHY two dicts not one:
#   Messages arrive asynchronously on two topics
#   Two dicts make the "which half arrived?" question O(1) lookups
#   One dict with typed entries would need type checks on every access

# Line 45: threading.Lock()
self._lock = threading.Lock()
# WHY a lock:
#   Kafka consumer may run multiple threads (max_poll_records > 1)
#   Without lock: two threads add_preprocessed() for different doc_ids simultaneously
#   → Dict mutation is not thread-safe in Python (CPython GIL is NOT a guarantee here)

# Lines 48-53: stats dict
self.stats = {
    "preprocessed_received": 0,
    "engineered_received": 0,
    "joins_completed": 0,
    "evictions": 0,
}
# WHY track evictions:
#   Evictions = messages whose other half NEVER arrived within TTL
#   High eviction rate = upstream pipeline dropping messages or huge latency
#   This metric is your early warning for pipeline failures
#   In production: expose via /metrics endpoint for Prometheus scraping

# Line 37: ttl_seconds=300
# WHY 5 minutes:
#   Feature engineering normally takes <5 seconds after preprocessing
#   5 minutes is 60x buffer for slow days, restarts, GC pauses
#   Too short: valid pairs evicted before join completes → missed classifications
#   Too long: memory leak if upstream starts failing
```

---

## FILE 15: `enterprise_platform/classification/adapter.py`
**Role:** Translates upstream schema to classifier input format.

```python
# Lines 40-45: _POLICY_HINT_PASSTHROUGH mapping
"Restrict": "Quarantine"  # upstream uses "Restrict", we use "Quarantine"
# WHY this mapping exists:
#   The feature_engineering team uses "Restrict" in their pii_policy_hint enum
#   Our policy engine uses "Quarantine" (DLP industry standard term)
#   The adapter is the vocabulary boundary — different teams use different terms
#   Without this adapter, a "Restrict" hint would be treated as unknown → default to Allow

# Lines 95-103: get_text_from_preprocessed()
masked = pp_dict.get("masked_text", "") or ""
if masked.strip():
    return masked
# WHY prefer masked_text over clean_text:
#   Presidio (upstream masker) has already replaced SSN → [SSN], Aadhaar → [AADHAAR]
#   Using masked_text means our LR model sees [SSN] tokens, not raw numbers
#   But our POLICY ENGINE still scans for unmasked patterns in the same text
#   Wait — contradiction? No:
#   The policy engine operates on the SAME text as the classifier
#   If we pass masked_text, Presidio already caught the PII
#   Our regex then catches anything Presidio MISSED (Aadhaar in non-standard format)
#   This is the defense-in-depth design

# Lines 124-130: Fallback when preprocessed is None (ALLOW_ENGINEERED_ONLY=true)
top_terms = _safe_get(engineered, "classical_features.tfidf.top_features", {})
text = " ".join(sorted(top_terms.keys(), key=lambda k: -top_terms[k]))
# WHY reconstruct text from TF-IDF top features:
#   engineered_features carries top TF-IDF terms from the upstream TF-IDF engine
#   These are NOT the same as our TF-IDF (different vocabulary) but better than empty
#   The LR model gets degraded input but XGBoost (metadata + hashed features) is unaffected
#   This mode is explicitly labeled "degraded LR" in the config comment
```

---

## FILE 16: `enterprise_platform/classification/schema.py`
**Role:** Pydantic output schema for Kafka classification_results topic.

```python
# Lines 18-26: Optional pydantic import
try:
    from pydantic import BaseModel, Field
    PYDANTIC_OK = True
except ImportError:
    PYDANTIC_OK = False
    BaseModel = object
# WHY optional pydantic:
#   The consumer runs with just kafka-python + numpy + sklearn
#   Pydantic is a nice-to-have for schema validation, not required at runtime
#   The classification result is published as raw JSON dict (not validated Pydantic)
#   Pydantic is used by OTHER services that CONSUME the topic (downstream validation)
#   This schema.py serves as CONTRACT DOCUMENTATION for downstream teams

# Line 52-75: ClassificationResult fields
# doc_id, parent_doc_id, event_id, ingest_id → lineage chain
# label, confidence, class_probabilities → ML output
# evidence → explainability
# policy_trace → compliance audit (includes calibration_source)
# final_action → DLP instruction
# classification_run_id, classification_timestamp → provenance
# source_topics → which Kafka topics fed this result
```

---

## FILE 17: `scripts/calibrate_thresholds.py` (ADDED)
**Role:** Replaces hand-picked thresholds with data-driven values.

```python
# Lines 54-103: _sweep_restricted_threshold()
# Strategy: find the LOWEST threshold where precision >= 0.90
# Why precision >= 0.90 (not F1 or recall):
#   A false positive on restricted_override_prob is VERY costly
#   (Normal doc quarantined = workflow blocked for Legal + DataGovernance review)
#   A false negative is also bad but that's handled by PII regex (deterministic)
#   So: prioritize precision, then maximize recall within that constraint

# Lines 106-131: _sweep_confidential_threshold()
# Strategy: maximize F1
# Why F1 (not precision or recall):
#   Confidential escalation is less critical than restricted
#   Missing a Confidential → Encrypt (false negative) → weaker protection
#   False positive → unnecessary Encrypt (cost, friction)
#   Balanced F1 is the right tradeoff here

# Lines 134-167: _sweep_low_confidence_threshold()
# Strategy: lowest threshold where above-threshold accuracy >= 0.80
# Why accuracy here (not precision/recall):
#   Low confidence triggers HumanReview for ALL classes
#   We want: "when model is confident, it's right at least 80% of the time"
#   Taking the LOWEST valid threshold minimizes human review burden
#   (Every doc below threshold = a human review request = operational cost)
```

---

## FILE 18: `scripts/benchmark_latency.py` (ADDED)
**Role:** Measures p50/p95/p99 latency, validates p95 < 200ms.

```python
# Lines 47-70: benchmark()
# WHY warm-up runs:
#   First predictions are slow due to:
#   - Python module lazy imports on first predict
#   - JIT compilation in numpy/scipy
#   - OS file caching of model joblib files
#   Warm-up runs = representative production latency, not startup overhead

# Why time.perf_counter() not time.time():
#   time.time() resolution can be 10-15ms on Windows (system clock tick)
#   time.perf_counter() = high-resolution performance counter (~100ns on Windows)
#   For sub-200ms measurements, you NEED perf_counter resolution
```

---

## FILE 19: `configs/policy.yaml` (UPDATED)
**Role:** Central policy configuration. Editable without code changes.

```yaml
# thresholds: (UPDATED to data-driven calibrated values)
restricted_override_prob: 0.65   # was 0.70 (hand-picked)
confidential_escalate_prob: 0.75 # was 0.80 (hand-picked)
low_confidence_prob: 0.50        # was 0.55 (hand-picked)

# WHY lower restricted threshold (0.65 not 0.70):
#   Calibration found: at 0.65, P(Restricted) achieves precision >= 0.90 with better recall
#   At 0.70 (old): some true Restricted docs were missed (false negatives)
#   At 0.65 (new): catches more true Restricted at still-high precision

# calibration_metadata: (ADDED)
# WHY this section:
#   Without it, a future auditor sees "restricted_override_prob: 0.65" and asks
#   "who picked this number and why?"
#   With it: "precision_recall_sweep on data/synthetic_dataset.csv, 2026-04-29"
#   The threshold is DATA-DRIVEN, DOCUMENTED, and REPRODUCIBLE
```

---

## FILE 20: `configs/model.yaml` (UPDATED)

```yaml
# explainability:
#   lime_skip_confidence: 0.90  (ADDED)
# WHY 0.90 specifically:
#   Tested on the synthetic dataset: ~70-80% of documents get max_class_prob > 0.90
#   Those 70-80% skip LIME perturbation → 100-150ms saved per doc
#   The remaining 20-30% (low-confidence, ambiguous docs) still get full LIME
#   These are exactly the docs that NEED the most detailed explanation
#   Trade-off is optimal: save time on easy cases, spend it on hard cases
```

---
