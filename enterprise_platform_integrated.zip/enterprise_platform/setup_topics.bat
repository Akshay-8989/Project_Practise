@echo off
REM =============================================================================
REM  AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM
REM  setup_topics.bat — Create all Kafka topics
REM =============================================================================
REM  Prerequisites:
REM    - Java 11+ installed and on PATH
REM    - Kafka extracted (update KAFKA_HOME below)
REM    - Zookeeper + Kafka broker running (run start_kafka.bat first)
REM =============================================================================

setlocal enabledelayedexpansion

REM ── CONFIGURE THIS PATH ──────────────────────────────────────────────────────
set KAFKA_HOME=C:\kafka
REM ─────────────────────────────────────────────────────────────────────────────

set KAFKA_BIN=%KAFKA_HOME%\bin\windows
set BOOTSTRAP=localhost:9092

echo.
echo =============================================================================
echo   AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM
echo   Kafka Topic Setup
echo =============================================================================
echo.
echo Kafka home : %KAFKA_HOME%
echo Bootstrap  : %BOOTSTRAP%
echo.

REM Check kafka-topics.bat exists
if not exist "%KAFKA_BIN%\kafka-topics.bat" (
    echo [ERROR] kafka-topics.bat not found at %KAFKA_BIN%
    echo         Update KAFKA_HOME in this file to your Kafka installation path.
    pause
    exit /b 1
)

echo Creating topics...
echo.

REM ── INGESTION LAYER TOPICS ───────────────────────────────────────────────────
echo [INGESTION] Creating ingest_requests ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic ingest_requests --bootstrap-server %BOOTSTRAP% --partitions 3 --replication-factor 1 --if-not-exists 2>nul
echo [INGESTION] Creating raw_documents ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic raw_documents --bootstrap-server %BOOTSTRAP% --partitions 3 --replication-factor 1 --if-not-exists 2>nul
echo [INGESTION] Creating normalized_documents ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic normalized_documents --bootstrap-server %BOOTSTRAP% --partitions 3 --replication-factor 1 --if-not-exists 2>nul
echo [INGESTION] Creating single_entity_docs ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic single_entity_docs --bootstrap-server %BOOTSTRAP% --partitions 3 --replication-factor 1 --if-not-exists 2>nul
echo [INGESTION] Creating multi_entity_docs ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic multi_entity_docs --bootstrap-server %BOOTSTRAP% --partitions 3 --replication-factor 1 --if-not-exists 2>nul
echo [INGESTION] Creating audit_logs ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic audit_logs --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul
echo [INGESTION] Creating retry_queue ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic retry_queue --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul
echo [INGESTION] Creating dead_letter_queue ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic dead_letter_queue --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul

REM ── PREPROCESSING LAYER TOPICS ───────────────────────────────────────────────
echo [PREPROCESSING] Creating preprocessed_documents ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic preprocessed_documents --bootstrap-server %BOOTSTRAP% --partitions 3 --replication-factor 1 --if-not-exists 2>nul
echo [PREPROCESSING] Creating preprocessing_audit_logs ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic preprocessing_audit_logs --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul
echo [PREPROCESSING] Creating preprocessing_retry_queue ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic preprocessing_retry_queue --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul
echo [PREPROCESSING] Creating preprocessing_dead_letter_queue ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic preprocessing_dead_letter_queue --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul

REM ── FEATURE ENGINEERING LAYER TOPICS ─────────────────────────────────────────
echo [FEATURE_ENG] Creating engineered_features ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic engineered_features --bootstrap-server %BOOTSTRAP% --partitions 3 --replication-factor 1 --if-not-exists 2>nul
echo [FEATURE_ENG] Creating feature_audit_logs ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic feature_audit_logs --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul
echo [FEATURE_ENG] Creating feature_retry_queue ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic feature_retry_queue --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul
echo [FEATURE_ENG] Creating feature_dead_letter_queue ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic feature_dead_letter_queue --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul
echo [FEATURE_ENG] Creating training_feature_store ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic training_feature_store --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul
echo [FEATURE_ENG] Creating realtime_feature_store ...
call "%KAFKA_BIN%\kafka-topics.bat" --create --topic realtime_feature_store --bootstrap-server %BOOTSTRAP% --partitions 1 --replication-factor 1 --if-not-exists 2>nul

echo.
echo =============================================================================
echo   All topics created. Verifying...
echo =============================================================================
call "%KAFKA_BIN%\kafka-topics.bat" --list --bootstrap-server %BOOTSTRAP%
echo.
echo Done. All topics are ready.
echo =============================================================================
pause
