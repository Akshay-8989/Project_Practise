@echo off
REM =============================================================================
REM  AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM
REM  run_all.bat — Start full platform (Kafka + all 3 layers)
REM =============================================================================
REM  USAGE:
REM    run_all.bat              — starts with Kafka (default)
REM    run_all.bat --no-kafka   — skip Kafka start (Kafka already running)
REM    run_all.bat --batch      — run batch test mode, not consumer loop
REM =============================================================================
REM  EDIT THESE PATHS BEFORE FIRST RUN:
set KAFKA_HOME=C:\kafka
set PYTHON_EXE=python
REM  If using a venv:
REM    set PYTHON_EXE=venv\Scripts\python.exe
REM =============================================================================

setlocal enabledelayedexpansion

set KAFKA_BIN=%KAFKA_HOME%\bin\windows
set PLATFORM_ROOT=%~dp0
set SKIP_KAFKA=0
set BATCH_MODE=0

for %%A in (%*) do (
    if "%%A"=="--no-kafka" set SKIP_KAFKA=1
    if "%%A"=="--batch"    set BATCH_MODE=1
)

echo.
echo =============================================================================
echo   AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM
echo   Starting All Layers
echo =============================================================================
echo   Platform root : %PLATFORM_ROOT%
echo   Kafka home    : %KAFKA_HOME%
echo   Python        : %PYTHON_EXE%
echo   Skip Kafka    : %SKIP_KAFKA%
echo   Batch mode    : %BATCH_MODE%
echo =============================================================================
echo.

REM ── STEP 1: Start Zookeeper ───────────────────────────────────────────────────
if "%SKIP_KAFKA%"=="0" (
    echo [STEP 1/6] Starting Zookeeper...
    if not exist "%KAFKA_BIN%\zookeeper-server-start.bat" (
        echo [ERROR] Kafka not found at %KAFKA_HOME%
        echo         Update KAFKA_HOME at the top of this file.
        pause & exit /b 1
    )
    start "Zookeeper" cmd /k "%KAFKA_BIN%\zookeeper-server-start.bat" "%KAFKA_HOME%\config\zookeeper.properties"
    echo         Zookeeper window started. Waiting 8 seconds...
    timeout /t 8 /nobreak >nul
) else (
    echo [STEP 1/6] Zookeeper — SKIPPED (--no-kafka)
)

REM ── STEP 2: Start Kafka Broker ────────────────────────────────────────────────
if "%SKIP_KAFKA%"=="0" (
    echo [STEP 2/6] Starting Kafka Broker...
    start "Kafka Broker" cmd /k "%KAFKA_BIN%\kafka-server-start.bat" "%KAFKA_HOME%\config\server.properties"
    echo         Kafka window started. Waiting 12 seconds...
    timeout /t 12 /nobreak >nul
) else (
    echo [STEP 2/6] Kafka Broker — SKIPPED (--no-kafka)
)

REM ── STEP 3: Create Topics ─────────────────────────────────────────────────────
echo [STEP 3/6] Creating Kafka topics...
call "%PLATFORM_ROOT%setup_topics.bat" >nul 2>&1
echo         Topics created (or already exist).

REM ── STEP 4: Start Ingestion Layer ────────────────────────────────────────────
echo [STEP 4/6] Starting Ingestion Layer consumer...
if "%BATCH_MODE%"=="0" (
    start "Ingestion Layer" cmd /k "cd /d %PLATFORM_ROOT%ingestion && %PYTHON_EXE% consumer.py"
) else (
    echo         Batch mode — ingestion consumer not started.
)
timeout /t 4 /nobreak >nul

REM ── STEP 5: Start Preprocessing Layer ────────────────────────────────────────
echo [STEP 5/6] Starting Preprocessing Layer consumer...
if "%BATCH_MODE%"=="0" (
    start "Preprocessing Layer" cmd /k "cd /d %PLATFORM_ROOT%preprocessing && %PYTHON_EXE% app.py --consumer"
) else (
    echo         Batch mode — preprocessing consumer not started.
)
timeout /t 4 /nobreak >nul

REM ── STEP 6: Start Feature Engineering Layer ───────────────────────────────────
echo [STEP 6/6] Starting Feature Engineering Layer consumer...
if "%BATCH_MODE%"=="0" (
    start "Feature Engineering Layer" cmd /k "cd /d %PLATFORM_ROOT%feature_engineering && %PYTHON_EXE% app.py --consumer"
) else (
    echo         Batch mode — feature engineering consumer not started.
)

echo.
echo =============================================================================
echo   Platform started successfully!
echo.
echo   WINDOWS OPENED:
echo     [Zookeeper]               - Kafka coordination
echo     [Kafka Broker]            - Message broker
echo     [Ingestion Layer]         - Consumes: ingest_requests
echo                                 Publishes: normalized_documents,
echo                                            single_entity_docs,
echo                                            multi_entity_docs
echo     [Preprocessing Layer]     - Consumes: normalized_documents,
echo                                            single_entity_docs,
echo                                            multi_entity_docs
echo                                 Publishes: preprocessed_documents
echo     [Feature Engineering]     - Consumes: preprocessed_documents
echo                                 Publishes: engineered_features
echo.
echo   TO TEST: Run scripts\test_end_to_end.bat
echo   TO STOP: Run stop_all.bat
echo =============================================================================
echo.
pause
