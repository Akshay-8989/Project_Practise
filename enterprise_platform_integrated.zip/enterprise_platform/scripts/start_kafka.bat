@echo off
REM =============================================================================
REM  start_kafka.bat — Start Zookeeper + Kafka Broker only
REM  Run this FIRST before run_all.bat --no-kafka
REM =============================================================================

set KAFKA_HOME=C:\kafka
set KAFKA_BIN=%KAFKA_HOME%\bin\windows

echo Starting Zookeeper...
start "Zookeeper" cmd /k "%KAFKA_BIN%\zookeeper-server-start.bat" "%KAFKA_HOME%\config\zookeeper.properties"
timeout /t 8 /nobreak >nul

echo Starting Kafka Broker...
start "Kafka Broker" cmd /k "%KAFKA_BIN%\kafka-server-start.bat" "%KAFKA_HOME%\config\server.properties"
timeout /t 12 /nobreak >nul

echo Kafka is running. Now run: setup_topics.bat
