#!/usr/bin/env python3
"""
test_end_to_end.py
===================
Enterprise Sensitivity Classification Platform
End-to-End Integration Test (No Kafka required — batch mode)

Tests the complete pipeline:
  Sample Document → Ingestion → Preprocessing → Feature Engineering

Outputs JSON at each stage showing exact data transformation.

Usage:
  cd enterprise_platform
  python scripts/test_end_to_end.py
  python scripts/test_end_to_end.py --sample payroll   (default)
  python scripts/test_end_to_end.py --sample contract
  python scripts/test_end_to_end.py --all
"""

from __future__ import annotations
import sys
import os
import json
import time
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional

# ── Path setup ────────────────────────────────────────────────────────────────
PLATFORM_ROOT = Path(__file__).parent.parent
INGESTION_DIR    = PLATFORM_ROOT / "ingestion"
PREPROCESSING_DIR = PLATFORM_ROOT / "preprocessing"
FEATURE_ENG_DIR  = PLATFORM_ROOT / "feature_engineering"
SAMPLE_DIR       = PLATFORM_ROOT / "sample_data"
LOG_DIR          = PLATFORM_ROOT / "logs"

LOG_DIR.mkdir(exist_ok=True)


def banner(title: str):
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def section(title: str):
    print(f"\n{'─' * 60}")
    print(f"  {title}")
    print(f"{'─' * 60}")


def pretty(obj: Dict, max_chars: int = 1200) -> str:
    s = json.dumps(obj, indent=2, default=str)
    if len(s) > max_chars:
        s = s[:max_chars] + "\n  ... [truncated for display] ..."
    return s


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 1 — Ingestion Layer
# ─────────────────────────────────────────────────────────────────────────────

def run_ingestion(event_payload: Dict) -> Optional[Dict]:
    """Run ingestion layer's app.py pipeline on a raw event payload."""
    section("STAGE 1: INGESTION LAYER")
    print("  Input  : Raw event from source system (HRMS/ERP/CRM)")
    print("  Output : NormalizedDocument → Kafka topic: normalized_documents")
    print()

    # Add ingestion layer to sys.path
    if str(INGESTION_DIR) not in sys.path:
        sys.path.insert(0, str(INGESTION_DIR))

    # Change to ingestion dir so relative paths (logs/, uploads/) resolve
    original_cwd = os.getcwd()
    os.chdir(INGESTION_DIR)

    try:
        # Import ingestion app (lazy import so path is correct)
        import importlib
        import app as ingest_app
        importlib.reload(ingest_app)

        # Build IngestEvent from the payload
        from schema import IngestEvent, IngestSource

        # Write file content to uploads/ if provided inline
        file_content = event_payload.pop("file_content", None)
        file_name    = event_payload.get("file_name", "test_doc.txt")
        upload_path  = INGESTION_DIR / "uploads" / file_name

        if file_content:
            upload_path.write_text(file_content, encoding="utf-8")
            event_payload["storage_uri"] = str(upload_path)
            print(f"  Wrote test file → {upload_path}")

        event_payload.setdefault("ingest_source", IngestSource.FOLDER_WATCH.value)

        t0 = time.time()
        result = ingest_app.process_event(event_payload)
        elapsed = (time.time() - t0) * 1000

        if result.success:
            print(f"\n  ✅ Ingestion SUCCESS in {elapsed:.1f}ms")
            print(f"  Structure : {result.structure_type}")
            print(f"  Category  : {result.data_category}")
            print(f"  Segments  : {result.segment_count}")
            print(f"  Topics    : {result.topics_written}")

            # Return the last normalized document (for pipeline chaining)
            if hasattr(result, "_last_normalized"):
                return result._last_normalized
            return {"ingestion_result": result.__dict__, "storage_uri": str(upload_path)}
        else:
            print(f"\n  ❌ Ingestion FAILED: {result.failure_reason}")
            print(f"     Detail: {result.failure_detail}")
            return None

    except Exception as exc:
        print(f"\n  ❌ Ingestion error: {exc}")
        import traceback; traceback.print_exc()
        return None
    finally:
        os.chdir(original_cwd)
        # Remove ingestion from path to avoid conflicts
        if str(INGESTION_DIR) in sys.path:
            sys.path.remove(str(INGESTION_DIR))


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 2 — Preprocessing Layer  
# ─────────────────────────────────────────────────────────────────────────────

def run_preprocessing(normalized_payload: Dict) -> Optional[Dict]:
    """Run preprocessing pipeline on a NormalizedDocument payload."""
    section("STAGE 2: PREPROCESSING LAYER")
    print("  Input  : NormalizedDocument from topic: normalized_documents")
    print("  Output : PreprocessedDocument → Kafka topic: preprocessed_documents")
    print()

    if str(PREPROCESSING_DIR) not in sys.path:
        sys.path.insert(0, str(PREPROCESSING_DIR))

    original_cwd = os.getcwd()
    os.chdir(PREPROCESSING_DIR)

    try:
        import importlib
        import pipeline as pp_pipeline
        importlib.reload(pp_pipeline)

        t0 = time.time()
        result = pp_pipeline.run_pipeline(normalized_payload, source_topic="normalized_documents")
        elapsed = (time.time() - t0) * 1000

        if result.documents:
            doc = result.documents[0]
            doc_dict = doc.model_dump()

            print(f"  ✅ Preprocessing SUCCESS in {elapsed:.1f}ms")
            print(f"  Status       : {result.status}")
            print(f"  Chunks       : {result.chunks_produced}")
            print(f"  Language     : {doc_dict.get('language', {}).get('code', 'en')}")
            print(f"  PII Found    : {doc_dict.get('pii_entities', {}).get('total_count', 0)} entities")
            print(f"  Tokens       : {len(doc_dict.get('tokens', []))}")
            print(f"  Recm. Model  : {doc_dict.get('recommended_model', 'english_classifier_v1')}")
            print(f"  PII Hint     : {doc_dict.get('pii_policy_hint', 'Allow')}")

            # Show masked text excerpt
            masked = doc_dict.get("masked_text", "")
            if masked:
                print(f"\n  Masked text (first 300 chars):")
                print(f"  {masked[:300]}...")

            return doc_dict
        else:
            print(f"  ❌ Preprocessing FAILED: {result.failure_reason}")
            return None

    except Exception as exc:
        print(f"\n  ❌ Preprocessing error: {exc}")
        import traceback; traceback.print_exc()
        return None
    finally:
        os.chdir(original_cwd)
        if str(PREPROCESSING_DIR) in sys.path:
            sys.path.remove(str(PREPROCESSING_DIR))


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 3 — Feature Engineering Layer
# ─────────────────────────────────────────────────────────────────────────────

def run_feature_engineering(preprocessed_payload: Dict) -> Optional[Dict]:
    """Run feature engineering pipeline on a PreprocessedDocument payload."""
    section("STAGE 3: FEATURE ENGINEERING LAYER")
    print("  Input  : PreprocessedDocument from topic: preprocessed_documents")
    print("  Output : EngineeredFeatureSet → Kafka topic: engineered_features")
    print()

    if str(FEATURE_ENG_DIR) not in sys.path:
        sys.path.insert(0, str(FEATURE_ENG_DIR))

    original_cwd = os.getcwd()
    os.chdir(FEATURE_ENG_DIR)

    try:
        import importlib
        import pipeline as fe_pipeline
        importlib.reload(fe_pipeline)

        t0 = time.time()
        result = fe_pipeline.run_pipeline(preprocessed_payload)
        elapsed = (time.time() - t0) * 1000

        if result.feature_set:
            fs = result.feature_set.model_dump()

            serving = fs.get("serving_features", {})
            classical = fs.get("classical_features", {})
            embedding = fs.get("embedding_features", {})

            print(f"  ✅ Feature Engineering SUCCESS in {elapsed:.1f}ms")
            print(f"  Status          : {result.status}")
            print(f"  Combined Dim    : {serving.get('combined_dim', 0)}")
            print(f"  Embedding Dim   : {serving.get('embedding_dim', 0)}")
            print(f"  TF-IDF Features : {serving.get('tfidf_features', 0)}")
            print(f"  Dense Ready     : {serving.get('dense_vector_ready', False)}")
            print(f"  Embedding Ready : {serving.get('embedding_ready', False)}")
            print(f"  Language        : {fs.get('language', 'en')}")
            print(f"  PII Policy Hint : {fs.get('pii_policy_hint', 'Allow')}")
            print(f"  Structure Type  : {fs.get('structure_type', 'single')}")

            # Risk features
            risk = classical.get("risk_features", {})
            if risk:
                print(f"\n  Risk Features (Classification Signals):")
                for k, v in risk.items():
                    if isinstance(v, float):
                        print(f"    {k:<35}: {v:.4f}")
                    else:
                        print(f"    {k:<35}: {v}")

            return fs
        else:
            print(f"  ❌ Feature Engineering FAILED: {result.failure_reason}")
            return None

    except Exception as exc:
        print(f"\n  ❌ Feature Engineering error: {exc}")
        import traceback; traceback.print_exc()
        return None
    finally:
        os.chdir(original_cwd)
        if str(FEATURE_ENG_DIR) in sys.path:
            sys.path.remove(str(FEATURE_ENG_DIR))


# ─────────────────────────────────────────────────────────────────────────────
# Direct batch mode (bypasses ingestion — feeds preprocessing directly)
# ─────────────────────────────────────────────────────────────────────────────

def run_direct_pipeline(sample_name: str):
    """
    Run sample through Preprocessing + Feature Engineering directly.
    This is the reliable demo mode — no need for file parser setup.
    """
    banner(f"ENTERPRISE SENSITIVITY CLASSIFICATION PLATFORM — END-TO-END TEST")
    print(f"  Sample  : {sample_name}")
    print(f"  Mode    : Direct batch (Preprocessing → Feature Engineering)")
    print(f"  Time    : {datetime.utcnow().isoformat()}")

    # Load sample
    sample_path = SAMPLE_DIR / f"{sample_name}_sample.json"
    if not sample_path.exists():
        # Try preprocessing sample inputs
        sample_path = PREPROCESSING_DIR / "sample_inputs" / f"{sample_name}.json"
    if not sample_path.exists():
        print(f"\n[ERROR] Sample not found: {sample_name}")
        print(f"  Available samples in sample_data/:")
        for f in SAMPLE_DIR.glob("*.json"):
            print(f"    - {f.stem}")
        return

    with open(sample_path, encoding="utf-8") as f:
        raw_event = json.load(f)

    print(f"\n  Input file: {sample_path}")
    section("RAW INPUT DOCUMENT")
    print(f"  Source System  : {raw_event.get('source_system', '?')}")
    print(f"  Department     : {raw_event.get('department', '?')}")
    print(f"  Document Type  : {raw_event.get('document_type', '?')}")
    print(f"  File Name      : {raw_event.get('file_name', '?')}")
    content = raw_event.get("file_content", "")
    if content:
        print(f"\n  Content preview (first 400 chars):")
        print("  " + content[:400].replace("\n", "\n  "))

    # Build a NormalizedDocument-like payload for preprocessing
    # (simulating what ingestion would produce)
    import uuid
    normalized_payload = {
        "doc_id":         str(uuid.uuid4()),
        "parent_doc_id":  None,
        "event_id":       raw_event.get("event_id", str(uuid.uuid4())),
        "ingest_id":      str(uuid.uuid4()),
        "file_name":      raw_event.get("file_name", "test.txt"),
        "file_type":      raw_event.get("file_type", "txt"),
        "raw_text":       raw_event.get("file_content", ""),
        "text_content":   raw_event.get("file_content", ""),
        "structure_type": "single",
        "data_category":  "unstructured",
        "segment_index":  None,
        "total_segments": None,
        "business_metadata": {
            "document_id":   raw_event.get("event_id", ""),
            "source_system": raw_event.get("source_system", "UNKNOWN"),
            "department":    raw_event.get("department", "UNKNOWN"),
            "business_unit": raw_event.get("business_unit", "UNKNOWN"),
            "region":        raw_event.get("region", "UNKNOWN"),
            "owner":         raw_event.get("owner", "UNKNOWN"),
            "document_type": raw_event.get("document_type", "general"),
            "client_name":   raw_event.get("client_name", "UNKNOWN"),
            "source_channel":raw_event.get("source_channel", "UNKNOWN"),
            "created_at":    raw_event.get("created_at", ""),
            "tags":          raw_event.get("tags", []),
            "validation_issues": [],
            "is_complete":   True,
        },
        "technical_metadata": {
            "ingest_id":        str(uuid.uuid4()),
            "ingest_timestamp": datetime.utcnow().isoformat(),
            "ingest_source":    "folder_watch",
            "ingestion_version":"2.0.0",
            "file_name":        raw_event.get("file_name", "test.txt"),
            "file_size_bytes":  len(raw_event.get("file_content", "")),
            "mime_type":        "text/plain",
            "file_extension":   raw_event.get("file_type", "txt"),
            "checksum_sha256":  "",
            "parser_used":      "direct_text",
        },
    }

    # STAGE 2: Preprocessing
    preprocessed = run_preprocessing(normalized_payload)
    if not preprocessed:
        print("\n[PIPELINE STOPPED] Preprocessing failed.")
        return

    # STAGE 3: Feature Engineering
    features = run_feature_engineering(preprocessed)
    if not features:
        print("\n[PIPELINE STOPPED] Feature engineering failed.")
        return

    # ── Final Summary ────────────────────────────────────────────────────────
    banner("PIPELINE COMPLETE — FINAL OUTPUT SUMMARY")

    pii_entities = preprocessed.get("pii_entities", {})
    risk_features = features.get("classical_features", {}).get("risk_features", {})
    serving = features.get("serving_features", {})

    print(f"""
  Document ID     : {preprocessed.get('doc_id', '?')}
  Source System   : {normalized_payload['business_metadata']['source_system']}
  Document Type   : {normalized_payload['business_metadata']['document_type']}
  Language        : {preprocessed.get('language', {}).get('code', 'en')}
  Recommended Model: {preprocessed.get('recommended_model', '?')}

  ── PII Detection ──────────────────────────────────────────────────────
  Total PII Found : {pii_entities.get('total_count', 0)} entities
  PII Types       : {', '.join(pii_entities.get('detected_types', [])) or 'None'}
  Policy Hint     : {preprocessed.get('pii_policy_hint', 'Allow')}

  ── Feature Engineering ────────────────────────────────────────────────
  Combined Dim    : {serving.get('combined_dim', 0)} dimensions
  Embedding Dim   : {serving.get('embedding_dim', 0)} dimensions
  TF-IDF Features : {serving.get('tfidf_features', 0)} features
  Vector Ready    : {serving.get('dense_vector_ready', False)}

  ── Risk Signals (→ Classification Layer input) ─────────────────────────""")

    for k, v in list(risk_features.items())[:10]:
        if isinstance(v, float):
            print(f"  {k:<40}: {v:.4f}")
        else:
            print(f"  {k:<40}: {v}")

    print(f"""
  ── NEXT STEP ─────────────────────────────────────────────────────────
  The EngineeredFeatureSet above is published to Kafka topic:
    engineered_features

  The Classification Layer (future) will consume this and predict:
    → sensitivity_label  : Public | Internal | Confidential | Restricted
    → confidence_score   : [0.0 - 1.0]
    → evidence_tokens    : top-k PII/sensitive phrases
    → policy_action      : Allow | Encrypt | Restrict | Quarantine
    → audit_log_entry    : timestamped compliance record
  """)

    # Save full output to JSON
    output_path = LOG_DIR / f"e2e_test_{sample_name}_{int(time.time())}.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump({
            "test_run": datetime.utcnow().isoformat(),
            "sample": sample_name,
            "stages": {
                "stage2_preprocessing": preprocessed,
                "stage3_feature_engineering": features,
            }
        }, f, indent=2, default=str)

    print(f"  Full output saved: {output_path}")
    print("=" * 70)


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Enterprise Sensitivity Classification Platform — E2E Test"
    )
    parser.add_argument("--sample", default="hr_payroll",
                        choices=["hr_payroll", "financial_contract"],
                        help="Sample to test (default: hr_payroll)")
    parser.add_argument("--all", action="store_true",
                        help="Run all samples")
    args = parser.parse_args()

    if args.all:
        for name in ["hr_payroll", "financial_contract"]:
            run_direct_pipeline(name)
    else:
        run_direct_pipeline(args.sample)


if __name__ == "__main__":
    main()
