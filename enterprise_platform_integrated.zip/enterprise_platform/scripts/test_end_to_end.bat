@echo off
REM =============================================================================
REM  test_end_to_end.bat — Run end-to-end integration test (No Kafka needed)
REM =============================================================================
REM  Tests: Sample Document → Preprocessing → Feature Engineering
REM  No Kafka required. Pure batch mode.
REM =============================================================================

set PYTHON_EXE=python
set PLATFORM_ROOT=%~dp0..

echo.
echo =============================================================================
echo   AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM — E2E TEST
echo =============================================================================
echo.
echo Which sample to test?
echo   1. HR Payroll (Confidential - PAN, Salary, Employee ID)
echo   2. Financial Contract (Restricted - SSN, EIN, Contract Value)
echo   3. Both samples
echo.
set /p CHOICE=Enter choice (1/2/3) [default=1]: 

if "%CHOICE%"=="2" (
    %PYTHON_EXE% "%PLATFORM_ROOT%\scripts\test_end_to_end.py" --sample financial_contract
) else if "%CHOICE%"=="3" (
    %PYTHON_EXE% "%PLATFORM_ROOT%\scripts\test_end_to_end.py" --all
) else (
    %PYTHON_EXE% "%PLATFORM_ROOT%\scripts\test_end_to_end.py" --sample hr_payroll
)

echo.
echo Test complete. Check logs\ folder for full JSON output.
pause
