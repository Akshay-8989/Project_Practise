"""
config.py
==========
Environment-driven configuration for the Enterprise Preprocessing Layer.

All tunables are read from environment variables (or .env file).
Nothing is hardcoded. Production deploys set vars via CI/secrets manager.
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional, Set

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def _e(key: str, default: str = "") -> str:
    return os.environ.get(key, default)

def _eb(key: str, default: bool = False) -> bool:
    return _e(key, str(default)).lower() in ("true", "1", "yes")

def _ei(key: str, default: int = 0) -> int:
    try:
        return int(_e(key, str(default)))
    except ValueError:
        return default

def _ef(key: str, default: float = 0.0) -> float:
    try:
        return float(_e(key, str(default)))
    except ValueError:
        return default

def _elist(key: str, default: str = "") -> List[str]:
    raw = _e(key, default)
    return [x.strip() for x in raw.split(",") if x.strip()] if raw else []


# ─────────────────────────────────────────────────────────────────────────────
# Kafka
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class KafkaConfig:
    bootstrap_servers:  str  = field(default_factory=lambda: _e("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"))
    security_protocol:  str  = field(default_factory=lambda: _e("KAFKA_SECURITY_PROTOCOL", "PLAINTEXT"))
    ssl_cafile:   Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_CAFILE") or None)
    ssl_certfile: Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_CERTFILE") or None)
    ssl_keyfile:  Optional[str] = field(default_factory=lambda: _e("KAFKA_SSL_KEYFILE") or None)

    # Consumer
    group_id:           str  = field(default_factory=lambda: _e("KAFKA_CONSUMER_GROUP", "preprocessing_service_v1"))
    auto_offset_reset:  str  = field(default_factory=lambda: _e("KAFKA_AUTO_OFFSET_RESET", "earliest"))
    enable_auto_commit: bool = False
    max_poll_records:   int  = field(default_factory=lambda: _ei("KAFKA_MAX_POLL_RECORDS", 20))
    session_timeout_ms: int  = field(default_factory=lambda: _ei("KAFKA_SESSION_TIMEOUT_MS", 45000))

    # Producer
    acks:               str  = field(default_factory=lambda: _e("KAFKA_ACKS", "all"))
    retries:            int  = field(default_factory=lambda: _ei("KAFKA_RETRIES", 3))
    compression_type:   str  = field(default_factory=lambda: _e("KAFKA_COMPRESSION", "gzip"))
    enable_idempotence: bool = field(default_factory=lambda: _eb("KAFKA_ENABLE_IDEMPOTENCE", True))

    def _ssl_kwargs(self) -> dict:
        if self.security_protocol != "SSL":
            return {}
        return dict(ssl_cafile=self.ssl_cafile, ssl_certfile=self.ssl_certfile, ssl_keyfile=self.ssl_keyfile)

    def producer_kwargs(self) -> dict:
        return dict(
            bootstrap_servers   = self.bootstrap_servers,
            security_protocol   = self.security_protocol,
            acks                = self.acks,
            retries             = self.retries,
            compression_type    = self.compression_type,
            enable_idempotence  = self.enable_idempotence,
            **self._ssl_kwargs(),
        )

    def consumer_kwargs(self) -> dict:
        return dict(
            bootstrap_servers   = self.bootstrap_servers,
            security_protocol   = self.security_protocol,
            group_id            = self.group_id,
            auto_offset_reset   = self.auto_offset_reset,
            enable_auto_commit  = self.enable_auto_commit,
            max_poll_records    = self.max_poll_records,
            session_timeout_ms  = self.session_timeout_ms,
            **self._ssl_kwargs(),
        )


# ─────────────────────────────────────────────────────────────────────────────
# Topics
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TopicsConfig:
    # Input (from Ingestion Layer)
    normalized_docs:  str = field(default_factory=lambda: _e("TOPIC_NORMALIZED_DOCUMENTS", "normalized_documents"))
    single_entity:    str = field(default_factory=lambda: _e("TOPIC_SINGLE_ENTITY_DOCS",   "single_entity_docs"))
    multi_entity:     str = field(default_factory=lambda: _e("TOPIC_MULTI_ENTITY_DOCS",     "multi_entity_docs"))

    # Output
    preprocessed:     str = field(default_factory=lambda: _e("TOPIC_PREPROCESSED_DOCS",    "preprocessed_documents"))
    audit_logs:       str = field(default_factory=lambda: _e("TOPIC_AUDIT_LOGS",            "preprocessing_audit_logs"))
    retry_queue:      str = field(default_factory=lambda: _e("TOPIC_RETRY_QUEUE",           "preprocessing_retry_queue"))
    dlq:              str = field(default_factory=lambda: _e("TOPIC_DLQ",                   "preprocessing_dead_letter_queue"))

    @property
    def input_topics(self) -> List[str]:
        return [self.normalized_docs, self.single_entity, self.multi_entity]


# ─────────────────────────────────────────────────────────────────────────────
# PII Masking
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PIIConfig:
    enabled:     bool       = field(default_factory=lambda: _eb("PII_MASKING_ENABLED", True))
    secure_mode: bool       = field(default_factory=lambda: _eb("PII_SECURE_MODE", False))
    types:       List[str]  = field(default_factory=lambda: _elist(
        "PII_TYPES_ENABLED",
        "EMAIL,PHONE,PAN,AADHAAR,SSN,IBAN,CREDIT_CARD,DOB,EMPLOYEE_ID,BANK_ACCOUNT",
    ))

    @property
    def enabled_types(self) -> Set[str]:
        return set(self.types) if self.types else {
            "EMAIL", "PHONE", "PAN", "AADHAAR", "SSN",
            "IBAN", "CREDIT_CARD", "DOB", "EMPLOYEE_ID", "BANK_ACCOUNT",
        }


# ─────────────────────────────────────────────────────────────────────────────
# Language Detection
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LanguageConfig:
    enabled:   bool = field(default_factory=lambda: _eb("LANGUAGE_DETECTION_ENABLED", True))
    min_chars: int  = field(default_factory=lambda: _ei("LANGUAGE_DETECTION_MIN_CHARS", 20))
    default:   str  = field(default_factory=lambda: _e("LANGUAGE_DEFAULT", "en"))

    # Language code → recommended model name (downstream Classification Layer)
    model_routing: dict = field(default_factory=lambda: {
        "en":    "english_classifier_v1",
        "hi":    "hindi_classifier_v1",
        "mr":    "multilingual_classifier_v1",
        "fr":    "multilingual_classifier_v1",
        "de":    "multilingual_classifier_v1",
        "es":    "multilingual_classifier_v1",
        "zh":    "multilingual_classifier_v1",
        "ar":    "multilingual_classifier_v1",
        "other": "multilingual_classifier_v1",
    })

    def get_model(self, lang_code: str) -> str:
        return self.model_routing.get(lang_code, self.model_routing["other"])


# ─────────────────────────────────────────────────────────────────────────────
# Tokenisation
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TokenizerConfig:
    backend:              str       = field(default_factory=lambda: _e("TOKENIZER_BACKEND", "nltk"))
    lemmatization:        bool      = field(default_factory=lambda: _eb("LEMMATIZATION_ENABLED", True))
    stopword_removal:     bool      = field(default_factory=lambda: _eb("STOPWORD_REMOVAL_ENABLED", False))
    custom_stopwords:     List[str] = field(default_factory=lambda: _elist("CUSTOM_STOPWORDS"))


# ─────────────────────────────────────────────────────────────────────────────
# Chunking
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ChunkingConfig:
    enabled:       bool = field(default_factory=lambda: _eb("CHUNKING_ENABLED", True))
    max_tokens:    int  = field(default_factory=lambda: _ei("CHUNK_MAX_TOKENS", 512))
    overlap_tokens:int  = field(default_factory=lambda: _ei("CHUNK_OVERLAP_TOKENS", 64))
    min_chars:     int  = field(default_factory=lambda: _ei("CHUNK_MIN_CHARS", 80))


# ─────────────────────────────────────────────────────────────────────────────
# Text Cleaning
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CleaningConfig:
    remove_html:          bool = field(default_factory=lambda: _eb("CLEANING_REMOVE_HTML", True))
    normalize_unicode:    bool = field(default_factory=lambda: _eb("CLEANING_NORMALIZE_UNICODE", True))
    remove_ocr_artifacts: bool = field(default_factory=lambda: _eb("CLEANING_REMOVE_OCR_ARTIFACTS", True))
    collapse_whitespace:  bool = field(default_factory=lambda: _eb("CLEANING_COLLAPSE_WHITESPACE", True))
    deduplicate_lines:    bool = field(default_factory=lambda: _eb("CLEANING_DEDUPLICATE_LINES", True))
    min_text_length:      int  = field(default_factory=lambda: _ei("CLEANING_MIN_TEXT_LENGTH", 10))
    max_text_length:      int  = field(default_factory=lambda: _ei("CLEANING_MAX_TEXT_LENGTH", 2_000_000))


# ─────────────────────────────────────────────────────────────────────────────
# Retry
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RetryConfig:
    max_attempts:       int   = field(default_factory=lambda: _ei("RETRY_MAX_ATTEMPTS", 3))
    backoff_seconds:    float = field(default_factory=lambda: _ef("RETRY_BACKOFF_SECONDS", 2.0))
    backoff_multiplier: float = field(default_factory=lambda: _ef("RETRY_BACKOFF_MULTIPLIER", 2.0))


# ─────────────────────────────────────────────────────────────────────────────
# App
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AppConfig:
    env:        str = field(default_factory=lambda: _e("APP_ENV", "development"))
    log_level:  str = field(default_factory=lambda: _e("LOG_LEVEL", "INFO"))
    log_file:   str = field(default_factory=lambda: _e("LOG_FILE", "logs/preprocessing.log"))
    version:    str = field(default_factory=lambda: _e("PREPROCESSING_VERSION", "1.0.0"))

    kafka:      KafkaConfig     = field(default_factory=KafkaConfig)
    topics:     TopicsConfig    = field(default_factory=TopicsConfig)
    pii:        PIIConfig       = field(default_factory=PIIConfig)
    language:   LanguageConfig  = field(default_factory=LanguageConfig)
    tokenizer:  TokenizerConfig = field(default_factory=TokenizerConfig)
    chunking:   ChunkingConfig  = field(default_factory=ChunkingConfig)
    cleaning:   CleaningConfig  = field(default_factory=CleaningConfig)
    retry:      RetryConfig     = field(default_factory=RetryConfig)


CONFIG = AppConfig()
