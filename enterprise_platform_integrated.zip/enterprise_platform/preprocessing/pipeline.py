"""
pipeline.py
============
Core Preprocessing Pipeline Orchestrator.

Wires all components in order:

  [1]  Validate schema           validator.validate_ingestion_payload()
  [2]  Clean text                cleaner.clean_text()
  [3]  Detect language           language_detector.detect_language()
  [4]  Mask PII                  pii_masker.mask_pii()
  [5]  Tokenise                  tokenizer.tokenize()
  [6]  Chunk (if long doc)       chunker.chunk_text()
  [7]  Compute stats             enricher.compute_stats()
  [8]  Compute risk signals      enricher.compute_risk_signals()
  [9]  Build PreprocessedDocument(s)
  [10] Publish to Kafka           producer
  [11] Write audit log            producer.send_audit()

For SINGLE documents: produces 1 PreprocessedDocument.
For MULTI segments:   produces 1 PreprocessedDocument per chunk.
For chunked docs:     produces N PreprocessedDocuments (one per chunk),
                      each with chunk_info.chunk_id and total_chunks.

Parent-child lineage is always preserved:
  - parent_doc_id carried from ingestion
  - chunk_info.chunk_id / total_chunks for within-document chunking
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from schema import (
    ChunkInfo,
    IngestionDocument,
    LanguageResult,
    PIIEntities,
    PreprocessedDocument,
    PreprocessingAudit,
    PreprocessingDLR,
    PreprocessingMetadata,
    ProcessingStatus,
    TextStats,
    ValidationResult,
)
from config import CONFIG
from logger import get_logger
from validator import validate_ingestion_payload
from cleaner import clean_text
from language_detector import detect_language
from pii_masker import mask_pii, get_policy_hint
from tokenizer import tokenize
from chunker import chunk_text, build_chunk_info, should_chunk
from enricher import compute_stats, compute_risk_signals, build_preprocessing_metadata

log = get_logger("pipeline")


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline result
# ─────────────────────────────────────────────────────────────────────────────

class PipelineResult:
    __slots__ = [
        "doc_id", "preprocess_id", "status", "documents",
        "audit", "dlr", "failure_reason", "failure_detail",
        "chunks_produced", "processing_time_ms",
    ]

    def __init__(self, doc_id: str = ""):
        self.doc_id             = doc_id
        self.preprocess_id      = str(uuid.uuid4())
        self.status             = ProcessingStatus.FAILED.value
        self.documents:         List[PreprocessedDocument] = []
        self.audit:             Optional[PreprocessingAudit] = None
        self.dlr:               Optional[PreprocessingDLR] = None
        self.failure_reason:    Optional[str] = None
        self.failure_detail:    Optional[str] = None
        self.chunks_produced:   int = 0
        self.processing_time_ms:float = 0.0

    def __repr__(self):
        if self.status == ProcessingStatus.SUCCESS.value:
            return (
                f"<OK  doc_id={self.doc_id} "
                f"chunks={self.chunks_produced} "
                f"time={self.processing_time_ms:.0f}ms>"
            )
        return (
            f"<FAIL doc_id={self.doc_id} "
            f"reason={self.failure_reason}: {self.failure_detail}>"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Main pipeline function
# ─────────────────────────────────────────────────────────────────────────────

def run_pipeline(
    raw_payload: Dict,
    source_topic: str = "normalized_documents",
) -> PipelineResult:
    """
    Execute the full preprocessing pipeline for one Kafka message.

    Args:
        raw_payload:  Deserialised Kafka message dict from Ingestion Layer.
        source_topic: Which Kafka topic this message arrived from.

    Returns:
        PipelineResult with status, list of PreprocessedDocument(s), and audit record.
    """
    start_time      = time.monotonic()
    result          = PipelineResult()
    pipeline_steps: List[str] = []
    step_warnings:  Dict[str, str] = {}

    # ─────────────────────────────────────────────────────────────────────
    # [1] Schema validation
    # ─────────────────────────────────────────────────────────────────────
    val_result, doc = validate_ingestion_payload(raw_payload)
    if not val_result.success:
        return _fail(
            result, raw_payload, source_topic,
            "SCHEMA_VALIDATION", val_result.failure_reason, val_result.failure_detail,
            start_time,
        )

    result.doc_id = doc.doc_id
    pipeline_steps.append("schema_validation")
    log.info(
        "[%s] Pipeline start | source=%s | structure=%s | chars=%d",
        doc.doc_id, doc.business_metadata.source_system,
        doc.structure_type, len(doc.raw_text),
    )

    # ─────────────────────────────────────────────────────────────────────
    # [2] Text cleaning
    # ─────────────────────────────────────────────────────────────────────
    try:
        clean, clean_warnings = clean_text(doc.raw_text, doc_id=doc.doc_id)
        pipeline_steps.append("text_cleaning")
        if clean_warnings:
            step_warnings["cleaner"] = "; ".join(clean_warnings)
    except Exception as exc:
        return _fail(result, raw_payload, source_topic,
                     "CLEANING", "CLEAN_FAILED", str(exc), start_time)

    if len(clean.strip()) < CONFIG.cleaning.min_text_length:
        return _fail(result, raw_payload, source_topic,
                     "CLEANING", "EMPTY_AFTER_CLEAN",
                     f"Text became empty or too short after cleaning ({len(clean)} chars)",
                     start_time)

    # ─────────────────────────────────────────────────────────────────────
    # [3] Language detection
    # ─────────────────────────────────────────────────────────────────────
    try:
        lang = detect_language(clean, doc_id=doc.doc_id)
        pipeline_steps.append("language_detection")
    except Exception as exc:
        log.warning("[%s] Language detection failed: %s — using default", doc.doc_id, exc)
        from schema import LanguageResult
        lang = LanguageResult()
        step_warnings["language"] = str(exc)
    
    # ─────────────────────────────────────────────────────────────────────
    # [4] PII detection + masking
    # ─────────────────────────────────────────────────────────────────────
    try:
        masked, pii_entities, pii_matches = mask_pii(clean, doc_id=doc.doc_id)
        policy_hint = get_policy_hint(pii_entities)
        pipeline_steps.append("pii_masking")
    except Exception as exc:
        log.warning("[%s] PII masking failed: %s — using unmasked text", doc.doc_id, exc)
        masked = clean
        from schema import PIIEntities
        pii_entities = PIIEntities()
        policy_hint  = "Allow"
        step_warnings["pii_masker"] = str(exc)

    # ─────────────────────────────────────────────────────────────────────
    # [5] Tokenisation
    # ─────────────────────────────────────────────────────────────────────
    try:
        tokens, sentences = tokenize(masked, doc_id=doc.doc_id)
        pipeline_steps.append("tokenization")
    except Exception as exc:
        log.warning("[%s] Tokenisation failed: %s", doc.doc_id, exc)
        tokens    = masked.split()
        sentences = [masked]
        step_warnings["tokenizer"] = str(exc)

    # ─────────────────────────────────────────────────────────────────────
    # [6] Chunking
    # ─────────────────────────────────────────────────────────────────────
    try:
        chunks = chunk_text(masked, sentences, doc_id=doc.doc_id)
        pipeline_steps.append("chunking")
    except Exception as exc:
        log.warning("[%s] Chunking failed: %s — using full text", doc.doc_id, exc)
        chunks = [masked]
        step_warnings["chunker"] = str(exc)

    # ─────────────────────────────────────────────────────────────────────
    # [7] Statistics
    # ─────────────────────────────────────────────────────────────────────
    stats = compute_stats(
        raw_text    = doc.raw_text,
        clean_text  = clean,
        masked_text = masked,
        tokens      = tokens,
        sentences   = sentences,
    )
    pipeline_steps.append("stats_computation")

    # ─────────────────────────────────────────────────────────────────────
    # [8] Risk signals
    # ─────────────────────────────────────────────────────────────────────
    risk_signals = compute_risk_signals(masked)
    pipeline_steps.append("risk_signals")

    # ─────────────────────────────────────────────────────────────────────
    # [9] Build PreprocessedDocument(s) — one per chunk
    # ─────────────────────────────────────────────────────────────────────
    preprocess_meta = build_preprocessing_metadata(
        preprocess_id  = result.preprocess_id,
        version        = CONFIG.version,
        pipeline_steps = pipeline_steps,
        step_warnings  = step_warnings,
        start_time     = start_time,
    )

    documents: List[PreprocessedDocument] = []
    total_chunks = len(chunks)

    for i, chunk in enumerate(chunks):
        chunk_info = build_chunk_info(
            chunk_index  = i,
            total_chunks = total_chunks,
            chunk_text   = chunk,
        )

        # For chunked docs, tokens are per-chunk
        chunk_tokens = chunk.split() if total_chunks > 1 else tokens

        pdoc = PreprocessedDocument(
            # Identity
            doc_id          = str(uuid.uuid4()) if total_chunks > 1 else doc.doc_id,
            parent_doc_id   = doc.doc_id if total_chunks > 1 else doc.parent_doc_id,
            event_id        = doc.event_id,
            ingest_id       = doc.technical_metadata.ingest_id,

            # Text
            clean_text      = clean if total_chunks == 1 else chunk,
            masked_text     = chunk,
            tokens          = chunk_tokens,
            sentence_chunks = chunks if total_chunks == 1 else [chunk],

            # Language
            language            = lang,
            recommended_model   = lang.recommended_model,

            # PII
            pii_entities    = pii_entities,
            pii_policy_hint = policy_hint,

            # Stats (full-doc stats on first chunk, chunk-specific otherwise)
            stats           = stats if i == 0 else TextStats(
                raw_chars   = len(doc.raw_text) if i == 0 else 0,
                clean_chars = len(chunk),
                masked_chars= len(chunk),
                token_count = len(chunk_tokens),
            ),

            # Lineage
            structure_type  = doc.structure_type,
            data_category   = doc.data_category,
            segment_index   = doc.segment_index,
            total_segments  = doc.total_segments,
            segment_type    = doc.segment_type,
            chunk_info      = chunk_info,

            # Metadata forwarded
            business_metadata = doc.business_metadata,

            # Provenance
            preprocessing   = preprocess_meta,

            # Status
            status          = (ProcessingStatus.SUCCESS.value
                               if not step_warnings
                               else ProcessingStatus.PARTIAL.value),
            status_detail   = "; ".join(step_warnings.values()) if step_warnings else None,
        )
        documents.append(pdoc)

    result.documents       = documents
    result.chunks_produced = len(documents)
    result.status          = ProcessingStatus.SUCCESS.value
    result.processing_time_ms = (time.monotonic() - start_time) * 1000

    # ─────────────────────────────────────────────────────────────────────
    # [11] Build audit record
    # ─────────────────────────────────────────────────────────────────────
    pii_types_found = [
        k for k, v in pii_entities.model_dump().items() if v > 0
    ]
    result.audit = PreprocessingAudit(
        doc_id              = doc.doc_id,
        ingest_id           = doc.technical_metadata.ingest_id,
        preprocess_id       = result.preprocess_id,
        source_topic        = source_topic,
        file_name           = doc.technical_metadata.file_name,
        source_system       = doc.business_metadata.source_system,
        department          = doc.business_metadata.department,
        status              = result.status,
        language            = lang.code,
        structure_type      = doc.structure_type,
        pii_types_found     = pii_types_found,
        pii_total_count     = pii_entities.total,
        pipeline_steps      = pipeline_steps,
        step_warnings       = step_warnings,
        chunks_produced     = len(documents),
        processing_time_ms  = result.processing_time_ms,
    )

    log.info(
        "[%s] Pipeline complete | chunks=%d | pii=%d | lang=%s | time=%.0fms | status=%s",
        doc.doc_id, len(documents), pii_entities.total,
        lang.code, result.processing_time_ms, result.status,
    )
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Failure helper
# ─────────────────────────────────────────────────────────────────────────────

def _fail(
    result:      PipelineResult,
    raw_payload: Dict,
    source_topic:str,
    stage:       str,
    reason:      str,
    detail:      str,
    start_time:  float,
) -> PipelineResult:
    elapsed = (time.monotonic() - start_time) * 1000
    result.failure_reason    = reason
    result.failure_detail    = detail
    result.processing_time_ms = elapsed

    doc_id    = raw_payload.get("doc_id", "")
    ingest_id = (raw_payload.get("technical_metadata") or {}).get("ingest_id", "")
    source    = (raw_payload.get("business_metadata") or {}).get("source_system", "UNKNOWN")

    result.dlr = PreprocessingDLR(
        doc_id          = doc_id,
        ingest_id       = ingest_id,
        source_topic    = source_topic,
        file_name       = (raw_payload.get("technical_metadata") or {}).get("file_name", ""),
        source_system   = source,
        failure_stage   = stage,
        failure_reason  = reason,
        failure_detail  = detail,
        original_payload= raw_payload,
    )

    result.audit = PreprocessingAudit(
        doc_id          = doc_id,
        ingest_id       = ingest_id,
        preprocess_id   = result.preprocess_id,
        source_topic    = source_topic,
        source_system   = source,
        status          = ProcessingStatus.FAILED.value,
        failure_reason  = reason,
        failure_detail  = detail,
        processing_time_ms = elapsed,
    )

    log.error(
        "[%s] Pipeline FAILED | stage=%s | reason=%s | %s",
        doc_id, stage, reason, detail,
    )
    return result
