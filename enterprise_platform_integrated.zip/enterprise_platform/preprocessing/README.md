# Enterprise Preprocessing Layer
## Automated Sensitivity Classification Platform — v1.0

---

## Where This Layer Sits

```
Source Systems  →  Ingestion Layer  →  [PREPROCESSING LAYER]  →  Feature Engineering  →  Classification
```

The Preprocessing Layer sits between the Ingestion Layer and the Feature Engineering / Classification layers.
It converts raw extracted text into clean, structured, ML-ready payloads.

---

## Full Pipeline Per Document

```
Kafka Message (from Ingestion Layer)
  normalized_documents | single_entity_docs | multi_entity_docs
            │
            ▼
  [1]  Schema Validation
       Pydantic parse of IngestionDocument
            │
            ▼
  [2]  Text Cleaning
       HTML removal | OCR artifacts | Unicode normalisation
       smart quotes | boilerplate stripping | whitespace collapse
       duplicate line removal | encoding repair (mojibake)
            │
            ▼
  [3]  Language Detection
       langdetect → langid → Unicode script heuristic → default
       Produces: language code + recommended_model
            │
            ▼
  [4]  PII Detection + Masking
       EMAIL → <EMAIL>   |   PAN → <PAN>   |   AADHAAR → <AADHAAR>
       PHONE → <PHONE>   |   SSN → <SSN>   |   IBAN → <IBAN>
       CREDIT_CARD → <CREDIT_CARD>   |   DOB → <DOB>
       EMPLOYEE_ID → <EMPLOYEE_ID>   |   BANK_ACCOUNT → <BANK_ACCOUNT>
            │
            ▼
  [5]  Tokenisation
       NLTK (default) or spaCy
       → word tokens (lemmatised, optional stopword removal)
       → sentence list (for transformer chunking)
            │
            ▼
  [6]  Chunking (long documents)
       Sentence-aware overlapping chunks
       Max 512 tokens per chunk, 64-token overlap
       Preserves parent-child lineage (chunk_id + total_chunks)
            │
            ▼
  [7]  Statistics
       raw_chars → clean_chars → reduction %
       token_count | sentence_count | word_count
            │
            ▼
  [8]  Risk Signals
       Keyword-based soft signals (restricted / confidential / internal)
       NOT classification — feature hints only
            │
            ▼
  [9]  Build PreprocessedDocument(s)
       One per chunk (N chunks for long docs)
            │
  ┌─────────┴──────────┐
  │                    │
preprocessed_documents  preprocessing_audit_logs
(Feature Eng consumes)  (Governance dashboard)
```

---

## Kafka Topics

| Topic | Direction | Purpose |
|---|---|---|
| `normalized_documents` | INPUT | All valid ingestion output |
| `single_entity_docs` | INPUT | Single-entity documents |
| `multi_entity_docs` | INPUT | Multi-entity segments |
| `preprocessed_documents` | OUTPUT | ML-ready payloads for Feature Engineering |
| `preprocessing_audit_logs` | OUTPUT | Compliance trail |
| `preprocessing_retry_queue` | OUTPUT | Failed docs within retry limit |
| `preprocessing_dead_letter_queue` | OUTPUT | Failed docs past retry limit |

---

## Output Schema (what Feature Engineering consumes)

```json
{
  "doc_id": "DOC-HRMS-2026-00441",
  "parent_doc_id": null,
  "event_id": "evt-20260418-hrms-001",
  "ingest_id": "ingest-001-uuid",

  "clean_text":   "Employee Joining Form Employee Name Rohan Sharma...",
  "masked_text":  "Employee Joining Form Employee Name Rohan Sharma Employee ID <EMPLOYEE_ID> Date of Birth <DOB> PAN <PAN> Aadhaar <AADHAAR> Personal Email <EMAIL> Mobile <PHONE> Bank Account <BANK_ACCOUNT>...",

  "tokens": ["employee", "joining", "form", "rohan", "sharma", "<employee_id>", "<dob>", "<pan>"],
  "sentence_chunks": [
    "Employee Joining Form Employee Name Rohan Sharma <EMPLOYEE_ID>...",
    "Designation Senior Data Engineer Department Engineering CTC INR..."
  ],

  "language": {
    "code": "en",
    "name": "English",
    "confidence": 0.9987,
    "recommended_model": "english_classifier_v1",
    "detection_method": "langdetect"
  },
  "recommended_model": "english_classifier_v1",

  "pii_entities": {
    "EMAIL": 1, "PHONE": 1, "PAN": 1, "AADHAAR": 1,
    "SSN": 0, "IBAN": 0, "CREDIT_CARD": 0,
    "DOB": 1, "EMPLOYEE_ID": 1, "BANK_ACCOUNT": 1
  },
  "pii_policy_hint": "Quarantine",

  "stats": {
    "raw_chars": 812, "clean_chars": 640, "masked_chars": 598,
    "raw_words": 148, "clean_words": 115, "token_count": 98,
    "sentence_count": 8, "reduction_pct": 21.2
  },

  "structure_type": "single",
  "data_category": "unstructured",
  "segment_index": null,
  "total_segments": null,
  "segment_type": "full_document",

  "chunk_info": {
    "is_chunked": false, "chunk_id": 0, "total_chunks": 1,
    "chunk_token_count": 98
  },

  "business_metadata": {
    "source_system": "HRMS", "department": "HR",
    "business_unit": "People Operations", "region": "India",
    "owner": "hr-team@initech.com", "document_type": "hr_record",
    "created_at": "2026-04-18", "tags": ["onboarding", "pii"]
  },

  "preprocessing": {
    "preprocess_id": "uuid",
    "preprocess_timestamp": "2026-04-18T10:30:15",
    "preprocess_version": "1.0.0",
    "pipeline_steps": ["schema_validation","text_cleaning","language_detection",
                       "pii_masking","tokenization","chunking","stats_computation","risk_signals"],
    "step_warnings": {},
    "processing_time_ms": 48.3
  },

  "status": "success"
}
```

---

## PII Masking Reference

| PII Type | Example Input | Masked Output | Severity |
|---|---|---|---|
| `AADHAAR` | `1234 5678 9012` | `<AADHAAR>` | Critical |
| `PAN` | `ABCDE1234F` | `<PAN>` | Critical |
| `SSN` | `123-45-6789` | `<SSN>` | Critical |
| `IBAN` | `GB29NWBK60161331926819` | `<IBAN>` | Critical |
| `CREDIT_CARD` | `4111111111111111` | `<CREDIT_CARD>` | Critical |
| `BANK_ACCOUNT` | `HDFC12345678901` | `<BANK_ACCOUNT>` | Critical |
| `EMAIL` | `john@company.com` | `<EMAIL>` | High |
| `PHONE` | `9876543210` | `<PHONE>` | High |
| `EMPLOYEE_ID` | `EMP-2026-00441` | `<EMPLOYEE_ID>` | High |
| `DOB` | `18/04/1990` | `<DOB>` | Medium |

Policy hint derived from PII presence:
- **Quarantine** — any Critical PII found
- **Restrict** — only High/Medium PII found
- **Allow** — no PII found

---

## Project Structure

```
enterprise_preprocessing/
│
├── app.py                  Batch / direct mode entry point (no Kafka needed for testing)
├── consumer.py             Kafka consumer loop (production mode)
├── pipeline.py             Core pipeline orchestrator
├── cleaner.py              Text normalisation (HTML, OCR, unicode, whitespace)
├── pii_masker.py           PII detection + masking (10 PII types)
├── language_detector.py    Language detection + model routing
├── tokenizer.py            Dual-path tokenisation (NLTK/spaCy)
├── chunker.py              Long-document chunking with overlap
├── enricher.py             Stats, risk signals, preprocessing metadata
├── validator.py            Schema + business rule validation
├── producer.py             Kafka producer wrapper
├── retry_handler.py        Exponential backoff + DLQ escalation
├── schema.py               All Pydantic models
├── config.py               Environment-driven configuration
├── logger.py               Rotating structured logger
│
├── .env.example            Environment config template
├── requirements.txt
│
├── sample_inputs/          Example ingestion payloads for testing
│   ├── hr_record_single.json
│   ├── email_segment_multi.json
│   └── financial_report_html.json
│
├── sample_outputs/         (created on first run)
└── logs/                   preprocessing.log (auto-created)
```

---

## Windows — Kafka Setup

If the Ingestion Layer Kafka is already running, skip to Step 5.

**Step 1: Start Zookeeper**
```cmd
cd C:\kafka
.\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties
```

**Step 2: Start Kafka Broker**
```cmd
cd C:\kafka
.\bin\windows\kafka-server-start.bat .\config\server.properties
```

**Step 3: Create preprocessing topics**
```cmd
cd C:\kafka

.\bin\windows\kafka-topics.bat --create --topic preprocessed_documents --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic preprocessing_audit_logs --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic preprocessing_retry_queue --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

.\bin\windows\kafka-topics.bat --create --topic preprocessing_dead_letter_queue --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
```

**Step 4: Verify topics**
```cmd
.\bin\windows\kafka-topics.bat --list --bootstrap-server localhost:9092
```

---

## Install Dependencies

```bash
pip install -r requirements.txt
```

Download NLTK data (one-time):
```python
python -c "import nltk; nltk.download('punkt'); nltk.download('punkt_tab'); nltk.download('wordnet'); nltk.download('stopwords')"
```

---

## How to Run

### Mode 1 — Test without Kafka (batch file mode)
```bash
# Process a single JSON payload file
python app.py --file sample_inputs/hr_record_single.json

# Process and save output
python app.py --file sample_inputs/financial_report_html.json --output sample_outputs/result.json

# Process all files in a folder
python app.py --folder sample_inputs/
```

### Mode 2 — Kafka consumer (production)
```bash
# Start the consumer (reads from ingestion layer topics)
python app.py --consumer
```

### Mode 3 — Direct Python usage
```python
from app import preprocess_payload
import json

with open("sample_inputs/hr_record_single.json") as f:
    payload = json.load(f)

result = preprocess_payload(payload)
print(result["masked_text"])
print(result["pii_entities"])
print(result["language"])
```

---

## Monitor Kafka Output (Windows)

```cmd
cd C:\kafka

# Watch preprocessed documents (what Feature Engineering will consume)
.\bin\windows\kafka-console-consumer.bat --topic preprocessed_documents --from-beginning --bootstrap-server localhost:9092

# Watch audit logs
.\bin\windows\kafka-console-consumer.bat --topic preprocessing_audit_logs --from-beginning --bootstrap-server localhost:9092
```

---

## Integration: Ingestion Layer → Preprocessing Layer

The Preprocessing Layer consumes exactly what the Ingestion Layer publishes.
The `IngestionDocument` schema in `schema.py` maps directly to `NormalizedDocument` from `enterprise_ingestion/schema.py`.

**No code changes needed between layers** — the Kafka topic is the integration contract.

---

## Integration: Preprocessing Layer → Feature Engineering Layer

The Feature Engineering Layer reads `preprocessed_documents` topic.

Key fields it uses:

| Field | Used for |
|---|---|
| `masked_text` | TF-IDF vectorisation, n-gram extraction |
| `tokens` | Bag-of-words features, classical ML |
| `sentence_chunks` | BERT/RoBERTa chunk inference |
| `language.code` | Routes to language-specific model |
| `recommended_model` | Tells classifier which model to load |
| `pii_entities` | Feature signals (PAN count, EMAIL count, etc.) |
| `pii_policy_hint` | Preliminary risk signal |
| `stats.token_count` | Document length feature |
| `business_metadata.department` | Prior signal for classification |
| `business_metadata.document_type` | Prior signal for classification |
| `chunk_info.chunk_id` / `total_chunks` | Chunk aggregation for long docs |

---

## Configuration Reference

All settings in `.env` (copy from `.env.example`):

| Variable | Default | Description |
|---|---|---|
| `PII_MASKING_ENABLED` | `true` | Enable/disable PII masking |
| `PII_TYPES_ENABLED` | all 10 types | Comma-separated list to enable |
| `TOKENIZER_BACKEND` | `nltk` | `nltk` or `spacy` |
| `LEMMATIZATION_ENABLED` | `true` | Apply WordNet lemmatisation |
| `STOPWORD_REMOVAL_ENABLED` | `false` | Remove NLTK stopwords |
| `CHUNKING_ENABLED` | `true` | Enable long-doc chunking |
| `CHUNK_MAX_TOKENS` | `512` | Tokens per chunk (BERT limit) |
| `CHUNK_OVERLAP_TOKENS` | `64` | Overlap between chunks |
| `LANGUAGE_DETECTION_ENABLED` | `true` | Enable language detection |
| `LANGUAGE_DEFAULT` | `en` | Fallback when detection fails |
| `CLEANING_REMOVE_HTML` | `true` | Strip HTML tags |
| `CLEANING_REMOVE_OCR_ARTIFACTS` | `true` | Remove OCR garbage |
| `CLEANING_DEDUPLICATE_LINES` | `true` | Remove consecutive duplicate lines |

---

## Future Extensibility

| Enhancement | How to add |
|---|---|
| **Microsoft Presidio PII** | Install presidio-analyzer, wrap in `pii_masker.py` as an alternative backend |
| **fastText language detection** | Add `_try_fasttext()` in `language_detector.py` — same interface |
| **Custom PII patterns** | Add new `PIIPattern` entries in `pii_masker.py` registry |
| **Hindi/Marathi stopwords** | Add language-specific stopword sets in `tokenizer.py` |
| **Async pipeline** | Replace consumer loop with `aiokafka` for higher throughput |
| **Presidio entity vault** | Implement SECURE_MODE in `pii_masker.py` to store encrypted originals |
| **New languages** | Add `model_routing` entries in `config.py` `LanguageConfig` |
