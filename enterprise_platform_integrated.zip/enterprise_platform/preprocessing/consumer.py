"""
consumer.py
============
Kafka Consumer for the Enterprise Preprocessing Layer.

Consumes from three input topics (published by the Ingestion Layer):
  - normalized_documents
  - single_entity_docs
  - multi_entity_docs

For each message:
  1. Deserialise payload
  2. Run preprocessing pipeline (pipeline.run_pipeline)
  3. Publish PreprocessedDocument(s) to preprocessed_documents
  4. Publish audit record
  5. Route failures to DLQ or retry_queue
  6. Manual offset commit after processing

Graceful shutdown on SIGINT / SIGTERM.
"""

from __future__ import annotations

import json
import signal
from typing import Dict

from kafka import KafkaConsumer
from kafka.errors import NoBrokersAvailable

from config import CONFIG
from logger import get_logger
from producer import PreprocessingProducer
from pipeline import run_pipeline
from schema import ProcessingStatus

log = get_logger("consumer")


def _deser(data: bytes) -> Dict:
    try:
        return json.loads(data.decode("utf-8")) if data else {}
    except Exception:
        return {}


class PreprocessingConsumer:
    """
    Consumes from Ingestion Layer topics and drives the preprocessing pipeline.
    """

    def __init__(self):
        self._running  = True
        self._producer = None
        self._consumer = None
        self._stats    = {"received": 0, "success": 0, "failed": 0, "chunks": 0}

        signal.signal(signal.SIGINT,  self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)

    def run(self):
        """Start the consumer loop. Blocks until shutdown."""
        try:
            self._producer = PreprocessingProducer()
            self._consumer = KafkaConsumer(
                *CONFIG.topics.input_topics,
                value_deserializer = _deser,
                key_deserializer   = lambda k: k.decode("utf-8") if k else None,
                **CONFIG.kafka.consumer_kwargs(),
            )
        except NoBrokersAvailable as exc:
            log.critical("Kafka unavailable: %s — start Kafka first", exc)
            raise

        log.info(
            "Preprocessing consumer started | topics=%s | group=%s",
            CONFIG.topics.input_topics, CONFIG.kafka.group_id,
        )

        try:
            for msg in self._consumer:
                if not self._running:
                    break
                self._handle_message(msg)
        finally:
            self._consumer.close()
            self._producer.close()
            log.info(
                "Consumer shutdown | received=%d success=%d failed=%d chunks=%d",
                self._stats["received"], self._stats["success"],
                self._stats["failed"], self._stats["chunks"],
            )

    def _handle_message(self, msg):
        self._stats["received"] += 1
        raw_payload = msg.value
        source_topic = msg.topic

        log.debug(
            "Received message | topic=%s partition=%d offset=%d",
            msg.topic, msg.partition, msg.offset,
        )

        # Run pipeline
        result = run_pipeline(raw_payload, source_topic=source_topic)

        if result.status == ProcessingStatus.SUCCESS.value or \
           result.status == ProcessingStatus.PARTIAL.value:
            self._stats["success"] += 1
            self._stats["chunks"] += result.chunks_produced

            # Publish all PreprocessedDocument chunks
            for pdoc in result.documents:
                self._producer.send_preprocessed(pdoc.model_dump())

            # Audit
            if result.audit:
                self._producer.send_audit(result.audit.model_dump())

            log.info("Processed: %s", result)

        else:
            self._stats["failed"] += 1

            # DLQ
            if result.dlr:
                self._producer.send_dlq(result.dlr.model_dump())

            # Audit
            if result.audit:
                self._producer.send_audit(result.audit.model_dump())

            log.warning("Failed: %s", result)

        # Manual commit — only after processing complete
        self._consumer.commit()

        # Periodic stats log
        if self._stats["received"] % 100 == 0:
            log.info(
                "Stats | recv=%d ok=%d fail=%d chunks=%d",
                self._stats["received"], self._stats["success"],
                self._stats["failed"], self._stats["chunks"],
            )

    def _handle_shutdown(self, *_):
        log.info("Shutdown signal — stopping after current message.")
        self._running = False
