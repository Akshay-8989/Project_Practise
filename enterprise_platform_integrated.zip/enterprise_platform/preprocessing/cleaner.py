"""
cleaner.py
===========
Enterprise text normalisation pipeline.

Handles all the messiness of real enterprise document text:
  - OCR artifacts (garbled characters, |||, §§§, random symbols)
  - HTML/XML remnants from email clients and DMS exports
  - Unicode oddities (zero-width chars, non-breaking spaces, smart quotes)
  - Excessive whitespace, tabs, mixed line endings (CRLF/LF)
  - Duplicate or near-duplicate consecutive lines (common in template docs)
  - Boilerplate / legal footer patterns
  - Encoding repair (mojibake: â€™ → ')

The cleaned text is the foundation for all subsequent steps.
PII masking happens AFTER cleaning so patterns are recognisable.

Output: clean_text (str) — ready for PII masking, tokenisation, chunking.
"""

from __future__ import annotations

import re
import unicodedata
from typing import List, Tuple

from config import CONFIG
from logger import get_logger

log = get_logger("cleaner")

# ─────────────────────────────────────────────────────────────────────────────
# Compiled patterns (module-level for performance)
# ─────────────────────────────────────────────────────────────────────────────

# HTML / XML tags
_HTML_TAG   = re.compile(r"<[^>]{0,200}>", re.DOTALL)
# HTML entities: &amp; &nbsp; &#160; etc.
_HTML_ENT   = re.compile(r"&(?:#\d+|#x[\da-fA-F]+|[a-zA-Z]{2,8});")
# Inline CSS / style blocks
_STYLE_BLCK = re.compile(r"<style[^>]*>.*?</style>", re.DOTALL | re.IGNORECASE)
# Script blocks
_SCRIPT_BLK = re.compile(r"<script[^>]*>.*?</script>", re.DOTALL | re.IGNORECASE)

# OCR artifact patterns
_OCR_ARTIFACTS = [
    re.compile(r"[|]{3,}"),                         # ||| lines (OCR column separators)
    re.compile(r"[_]{4,}"),                         # ____ underline lines
    re.compile(r"[=]{4,}"),                         # ==== separator lines (keep shorter ones)
    re.compile(r"[·•◦▪▫]{3,}"),                    # bullet runs
    re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]"), # control chars
    re.compile(r"[^\x00-\x7F\u00A0-\uD7FF\uE000-\uFFFD]"),  # surrogates / PUA
    re.compile(r"\ufffd+"),                         # replacement char runs
    re.compile(r"(?<!\w)(\w)\1{4,}(?!\w)"),         # character stutters: "aaaaa"
]

# Zero-width and invisible chars
_ZERO_WIDTH = re.compile(r"[\u200b\u200c\u200d\u200e\u200f\ufeff\u00ad]")

# Smart quotes → ASCII
_SMART_QUOTES = str.maketrans({
    "\u2018": "'", "\u2019": "'",
    "\u201c": '"', "\u201d": '"',
    "\u2013": "-", "\u2014": "-",
    "\u2026": "...",
    "\u00a0": " ",   # non-breaking space
    "\u00b7": "·",
})

# Repeated punctuation runs (artefacts of copy-paste or template fills)
_PUNCT_RUNS = re.compile(r"([.,;:!?])\1{3,}")

# Encoding repair: common mojibake pairs
_MOJIBAKE = [
    ("\u00e2\u0080\u0099", "'"),      # â€™ → '
    ("\u00e2\u0080\u009c", '"'),      # â€œ → "
    ("\u00e2\u0080\u009d", '"'),      # â€  → "
    ("\u00e2\u0080\u0093", "-"),      # â€" → –
    ("\u00e2\u0080\u0094", "-"),      # â€" → —
    ("\u00c2\u00a0", " "),            # Â  → NBSP
]

# Boilerplate patterns (legal footers, confidentiality notices)
_BOILERPLATE = re.compile(
    r"(?:^|\n)"
    r"(?:this (email|message|communication) (and any|contains)|"
    r"confidentiality notice|"
    r"this message is intended only for|"
    r"if you (have received|are not the intended)|"
    r"please (delete|destroy) (this|all copies)|"
    r"privileged and confidential|"
    r"do not (distribute|forward|copy) without|"
    r"unsubscribe at any time)"
    r".{0,500}",
    re.IGNORECASE | re.DOTALL,
)

# Excessive blank lines
_MULTI_BLANK = re.compile(r"\n{3,}")

# Horizontal tab → space
_TABS = re.compile(r"\t+")

# Trailing whitespace per line
_TRAIL_SPACE = re.compile(r"[ \t]+$", re.MULTILINE)

# Very long "words" with no spaces (likely garbled base64, hash, binary embed)
_GARBAGE_WORD = re.compile(r"\b[A-Za-z0-9+/]{80,}\b")


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def clean_text(raw: str, doc_id: str = "") -> Tuple[str, List[str]]:
    """
    Run the full cleaning pipeline on raw extracted text.

    Args:
        raw:    Raw text from the Ingestion Layer.
        doc_id: Used only for log messages.

    Returns:
        (clean_text, warnings)
        clean_text: normalised, de-noised text ready for PII masking.
        warnings:   list of non-fatal issues detected.
    """
    cfg      = CONFIG.cleaning
    text     = raw
    warnings: List[str] = []

    # ── Step 1: Encoding repair (mojibake) ───────────────────────────────
    for broken, fixed in _MOJIBAKE:
        text = text.replace(broken, fixed)

    # ── Step 2: HTML / script / style removal ────────────────────────────
    if cfg.remove_html:
        orig_len = len(text)
        text = _SCRIPT_BLK.sub(" ", text)
        text = _STYLE_BLCK.sub(" ", text)
        text = _HTML_TAG.sub(" ", text)
        text = _HTML_ENT.sub(" ", text)
        if len(text) < orig_len * 0.9:
            warnings.append(f"html_stripped:{orig_len - len(text)}_chars")

    # ── Step 3: Unicode normalisation ────────────────────────────────────
    if cfg.normalize_unicode:
        text = text.translate(_SMART_QUOTES)
        text = _ZERO_WIDTH.sub("", text)
        # NFC normalisation: compose canonical equivalents
        text = unicodedata.normalize("NFC", text)

    # ── Step 4: OCR artifact removal ─────────────────────────────────────
    if cfg.remove_ocr_artifacts:
        for pattern in _OCR_ARTIFACTS:
            text = pattern.sub(" ", text)
        text = _GARBAGE_WORD.sub(" <ENCODED_BLOCK> ", text)
        text = _PUNCT_RUNS.sub(r"\1", text)

    # ── Step 5: Boilerplate stripping ─────────────────────────────────────
    match = _BOILERPLATE.search(text)
    if match:
        warnings.append("boilerplate_footer_stripped")
        text = text[:match.start()].strip()

    # ── Step 6: Whitespace normalisation ─────────────────────────────────
    if cfg.collapse_whitespace:
        text = _TABS.sub(" ", text)
        text = _TRAIL_SPACE.sub("", text)
        # Collapse inline runs of spaces (but NOT newlines)
        text = re.sub(r" {2,}", " ", text)
        text = _MULTI_BLANK.sub("\n\n", text)
        # Normalise Windows CRLF
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        text = text.strip()

    # ── Step 7: Duplicate / near-duplicate line removal ───────────────────
    if cfg.deduplicate_lines:
        text, dups = _dedup_lines(text)
        if dups:
            warnings.append(f"duplicate_lines_removed:{dups}")

    log.debug(
        "[%s] Cleaning done: %d → %d chars (%.1f%% reduction)",
        doc_id, len(raw), len(text),
        (len(raw) - len(text)) / max(len(raw), 1) * 100,
    )
    return text, warnings


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _dedup_lines(text: str) -> Tuple[str, int]:
    """
    Remove consecutive duplicate lines (common in template documents,
    header/footer repetitions, OCR page restarts).
    Non-consecutive duplicates are kept — order matters for context.
    """
    lines  = text.split("\n")
    result = []
    prev   = None
    dups   = 0

    for line in lines:
        stripped = line.strip()
        if stripped and stripped == prev:
            dups += 1
            continue
        result.append(line)
        if stripped:
            prev = stripped

    return "\n".join(result), dups
