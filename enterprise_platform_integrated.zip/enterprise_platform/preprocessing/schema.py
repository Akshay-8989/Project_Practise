"""
schema.py
==========
Canonical Pydantic models for the Preprocessing Layer.

Model hierarchy:
  IngestionDocument      — what arrives from the Ingestion Layer (input)
  PreprocessedDocument   — the canonical output pushed to Kafka (output)
  PIIEntities            — PII detection summary per document
  ChunkInfo              — chunking lineage metadata
  TextStats              — before/after metrics
  LanguageResult         — language detection output
  PreprocessingAudit     — audit record for every document processed
  PreprocessingDLR       — dead-letter record for failed documents

Design contract:
  - The Feature Engineering Layer ONLY needs PreprocessedDocument
  - PreprocessedDocument.masked_text   → input for TF-IDF / transformers
  - PreprocessedDocument.tokens        → input for classical ML
  - PreprocessedDocument.sentence_chunks → input for BERT chunked inference
  - PreprocessedDocument.language      → routes to language-specific model
  - PreprocessedDocument.recommended_model → tells classifier which model to load
"""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


# ─────────────────────────────────────────────────────────────────────────────
# Enums
# ─────────────────────────────────────────────────────────────────────────────

class ProcessingStatus(str, Enum):
    SUCCESS  = "success"
    PARTIAL  = "partial"    # some steps failed but output is usable
    FAILED   = "failed"
    SKIPPED  = "skipped"    # e.g. document below min length threshold


class StructureType(str, Enum):
    SINGLE = "single"
    MULTI  = "multi"


class DataCategory(str, Enum):
    STRUCTURED      = "structured"
    SEMI_STRUCTURED = "semi_structured"
    UNSTRUCTURED    = "unstructured"


# ─────────────────────────────────────────────────────────────────────────────
# Input: what arrives from the Ingestion Layer
# ─────────────────────────────────────────────────────────────────────────────

class IngestionBusinessMetadata(BaseModel):
    """Business metadata subset forwarded from Ingestion Layer."""
    source_system:  str = "UNKNOWN"
    department:     str = "UNKNOWN"
    business_unit:  str = "UNKNOWN"
    region:         str = "UNKNOWN"
    owner:          str = "UNKNOWN"
    document_type:  str = "general"
    client_name:    str = "UNKNOWN"
    source_channel: str = "UNKNOWN"
    created_at:     Optional[str] = None
    tags:           List[str] = Field(default_factory=list)

    class Config:
        extra = "allow"    # accept any additional fields from ingestion


class IngestionTechnicalMetadata(BaseModel):
    """Technical metadata subset forwarded from Ingestion Layer."""
    ingest_id:          str = ""
    ingest_timestamp:   str = ""
    file_name:          str = ""
    file_size_bytes:    int = 0
    mime_type:          str = ""
    checksum_sha256:    str = ""
    parser_used:        str = ""
    parser_status:      str = "ok"
    structure_type:     str = StructureType.SINGLE.value
    data_category:      str = DataCategory.UNSTRUCTURED.value
    structure_signals:  List[str] = Field(default_factory=list)
    split_count:        int = 1

    class Config:
        extra = "allow"


class IngestionDocument(BaseModel):
    """
    Canonical schema of what the Ingestion Layer publishes.
    Maps to NormalizedDocument from enterprise_ingestion/schema.py.
    """
    doc_id:             str
    parent_doc_id:      Optional[str] = None
    event_id:           str = ""

    raw_text:           str
    segment_index:      Optional[int] = None
    total_segments:     Optional[int] = None
    segment_type:       Optional[str] = None

    structure_type:     str = StructureType.SINGLE.value
    data_category:      str = DataCategory.UNSTRUCTURED.value

    business_metadata:  IngestionBusinessMetadata  = Field(default_factory=IngestionBusinessMetadata)
    technical_metadata: IngestionTechnicalMetadata = Field(default_factory=IngestionTechnicalMetadata)

    @field_validator("raw_text")
    @classmethod
    def _text_present(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("raw_text cannot be empty")
        return v

    class Config:
        extra = "allow"


# ─────────────────────────────────────────────────────────────────────────────
# PII Entities summary
# ─────────────────────────────────────────────────────────────────────────────

class PIIEntities(BaseModel):
    """Count of each PII type detected in the document."""
    EMAIL:       int = 0
    PHONE:       int = 0
    PAN:         int = 0
    AADHAAR:     int = 0
    SSN:         int = 0
    IBAN:        int = 0
    CREDIT_CARD: int = 0
    DOB:         int = 0
    EMPLOYEE_ID: int = 0
    BANK_ACCOUNT:int = 0

    @property
    def total(self) -> int:
        return sum(self.model_dump().values())

    @property
    def has_restricted_pii(self) -> bool:
        """True if any high-severity PII is present (triggers Quarantine hint)."""
        return any([self.PAN, self.AADHAAR, self.SSN, self.IBAN,
                    self.CREDIT_CARD, self.BANK_ACCOUNT])

    @property
    def has_confidential_pii(self) -> bool:
        return any([self.EMAIL, self.PHONE, self.DOB, self.EMPLOYEE_ID])


# ─────────────────────────────────────────────────────────────────────────────
# Language detection result
# ─────────────────────────────────────────────────────────────────────────────

class LanguageResult(BaseModel):
    code:              str    = "en"      # ISO 639-1 code
    name:              str    = "English"
    confidence:        float  = 0.0       # 0.0–1.0
    recommended_model: str    = "english_classifier_v1"
    detection_method:  str    = "langdetect"


# ─────────────────────────────────────────────────────────────────────────────
# Text statistics
# ─────────────────────────────────────────────────────────────────────────────

class TextStats(BaseModel):
    raw_chars:      int = 0
    clean_chars:    int = 0
    masked_chars:   int = 0
    raw_words:      int = 0
    clean_words:    int = 0
    token_count:    int = 0
    sentence_count: int = 0
    reduction_pct:  float = 0.0    # (raw_chars - clean_chars) / raw_chars * 100


# ─────────────────────────────────────────────────────────────────────────────
# Chunk info
# ─────────────────────────────────────────────────────────────────────────────

class ChunkInfo(BaseModel):
    is_chunked:      bool = False
    chunk_id:        int  = 0      # 0-based index within parent
    total_chunks:    int  = 1
    chunk_token_count: int = 0
    chunk_char_start: Optional[int] = None
    chunk_char_end:   Optional[int] = None


# ─────────────────────────────────────────────────────────────────────────────
# Preprocessing metadata (generated by this layer)
# ─────────────────────────────────────────────────────────────────────────────

class PreprocessingMetadata(BaseModel):
    preprocess_id:       str   = Field(default_factory=lambda: str(uuid.uuid4()))
    preprocess_timestamp:str   = Field(default_factory=lambda: datetime.utcnow().isoformat())
    preprocess_version:  str   = "1.0.0"
    pipeline_steps:      List[str] = Field(default_factory=list)   # steps executed in order
    step_warnings:       Dict[str, str] = Field(default_factory=dict)   # step → warning msg
    processing_time_ms:  float = 0.0


# ─────────────────────────────────────────────────────────────────────────────
# OUTPUT: PreprocessedDocument — what Feature Engineering consumes
# ─────────────────────────────────────────────────────────────────────────────

class PreprocessedDocument(BaseModel):
    """
    The canonical output of the Preprocessing Layer.

    Published to: preprocessed_documents topic.

    The Feature Engineering Layer reads:
      masked_text       → TF-IDF vectorisation, n-gram extraction
      tokens            → classical ML features (bag-of-words, tf-idf)
      sentence_chunks   → transformer chunk inference (BERT/RoBERTa)
      language.code     → routes to language-specific model
      recommended_model → tells classifier which model variant to load
      pii_entities      → used as a feature signal by the classifier
      stats             → document statistics as additional features
      business_metadata → prior signals (department, doc_type, region)
    """

    # ── Identity (carried through from ingestion) ─────────────────────────
    doc_id:          str
    parent_doc_id:   Optional[str] = None
    event_id:        str = ""
    ingest_id:       str = ""         # from technical_metadata.ingest_id

    # ── Text representations ──────────────────────────────────────────────
    clean_text:      str              # normalised, de-noised, no PII removed
    masked_text:     str              # clean_text with PII replaced by tags
    tokens:          List[str] = Field(default_factory=list)   # word tokens (lemmatised if enabled)
    sentence_chunks: List[str] = Field(default_factory=list)   # semantic chunks for transformer inference

    # ── Language ──────────────────────────────────────────────────────────
    language:           LanguageResult = Field(default_factory=LanguageResult)
    recommended_model:  str = "english_classifier_v1"

    # ── PII summary ───────────────────────────────────────────────────────
    pii_entities:    PIIEntities = Field(default_factory=PIIEntities)
    pii_policy_hint: str = "Allow"    # Allow | Encrypt | Restrict | Quarantine

    # ── Document statistics ────────────────────────────────────────────────
    stats:           TextStats  = Field(default_factory=TextStats)

    # ── Structure / lineage (carried from ingestion) ──────────────────────
    structure_type:  str = StructureType.SINGLE.value
    data_category:   str = DataCategory.UNSTRUCTURED.value
    segment_index:   Optional[int] = None
    total_segments:  Optional[int] = None
    segment_type:    Optional[str] = None

    # ── Chunking metadata ─────────────────────────────────────────────────
    chunk_info:      ChunkInfo = Field(default_factory=ChunkInfo)

    # ── Metadata forwarded from ingestion ────────────────────────────────
    business_metadata: IngestionBusinessMetadata = Field(default_factory=IngestionBusinessMetadata)

    # ── Processing provenance ─────────────────────────────────────────────
    preprocessing:   PreprocessingMetadata = Field(default_factory=PreprocessingMetadata)

    # ── Status ────────────────────────────────────────────────────────────
    status:          str = ProcessingStatus.SUCCESS.value
    status_detail:   Optional[str] = None

    class Config:
        use_enum_values = True


# ─────────────────────────────────────────────────────────────────────────────
# Audit record
# ─────────────────────────────────────────────────────────────────────────────

class PreprocessingAudit(BaseModel):
    audit_id:            str   = Field(default_factory=lambda: str(uuid.uuid4()))
    doc_id:              str   = ""
    ingest_id:           str   = ""
    preprocess_id:       str   = ""
    source_topic:        str   = ""
    file_name:           str   = ""
    source_system:       str   = ""
    department:          str   = ""
    status:              str   = ProcessingStatus.SUCCESS.value
    language:            str   = "en"
    structure_type:      str   = ""
    pii_types_found:     List[str] = Field(default_factory=list)
    pii_total_count:     int   = 0
    pipeline_steps:      List[str] = Field(default_factory=list)
    step_warnings:       Dict[str, str] = Field(default_factory=dict)
    chunks_produced:     int   = 1
    processing_time_ms:  float = 0.0
    failure_reason:      Optional[str] = None
    failure_detail:      Optional[str] = None
    timestamp:           str   = Field(default_factory=lambda: datetime.utcnow().isoformat())


# ─────────────────────────────────────────────────────────────────────────────
# Dead letter record
# ─────────────────────────────────────────────────────────────────────────────

class PreprocessingDLR(BaseModel):
    dlr_id:          str = Field(default_factory=lambda: str(uuid.uuid4()))
    doc_id:          str = ""
    ingest_id:       str = ""
    source_topic:    str = ""
    file_name:       str = ""
    source_system:   str = ""
    failure_stage:   str = ""
    failure_reason:  str = ""
    failure_detail:  str = ""
    retry_count:     int = 0
    original_payload:Optional[Dict[str, Any]] = None
    failed_at:       str = Field(default_factory=lambda: datetime.utcnow().isoformat())


# ─────────────────────────────────────────────────────────────────────────────
# Validation result (internal helper)
# ─────────────────────────────────────────────────────────────────────────────

class ValidationResult(BaseModel):
    success:        bool
    failure_reason: Optional[str] = None
    failure_detail: Optional[str] = None

    @classmethod
    def ok(cls) -> "ValidationResult":
        return cls(success=True)

    @classmethod
    def fail(cls, reason: str, detail: str = "") -> "ValidationResult":
        return cls(success=False, failure_reason=reason, failure_detail=detail)
