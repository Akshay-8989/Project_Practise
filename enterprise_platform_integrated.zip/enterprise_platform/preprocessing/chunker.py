"""
chunker.py
===========
Long-document chunking for transformer inference.

BERT/RoBERTa/DeBERTa have a 512-token input limit.
Long documents must be split into overlapping chunks that:
  - Respect sentence boundaries (no mid-sentence splits)
  - Preserve logical context via configurable token overlap
  - Carry parent-child lineage (parent doc_id + chunk index)
  - Are the right size for downstream inference

Chunking strategy:
  1. Split text into sentences
  2. Greedily pack sentences into a chunk until max_tokens is reached
  3. On overflow: close current chunk, start new chunk with last N overlap tokens
  4. Final chunk: any remaining sentences

Overlap ensures context isn't lost at chunk boundaries.
This is the standard windowed chunking approach used in production NLP systems.

Output:
  List of chunk texts (sentence_chunks field in PreprocessedDocument)
  ChunkInfo metadata for each chunk published as its own Kafka message
"""

from __future__ import annotations

from typing import List, Tuple

from schema import ChunkInfo
from config import CONFIG
from logger import get_logger

log = get_logger("chunker")


def should_chunk(text: str) -> bool:
    """
    Decide whether a document needs chunking.
    Rough heuristic: 4 chars ≈ 1 token.
    """
    cfg = CONFIG.chunking
    if not cfg.enabled:
        return False
    estimated_tokens = len(text) // 4
    return estimated_tokens > cfg.max_tokens


def chunk_text(
    text:      str,
    sentences: List[str],
    doc_id:    str = "",
) -> List[str]:
    """
    Split text into overlapping sentence-aware chunks.

    Args:
        text:      Full masked text (used as fallback if sentences is empty).
        sentences: Pre-computed sentence list from tokenizer.py.
        doc_id:    For logging.

    Returns:
        List of chunk strings. Length ≥ 1 (single-chunk = full text for short docs).
    """
    cfg = CONFIG.chunking

    if not sentences:
        sentences = _split_by_newline(text)

    if not should_chunk(text):
        return [text]

    chunks   = []
    current_tokens: List[str] = []
    current_chars  = 0

    # Rough token estimation: whitespace-split words ≈ tokens
    def _word_count(s: str) -> int:
        return len(s.split())

    for sent in sentences:
        sent_tokens = _word_count(sent)
        sent_chars  = len(sent)

        if sent_chars < cfg.min_chars:
            # Too short to be its own sentence — append to current
            current_tokens.append(sent)
            current_chars += sent_chars
            continue

        # Check if adding this sentence would overflow
        current_count = sum(_word_count(s) for s in current_tokens)

        if current_count + sent_tokens > cfg.max_tokens and current_tokens:
            # Close current chunk
            chunks.append(" ".join(current_tokens))

            # Build overlap: last N overlap tokens worth of sentences
            overlap_budget = cfg.overlap_tokens
            overlap_sents  = []
            running        = 0
            for prev_sent in reversed(current_tokens):
                wc = _word_count(prev_sent)
                if running + wc <= overlap_budget:
                    overlap_sents.insert(0, prev_sent)
                    running += wc
                else:
                    break

            current_tokens = overlap_sents + [sent]
            current_chars  = sum(len(s) for s in current_tokens)
        else:
            current_tokens.append(sent)
            current_chars += sent_chars

    # Close final chunk
    if current_tokens:
        chunks.append(" ".join(current_tokens))

    log.debug("[%s] Chunked into %d chunks", doc_id, len(chunks))
    return chunks if chunks else [text]


def build_chunk_info(
    chunk_index:  int,
    total_chunks: int,
    chunk_text:   str,
    char_start:   int = 0,
) -> ChunkInfo:
    return ChunkInfo(
        is_chunked       = total_chunks > 1,
        chunk_id         = chunk_index,
        total_chunks     = total_chunks,
        chunk_token_count= len(chunk_text.split()),
        chunk_char_start = char_start,
        chunk_char_end   = char_start + len(chunk_text),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Helper
# ─────────────────────────────────────────────────────────────────────────────

def _split_by_newline(text: str) -> List[str]:
    """Fallback splitter when sentence list is empty."""
    return [line.strip() for line in text.split("\n") if line.strip()]
