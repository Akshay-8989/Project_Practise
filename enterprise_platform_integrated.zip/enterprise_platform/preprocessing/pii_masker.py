"""
pii_masker.py
==============
Enterprise PII Detection and Masking.

Detects and masks:
  EMAIL         john.doe@company.com  →  <EMAIL>
  PHONE         9876543210            →  <PHONE>
  PAN           ABCDE1234F            →  <PAN>
  AADHAAR       1234 5678 9012        →  <AADHAAR>
  SSN           123-45-6789           →  <SSN>
  IBAN          GB29NWBK60161331926819→  <IBAN>
  CREDIT_CARD   4111111111111111      →  <CREDIT_CARD>
  DOB           18/04/1990            →  <DOB>
  EMPLOYEE_ID   EMP-2024-00441        →  <EMPLOYEE_ID>
  BANK_ACCOUNT  HDFC12345678          →  <BANK_ACCOUNT>

Design:
  - Each PII type has its own compiled pattern (performance)
  - Patterns applied in severity order (Restricted-PII first)
  - Overlapping matches: earlier / longer match wins
  - All detections return (type, start, end, original_value)
  - Original values are discarded unless PII_SECURE_MODE=true
  - Returns: masked_text, PIIEntities count summary, List[PIIMatch]

Constraint C1 from PS: "No raw PII may be stored post-classification —
masking mandatory before persistence."
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Tuple

from schema import PIIEntities
from config import CONFIG
from logger import get_logger

log = get_logger("pii_masker")


# ─────────────────────────────────────────────────────────────────────────────
# PII pattern registry
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PIIPattern:
    name:    str
    pattern: re.Pattern
    tag:     str          # replacement tag e.g. <PAN>
    severity:int          # 1=low … 4=critical (matches sensitivity label scale)


# Patterns ordered high → low severity so high-severity matches shadow lower ones
_PATTERNS: List[PIIPattern] = [

    # ── Critical (map to Restricted) ─────────────────────────────────────

    PIIPattern("AADHAAR",
        re.compile(r"\b[2-9]\d{3}\s?\d{4}\s?\d{4}\b"),
        "<AADHAAR>", 4),

    PIIPattern("PAN",
        re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b"),
        "<PAN>", 4),

    PIIPattern("SSN",
        re.compile(r"\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b"),
        "<SSN>", 4),

    PIIPattern("IBAN",
        re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}(?:[A-Z0-9]?){0,16}\b"),
        "<IBAN>", 4),

    PIIPattern("CREDIT_CARD",
        re.compile(
            r"\b(?:4[0-9]{12}(?:[0-9]{3})?"          # Visa
            r"|5[1-5][0-9]{14}"                        # MC
            r"|3[47][0-9]{13}"                         # Amex
            r"|3(?:0[0-5]|[68][0-9])[0-9]{11}"       # Diners
            r"|6(?:011|5[0-9]{2})[0-9]{12})\b"        # Discover
        ),
        "<CREDIT_CARD>", 4),

    PIIPattern("BANK_ACCOUNT",
        re.compile(
            r"\b(?:"
            r"(?:HDFC|ICICI|SBI|AXIS|KOTAK|BOI|PNB|CANARA|UNION)\s*[-:]?\s*\d{8,18}"  # Indian banks
            r"|\d{9,18}"                               # generic account number
            r")\b",
            re.IGNORECASE,
        ),
        "<BANK_ACCOUNT>", 4),

    # ── High (map to Confidential) ────────────────────────────────────────

    PIIPattern("EMAIL",
        re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"),
        "<EMAIL>", 3),

    PIIPattern("PHONE",
        re.compile(
            r"\b(?:"
            r"(?:\+91[-\s]?)?[6-9]\d{9}"              # Indian mobile
            r"|(?:\+1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}"  # US
            r"|\+\d{1,3}[-\s]?\d{6,14}"               # international
            r")\b"
        ),
        "<PHONE>", 3),

    PIIPattern("EMPLOYEE_ID",
        re.compile(
            r"\b(?:"
            r"EMP[-_]?\d{4,10}"                       # EMP-2024-00441
            r"|EMPID[-_]?\d{4,10}"
            r"|E\d{5,10}"                             # E12345
            r"|[A-Z]{2,4}[-_]\d{4,10}"               # HR-001234
            r")\b",
            re.IGNORECASE,
        ),
        "<EMPLOYEE_ID>", 3),

    # ── Medium (map to Internal) ──────────────────────────────────────────

    PIIPattern("DOB",
        re.compile(
            r"\b(?:"
            r"(?:0[1-9]|[12]\d|3[01])[/\-.](?:0[1-9]|1[0-2])[/\-.](?:19|20)\d{2}"   # DD/MM/YYYY
            r"|(?:19|20)\d{2}[/\-.](?:0[1-9]|1[0-2])[/\-.](?:0[1-9]|[12]\d|3[01])"  # YYYY/MM/DD
            r")\b"
        ),
        "<DOB>", 2),
]


# ─────────────────────────────────────────────────────────────────────────────
# Match dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PIIMatch:
    pii_type:     str
    start:        int
    end:          int
    original:     str   # only populated in SECURE_MODE; otherwise ""
    tag:          str


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def mask_pii(
    text: str,
    doc_id: str = "",
) -> Tuple[str, PIIEntities, List[PIIMatch]]:
    """
    Detect and mask PII in text.

    Args:
        text:   Cleaned text (output from cleaner.py).
        doc_id: For logging.

    Returns:
        masked_text:  Text with PII replaced by placeholder tags.
        pii_entities: Count summary per PII type (for schema + audit).
        matches:      Ordered list of all matches found (for audit/secure mode).
    """
    if not CONFIG.pii.enabled:
        return text, PIIEntities(), []

    enabled = CONFIG.pii.enabled_types
    secure  = CONFIG.pii.secure_mode

    # ── Collect all non-overlapping matches ───────────────────────────────
    all_matches: List[PIIMatch] = []
    covered: List[Tuple[int, int]] = []    # (start, end) ranges already claimed

    for pdef in _PATTERNS:
        if pdef.name not in enabled:
            continue
        for m in pdef.pattern.finditer(text):
            start, end = m.start(), m.end()
            # Skip if overlaps with an already-claimed range
            if _overlaps(start, end, covered):
                continue
            covered.append((start, end))
            all_matches.append(PIIMatch(
                pii_type = pdef.name,
                start    = start,
                end      = end,
                original = m.group() if secure else "",
                tag      = pdef.tag,
            ))

    # ── Sort by start position, apply replacements right-to-left ──────────
    all_matches.sort(key=lambda m: m.start)
    masked = _apply_masks(text, all_matches)

    # ── Build entity count summary ────────────────────────────────────────
    counts: Dict[str, int] = {}
    for m in all_matches:
        counts[m.pii_type] = counts.get(m.pii_type, 0) + 1

    entities = PIIEntities(**{
        k: counts.get(k, 0) for k in PIIEntities.model_fields
    })

    if entities.total > 0:
        log.info(
            "[%s] PII masked: total=%d | types=%s",
            doc_id, entities.total,
            {k: v for k, v in counts.items()},
        )

    return masked, entities, all_matches


def get_policy_hint(entities: PIIEntities) -> str:
    """
    Derive a preliminary policy action from PII presence.
    The Classification Model may override this.

    Restricted PII (PAN/Aadhaar/SSN/IBAN/CC/BankAccount) → Quarantine
    Confidential PII (Email/Phone/DOB/EmployeeID)         → Restrict
    No PII                                                 → Allow
    """
    if entities.has_restricted_pii:
        return "Quarantine"
    if entities.has_confidential_pii:
        return "Restrict"
    return "Allow"


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _overlaps(start: int, end: int, covered: List[Tuple[int, int]]) -> bool:
    for cs, ce in covered:
        if start < ce and end > cs:
            return True
    return False


def _apply_masks(text: str, matches: List[PIIMatch]) -> str:
    """Apply replacements from right to left to preserve indices."""
    chars = list(text)
    for m in reversed(matches):
        chars[m.start:m.end] = list(m.tag)
    return "".join(chars)
