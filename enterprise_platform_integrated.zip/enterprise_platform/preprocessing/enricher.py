"""
enricher.py
============
Metadata enrichment and document statistics computation.

Runs after all text transformations are complete.
Adds:
  - TextStats (before/after metrics — char counts, word counts, reduction %)
  - Preprocessing metadata (pipeline steps, warnings, timing)
  - Inferred document type hints (for classifier as feature signals)
  - Computed risk signals from text content (keyword-based, no ML)

Risk signals are HINTS for the Classification Layer — they are not
the final sensitivity label. The model decides the label.
"""

from __future__ import annotations

import re
import time
from typing import Dict, List, Optional, Tuple

from schema import (
    IngestionDocument,
    PreprocessingMetadata,
    TextStats,
)
from config import CONFIG
from logger import get_logger

log = get_logger("enricher")


# ─────────────────────────────────────────────────────────────────────────────
# Keyword risk signals (used as soft features, not hard rules)
# These align with the sensitivity taxonomy from the PS
# ─────────────────────────────────────────────────────────────────────────────

_RESTRICTED_SIGNALS = re.compile(
    r"\b(?:restricted|top.?secret|classified|for official use only|"
    r"do not distribute|pci.?dss|hipaa|confidential.*?only|"
    r"trade.?secret|attorney.?client|privileged)\b",
    re.IGNORECASE,
)

_CONFIDENTIAL_SIGNALS = re.compile(
    r"\b(?:confidential|salary|compensation|performance review|"
    r"medical|diagnosis|treatment|legal.?opinion|merger|"
    r"acquisition|strategic.?plan|board.?meeting|"
    r"non.?disclosure|nda)\b",
    re.IGNORECASE,
)

_INTERNAL_SIGNALS = re.compile(
    r"\b(?:internal.?use|internal.?only|employee|hr.?policy|"
    r"company.?policy|org.?chart|headcount|budget.?internal|"
    r"internal.?memo|not.?for.?external)\b",
    re.IGNORECASE,
)

_FINANCIAL_SIGNALS = re.compile(
    r"\b(?:revenue|profit|loss|balance.?sheet|income.?statement|"
    r"cash.?flow|quarterly.?results|annual.?report|"
    r"ebitda|roi|p&l|financial.?data)\b",
    re.IGNORECASE,
)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def compute_stats(
    raw_text:    str,
    clean_text:  str,
    masked_text: str,
    tokens:      List[str],
    sentences:   List[str],
) -> TextStats:
    """Compute before/after text statistics."""
    raw_chars   = len(raw_text)
    clean_chars = len(clean_text)

    return TextStats(
        raw_chars      = raw_chars,
        clean_chars    = clean_chars,
        masked_chars   = len(masked_text),
        raw_words      = len(raw_text.split()),
        clean_words    = len(clean_text.split()),
        token_count    = len(tokens),
        sentence_count = len(sentences),
        reduction_pct  = round(
            (raw_chars - clean_chars) / max(raw_chars, 1) * 100, 2
        ),
    )


def compute_risk_signals(masked_text: str) -> Dict[str, int]:
    """
    Keyword-based risk signals (counts of matching terms).
    These are passed to the Classification Layer as auxiliary features.

    Note: This is NOT classification — it is feature enrichment.
    The ML model makes the final sensitivity label decision.
    """
    return {
        "restricted_signals":   len(_RESTRICTED_SIGNALS.findall(masked_text)),
        "confidential_signals": len(_CONFIDENTIAL_SIGNALS.findall(masked_text)),
        "internal_signals":     len(_INTERNAL_SIGNALS.findall(masked_text)),
        "financial_signals":    len(_FINANCIAL_SIGNALS.findall(masked_text)),
    }


def build_preprocessing_metadata(
    preprocess_id:    str,
    version:          str,
    pipeline_steps:   List[str],
    step_warnings:    Dict[str, str],
    start_time:       float,
) -> PreprocessingMetadata:
    """Build the preprocessing provenance record."""
    elapsed_ms = round((time.monotonic() - start_time) * 1000, 2)
    return PreprocessingMetadata(
        preprocess_id       = preprocess_id,
        preprocess_version  = version,
        pipeline_steps      = pipeline_steps,
        step_warnings       = step_warnings,
        processing_time_ms  = elapsed_ms,
    )
