"""
validator.py
=============
Validates IngestionDocument payloads received from the Ingestion Layer.

Two passes:
  Pass 1 — Schema validation   (Pydantic parsing)
  Pass 2 — Business rules      (text length, required fields, enum membership)

Validation failures → DLQ.  Warnings → audit log only.
"""

from __future__ import annotations

import json
from typing import Any, Dict, Tuple

from pydantic import ValidationError

from schema import IngestionDocument, ValidationResult
from config import CONFIG
from logger import get_logger

log = get_logger("validator")


def validate_ingestion_payload(raw: Dict[str, Any]) -> Tuple[ValidationResult, IngestionDocument | None]:
    """
    Parse and validate a raw Kafka message dict from the Ingestion Layer.

    Returns:
        (ValidationResult, IngestionDocument | None)
        IngestionDocument is None when validation fails.
    """

    # ── Pass 1: Pydantic schema parse ─────────────────────────────────────
    try:
        doc = IngestionDocument(**raw)
    except ValidationError as exc:
        errors = "; ".join(
            f"{e['loc']}: {e['msg']}" for e in exc.errors()
        )
        return ValidationResult.fail("SCHEMA_VALIDATION_ERROR", errors), None
    except Exception as exc:
        return ValidationResult.fail("PARSE_ERROR", str(exc)), None

    # ── Pass 2: Business rules ────────────────────────────────────────────

    # doc_id
    if not doc.doc_id or not doc.doc_id.strip():
        return ValidationResult.fail("EMPTY_DOC_ID", "doc_id must not be empty"), None

    # raw_text
    text = doc.raw_text.strip()
    if not text:
        return ValidationResult.fail("EMPTY_TEXT", "raw_text is empty"), None

    if len(text) < CONFIG.cleaning.min_text_length:
        return ValidationResult.fail(
            "TEXT_TOO_SHORT",
            f"{len(text)} chars — minimum is {CONFIG.cleaning.min_text_length}",
        ), None

    if len(text) > CONFIG.cleaning.max_text_length:
        return ValidationResult.fail(
            "TEXT_TOO_LONG",
            f"{len(text)} chars — maximum is {CONFIG.cleaning.max_text_length}",
        ), None

    # structure_type
    if doc.structure_type not in ("single", "multi"):
        return ValidationResult.fail(
            "INVALID_STRUCTURE_TYPE",
            f"Got '{doc.structure_type}' — expected 'single' or 'multi'",
        ), None

    # Warn (not fail) on missing metadata
    if doc.business_metadata.source_system in ("UNKNOWN", ""):
        log.warning("[%s] Missing business_metadata.source_system", doc.doc_id)
    if doc.business_metadata.department in ("UNKNOWN", ""):
        log.warning("[%s] Missing business_metadata.department", doc.doc_id)

    return ValidationResult.ok(), doc
