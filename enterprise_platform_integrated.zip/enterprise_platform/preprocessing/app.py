"""
app.py
=======
Standalone preprocessing entry point — for testing and batch processing
WITHOUT requiring a live Kafka consumer loop.

Useful for:
  - Unit testing individual pipeline steps
  - Batch preprocessing from JSON files
  - Integration testing against sample_inputs/
  - CI/CD pipeline validation

For production use: run consumer.py (Kafka-driven).
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

from config import CONFIG
from logger import get_logger
from pipeline import run_pipeline
from schema import ProcessingStatus

log = get_logger("app")


def preprocess_payload(payload: Dict) -> Dict:
    """
    Preprocess a single payload dict and return the result dict.
    Does NOT require Kafka. Used for testing and batch processing.
    """
    result = run_pipeline(payload, source_topic="direct_input")

    if not result.documents:
        return {
            "status":         result.status,
            "failure_reason": result.failure_reason,
            "failure_detail": result.failure_detail,
        }

    # Return first chunk (for single/short docs this is the only chunk)
    return result.documents[0].model_dump()


def preprocess_file(json_path: str) -> List[Dict]:
    """
    Load a JSON file containing one ingestion payload and preprocess it.
    Returns list of PreprocessedDocument dicts (one per chunk).
    """
    with open(json_path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    result = run_pipeline(payload, source_topic="file_input")
    return [doc.model_dump() for doc in result.documents]


def preprocess_folder(folder: str) -> List[Dict]:
    """
    Process all .json files in a folder as ingestion payloads.
    """
    results = []
    for fname in sorted(os.listdir(folder)):
        if not fname.endswith(".json"):
            continue
        fpath = os.path.join(folder, fname)
        log.info("Processing: %s", fname)
        try:
            docs = preprocess_file(fpath)
            results.extend(docs)
            log.info("  → %d chunk(s) from %s", len(docs), fname)
        except Exception as exc:
            log.error("  FAILED: %s — %s", fname, exc)
    return results


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Enterprise Preprocessing Layer — Direct/Batch mode"
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--file",   type=str, help="Path to a single JSON payload file")
    group.add_argument("--folder", type=str, help="Path to folder of JSON payload files")
    group.add_argument("--consumer", action="store_true", help="Start Kafka consumer loop")
    parser.add_argument("--output", type=str, help="Write output JSON to this path")
    args = parser.parse_args()

    if args.consumer:
        from consumer import PreprocessingConsumer
        PreprocessingConsumer().run()

    elif args.file:
        docs = preprocess_file(args.file)
        output = json.dumps(docs, indent=2, default=str)
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(output)
            print(f"Output written to {args.output}")
        else:
            print(output)

    elif args.folder:
        docs = preprocess_folder(args.folder)
        output = json.dumps(docs, indent=2, default=str)
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(output)
            print(f"Output written to {args.output} ({len(docs)} documents)")
        else:
            print(f"Processed {len(docs)} documents")
