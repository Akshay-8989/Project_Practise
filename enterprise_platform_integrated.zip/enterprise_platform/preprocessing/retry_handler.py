"""
retry_handler.py
=================
Retry logic with exponential backoff for the Preprocessing Layer.
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, Optional, Tuple, TypeVar

from config import CONFIG
from logger import get_logger

log = get_logger("retry_handler")
T = TypeVar("T")


def with_retry(
    func:     Callable[[], T],
    context:  Dict[str, Any],
    producer: Any,
    stage:    str = "unknown",
) -> Tuple[bool, Optional[T], Optional[str]]:
    """
    Execute func with exponential backoff retry.
    On persistent failure: send DLQ record and return (False, None, error).
    """
    max_att    = CONFIG.retry.max_attempts
    backoff    = CONFIG.retry.backoff_seconds
    multiplier = CONFIG.retry.backoff_multiplier
    last_err   = ""

    for attempt in range(1, max_att + 1):
        try:
            return True, func(), None
        except Exception as exc:
            last_err = str(exc)
            log.warning(
                "[%s] Attempt %d/%d FAILED | stage=%s | %s",
                context.get("doc_id", "?"), attempt, max_att, stage, exc,
            )
            if attempt < max_att:
                sleep = backoff * (multiplier ** (attempt - 1))
                log.info("[%s] Retrying in %.1fs", context.get("doc_id", "?"), sleep)
                time.sleep(sleep)

    # Exhausted — send to DLQ
    try:
        from schema import PreprocessingDLR
        dlr = PreprocessingDLR(
            doc_id         = context.get("doc_id", ""),
            ingest_id      = context.get("ingest_id", ""),
            source_topic   = context.get("source_topic", ""),
            source_system  = context.get("source_system", "UNKNOWN"),
            failure_stage  = stage,
            failure_reason = "MAX_RETRIES_EXCEEDED",
            failure_detail = last_err,
            retry_count    = max_att,
        )
        producer.send_dlq(dlr.model_dump())
    except Exception as dlq_exc:
        log.error("Failed to write DLQ: %s", dlq_exc)

    return False, None, last_err
