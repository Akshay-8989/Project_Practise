"""
logger.py
==========
Shared structured logger for all preprocessing modules.
"""

import logging
import os
import sys
from logging.handlers import RotatingFileHandler

_configured: set = set()


def get_logger(name: str = "preprocessing") -> logging.Logger:
    logger = logging.getLogger(name)
    if name in _configured:
        return logger
    _configured.add(name)

    try:
        from config import CONFIG
        level    = getattr(logging, CONFIG.log_level.upper(), logging.INFO)
        log_file = CONFIG.log_file
    except Exception:
        level    = logging.INFO
        log_file = "logs/preprocessing.log"

    logger.setLevel(level)
    logger.propagate = False

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)-28s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    try:
        os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)
        fh = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=5, encoding="utf-8")
        fh.setLevel(level)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except Exception as exc:
        logger.warning("Cannot open log file %s: %s", log_file, exc)

    return logger
