"""
language_detector.py
=====================
Enterprise language detection with model routing.

Detects the primary language of a document's clean text and maps it to the
correct downstream classification model.

Detection strategy (graceful degradation):
  1. langdetect  (probabilistic, good for short text)
  2. langid      (fast, no external dependency)
  3. Heuristic   (Unicode script analysis for Hindi/Marathi/Arabic/CJK)
  4. Default     (falls back to CONFIG.language.default, usually "en")

Language → model routing table is configurable in config.py:
  "en"    → english_classifier_v1
  "hi"    → hindi_classifier_v1
  "mr"    → multilingual_classifier_v1
  "fr"    → multilingual_classifier_v1
  other   → multilingual_classifier_v1

IMPORTANT: Language detection runs on masked_text (PII already removed)
to avoid false signals from structured PII tokens (Aadhaar digits, etc.)
"""

from __future__ import annotations

import re
from typing import Optional

from schema import LanguageResult
from config import CONFIG
from logger import get_logger

log = get_logger("language_detector")

# ISO 639-1 → English name
_LANG_NAMES: dict = {
    "en": "English", "hi": "Hindi", "mr": "Marathi",
    "fr": "French",  "de": "German","es": "Spanish",
    "zh": "Chinese", "ar": "Arabic","ja": "Japanese",
    "ko": "Korean",  "pt": "Portuguese", "it": "Italian",
    "ru": "Russian", "nl": "Dutch", "pl": "Polish",
    "unknown": "Unknown",
}

# Unicode range heuristics for script-based detection
_DEVANAGARI = re.compile(r"[\u0900-\u097F]")   # Hindi, Marathi, Sanskrit
_ARABIC     = re.compile(r"[\u0600-\u06FF]")
_CJK        = re.compile(r"[\u4E00-\u9FFF]")
_CYRILLIC   = re.compile(r"[\u0400-\u04FF]")
_HANGUL     = re.compile(r"[\uAC00-\uD7AF]")
_HIRAGANA   = re.compile(r"[\u3040-\u309F]")


def detect_language(text: str, doc_id: str = "") -> LanguageResult:
    """
    Detect the primary language of text.

    Args:
        text:   Masked text (PII already removed).
        doc_id: For logging.

    Returns:
        LanguageResult with code, name, confidence, recommended_model.
    """
    cfg = CONFIG.language

    if not cfg.enabled:
        return _build_result(cfg.default, 1.0, "disabled")

    if not text or len(text.strip()) < cfg.min_chars:
        log.debug("[%s] Text too short for language detection — using default", doc_id)
        return _build_result(cfg.default, 0.5, "too_short")

    # ── Method 1: langdetect ─────────────────────────────────────────────
    result = _try_langdetect(text)
    if result:
        log.debug("[%s] Language: %s (%.2f) via langdetect", doc_id, result.code, result.confidence)
        return result

    # ── Method 2: langid ─────────────────────────────────────────────────
    result = _try_langid(text)
    if result:
        log.debug("[%s] Language: %s (%.2f) via langid", doc_id, result.code, result.confidence)
        return result

    # ── Method 3: Unicode script heuristic ───────────────────────────────
    result = _script_heuristic(text)
    if result:
        log.debug("[%s] Language: %s via script heuristic", doc_id, result.code)
        return result

    # ── Fallback ──────────────────────────────────────────────────────────
    log.debug("[%s] Language detection fallback → %s", doc_id, cfg.default)
    return _build_result(cfg.default, 0.3, "fallback")


# ─────────────────────────────────────────────────────────────────────────────
# Detection backends
# ─────────────────────────────────────────────────────────────────────────────

def _try_langdetect(text: str) -> Optional[LanguageResult]:
    try:
        from langdetect import detect, detect_langs
        langs = detect_langs(text[:2000])       # use first 2000 chars for speed
        if langs:
            top = langs[0]
            code = top.lang
            conf = float(top.prob)
            if conf >= 0.6:                     # only trust high-confidence detections
                return _build_result(code, conf, "langdetect")
    except Exception:
        pass
    return None


def _try_langid(text: str) -> Optional[LanguageResult]:
    try:
        import langid
        code, conf = langid.classify(text[:2000])
        # langid returns negative log-prob; normalise to [0,1] heuristically
        normalised = min(1.0, abs(conf) / 100.0) if conf < 0 else min(1.0, conf)
        if normalised >= 0.5:
            return _build_result(code, normalised, "langid")
    except Exception:
        pass
    return None


def _script_heuristic(text: str) -> Optional[LanguageResult]:
    """Detect language from Unicode script presence."""
    total = max(len(text), 1)

    checks = [
        (_DEVANAGARI, "hi", "Devanagari_script"),
        (_CJK,        "zh", "CJK_script"),
        (_ARABIC,     "ar", "Arabic_script"),
        (_CYRILLIC,   "ru", "Cyrillic_script"),
        (_HANGUL,     "ko", "Hangul_script"),
        (_HIRAGANA,   "ja", "Hiragana_script"),
    ]
    for pattern, code, method in checks:
        count = len(pattern.findall(text))
        ratio = count / total
        if ratio > 0.15:                        # >15% chars in this script
            return _build_result(code, min(0.9, ratio * 2), method)

    return None


# ─────────────────────────────────────────────────────────────────────────────
# Builder
# ─────────────────────────────────────────────────────────────────────────────

def _build_result(code: str, confidence: float, method: str) -> LanguageResult:
    # Normalise: langdetect sometimes returns zh-cn, zh-tw etc.
    base_code = code.split("-")[0].lower() if code else CONFIG.language.default
    name      = _LANG_NAMES.get(base_code, "Unknown")
    model     = CONFIG.language.get_model(base_code)

    return LanguageResult(
        code              = base_code,
        name              = name,
        confidence        = round(confidence, 4),
        recommended_model = model,
        detection_method  = method,
    )
