"""
tokenizer.py
=============
Enterprise tokenisation layer.

Produces tokens for two downstream ML paths:

  Classical ML path (TF-IDF / n-grams):
    tokens = list of normalised word tokens
    Optional: lemmatisation, stopword removal

  Transformer path (BERT / RoBERTa / DeBERTa):
    sentence_chunks = list of semantically coherent text chunks
    Each chunk respects sentence boundaries
    (chunker.py handles max-token splitting)

Backend selection (config-driven):
  nltk  — default, fast, Windows-compatible, no model download needed
  spacy — richer lemmatisation, NER-aware tokenisation

Both backends produce the same output shape so the rest of the pipeline
does not need to know which was used.
"""

from __future__ import annotations

import re
import string
from typing import List, Tuple

from config import CONFIG
from logger import get_logger

log = get_logger("tokenizer")

# Sentence boundary splitter (handles Mr., Dr., vs., etc.)
_SENT_BOUNDARY = re.compile(
    r"(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|!)\s+"
)
_NON_ALPHA = re.compile(r"[^a-zA-Z0-9\s]")
_MULTI_SPACE = re.compile(r"\s+")


def tokenize(
    text: str,
    doc_id: str = "",
) -> Tuple[List[str], List[str]]:
    """
    Tokenise masked text.

    Args:
        text:   Masked text (PII already replaced with tags).
        doc_id: For logging.

    Returns:
        tokens          — word tokens (for classical ML)
        sentences       — sentence-split text chunks (for transformer path)
    """
    backend = CONFIG.tokenizer.backend.lower()

    if backend == "spacy":
        tokens, sentences = _tokenize_spacy(text, doc_id)
    else:
        tokens, sentences = _tokenize_nltk(text, doc_id)

    log.debug("[%s] Tokenised: %d tokens | %d sentences", doc_id, len(tokens), len(sentences))
    return tokens, sentences


# ─────────────────────────────────────────────────────────────────────────────
# NLTK backend (default)
# ─────────────────────────────────────────────────────────────────────────────

def _tokenize_nltk(text: str, doc_id: str) -> Tuple[List[str], List[str]]:
    """
    NLTK-based tokenisation.
    Falls back to simple whitespace tokenisation if NLTK is unavailable.
    """
    try:
        import nltk

        # Lazy-download required corpora (cached after first run)
        _ensure_nltk_data()

        # Sentence tokenisation
        from nltk.tokenize import sent_tokenize, word_tokenize
        sentences = sent_tokenize(text)

        # Word tokenisation
        raw_tokens = word_tokenize(text)

        # Apply processing pipeline
        tokens = _process_tokens_nltk(raw_tokens)

        return tokens, sentences

    except ImportError:
        log.warning("[%s] NLTK not installed — using fallback tokeniser", doc_id)
        return _fallback_tokenize(text)
    except Exception as exc:
        log.warning("[%s] NLTK tokenisation failed: %s — using fallback", doc_id, exc)
        return _fallback_tokenize(text)


def _process_tokens_nltk(raw_tokens: List[str]) -> List[str]:
    """Apply lemmatisation / stopword removal to NLTK word tokens."""
    cfg = CONFIG.tokenizer

    # Filter punctuation-only tokens
    tokens = [t for t in raw_tokens if not all(c in string.punctuation for c in t)]

    # Lowercase
    tokens = [t.lower() for t in tokens]

    # Remove pure numeric tokens (usually not informative for sensitivity classification)
    tokens = [t for t in tokens if not t.isdigit()]

    # Keep PII placeholder tags intact (e.g. <PAN>, <EMAIL>)
    # These are valuable features for the classifier
    # Don't strip angle brackets from tags
    def _is_pii_tag(t: str) -> bool:
        return t.startswith("<") and t.endswith(">")

    # Lemmatisation (optional)
    if cfg.lemmatization:
        try:
            from nltk.stem import WordNetLemmatizer
            lem = WordNetLemmatizer()
            tokens = [lem.lemmatize(t) if not _is_pii_tag(t) else t for t in tokens]
        except Exception:
            pass

    # Stopword removal (optional — disabled by default for sensitivity classification
    # because domain stopwords carry meaning: "restricted", "internal", "only")
    if cfg.stopword_removal:
        try:
            from nltk.corpus import stopwords
            stop = set(stopwords.words("english"))
            # Add custom stopwords from config
            stop.update(cfg.custom_stopwords)
            tokens = [t for t in tokens if t not in stop or _is_pii_tag(t)]
        except Exception:
            pass

    # Remove very short tokens (single chars) — but keep PII tags
    tokens = [t for t in tokens if len(t) > 1 or _is_pii_tag(t)]

    return tokens


def _ensure_nltk_data():
    """Download required NLTK corpora if not already present."""
    import nltk
    required = [
        ("tokenizers/punkt",          "punkt"),
        ("tokenizers/punkt_tab",      "punkt_tab"),
        ("corpora/wordnet",           "wordnet"),
        ("corpora/stopwords",         "stopwords"),
        ("taggers/averaged_perceptron_tagger", "averaged_perceptron_tagger"),
    ]
    for path, pkg in required:
        try:
            nltk.data.find(path)
        except LookupError:
            try:
                nltk.download(pkg, quiet=True)
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────────────────────
# spaCy backend (optional, richer)
# ─────────────────────────────────────────────────────────────────────────────

_spacy_nlp = None


def _get_spacy_nlp():
    global _spacy_nlp
    if _spacy_nlp is None:
        import spacy
        try:
            _spacy_nlp = spacy.load("en_core_web_sm")
        except OSError:
            log.warning("spaCy model 'en_core_web_sm' not found. "
                        "Run: python -m spacy download en_core_web_sm")
            _spacy_nlp = spacy.blank("en")
    return _spacy_nlp


def _tokenize_spacy(text: str, doc_id: str) -> Tuple[List[str], List[str]]:
    try:
        nlp = _get_spacy_nlp()
        doc = nlp(text[:100_000])   # spaCy has a default limit

        cfg = CONFIG.tokenizer
        tokens = []
        for token in doc:
            if token.is_punct or token.is_space:
                continue
            t = token.lemma_.lower() if cfg.lemmatization else token.lower_
            if cfg.stopword_removal and token.is_stop:
                continue
            if len(t) <= 1 and not t.startswith("<"):
                continue
            tokens.append(t)

        sentences = [sent.text.strip() for sent in doc.sents if sent.text.strip()]
        return tokens, sentences

    except ImportError:
        log.warning("[%s] spaCy not installed — using NLTK fallback", doc_id)
        return _tokenize_nltk(text, doc_id)
    except Exception as exc:
        log.warning("[%s] spaCy failed: %s — falling back to NLTK", doc_id, exc)
        return _tokenize_nltk(text, doc_id)


# ─────────────────────────────────────────────────────────────────────────────
# Fallback: pure Python tokenisation (no NLTK, no spaCy)
# ─────────────────────────────────────────────────────────────────────────────

def _fallback_tokenize(text: str) -> Tuple[List[str], List[str]]:
    """Simple regex-based fallback when NLP libraries are unavailable."""
    # Sentences
    sentences = [s.strip() for s in _SENT_BOUNDARY.split(text) if s.strip()]

    # Tokens
    cleaned = _NON_ALPHA.sub(" ", text.lower())
    tokens  = [t for t in _MULTI_SPACE.sub(" ", cleaned).split() if len(t) > 1]

    return tokens, sentences
