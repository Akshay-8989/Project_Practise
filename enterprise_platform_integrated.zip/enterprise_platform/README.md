# AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM

> Enterprise-grade document sensitivity classification — Ingestion → Preprocessing → Feature Engineering

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Quick Start (No Kafka)](#quick-start-no-kafka)
3. [Full Kafka Setup (Windows)](#full-kafka-setup-windows)
4. [Project Structure](#project-structure)
5. [Kafka Topics Reference](#kafka-topics-reference)
6. [Data Flow — Schema to Schema](#data-flow--schema-to-schema)
7. [Layer-by-Layer Codebase Audit](#layer-by-layer-codebase-audit)
8. [Configuration Guide](#configuration-guide)
9. [Sample End-to-End Output](#sample-end-to-end-output)
10. [Faculty Demo Guide](#faculty-demo-guide)
11. [Classification Layer — Next Steps](#classification-layer--next-steps)
12. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

```
Enterprise Source Systems
  (HRMS / ERP / CRM / SharePoint / Email / S3 / APIs)
           │
           ▼
┌──────────────────────────────────────────────────────────────────┐
│  INGESTION LAYER  (ingestion/)                                   │
│                                                                  │
│  Input  : ingest_requests (Kafka) / API upload / Folder watch   │
│  Parsers: PDF (pdfplumber), DOCX, CSV/XLSX, JSON, EML, TXT      │
│  Detect : Structure type (SINGLE vs MULTI entity)               │
│  Output : normalized_documents, single_entity_docs,             │
│           multi_entity_docs → Kafka                             │
└────────────────────────────┬─────────────────────────────────────┘
                             │ normalized_documents
                             │ single_entity_docs
                             │ multi_entity_docs
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│  PREPROCESSING LAYER  (preprocessing/)                           │
│                                                                  │
│  Input  : normalized_documents (Kafka)                           │
│  Clean  : HTML removal, Unicode normalization, OCR artifact fix  │
│  Mask   : PII (PAN, Aadhaar, SSN, IBAN, Email, Phone, DOB...)   │
│  Detect : Language (langdetect → route to model)                │
│  Chunk  : 512-token chunks with 64-token overlap                │
│  Output : preprocessed_documents → Kafka                        │
└────────────────────────────┬─────────────────────────────────────┘
                             │ preprocessed_documents
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│  FEATURE ENGINEERING LAYER  (feature_engineering/)              │
│                                                                  │
│  Input  : preprocessed_documents (Kafka)                         │
│  TF-IDF : 10,000-feature sparse vector (sklearn)                │
│  Embed  : Sentence embeddings (MiniLM-L6-v2 default)            │
│  Risk   : PII count, keyword signals, metadata priors           │
│  Output : engineered_features → Kafka                           │
└────────────────────────────┬─────────────────────────────────────┘
                             │ engineered_features
                             ▼
          [CLASSIFICATION LAYER — future]
          Predicts: Public | Internal | Confidential | Restricted
          Outputs : confidence + evidence + policy_action + audit_log
```

---

## Quick Start (No Kafka)

Test the full Preprocessing + Feature Engineering pipeline without Kafka:

```cmd
REM 1. Install dependencies
setup_venv.bat

REM 2. Run end-to-end test (batch mode — no Kafka needed)
scripts\test_end_to_end.bat

REM Or directly via Python:
venv\Scripts\python scripts\test_end_to_end.py --sample hr_payroll
venv\Scripts\python scripts\test_end_to_end.py --sample financial_contract
venv\Scripts\python scripts\test_end_to_end.py --all
```

---

## Full Kafka Setup (Windows)

### Prerequisites

| Component | Version | Link |
|-----------|---------|------|
| Python    | 3.10+   | https://www.python.org/downloads/ |
| Java      | 11+     | https://adoptium.net/ |
| Kafka     | 3.6.x   | https://kafka.apache.org/downloads |

### Step-by-Step

**Step 1 — Install Java 11+**
```cmd
winget install EclipseAdoptium.Temurin.11.JDK
java -version   # should show 11.x or higher
```

**Step 2 — Install Kafka**
```cmd
REM Download kafka_2.13-3.6.0.tgz from https://kafka.apache.org/downloads
REM Extract to C:\kafka
REM Your structure: C:\kafka\bin\windows\kafka-server-start.bat
```

**Step 3 — Edit KAFKA_HOME in batch files**
```
Open run_all.bat and setup_topics.bat
Change: set KAFKA_HOME=C:\kafka
To your actual path
```

**Step 4 — Install Python packages**
```cmd
setup_venv.bat
```

**Step 5 — Start platform**
```cmd
REM Full auto-start (starts Zookeeper + Kafka + all 3 layers):
run_all.bat

REM OR — manually step by step:
scripts\start_kafka.bat        # start Kafka
setup_topics.bat               # create all topics
REM Then in separate cmd windows:
cd ingestion   && venv\Scripts\python consumer.py
cd preprocessing && venv\Scripts\python app.py --consumer
cd feature_engineering && venv\Scripts\python app.py --consumer
```

**Step 6 — Send a test document**
```cmd
scripts\test_end_to_end.bat
```

**Step 7 — Stop everything**
```cmd
stop_all.bat
```

---

## Project Structure

```
enterprise_platform/
│
├── ingestion/                    # Layer 1 — Document Ingestion
│   ├── app.py                    # Pipeline orchestrator + folder watcher
│   ├── consumer.py               # Kafka consumer (ingest_requests)
│   ├── producer.py               # Kafka producer (all output topics)
│   ├── parser.py                 # PDF/DOCX/CSV/JSON/TXT parsers
│   ├── splitter.py               # SINGLE vs MULTI entity detection
│   ├── metadata_handler.py       # Business metadata resolution
│   ├── validator.py              # Event + payload validation
│   ├── retry_handler.py          # Retry with exponential backoff
│   ├── schema.py                 # NormalizedDocument, IngestEvent models
│   ├── config.py                 # Environment-driven configuration
│   ├── logger.py                 # Structured logging
│   ├── api.py                    # FastAPI upload endpoint (optional)
│   ├── main.py                   # Alternate entry (folder watch mode)
│   ├── .env                      # Layer-specific env vars
│   ├── logs/                     # ingestion.log
│   └── uploads/                  # Temp file storage
│
├── preprocessing/                # Layer 2 — Text Preprocessing
│   ├── app.py                    # Entry point (consumer or batch)
│   ├── consumer.py               # Kafka consumer (normalized_documents etc.)
│   ├── producer.py               # Kafka producer (preprocessed_documents)
│   ├── pipeline.py               # Main pipeline orchestrator
│   ├── cleaner.py                # HTML, Unicode, OCR artifact removal
│   ├── pii_masker.py             # PII detection + masking (regex-based)
│   ├── language_detector.py      # Language detection (langdetect)
│   ├── tokenizer.py              # NLTK tokenization + lemmatization
│   ├── chunker.py                # Sliding window chunker (512 tokens)
│   ├── enricher.py               # Stats, metadata enrichment
│   ├── validator.py              # Payload validation
│   ├── retry_handler.py          # Retry logic
│   ├── schema.py                 # PreprocessedDocument model
│   ├── config.py                 # Configuration
│   ├── logger.py                 # Logging
│   ├── .env                      # Layer-specific env vars
│   └── logs/                     # preprocessing.log
│
├── feature_engineering/          # Layer 3 — Feature Engineering
│   ├── app.py                    # Entry point (consumer or batch)
│   ├── consumer.py               # Kafka consumer (preprocessed_documents)
│   ├── producer.py               # Kafka producer (engineered_features)
│   ├── pipeline.py               # Main pipeline orchestrator
│   ├── tfidf_engine.py           # TF-IDF vectorizer (sklearn)
│   ├── embedding_engine.py       # Sentence embeddings (MiniLM/BERT)
│   ├── keyword_features.py       # PII/sensitivity keyword signals
│   ├── metadata_encoder.py       # One-hot encode business metadata
│   ├── stats_features.py         # Document statistics features
│   ├── chunk_aggregator.py       # Aggregate chunk embeddings (mean/max)
│   ├── feature_registry.py       # Feature name registry
│   ├── serializer.py             # Feature serialization
│   ├── validator.py              # Payload validation
│   ├── retry_handler.py          # Retry logic
│   ├── schema.py                 # EngineeredFeatureSet model
│   ├── config.py                 # Configuration
│   ├── logger.py                 # Logging
│   ├── .env                      # Layer-specific env vars
│   ├── logs/                     # feature_engineering.log
│   └── artifacts/                # Saved models/vectorizers
│       ├── vectorizers/          # TF-IDF vectorizer pickle
│       ├── encoders/             # Metadata encoders
│       ├── embedding_cache/      # Cached embeddings
│       └── training_store/       # Training feature sets
│
├── configs/
│   └── platform.env              # Master env config (all layers)
│
├── scripts/
│   ├── test_end_to_end.py        # E2E integration test
│   ├── test_end_to_end.bat       # Windows wrapper
│   └── start_kafka.bat           # Kafka-only startup
│
├── sample_data/
│   ├── hr_payroll_sample.json    # HR payroll test document (PAN, Salary)
│   └── financial_contract_sample.json  # Contract test document (SSN, EIN)
│
├── logs/                         # Platform-level logs
│
├── run_all.bat                   # START: Zookeeper + Kafka + all 3 layers
├── stop_all.bat                  # STOP: all processes
├── setup_topics.bat              # CREATE: all Kafka topics
├── setup_venv.bat                # INSTALL: Python venv + all packages
└── README.md                     # This file
```

---

## Kafka Topics Reference

### Complete Topic Map

| Topic | Producer | Consumer | Purpose |
|-------|----------|----------|---------|
| `ingest_requests` | External systems / API | Ingestion consumer | Trigger ingestion |
| `raw_documents` | Ingestion | Audit/Governance | Full raw history |
| `normalized_documents` | Ingestion | Preprocessing | Parsed + normalized docs |
| `single_entity_docs` | Ingestion | Preprocessing | Single-entity documents |
| `multi_entity_docs` | Ingestion | Preprocessing | Multi-entity doc segments |
| `audit_logs` | Ingestion | Governance dashboard | Ingestion audit trail |
| `retry_queue` | Ingestion | Ingestion retry consumer | Failed ingestion retries |
| `dead_letter_queue` | Ingestion | Ops team | Ingestion DLQ |
| `preprocessed_documents` | Preprocessing | Feature Engineering | Cleaned + masked docs |
| `preprocessing_audit_logs` | Preprocessing | Governance dashboard | Preprocessing audit |
| `preprocessing_retry_queue` | Preprocessing | — | Preprocessing retries |
| `preprocessing_dead_letter_queue` | Preprocessing | Ops | Preprocessing DLQ |
| `engineered_features` | Feature Engineering | Classification Layer | ML-ready feature vectors |
| `feature_audit_logs` | Feature Engineering | Governance | Feature audit trail |
| `feature_retry_queue` | Feature Engineering | — | Feature retries |
| `feature_dead_letter_queue` | Feature Engineering | Ops | Feature DLQ |
| `training_feature_store` | Feature Engineering | ML training pipeline | Training data |
| `realtime_feature_store` | Feature Engineering | Inference API | Realtime features |

### Consumer Groups

| Layer | Consumer Group ID |
|-------|------------------|
| Ingestion | `ingestion_service_v1` |
| Preprocessing | `preprocessing_service_v1` |
| Feature Engineering | `feature_engineering_service_v1` |

---

## Data Flow — Schema to Schema

### Stage 1: IngestEvent → NormalizedDocument

**Input** (from source system):
```json
{
  "event_id": "EVT-HR-001",
  "source_system": "HRMS",
  "department": "HR",
  "document_type": "payroll",
  "file_name": "payroll_april_2024.pdf",
  "storage_uri": "uploads/payroll_april_2024.pdf"
}
```

**Output** (normalized_documents topic):
```json
{
  "doc_id": "uuid-v4",
  "structure_type": "single",
  "data_category": "unstructured",
  "raw_text": "CONFIDENTIAL PAYROLL DOCUMENT...",
  "business_metadata": {
    "source_system": "HRMS",
    "department": "HR",
    "document_type": "payroll"
  },
  "technical_metadata": {
    "ingest_id": "uuid-v4",
    "ingest_timestamp": "2024-04-30T10:00:00Z",
    "file_size_bytes": 24567,
    "checksum_sha256": "abc123..."
  }
}
```

### Stage 2: NormalizedDocument → PreprocessedDocument

**Output** (preprocessed_documents topic):
```json
{
  "doc_id": "uuid-v4",
  "clean_text": "CONFIDENTIAL PAYROLL DOCUMENT Employee Payslip April 2024...",
  "masked_text": "CONFIDENTIAL PAYROLL DOCUMENT Employee Payslip April 2024 Employee ID [EMPLOYEE_ID] Name Rajesh Kumar PAN [PAN] Aadhaar [AADHAAR] Bank [BANK_ACCOUNT]...",
  "tokens": ["confidential", "payroll", "document", "employee", ...],
  "sentence_chunks": ["CONFIDENTIAL PAYROLL DOCUMENT...", "Employee ID [EMPLOYEE_ID]..."],
  "language": {"code": "en", "confidence": 0.99},
  "recommended_model": "english_classifier_v1",
  "pii_entities": {
    "total_count": 5,
    "detected_types": ["PAN", "AADHAAR", "BANK_ACCOUNT", "EMPLOYEE_ID", "PHONE"]
  },
  "pii_policy_hint": "Restrict",
  "stats": {"word_count": 284, "char_count": 1823}
}
```

### Stage 3: PreprocessedDocument → EngineeredFeatureSet

**Output** (engineered_features topic):
```json
{
  "doc_id": "uuid-v4",
  "classical_features": {
    "tfidf_vector": [0.12, 0.0, 0.34, ...],
    "risk_features": {
      "pii_count": 5,
      "pii_density": 0.018,
      "has_financial_keywords": true,
      "has_personal_keywords": true,
      "keyword_score": 0.75
    }
  },
  "embedding_features": {
    "vector": [0.023, -0.145, 0.312, ...],
    "model_used": "all-MiniLM-L6-v2",
    "dim": 384
  },
  "serving_features": {
    "combined_dim": 10384,
    "embedding_dim": 384,
    "tfidf_features": 10000
  },
  "pii_policy_hint": "Restrict",
  "recommended_model": "english_classifier_v1"
}
```

---

## Configuration Guide

Each layer reads from its own `.env` file. Key variables:

### Topic Handoff — Critical Alignment

The following topic names MUST match exactly across layers:

```
Ingestion publishes:         normalized_documents
Preprocessing consumes:      normalized_documents   ← MUST MATCH

Ingestion publishes:         single_entity_docs
Preprocessing consumes:      single_entity_docs     ← MUST MATCH

Preprocessing publishes:     preprocessed_documents
Feature Engineering consumes: preprocessed_documents ← MUST MATCH
```

### Consumer Group Isolation

Each layer has a **separate consumer group** — this is critical:

- `ingestion_service_v1` — reads `ingest_requests`
- `preprocessing_service_v1` — reads `normalized_documents`, `single_entity_docs`, `multi_entity_docs`
- `feature_engineering_service_v1` — reads `preprocessed_documents`

Do NOT reuse consumer group IDs across layers — it causes partition contention.

---

## Faculty Demo Guide

### How to explain the architecture

> "We built an enterprise document sensitivity classification platform. Think of it like a document security assembly line. A document enters the Ingestion Layer where it's parsed from any format — PDF, DOCX, CSV — and normalized. It then moves to the Preprocessing Layer where PII like PAN numbers and bank accounts are detected and masked, and the text is cleaned and tokenized. Finally, the Feature Engineering Layer converts the text into machine learning vectors using TF-IDF and sentence embeddings. All three layers communicate through Apache Kafka, which acts as a fault-tolerant message bus."

### Why Kafka?

1. **Decoupling** — Each layer is independently deployable. If Feature Engineering crashes, Preprocessing doesn't stop.
2. **Durability** — Messages persist on disk. If a service restarts, it replays from its last offset.
3. **Scale** — Add more consumer instances to handle higher document volume. Partitions distribute load automatically.
4. **Audit trail** — Every document's journey is recorded in dedicated audit topics. Regulatory compliance requires this.

### Why 3 separate layers?

1. **SRP (Single Responsibility)** — Ingestion does only parsing. Preprocessing does only text cleaning. Feature Engineering does only ML feature extraction.
2. **Independent scaling** — Feature Engineering (GPU-heavy) can scale independently from Ingestion (I/O-heavy).
3. **Independent deployment** — Update the PII masker without touching the vectorizer.
4. **Testability** — Each layer has its own test surface.

### Enterprise relevance

| Aspect | How this project addresses it |
|--------|------------------------------|
| GDPR compliance | PII masking mandatory (C1 constraint). Audit log per document. |
| PCI DSS | Credit card numbers masked. Restricted classification triggers Quarantine action. |
| CCPA | SSN, personal data detected and masked before any persistence. |
| Auditability | Every document produces an audit record (timestamped, with stage, status, error). |
| Governance | Sensitivity label drives access control in downstream DLP/CASB systems. |
| Explainability | Evidence tokens (top-k features) justify every classification — no black-box. |

### Why stronger than typical student projects?

- Real Kafka-based streaming architecture (not just a Python script)
- Production-grade retry logic + dead letter queues (ops-ready)
- PII masking with typed entity detection (compliance-ready)
- Modular layer design with schema contracts (enterprise-ready)
- Environment-driven config, no hardcoding (deployment-ready)
- Audit trail generation (governance-ready)

---

## Classification Layer — Next Steps

The next layer consumes `engineered_features` and predicts sensitivity:

### Recommended Model Architecture

```python
# Input: EngineeredFeatureSet.classical_features.combined_vector
# Output: sensitivity_label, confidence_score, evidence_tokens

models = {
    "baseline":    LogisticRegression(C=1.0, class_weight="balanced"),
    "tree":        XGBClassifier(n_estimators=300, use_label_encoder=False),
    "transformer": SentenceClassifier(base_model="microsoft/deberta-v3-base"),
}

# Ensemble via soft voting
ensemble = VotingClassifier(
    estimators=list(models.items()),
    voting="soft",
    weights=[0.2, 0.3, 0.5],
)
```

### Classification Output Schema

```json
{
  "doc_id": "uuid-v4",
  "sensitivity_label": "Restricted",
  "confidence": {
    "public": 0.01,
    "internal": 0.04,
    "confidential": 0.12,
    "restricted": 0.83
  },
  "evidence_tokens": ["PAN", "AADHAAR", "BANK_ACCOUNT", "salary", "confidential"],
  "policy_action": "Quarantine",
  "audit_log": {
    "classified_at": "2024-04-30T10:02:15Z",
    "model_version": "ensemble_v2",
    "override_applied": false
  }
}
```

### Evaluation Targets (from Problem Statement)

| Metric | Target | Type |
|--------|--------|------|
| Precision (Confidential) | ≥ 0.90 | HARD |
| Precision (Restricted) | ≥ 0.95 | HARD |
| Recall (Restricted) | ≥ 0.97 | HARD |
| F1-Macro | ≥ 0.88 | HARD |
| Latency p95 | < 200ms | SOFT |
| Explainability coverage | 100% (≥3 tokens) | HARD |

---

## Troubleshooting

### "NoBrokersAvailable" error
Kafka isn't running. Start it first:
```cmd
scripts\start_kafka.bat
```
Wait 15 seconds before starting the Python layers.

### "ModuleNotFoundError"
Virtual environment not activated or packages not installed:
```cmd
setup_venv.bat
```

### Consumer gets no messages
Check that topic names match exactly between layers. Run:
```cmd
C:\kafka\bin\windows\kafka-topics.bat --list --bootstrap-server localhost:9092
```

### NLTK punkt not found
```cmd
python -c "import nltk; nltk.download('punkt_tab'); nltk.download('wordnet')"
```

### Feature Engineering: TF-IDF not fitted
First time running, the TF-IDF vectorizer has no training data.
It will use an untrained vectorizer and produce a zero vector.
Fix: run with some documents first, or pre-fit:
```cmd
cd feature_engineering
python app.py --fit-tfidf ..\sample_data\corpus.txt
```

### Windows path issues
All paths use `pathlib.Path` — forward/backward slash agnostic.
If you see path errors, ensure you're running batch files from the `enterprise_platform\` directory.

---

*Built as part of the Enterprise Sensitivity Classification Platform.*
*Architecture: Kafka + Python 3.10 + sklearn + sentence-transformers + NLTK*
