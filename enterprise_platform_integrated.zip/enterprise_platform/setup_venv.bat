@echo off
REM =============================================================================
REM  setup_venv.bat — Create shared virtual environment + install all packages
REM =============================================================================
REM  Creates ONE venv in enterprise_platform\venv\ shared across all 3 layers.
REM  After this runs, update PYTHON_EXE in run_all.bat to: venv\Scripts\python.exe
REM =============================================================================

setlocal
set PLATFORM_ROOT=%~dp0

echo.
echo =============================================================================
echo   AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM
echo   Virtual Environment Setup
echo =============================================================================
echo.

REM Check Python version
python --version 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found on PATH.
    echo         Install Python 3.10+ from https://www.python.org/downloads/
    echo         Ensure "Add Python to PATH" is checked during installation.
    pause & exit /b 1
)

echo Creating virtual environment at: %PLATFORM_ROOT%venv
python -m venv "%PLATFORM_ROOT%venv"
if errorlevel 1 (
    echo [ERROR] Failed to create virtual environment.
    pause & exit /b 1
)

echo Activating virtual environment...
call "%PLATFORM_ROOT%venv\Scripts\activate.bat"

echo Upgrading pip...
python -m pip install --upgrade pip --quiet

echo.
echo Installing Ingestion Layer packages...
pip install -r "%PLATFORM_ROOT%ingestion\requirements.txt" --quiet
if errorlevel 1 echo [WARN] Some ingestion packages may have failed

echo Installing Preprocessing Layer packages...
pip install -r "%PLATFORM_ROOT%preprocessing\requirements.txt" --quiet
if errorlevel 1 echo [WARN] Some preprocessing packages may have failed

echo Installing Feature Engineering Layer packages...
pip install -r "%PLATFORM_ROOT%feature_engineering\requirements.txt" --quiet
if errorlevel 1 echo [WARN] Some feature engineering packages may have failed

echo.
echo Downloading NLTK data (required for tokenizer)...
python -c "import nltk; nltk.download('punkt', quiet=True); nltk.download('punkt_tab', quiet=True); nltk.download('wordnet', quiet=True); nltk.download('averaged_perceptron_tagger', quiet=True); print('NLTK data downloaded.')"

echo.
echo =============================================================================
echo   Setup Complete!
echo.
echo   NEXT STEPS:
echo   1. Edit run_all.bat — set PYTHON_EXE=venv\Scripts\python.exe
echo   2. Edit run_all.bat — set KAFKA_HOME=C:\kafka (your Kafka path)
echo   3. Install Java 11+ from https://adoptium.net/
echo   4. Download Kafka 3.x from https://kafka.apache.org/downloads
echo   5. Run: setup_topics.bat
echo   6. Run: scripts\test_end_to_end.bat  (test without Kafka)
echo   7. Run: run_all.bat                  (full streaming mode)
echo =============================================================================
echo.
pause
