@echo off
REM =============================================================================
REM  AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM
REM  stop_all.bat — Stop all platform processes
REM =============================================================================

setlocal

set KAFKA_HOME=C:\kafka
set KAFKA_BIN=%KAFKA_HOME%\bin\windows

echo.
echo =============================================================================
echo   AUTOMATED SENSITIVITY CLASSIFICATION PLATFORM
echo   Stopping All Layers
echo =============================================================================
echo.

REM ── Stop Python layer processes ───────────────────────────────────────────────
echo [1/3] Stopping Python layer processes...
REM Kill python processes running our consumers (by window title)
taskkill /FI "WINDOWTITLE eq Ingestion Layer" /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq Preprocessing Layer" /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq Feature Engineering Layer" /F >nul 2>&1
echo         Python layer processes stopped.

REM ── Stop Kafka Broker ─────────────────────────────────────────────────────────
echo [2/3] Stopping Kafka Broker...
if exist "%KAFKA_BIN%\kafka-server-stop.bat" (
    call "%KAFKA_BIN%\kafka-server-stop.bat" >nul 2>&1
    timeout /t 5 /nobreak >nul
)
taskkill /FI "WINDOWTITLE eq Kafka Broker" /F >nul 2>&1
echo         Kafka Broker stopped.

REM ── Stop Zookeeper ────────────────────────────────────────────────────────────
echo [3/3] Stopping Zookeeper...
if exist "%KAFKA_BIN%\zookeeper-server-stop.bat" (
    call "%KAFKA_BIN%\zookeeper-server-stop.bat" >nul 2>&1
    timeout /t 5 /nobreak >nul
)
taskkill /FI "WINDOWTITLE eq Zookeeper" /F >nul 2>&1
echo         Zookeeper stopped.

echo.
echo =============================================================================
echo   All platform processes stopped.
echo   Logs preserved in: ingestion\logs\, preprocessing\logs\, feature_engineering\logs\
echo =============================================================================
echo.
pause
