"""
document_processor.py
---------------------
FR1 – Document Upload
FR2 – Document Processing: text + image OCR extraction + chunking

Two extraction paths:
  1. Text extraction  — pdfplumber / pypdf  (always runs)
  2. Image OCR        — pdfplumber images + pytesseract (runs if tesseract installed)

If tesseract is not installed, image extraction is skipped gracefully
and a warning is shown — text extraction still works normally.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


# ── Data model ────────────────────────────────────────────────────────────────

@dataclass
class DocumentChunk:
    text:        str
    source_file: str
    page_number: int
    chunk_index: int
    doc_hash:    str
    chunk_type:  str = "text"          # "text" or "image_ocr"
    metadata:    dict = field(default_factory=dict)


# ── Utilities ─────────────────────────────────────────────────────────────────

def _file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _clean_text(raw: str) -> str:
    text = raw.replace("\x00", "")
    text = re.sub(r"[\r\n]+", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", "-").replace("\u2014", "--")
    return text.strip()


def _split_into_chunks(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    if len(text) <= chunk_size:
        return [text] if text.strip() else []
    chunks, start = [], 0
    while start < len(text):
        end = start + chunk_size
        if end >= len(text):
            chunk = text[start:].strip()
            if chunk:
                chunks.append(chunk)
            break
        search_start = max(start, end - chunk_size // 5)
        boundary = max(
            text.rfind(". ", search_start, end),
            text.rfind(".\n", search_start, end),
            text.rfind("\n\n", search_start, end),
        )
        if boundary != -1:
            end = boundary + 1
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - chunk_overlap
    return chunks


# ── OCR setup ─────────────────────────────────────────────────────────────────

def _setup_tesseract() -> bool:
    """
    Configure pytesseract path and verify it works.
    Returns True if OCR is available, False otherwise.
    """
    try:
        import pytesseract
        from src.config import TESSERACT_PATH

        if TESSERACT_PATH:
            pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH
        else:
            # Common Windows paths to auto-detect
            import platform
            if platform.system() == "Windows":
                common_paths = [
                    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                    r"D:\Tesseract-OCR\tesseract.exe",
                ]
                for p in common_paths:
                    if Path(p).exists():
                        pytesseract.pytesseract.tesseract_cmd = p
                        logger.info("Auto-detected Tesseract at: %s", p)
                        break

        # Quick test
        pytesseract.get_tesseract_version()
        logger.info("Tesseract OCR available — image text extraction enabled.")
        return True

    except Exception as e:
        logger.warning(
            "Tesseract not available (%s). Image OCR disabled. "
            "Install Tesseract to enable image text extraction.", e
        )
        return False


_OCR_AVAILABLE: Optional[bool] = None   # cached after first check


def _ocr_available() -> bool:
    global _OCR_AVAILABLE
    if _OCR_AVAILABLE is None:
        _OCR_AVAILABLE = _setup_tesseract()
    return _OCR_AVAILABLE


# ── Image OCR extraction ──────────────────────────────────────────────────────

def _extract_images_from_page(page) -> List[str]:
    """
    Extract text from all images on a pdfplumber page using OCR.
    Returns list of OCR text strings (one per image).
    """
    if not _ocr_available():
        return []

    try:
        import pytesseract
        from PIL import Image
        import io

        ocr_texts = []
        for img_obj in page.images:
            try:
                # pdfplumber gives us image bbox; we crop it from the page
                x0 = img_obj["x0"]
                y0 = img_obj["y0"]
                x1 = img_obj["x1"]
                y1 = img_obj["y1"]

                # Render that region at high DPI for better OCR accuracy
                cropped = page.crop((x0, y0, x1, y1))
                pil_img = cropped.to_image(resolution=300).original

                # Run OCR
                text = pytesseract.image_to_string(pil_img, config="--psm 6")
                text = _clean_text(text)
                if text and len(text) > 20:   # skip near-empty results
                    ocr_texts.append(text)
                    logger.debug("OCR extracted %d chars from image on page", len(text))
            except Exception as img_exc:
                logger.debug("Could not OCR image: %s", img_exc)

        return ocr_texts

    except ImportError:
        return []


# ── Page extraction ───────────────────────────────────────────────────────────

def _extract_pages_with_images(pdf_path: Path):
    """
    Extract from each page:
      - raw text (via pdfplumber)
      - OCR text from embedded images (if tesseract available)

    Yields: (page_number, text, [ocr_texts])
    """
    try:
        import pdfplumber
        with pdfplumber.open(str(pdf_path)) as pdf:
            for i, page in enumerate(pdf.pages, start=1):
                text      = page.extract_text() or ""
                ocr_texts = _extract_images_from_page(page)
                yield i, text, ocr_texts
    except ImportError:
        # Fallback to pypdf (no image extraction)
        from pypdf import PdfReader
        reader = PdfReader(str(pdf_path))
        for i, page in enumerate(reader.pages, start=1):
            yield i, (page.extract_text() or ""), []


# ── Public API ────────────────────────────────────────────────────────────────

def load_and_chunk_pdf(
    pdf_path:     Path,
    chunk_size:   int = 512,
    chunk_overlap: int = 64,
) -> List[DocumentChunk]:
    """
    Full pipeline:
      PDF → extract text + OCR images → clean → chunk → DocumentChunk list

    Returns all chunks (text + image OCR) ready for embedding.
    """
    logger.info("Processing PDF: %s", pdf_path.name)
    doc_hash   = _file_hash(pdf_path)
    all_chunks : List[DocumentChunk] = []
    text_pages = 0
    ocr_images = 0

    for page_no, raw_text, ocr_texts in _extract_pages_with_images(pdf_path):

        # ── Regular text chunks ───────────────────────────────────────────────
        clean = _clean_text(raw_text)
        if clean:
            text_pages += 1
            for idx, chunk_text in enumerate(
                _split_into_chunks(clean, chunk_size, chunk_overlap)
            ):
                all_chunks.append(DocumentChunk(
                    text=chunk_text,
                    source_file=pdf_path.name,
                    page_number=page_no,
                    chunk_index=idx,
                    doc_hash=doc_hash,
                    chunk_type="text",
                ))

        # ── Image OCR chunks ──────────────────────────────────────────────────
        for img_idx, ocr_text in enumerate(ocr_texts):
            ocr_images += 1
            for idx, chunk_text in enumerate(
                _split_into_chunks(ocr_text, chunk_size, chunk_overlap)
            ):
                all_chunks.append(DocumentChunk(
                    text=f"[Image on Page {page_no}]: {chunk_text}",
                    source_file=pdf_path.name,
                    page_number=page_no,
                    chunk_index=idx,
                    doc_hash=doc_hash,
                    chunk_type="image_ocr",
                    metadata={"image_index": img_idx},
                ))

    logger.info(
        "  → %d text pages, %d image OCR extractions, %d total chunks",
        text_pages, ocr_images, len(all_chunks),
    )
    if ocr_images == 0 and _ocr_available():
        logger.info("  (no embedded images found in this PDF)")
    elif not _ocr_available():
        logger.info("  (image OCR skipped — Tesseract not installed)")

    return all_chunks


def ocr_status() -> dict:
    """Return OCR availability info for display in the UI."""
    available = _ocr_available()
    return {
        "available": available,
        "message":   "✅ Image OCR enabled (Tesseract detected)" if available
                     else "⚠️ Image OCR disabled — install Tesseract to extract text from images",
    }
