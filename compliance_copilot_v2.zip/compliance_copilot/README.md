# 🏦 GenAI Banking Policy & Compliance Copilot v2

RAG chatbot for banking policy PDFs.
**New in v2:** FAISS vector database + PDF image OCR extraction.

---

## 🆕 What's new in v2

| Feature | v1 | v2 |
|---|---|---|
| Vector DB | TF-IDF pickle | **FAISS** (proper vector database) |
| Embeddings | TF-IDF sparse | **TF-IDF + SVD dense vectors** (256-dim) |
| Image extraction | ❌ Text only | ✅ **OCR from embedded images** (if Tesseract installed) |
| Search | Cosine similarity (numpy) | **FAISS IndexFlatIP** (exact inner product) |

---

## ⚙️ Setup

### 1. Set your Phi-2 path
Open `src/config.py` line 21:
```python
PHI2_MODEL_NAME = r"D:\phi-2"   # ← your actual path
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. (Optional) Enable image OCR
Install Tesseract:
- **Windows:** Download from https://github.com/UB-Mannheim/tesseract/wiki
- **Linux:** `sudo apt install tesseract-ocr`
- **Mac:** `brew install tesseract`

Then set path in `src/config.py`:
```python
TESSERACT_PATH = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
```

### 4. Run
```bash
streamlit run app.py
```

---

## 🚀 How to use

1. Open `http://localhost:8501`
2. Check OCR status in sidebar (green = image extraction enabled)
3. Upload policy PDFs — you'll see text chunk + image OCR chunk counts
4. Type any question and press **Enter**
5. Answer appears with source citations (📄 text or 🖼️ image sources)

---

## 🔧 Troubleshoot

```bash
python test_pipeline.py    # diagnose issues
```

| Problem | Fix |
|---|---|
| FAISS not found | `pip install faiss-cpu` |
| Image OCR not working | Install Tesseract, set TESSERACT_PATH in config.py |
| Still connecting to HuggingFace | Check PHI2_MODEL_NAME is a local folder path |
| Empty answers | Run test_pipeline.py and share output |

---

## 📁 Project Structure

```
compliance_copilot/
├── app.py                    ← Streamlit UI
├── test_pipeline.py          ← Diagnostic script
├── requirements.txt
│
├── src/
│   ├── config.py             ← Set PHI2_MODEL_NAME + TESSERACT_PATH here
│   ├── document_processor.py ← PDF text + image OCR extraction
│   ├── vector_store.py       ← FAISS + TF-IDF/SVD embeddings
│   ├── llm_engine.py         ← Phi-2 local inference
│   └── rag_pipeline.py       ← RAG orchestration
│
└── data/
    ├── uploads/              ← PDFs stored here
    └── vectorstore/          ← FAISS index stored here
        ├── faiss_index.bin
        ├── faiss_meta.pkl
        ├── tfidf_vectorizer.pkl
        └── svd_transformer.pkl
```
