"""
producer.py
============
Kafka producer wrapper for the ingestion layer.

Provides topic-specific send methods:
  send_single()  → single_entity_docs
  send_multi()   → multi_entity_docs
  send_raw()     → raw_documents
  send_audit()   → audit_logs
  send_dlq()     → dead_letter_queue

Uses kafka-python library.
All sends are async with callbacks; call flush() to wait for broker acks.
"""

import json
from typing import Any

from kafka import KafkaProducer
from kafka.errors import KafkaError, NoBrokersAvailable

import config
from logger import get_logger

log = get_logger("producer")


def _serialise(obj: Any) -> bytes:
    return json.dumps(obj, default=str, ensure_ascii=False).encode("utf-8")


class IngestionProducer:
    """
    Wraps KafkaProducer with convenience methods per topic.

    Usage:
        producer = IngestionProducer()
        producer.send_single(payload_dict)
        producer.flush()
        producer.close()

    Or as context manager:
        with IngestionProducer() as p:
            p.send_single(payload)
    """

    def __init__(self):
        try:
            self._producer = KafkaProducer(
                bootstrap_servers   = config.KAFKA_BROKER,
                value_serializer    = _serialise,
                key_serializer      = lambda k: k.encode("utf-8") if k else None,
                acks                = config.KAFKA_PRODUCER_CONFIG["acks"],
                retries             = config.KAFKA_PRODUCER_CONFIG["retries"],
                compression_type    = config.KAFKA_PRODUCER_CONFIG["compression_type"],
            )
            log.info("Kafka producer connected to %s", config.KAFKA_BROKER)
        except NoBrokersAvailable:
            log.error(
                "Kafka broker not available at %s. "
                "Is Kafka running? See README for startup steps.",
                config.KAFKA_BROKER,
            )
            raise

    # ── Context manager ───────────────────────────────────────────────────

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ── Topic senders ─────────────────────────────────────────────────────

    def send_single(self, payload: dict):
        """Validated single-entity document → single_entity_docs."""
        self._send(config.TOPICS["single"], key=payload.get("doc_id"), data=payload)

    def send_multi(self, payload: dict):
        """One segment of a multi-entity document → multi_entity_docs."""
        self._send(config.TOPICS["multi"], key=payload.get("doc_id"), data=payload)

    def send_raw(self, payload: dict):
        """All documents also go to raw_documents for full history."""
        self._send(config.TOPICS["raw"], key=payload.get("doc_id"), data=payload)

    def send_audit(self, entry: dict):
        """Audit record → audit_logs. Key = ingest_id."""
        self._send(config.TOPICS["audit"], key=entry.get("ingest_id"), data=entry)

    def send_dlq(self, record: dict):
        """Failed records → dead_letter_queue. Key = file_name."""
        self._send(config.TOPICS["dlq"], key=record.get("file_name", "unknown"), data=record)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def flush(self, timeout: int = 30):
        """Block until all pending messages are delivered to brokers."""
        self._producer.flush(timeout=timeout)

    def close(self):
        self.flush()
        self._producer.close()
        log.info("Kafka producer closed.")

    # ── Internal ──────────────────────────────────────────────────────────

    def _send(self, topic: str, key: str | None, data: dict):
        try:
            (
                self._producer
                .send(topic, key=key, value=data)
                .add_callback(self._on_success)
                .add_errback(self._on_error)
            )
        except KafkaError as exc:
            log.error("Immediate send failure to %s: %s", topic, exc)

    @staticmethod
    def _on_success(meta):
        log.debug(
            "Delivered → topic=%s partition=%d offset=%d",
            meta.topic, meta.partition, meta.offset,
        )

    @staticmethod
    def _on_error(exc: KafkaError):
        log.error("Kafka delivery error: %s", exc)
