"""
app.py
=======
Main ingestion orchestrator.

Wires together:
  metadata_handler → parser → splitter → validator → producer

Entry points:
  process_file()    — one file + optional metadata dict
  process_folder()  — batch process all files in a folder
  watch_folder()    — live folder watcher (polls every N seconds)

Full pipeline per document:
─────────────────────────────────────────────────────────────────────────
  1. File type detection        (extension check + size check)
  2. Text extraction            (parser.parse_file)
  3. Metadata load + validate   (metadata_handler.load_metadata)
  4. Single vs Multi detection  (splitter.detect_structure)
  5. Build Kafka payloads       (one per segment)
  6. Schema validation          (validator.validate)
  7. Kafka publish              (producer → correct topic)
  8. Audit log                  (producer → audit_logs)
─────────────────────────────────────────────────────────────────────────
"""

import os
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import config
from logger import get_logger
from metadata_handler import load_metadata
from parser import parse_file, ParseResult
from producer import IngestionProducer
from splitter import detect_structure
from validator import validate

log = get_logger("app")


# ─────────────────────────────────────────────────────────────────────────────
# Result dataclass (simple dict-free Python dataclass)
# ─────────────────────────────────────────────────────────────────────────────

class ProcessingResult:
    def __init__(self, file_name: str):
        self.file_name      = file_name
        self.ingest_id      = str(uuid.uuid4())
        self.success        = False
        self.structure_type = None
        self.segment_count  = 0
        self.topic_sent     = None
        self.failure_reason = None
        self.failure_detail = None
        self.warnings       = []

    def __repr__(self):
        if self.success:
            return (
                f"<OK  {self.file_name} | type={self.structure_type} "
                f"segments={self.segment_count} topic={self.topic_sent}>"
            )
        return f"<FAIL {self.file_name} | {self.failure_reason}: {self.failure_detail}>"


# ─────────────────────────────────────────────────────────────────────────────
# Core pipeline
# ─────────────────────────────────────────────────────────────────────────────

def process_file(
    file_path:    str,
    source:       str          = "MANUAL_UPLOAD",
    inline_meta:  Optional[Dict] = None,
    producer:     Optional[IngestionProducer] = None,
) -> ProcessingResult:
    """
    Full ingestion pipeline for one file.

    Args:
        file_path:   Path to the file.
        source:      Source system identifier (e.g. "HRMS", "CRM", "EMAIL").
        inline_meta: Metadata dict from the uploading system.
                     Keys: source_system, file_type, author, department,
                           creation_date, region, business_unit, etc.
        producer:    Reuse an existing producer (for batch mode).
    """
    result        = ProcessingResult(os.path.basename(file_path))
    _own_producer = producer is None

    if _own_producer:
        try:
            producer = IngestionProducer()
        except Exception as exc:
            result.failure_reason = "KAFKA_UNAVAILABLE"
            result.failure_detail = str(exc)
            log.error("Cannot connect to Kafka: %s", exc)
            return result

    try:
        fname = os.path.basename(file_path)
        ext   = Path(fname).suffix.lower()

        # ── Step 1: File type check ───────────────────────────────────────
        if ext not in config.SUPPORTED_EXTENSIONS:
            return _fail(result, producer, fname, source,
                         "UNSUPPORTED_FORMAT",
                         f"Extension '{ext}' is not supported")

        size_mb = os.path.getsize(file_path) / (1024 * 1024)
        if size_mb > config.MAX_FILE_SIZE_MB:
            return _fail(result, producer, fname, source,
                         "FILE_TOO_LARGE",
                         f"{size_mb:.1f} MB exceeds limit of {config.MAX_FILE_SIZE_MB} MB")

        # ── Step 2: Text extraction ───────────────────────────────────────
        try:
            parse_result = parse_file(file_path, file_name=fname)
        except Exception as exc:
            return _fail(result, producer, fname, source,
                         "PARSE_ERROR", str(exc))

        # ZIP returns a list; treat as MULTI
        if isinstance(parse_result, list):
            return _handle_zip(
                results=parse_result,
                file_path=file_path,
                fname=fname,
                source=source,
                inline_meta=inline_meta,
                producer=producer,
                result=result,
            )

        if not parse_result.success:
            return _fail(result, producer, fname, source,
                         "PARSE_FAILED", parse_result.error or "Unknown parse error")

        result.warnings.extend(parse_result.warnings)

        # ── Step 3: Metadata load + validate ─────────────────────────────
        metadata = load_metadata(file_path, inline_meta=inline_meta)
        # Ensure file_type in metadata reflects actual parsed type
        if metadata.get("file_type") == "unknown":
            metadata["file_type"] = parse_result.file_type

        # ── Step 4: Single vs Multi detection ────────────────────────────
        struct = detect_structure(
            text      = parse_result.raw_text,
            source    = source,
            file_type = parse_result.file_type,
        )
        result.structure_type = struct.structure_type
        result.segment_count  = struct.segment_count

        log.info(
            "%s → structure=%s  segments=%d  signals=%s",
            fname, struct.structure_type, struct.segment_count, struct.signals,
        )

        # ── Steps 5–7: Build, validate, publish ───────────────────────────
        ingest_ts = datetime.utcnow().isoformat()

        if struct.structure_type == "single":
            payload = _build_payload(
                ingest_id      = result.ingest_id,
                doc_id         = str(uuid.uuid4()),
                fname          = fname,
                raw_text       = parse_result.raw_text,
                metadata       = metadata,
                structure_type = "single",
                segment_index  = None,
                total_segments = None,
                parent_doc_id  = None,
                segment_type   = None,
                signals        = struct.signals,
                parser_used    = parse_result.parser_used,
                warnings       = parse_result.warnings,
                ingest_ts      = ingest_ts,
            )

            val = validate(payload)
            if not val.success:
                return _fail(result, producer, fname, source,
                             val.failure_reason, val.failure_detail)

            producer.send_raw(payload)
            producer.send_single(payload)
            result.topic_sent = config.TOPICS["single"]
            log.info("→ %s: %s", config.TOPICS["single"], payload["doc_id"])

        else:
            # MULTI: publish one payload per segment
            parent_id = result.ingest_id
            sent_count = 0

            for seg in struct.segments:
                seg_payload = _build_payload(
                    ingest_id      = result.ingest_id,
                    doc_id         = str(uuid.uuid4()),
                    fname          = fname,
                    raw_text       = seg.text,
                    metadata       = metadata,
                    structure_type = "multi",
                    segment_index  = seg.segment_id,
                    total_segments = struct.segment_count,
                    parent_doc_id  = parent_id,
                    segment_type   = seg.segment_type,
                    signals        = struct.signals,
                    parser_used    = parse_result.parser_used,
                    warnings       = parse_result.warnings,
                    ingest_ts      = ingest_ts,
                )

                val = validate(seg_payload)
                if not val.success:
                    log.warning(
                        "Segment %d of %s failed validation → DLQ: %s",
                        seg.segment_id, fname, val.failure_detail,
                    )
                    _send_dlq(producer, fname, source,
                              val.failure_reason, val.failure_detail,
                              seg_payload)
                    continue

                producer.send_raw(seg_payload)
                producer.send_multi(seg_payload)
                sent_count += 1
                log.info(
                    "→ %s: %s  seg=%d/%d  type=%s",
                    config.TOPICS["multi"], seg_payload["doc_id"],
                    seg.segment_id + 1, struct.segment_count, seg.segment_type,
                )

            result.topic_sent    = config.TOPICS["multi"]
            result.segment_count = sent_count

        # ── Step 8: Audit log ─────────────────────────────────────────────
        result.success = True
        _send_audit(producer, result, fname, source, metadata)
        return result

    except Exception as exc:
        log.error("Unexpected error processing %s: %s", file_path, exc, exc_info=True)
        return _fail(result, producer,
                     os.path.basename(file_path), source, "UNEXPECTED_ERROR", str(exc))

    finally:
        if _own_producer:
            producer.close()


# ─────────────────────────────────────────────────────────────────────────────
# ZIP handler
# ─────────────────────────────────────────────────────────────────────────────

def _handle_zip(
    results:     List[ParseResult],
    file_path:   str,
    fname:       str,
    source:      str,
    inline_meta: Optional[Dict],
    producer:    IngestionProducer,
    result:      ProcessingResult,
) -> ProcessingResult:
    """Each file inside a ZIP is treated as an independent MULTI segment."""
    metadata   = load_metadata(file_path, inline_meta=inline_meta)
    ingest_ts  = datetime.utcnow().isoformat()
    parent_id  = result.ingest_id
    sent_count = 0

    for i, inner in enumerate(results):
        if not inner.success:
            log.warning("ZIP inner file %s failed: %s", inner.file_name, inner.error)
            continue

        payload = _build_payload(
            ingest_id      = result.ingest_id,
            doc_id         = str(uuid.uuid4()),
            fname          = inner.file_name,
            raw_text       = inner.raw_text,
            metadata       = metadata,
            structure_type = "multi",
            segment_index  = i,
            total_segments = len(results),
            parent_doc_id  = parent_id,
            segment_type   = f"zip_entry:{inner.file_name}",
            signals        = ["zip_container"],
            parser_used    = inner.parser_used,
            warnings       = inner.warnings,
            ingest_ts      = ingest_ts,
        )

        val = validate(payload)
        if not val.success:
            _send_dlq(producer, fname, source,
                      val.failure_reason, val.failure_detail, payload)
            continue

        producer.send_raw(payload)
        producer.send_multi(payload)
        sent_count += 1

    result.success        = True
    result.structure_type = "multi"
    result.segment_count  = sent_count
    result.topic_sent     = config.TOPICS["multi"]
    _send_audit(producer, result, fname, source, metadata)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Batch folder processor
# ─────────────────────────────────────────────────────────────────────────────

def process_folder(
    folder_path: str          = None,
    source:      str          = "MANUAL_UPLOAD",
    inline_meta: Optional[Dict] = None,
) -> List[ProcessingResult]:
    """
    Process all supported files in a folder.
    Reuses one Kafka producer for the entire batch.
    """
    folder = folder_path or config.UPLOAD_FOLDER
    os.makedirs(folder, exist_ok=True)

    files = [
        os.path.join(folder, f)
        for f in sorted(os.listdir(folder))
        if os.path.isfile(os.path.join(folder, f))
        and Path(f).suffix.lower() in config.SUPPORTED_EXTENSIONS
    ]

    if not files:
        log.warning("No supported files found in %s", folder)
        return []

    log.info("Batch starting: %d files from %s", len(files), folder)
    results = []

    try:
        producer = IngestionProducer()
    except Exception as exc:
        log.error("Cannot start batch — Kafka unavailable: %s", exc)
        return []

    with producer:
        for i, file_path in enumerate(files, 1):
            log.info("[%d/%d] %s", i, len(files), file_path)
            result = process_file(
                file_path   = file_path,
                source      = source,
                inline_meta = inline_meta,
                producer    = producer,
            )
            results.append(result)
            log.info("%s", result)

        producer.flush()

    ok   = sum(1 for r in results if r.success)
    fail = len(results) - ok
    log.info("Batch complete: %d OK, %d FAILED out of %d files", ok, fail, len(results))
    return results


# ─────────────────────────────────────────────────────────────────────────────
# Folder watcher (simple polling — no watchdog dependency)
# ─────────────────────────────────────────────────────────────────────────────

def watch_folder(
    folder_path:    str   = None,
    source:         str   = "MANUAL_UPLOAD",
    poll_seconds:   float = 5.0,
) -> None:
    """
    Continuously watch a folder and process new files as they appear.
    Tracks processed files so it doesn't re-process them.
    Press Ctrl+C to stop.
    """
    folder  = folder_path or config.UPLOAD_FOLDER
    os.makedirs(folder, exist_ok=True)
    seen    = set(os.listdir(folder))

    log.info("Watching %s every %.0f seconds. Press Ctrl+C to stop.", folder, poll_seconds)

    try:
        producer = IngestionProducer()
    except Exception as exc:
        log.error("Cannot start watcher — Kafka unavailable: %s", exc)
        return

    try:
        with producer:
            while True:
                time.sleep(poll_seconds)
                current = set(os.listdir(folder))
                new_files = current - seen
                for fname in sorted(new_files):
                    file_path = os.path.join(folder, fname)
                    if not os.path.isfile(file_path):
                        continue
                    if Path(fname).suffix.lower() not in config.SUPPORTED_EXTENSIONS:
                        log.debug("Ignoring unsupported file: %s", fname)
                        seen.add(fname)
                        continue
                    log.info("New file detected: %s", fname)
                    result = process_file(file_path, source=source, producer=producer)
                    log.info("%s", result)
                seen = current
    except KeyboardInterrupt:
        log.info("Folder watcher stopped.")


# ─────────────────────────────────────────────────────────────────────────────
# Payload builder
# ─────────────────────────────────────────────────────────────────────────────

def _build_payload(
    ingest_id, doc_id, fname, raw_text, metadata,
    structure_type, segment_index, total_segments,
    parent_doc_id, segment_type, signals,
    parser_used, warnings, ingest_ts,
) -> dict:
    """
    Build the canonical Kafka payload dict.
    Schema matches the PS requirement exactly.
    """
    return {
        # Identity
        "doc_id":           doc_id,
        "ingest_id":        ingest_id,
        "parent_doc_id":    parent_doc_id,

        # File info
        "file_name":        fname,

        # Content
        "raw_text":         raw_text,
        "char_count":       len(raw_text),
        "word_count":       len(raw_text.split()),

        # Metadata (as received from source system, validated + normalised)
        "metadata": {
            "source_system":    metadata.get("source_system", "unknown"),
            "file_type":        metadata.get("file_type", "unknown"),
            "author":           metadata.get("author", "unknown"),
            "department":       metadata.get("department", "unknown"),
            "creation_date":    metadata.get("creation_date", "unknown"),
            "region":           metadata.get("region", "unknown"),
            "business_unit":    metadata.get("business_unit", "unknown"),
            "client_name":      metadata.get("client_name", "unknown"),
            "source_channel":   metadata.get("source_channel", "unknown"),
            "upload_timestamp": metadata.get("upload_timestamp", ingest_ts),
            "metadata_complete":metadata.get("_metadata_complete", False),
            "metadata_issues":  metadata.get("_validation_issues", []),
        },

        # Structure
        "structure_type":   structure_type,
        "segment_index":    segment_index,
        "total_segments":   total_segments,
        "segment_type":     segment_type,
        "structure_signals":signals,

        # Processing metadata
        "parser_used":      parser_used,
        "parse_warnings":   warnings,
        "ingest_timestamp": ingest_ts,
        "ingestion_version":"1.0.0",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _fail(
    result:   ProcessingResult,
    producer: IngestionProducer,
    fname:    str,
    source:   str,
    reason:   str,
    detail:   str,
) -> ProcessingResult:
    result.failure_reason = reason
    result.failure_detail = detail
    _send_dlq(producer, fname, source, reason, detail)
    _send_audit(producer, result, fname, source, {})
    log.error("FAILED %s: %s — %s", fname, reason, detail)
    return result


def _send_dlq(producer, fname, source, reason, detail, payload=None):
    producer.send_dlq({
        "file_name":      fname,
        "source":         source,
        "failure_reason": reason,
        "failure_detail": detail,
        "raw_payload":    payload,
        "failed_at":      datetime.utcnow().isoformat(),
    })


def _send_audit(producer, result: ProcessingResult, fname, source, metadata):
    producer.send_audit({
        "ingest_id":      result.ingest_id,
        "file_name":      fname,
        "source":         source,
        "status":         "ingested" if result.success else "failed",
        "structure_type": result.structure_type,
        "segment_count":  result.segment_count,
        "topic_sent":     result.topic_sent,
        "failure_reason": result.failure_reason,
        "failure_detail": result.failure_detail,
        "metadata_dept":  metadata.get("department", "unknown"),
        "metadata_complete": metadata.get("_metadata_complete", False),
        "warnings":       result.warnings,
        "timestamp":      datetime.utcnow().isoformat(),
    })
