"""
utils/presidio_masker.py
------------------------
Real Microsoft Presidio integration for PII masking, with a graceful
fallback to the existing regex-based masker (utils/pii_masker.py) if
Presidio isn't installed.

Gap fix: the gap-analysis report flagged Presidio as "NOT WIRED" — it was
mentioned in docs but only the regex masker was actually called. This
module wires Presidio in as the primary masker; regex is the second line
of defense (still runs at the audit-log boundary in utils/pii_masker.py).

Design:
  - PresidioMasker.mask(text) returns (masked_text, list_of_entity_labels)
  - If presidio_analyzer / presidio_anonymizer aren't installed, we
    transparently fall back to utils.pii_masker.mask_text so the pipeline
    still works on a vanilla install. We log a one-time warning so the
    user knows they're on the fallback path.
  - We mask FOR PERSISTENCE ONLY. The classifier and policy engine see
    the raw text (they need the PII patterns to make correct decisions).
"""
from __future__ import annotations
from typing import List, Tuple
import sys

_PRESIDIO_AVAILABLE = False
_warned = False

try:
    from presidio_analyzer import AnalyzerEngine
    from presidio_anonymizer import AnonymizerEngine
    from presidio_anonymizer.entities import OperatorConfig
    _PRESIDIO_AVAILABLE = True
except Exception:
    _PRESIDIO_AVAILABLE = False


# PS-01 lists these as the PII types we must mask. Presidio recognizers
# cover a superset; we constrain the analyzer to this list so the output
# is predictable and tests are stable.
_PS_ENTITIES = [
    'US_SSN',
    'CREDIT_CARD',
    'IBAN_CODE',
    'IN_PAN',
    'IN_AADHAAR',
    'EMAIL_ADDRESS',
    'PHONE_NUMBER',
    'DATE_TIME',
    'US_PASSPORT',
    'PERSON',
    'LOCATION',
    'US_BANK_NUMBER',
]


class PresidioMasker:
    """
    Primary PII masker. Use this as the first masking pass; the regex
    masker in utils/pii_masker.py runs as a defensive second pass at
    the audit-log boundary.
    """

    def __init__(self):
        global _PRESIDIO_AVAILABLE
        self._analyzer = None
        self._anonymizer = None
        if _PRESIDIO_AVAILABLE:
            try:
                self._analyzer = AnalyzerEngine()
                self._anonymizer = AnonymizerEngine()
            except Exception as e:
                # spaCy model might not be downloaded — fall back quietly
                _PRESIDIO_AVAILABLE = False
                self._warn_fallback(f'Presidio init failed: {e}')

    @staticmethod
    def _warn_fallback(msg: str = ''):
        global _warned
        if not _warned:
            extra = f' ({msg})' if msg else ''
            print(f'[presidio_masker] Presidio not available{extra}. '
                  f'Falling back to regex masker.', file=sys.stderr)
            _warned = True

    @property
    def is_using_presidio(self) -> bool:
        return _PRESIDIO_AVAILABLE and self._analyzer is not None

    def mask(self, text: str) -> Tuple[str, List[str]]:
        """
        Returns (masked_text, list_of_entity_types_found).
        Masked text replaces each entity with <ENTITY_TYPE>.
        """
        if not text:
            return '', []

        if not self.is_using_presidio:
            # Fallback: regex masker (always available)
            from utils.pii_masker import mask_text
            return mask_text(text)

        try:
            results = self._analyzer.analyze(
                text=text,
                language='en',
                entities=_PS_ENTITIES,
                score_threshold=0.4,
            )
            entity_types = sorted({r.entity_type for r in results})

            operators = {
                e: OperatorConfig('replace', {'new_value': f'<{e}>'})
                for e in entity_types
            }
            if results:
                anon = self._anonymizer.anonymize(
                    text=text,
                    analyzer_results=results,
                    operators=operators or {
                        'DEFAULT': OperatorConfig('replace', {'new_value': '<PII>'})
                    },
                )
                return anon.text, entity_types
            return text, []
        except Exception as e:
            self._warn_fallback(f'Presidio analyze failed: {e}')
            from utils.pii_masker import mask_text
            return mask_text(text)


# Singleton — Presidio loading is expensive (spaCy model warmup).
_INSTANCE: PresidioMasker | None = None


def get_masker() -> PresidioMasker:
    global _INSTANCE
    if _INSTANCE is None:
        _INSTANCE = PresidioMasker()
    return _INSTANCE


def mask(text: str) -> Tuple[str, List[str]]:
    """Convenience function — uses the singleton masker."""
    return get_masker().mask(text)
