"""
run.py
------
One-command launcher: starts FastAPI backend + React UI together.

  python run.py

What it does:
  1. Starts FastAPI on port 8000 (background subprocess).
  2. Detects whether ui/node_modules exists:
       - YES → runs `npm run dev` (Vite dev server with HMR on :8501).
       - NO  → first auto-runs `npm install` once, then `npm run dev`.
       - If npm isn't installed at all, falls back to serving ui/dist
         with Python's http.server (assumes you ran `npm run build` once).
  3. Cleanly shuts down both children on Ctrl+C.
"""
from __future__ import annotations
import os
import sys
import time
import shutil
import signal
import subprocess
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent
UI_DIR = PROJECT_DIR / 'ui'

API_PORT = 8000
UI_PORT = 8501

BANNER = f"""
==============================================================
  DataShield — Sensitivity Classification Engine
==============================================================
  UI    ->  http://localhost:{UI_PORT}    (open this in browser)
  API   ->  http://localhost:{API_PORT}
  Docs  ->  http://localhost:{API_PORT}/docs  (Swagger)
--------------------------------------------------------------
  Press Ctrl+C to stop both services.
==============================================================
"""


def have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def start_api():
    print('[run.py] Starting FastAPI on http://localhost:8000 …')
    return subprocess.Popen(
        [sys.executable, 'api.py'],
        cwd=str(PROJECT_DIR),
        stdout=sys.stdout, stderr=sys.stderr,
    )


def ensure_ui_deps() -> bool:
    """Return True if we can run npm-based UI; False if we should fall back."""
    if not have('npm'):
        print('[run.py] npm not found — UI cannot run via Vite.')
        return False
    if not (UI_DIR / 'node_modules').exists():
        print('[run.py] First-run: installing UI dependencies (this happens once)…')
        try:
            subprocess.check_call(['npm', 'install', '--no-audit', '--no-fund', '--loglevel=error'],
                                  cwd=str(UI_DIR))
        except Exception as e:
            print(f'[run.py] npm install failed: {e}')
            return False
    return True


def start_ui_vite():
    print(f'[run.py] Starting React UI (Vite) on http://localhost:{UI_PORT} …')
    # On Windows, npm.cmd needs shell=True; use shell on all platforms for simplicity.
    use_shell = sys.platform == 'win32'
    cmd = ['npm', 'run', 'dev', '--', '--port', str(UI_PORT), '--host', '127.0.0.1', '--strictPort']
    return subprocess.Popen(
        cmd, cwd=str(UI_DIR),
        stdout=sys.stdout, stderr=sys.stderr,
        shell=use_shell,
    )


def start_ui_static_fallback():
    dist = UI_DIR / 'dist'
    if not dist.exists():
        print('[run.py] No ui/dist found. Cannot serve UI without npm.')
        print('         Install Node.js and re-run, or build once with `cd ui && npm install && npm run build`.')
        return None
    print(f'[run.py] Serving prebuilt UI (ui/dist) on http://localhost:{UI_PORT} …')
    return subprocess.Popen(
        [sys.executable, '-m', 'http.server', str(UI_PORT), '--bind', '127.0.0.1'],
        cwd=str(dist),
        stdout=sys.stdout, stderr=sys.stderr,
    )


def main():
    print(BANNER)

    api_proc = start_api()
    time.sleep(3)        # give uvicorn a moment to bind the port

    if ensure_ui_deps():
        ui_proc = start_ui_vite()
    else:
        ui_proc = start_ui_static_fallback()

    if ui_proc is None:
        print('[run.py] UI not started — visit http://localhost:8000/docs for the API Swagger UI.')

    try:
        while True:
            time.sleep(0.5)
            if api_proc.poll() is not None:
                print('[run.py] API process exited; shutting down.')
                break
            if ui_proc and ui_proc.poll() is not None:
                print('[run.py] UI process exited; shutting down.')
                break
    except KeyboardInterrupt:
        print('\n[run.py] Stopping …')
    finally:
        for proc in (ui_proc, api_proc):
            if proc and proc.poll() is None:
                try:
                    if sys.platform == 'win32':
                        proc.terminate()
                    else:
                        proc.send_signal(signal.SIGINT)
                    proc.wait(timeout=4)
                except Exception:
                    try: proc.kill()
                    except Exception: pass
        print('[run.py] Done.')


if __name__ == '__main__':
    main()
