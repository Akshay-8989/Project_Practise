"""
feature_engineering/schemas.py
------------------------------
Shared feature bundle dataclass. The wire format exchanged between this
layer and its consumers (API, UI, audit).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple, Optional


@dataclass
class FeatureSummary:
    """Inspectable view of the features computed for one document.

    Same numbers serve inference and inspection — the trained models'
    vectorizers and the numeric/metadata helpers below are the SAME
    pieces that produce inference-time features."""

    tfidf_top: List[Tuple[str, float]] = field(default_factory=list)
    unigram_count: int = 0
    bigram_count: int = 0
    # Inspection: dict-form numeric features (used in UI + audit)
    numeric_features: Dict[str, float] = field(default_factory=dict)
    # Inspection: labelled one-hot metadata features
    metadata_features: Dict[str, int] = field(default_factory=dict)
    # Optional transformer stats
    embedding_dim: Optional[int] = None
    embedding_norm: Optional[float] = None
    # TF-IDF vocabulary size (per language)
    vocab_size: int = 0
    used_language: str = 'en'
    # Provenance — was this served from cache?
    cache_hit: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            'tfidf_top': [
                {'token': t, 'weight': round(float(w), 4)} for t, w in self.tfidf_top
            ],
            'unigram_count': self.unigram_count,
            'bigram_count': self.bigram_count,
            'numeric_features': self.numeric_features,
            'metadata_features': self.metadata_features,
            'embedding_dim': self.embedding_dim,
            'embedding_norm': self.embedding_norm,
            'vocab_size': self.vocab_size,
            'used_language': self.used_language,
            'cache_hit': self.cache_hit,
        }
