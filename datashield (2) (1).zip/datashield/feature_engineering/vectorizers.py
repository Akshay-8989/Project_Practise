"""
feature_engineering/vectorizers.py
----------------------------------
Lazy-loaded, language-keyed wrappers around the trained vectorizers
that live inside model artifacts.

The shared layer doesn't *own* a separate TF-IDF vectorizer — the trained
one is pickled inside LogisticModel.pipeline. We reach into it once and
cache the handle. Same vectorizer drives inference (when the logistic
model predicts) AND inspection (when the UI shows top tokens).

Caches are module-level and survive across requests.
"""
from __future__ import annotations
import os
from functools import lru_cache
from typing import List, Optional, Tuple


# ─────────────────────────────────────────────────────────────
# TF-IDF (sourced from the trained LogisticModel)
# ─────────────────────────────────────────────────────────────

@lru_cache(maxsize=8)
def get_logistic_model(lang: str):
    """Lazy + cached load of the trained LogisticModel for `lang`.
    Returns None if no artifact is present (e.g. before training)."""
    try:
        from models.logistic_model import LogisticModel
        path = os.path.join('artifacts', lang, 'logistic.joblib')
        if not os.path.exists(path):
            return None
        return LogisticModel.load(path)
    except Exception as e:
        print(f'[feature_engineering] LR load failed for {lang}: {e}')
        return None


def get_tfidf_vectorizer(lang: str = 'en'):
    """Direct accessor for the persisted TF-IDF vectorizer of a language."""
    model = get_logistic_model(lang)
    if model is None:
        return None
    try:
        return model.pipeline.named_steps['tfidf']
    except Exception:
        return None


def tfidf_top_tokens(text: str, lang: str = 'en', top_k: int = 10) -> List[Tuple[str, float]]:
    """Top-k highest-weight TF-IDF tokens for one document.

    Uses the SAME vectorizer that drives inference, so the audit view
    shows what the model literally keys on."""
    vec = get_tfidf_vectorizer(lang)
    if vec is None or not text:
        return []
    try:
        import numpy as np
        X = vec.transform([text])
        row = X.toarray()[0]
        names = vec.get_feature_names_out()
        idx = np.argsort(-row)[:top_k]
        return [(names[i], float(row[i])) for i in idx if row[i] > 0]
    except Exception:
        return []


def tfidf_vocab_size(lang: str = 'en') -> int:
    vec = get_tfidf_vectorizer(lang)
    if vec is None:
        return 0
    try:
        return len(vec.get_feature_names_out())
    except Exception:
        return 0


# ─────────────────────────────────────────────────────────────
# Optional transformer embeddings
# ─────────────────────────────────────────────────────────────

@lru_cache(maxsize=8)
def get_transformer_model(lang: str):
    """Lazy + cached load of a fine-tuned transformer if one exists.
    Returns None if torch / artifact missing."""
    try:
        from models.transformer_model import TORCH_AVAILABLE, TransformerModel
    except Exception:
        return None
    if not TORCH_AVAILABLE:
        return None
    path = os.path.join('artifacts', lang, 'transformer.joblib')
    if not os.path.exists(path):
        return None
    try:
        return TransformerModel.load(path)
    except Exception as e:
        print(f'[feature_engineering] transformer load failed for {lang}: {e}')
        return None


def embedding_stats(text: str, lang: str = 'en') -> Optional[dict]:
    """Compute embedding (dim, L2 norm) for a single doc, or None if
    no transformer is available."""
    model = get_transformer_model(lang)
    if model is None or not hasattr(model, 'encode'):
        return None
    try:
        import numpy as np
        vec = model.encode([text])
        if vec is None or len(vec) == 0:
            return None
        arr = np.asarray(vec[0])
        return {
            'embedding_dim': int(arr.shape[0]),
            'embedding_norm': float(np.linalg.norm(arr)),
        }
    except Exception:
        return None
