"""
feature_engineering/tokenization.py
-----------------------------------
Single source of truth for tokenization, n-gram counts, and numeric
text statistics. Used by:
  - preprocessing      (token preview)
  - feature_engineering (TF-IDF input, n-gram counts, numeric vector)
  - models/xgboost     (numeric vector inside _featurize)
  - models/logistic    (TF-IDF wraps the same regex)

Previously every layer had its own slightly-different .split() definition.
Now they all call into this module.
"""
from __future__ import annotations
import re
from typing import List, Dict, Tuple

# Unicode-aware word tokenizer (handles English + Devanagari).
_TOKEN_RE = re.compile(r"\w+(?:'\w+)?", flags=re.UNICODE)


def tokenize(text: str) -> List[str]:
    """Deterministic word-level tokenizer."""
    if not text:
        return []
    return _TOKEN_RE.findall(text)


def ngram_counts(text: str) -> Tuple[int, int]:
    """Return (unigram_count, bigram_count)."""
    n = len(tokenize(text))
    return n, max(0, n - 1)


# Numeric features used by XGBoost AND surfaced to the UI for inspection.
# Both consumers MUST see the same numbers — that's why this lives here.
NUMERIC_FEATURE_ORDER = ('num_chars', 'num_tokens', 'num_digits', 'digit_ratio')


def numeric_text_stats(text: str) -> Dict[str, float]:
    """Dict form for inspection / UI."""
    if not text:
        return {k: 0.0 for k in NUMERIC_FEATURE_ORDER}
    num_chars = len(text)
    num_tokens = len(tokenize(text))
    num_digits = sum(ch.isdigit() for ch in text)
    return {
        'num_chars': float(num_chars),
        'num_tokens': float(num_tokens),
        'num_digits': float(num_digits),
        'digit_ratio': round(num_digits / max(num_chars, 1), 4),
    }


def numeric_text_stats_vector(text: str) -> List[float]:
    """Stable-order vector form for ML model consumption."""
    s = numeric_text_stats(text)
    return [float(s[k]) for k in NUMERIC_FEATURE_ORDER]
