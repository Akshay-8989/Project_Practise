"""
api.py
------
FastAPI REST API — the single integration surface for DataShield.

Endpoint groups:
  Classification
    POST /classify              — classify text payload
    POST /classify/file         — classify a single uploaded file (any format)
    POST /classify/batch        — async batch classification (multi-file)
    GET  /classify/status/{job_id}
                                — poll an async batch job
  Inspection (PS Layers 2 & 3 — preprocessing & feature engineering)
    POST /preprocess/preview    — see exactly how text is cleaned/masked/tokenized
    POST /features/preview      — see what the model "sees" before classifying
  History & audit
    GET  /history               — list classifications (paginated, filters)
    GET  /document/{doc_id}     — full record for one document
  Human-in-the-loop
    POST /override              — record a human correction or confirmation
    GET  /review-queue          — pending human reviews
  Policy + approvals (Constraint C4)
    POST /approval/sign-off     — Legal or DataGov approves a Restricted doc
    GET  /approval/status/{doc_id}
                                — approval gate status
  MLOps
    GET  /mlops/registry        — champion / challenger model registry
    GET  /mlops/drift           — drift monitoring report (PSI + label dist)
    GET  /mlops/audit           — recent audit log entries
    GET  /mlops/retraining      — retraining trigger recommendation
    POST /mlops/retrain         — run retraining workflow (synchronous)
    POST /mlops/export-batch    — export pending overrides as training CSV
  Health / metrics
    GET  /health
    GET  /metrics

The pipeline is loaded lazily on first request, so import-time is cheap
and PyCharm's "Run" stays snappy.
"""
from __future__ import annotations
import os
import sys
import json
import uuid
import time
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any

# ── Path bootstrap ──────────────────────────────────────────
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Local modules
import active_learning
import preprocessing
import feature_engineering
from ingestion import extract_text_from_bytes
import zipfile
import io as _io


# ─────────────────────────────────────────────────────────────
# Lazy pipeline loader
# ─────────────────────────────────────────────────────────────
_PIPELINE = None
_PIPELINE_LOCK = threading.Lock()


def get_pipeline():
    """Load the classifier on first call only (saves ~3s of startup time)."""
    global _PIPELINE
    if _PIPELINE is None:
        with _PIPELINE_LOCK:
            if _PIPELINE is None:
                from pipeline import SensitivityClassifier
                _PIPELINE = SensitivityClassifier(force_mode='fast')
    return _PIPELINE


# ─────────────────────────────────────────────────────────────
# App config
# ─────────────────────────────────────────────────────────────
app = FastAPI(
    title='DataShield — Sensitivity Classification Engine',
    description='PS-01 | Automated Data Sensitivity Classification | Local enterprise prototype',
    version='1.1.0',
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*'],
)


LOGS_DIR = os.path.join(PROJECT_DIR, 'logs')
AUDIT_LOG = os.path.join(LOGS_DIR, 'audit.jsonl')
OVERRIDE_LOG = os.path.join(LOGS_DIR, 'overrides.jsonl')
APPROVAL_LOG = os.path.join(LOGS_DIR, 'approvals.jsonl')
JOBS_PATH = os.path.join(LOGS_DIR, 'async_jobs.json')

os.makedirs(LOGS_DIR, exist_ok=True)


# ─────────────────────────────────────────────────────────────
# Pydantic request models
# ─────────────────────────────────────────────────────────────

class ClassifyTextRequest(BaseModel):
    text: str
    doc_id: Optional[str] = None
    source_system: Optional[str] = None
    department: Optional[str] = None
    file_type: Optional[str] = 'txt'


class OverrideRequest(BaseModel):
    doc_id: str
    original_label: str
    corrected_label: str
    reviewer: str
    reason: Optional[str] = ''


class ApprovalRequest(BaseModel):
    doc_id: str
    approver: str        # 'Legal' | 'DataGovernance'
    decision: str        # 'approved' | 'rejected'
    notes: Optional[str] = ''


class PreviewRequest(BaseModel):
    text: str
    metadata: Optional[Dict[str, Any]] = None


# ─────────────────────────────────────────────────────────────
# Core classification logic
# ─────────────────────────────────────────────────────────────

def _label_to_action(label: str) -> str:
    return {
        'Public': 'Allow',
        'Internal': 'Allow',
        'Confidential': 'Encrypt',
        'Restricted': 'Quarantine',
    }.get(label, 'Restrict')


def _classify(
    text: str,
    metadata: Optional[Dict[str, Any]] = None,
    doc_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Run preprocessing → classification → return enriched result."""
    if not text or not text.strip():
        raise HTTPException(400, 'No text provided.')

    t0 = time.time()

    # Step 1: Preprocessing (Layer 2)
    pre = preprocessing.preprocess(text, metadata or {})
    t_pre = time.time()

    # Step 2: Feature summary (Layer 3) — inspectable view from shared layer
    feat = feature_engineering.featurize(
        pre.clean_text,
        lang=pre.detected_language,
        top_k=8,
        metadata=pre.metadata,
    )
    t_feat = time.time()

    # Step 3: Classify (Layer 4-6). Pipeline runs on RAW text (policy
    # engine needs the PII patterns to fire).
    clf = get_pipeline()
    raw_result = clf.predict(pre.raw_text, pre.metadata, doc_id=doc_id)
    t_clf = time.time()

    final = {
        'doc_id': doc_id or raw_result.get('doc_id') or str(uuid.uuid4()),
        'label': raw_result.get('label'),
        'confidence': raw_result.get('confidence'),
        'class_probabilities': raw_result.get('class_probabilities', {}),
        'evidence': raw_result.get('evidence', []),
        'policy_action': raw_result.get('policy_trace', {}).get('action') or _label_to_action(raw_result.get('label')),
        'policy_trace': raw_result.get('policy_trace', {}),
        'model_contributions': raw_result.get('model_contributions', {}),
        'language': raw_result.get('language', {}),
        'audit': raw_result.get('audit', {}),
        'preprocessing': pre.for_audit(),
        'features': feat.to_dict(),
        'latency_ms': {
            'preprocessing': round((t_pre - t0) * 1000, 1),
            'features': round((t_feat - t_pre) * 1000, 1),
            'classification': round((t_clf - t_feat) * 1000, 1),
            'total': round((t_clf - t0) * 1000, 1),
        },
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    }
    return final


# ─────────────────────────────────────────────────────────────
# Classification endpoints
# ─────────────────────────────────────────────────────────────

@app.post('/classify')
def classify_text(req: ClassifyTextRequest):
    metadata = {
        'source_system': req.source_system,
        'department': req.department,
        'file_type': req.file_type,
    }
    return _classify(req.text, metadata, doc_id=req.doc_id)


@app.post('/classify/file')
async def classify_file(
    file: UploadFile = File(...),
    doc_id: Optional[str] = Form(None),
    source_system: Optional[str] = Form(None),
    department: Optional[str] = Form(None),
):
    """Classify one uploaded file (PDF / DOCX / TXT / JSON / CSV / etc)."""
    data = await file.read()
    text, file_meta = extract_text_from_bytes(data, file.filename)
    if not text or len(text.strip()) < 5:
        raise HTTPException(400, 'Could not extract meaningful text from file.')

    if source_system:
        file_meta['source_system'] = source_system
    if department:
        file_meta['department'] = department

    result = _classify(text, file_meta, doc_id=doc_id)
    result['source_file'] = file.filename
    result['extracted_text_preview'] = text[:400] + ('...' if len(text) > 400 else '')
    return result


# ── Async batch jobs ─────────────────────────────────────────

def _load_jobs() -> Dict[str, Any]:
    if not os.path.exists(JOBS_PATH):
        return {}
    try:
        with open(JOBS_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_jobs(jobs: Dict[str, Any]) -> None:
    with open(JOBS_PATH, 'w', encoding='utf-8') as f:
        json.dump(jobs, f, indent=2, default=str)


def _expand_zip_bytes(data: bytes, source_name: str) -> List[Dict[str, Any]]:
    """Recursively extract all supported files from a ZIP archive in memory.
    Returns a list of pseudo-uploads: [{'filename': ..., 'data': bytes}, ...]
    """
    SUPPORTED = ('.pdf', '.docx', '.txt', '.csv', '.json', '.md', '.html', '.htm', '.log', '.jsonl')
    out: List[Dict[str, Any]] = []
    try:
        with zipfile.ZipFile(_io.BytesIO(data)) as zf:
            for name in zf.namelist():
                # Skip dirs, macOS metadata, hidden files
                if name.endswith('/') or '__MACOSX' in name or '/.' in name:
                    continue
                if not name.lower().endswith(SUPPORTED):
                    continue
                try:
                    file_bytes = zf.read(name)
                except Exception:
                    continue
                # Preserve relative path inside ZIP as the source filename
                out.append({'filename': f'{source_name}/{name}', 'data': file_bytes})
    except zipfile.BadZipFile:
        pass
    return out


def _run_batch_job(job_id: str, items: List[Dict[str, Any]]):
    """Background worker — sequentially classifies each item, persisting
    per-item status (queued / running / done / failed) so the UI can show
    progress at file granularity."""
    jobs = _load_jobs()
    job = jobs.get(job_id, {})
    job['status'] = 'running'
    job['started_at'] = datetime.now(timezone.utc).isoformat()
    job['progress'] = {'completed': 0, 'total': len(items), 'failed': 0}

    # Per-file status table
    job['files'] = [
        {'source_file': it.get('source_file', f'item_{i}'), 'status': 'queued'}
        for i, it in enumerate(items)
    ]
    job['results'] = []
    jobs[job_id] = job
    _save_jobs(jobs)

    for i, item in enumerate(items):
        job['files'][i]['status'] = 'running'
        _save_jobs(jobs)

        try:
            res = _classify(
                item['text'],
                item.get('metadata') or {},
                doc_id=item.get('doc_id'),
            )
            job['files'][i]['status'] = 'done'
            job['files'][i]['label'] = res['label']
            job['files'][i]['confidence'] = res['confidence']
            job['files'][i]['policy_action'] = res['policy_action']
            job['results'].append({
                'doc_id': res['doc_id'],
                'source_file': item.get('source_file'),
                'label': res['label'],
                'confidence': res['confidence'],
                'policy_action': res['policy_action'],
            })
        except Exception as e:
            job['files'][i]['status'] = 'failed'
            job['files'][i]['error'] = str(e)
            job['progress']['failed'] += 1
            job['results'].append({
                'doc_id': item.get('doc_id'),
                'source_file': item.get('source_file'),
                'error': str(e),
            })

        job['progress']['completed'] = i + 1
        jobs[job_id] = job
        _save_jobs(jobs)

    job['status'] = 'completed'
    job['completed_at'] = datetime.now(timezone.utc).isoformat()
    jobs[job_id] = job
    _save_jobs(jobs)


@app.post('/classify/batch')
async def classify_batch(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
):
    """
    Submit multiple files / folders / ZIPs for asynchronous classification.

    Supports:
      - Single files (PDF, DOCX, TXT, CSV, JSON, MD, HTML, LOG)
      - Folders (use webkitdirectory on the frontend — every file in the
        folder arrives here as a separate UploadFile with its relative
        path as the filename)
      - ZIP archives (auto-expanded server-side; recursive scan)

    Returns a job_id; poll /classify/status/{job_id} for live progress.
    """
    if not files:
        raise HTTPException(400, 'No files supplied.')

    job_id = str(uuid.uuid4())
    items: List[Dict[str, Any]] = []
    expanded_from_zip = 0

    for f in files:
        data = await f.read()
        filename = f.filename or 'unnamed'

        # ZIP archives get auto-expanded
        if filename.lower().endswith('.zip'):
            inner = _expand_zip_bytes(data, source_name=filename)
            expanded_from_zip += len(inner)
            for inner_item in inner:
                text, meta = extract_text_from_bytes(inner_item['data'], inner_item['filename'])
                items.append({
                    'text': text,
                    'metadata': meta,
                    'source_file': inner_item['filename'],
                })
            continue

        # Regular file (or a file inside a folder, with relative path
        # preserved by the browser as filename)
        text, meta = extract_text_from_bytes(data, filename)
        items.append({
            'text': text,
            'metadata': meta,
            'source_file': filename,
        })

    if not items:
        raise HTTPException(400, 'No processable files (after expanding any ZIPs).')

    jobs = _load_jobs()
    jobs[job_id] = {
        'job_id': job_id,
        'status': 'queued',
        'submitted_at': datetime.now(timezone.utc).isoformat(),
        'progress': {'completed': 0, 'total': len(items), 'failed': 0},
        'expanded_from_zip': expanded_from_zip,
        'files': [{'source_file': it['source_file'], 'status': 'queued'} for it in items],
        'results': [],
    }
    _save_jobs(jobs)

    background_tasks.add_task(_run_batch_job, job_id, items)
    return {
        'job_id': job_id,
        'status': 'queued',
        'item_count': len(items),
        'expanded_from_zip': expanded_from_zip,
    }


@app.get('/classify/status/{job_id}')
def get_batch_status(job_id: str):
    jobs = _load_jobs()
    if job_id not in jobs:
        raise HTTPException(404, 'Job not found.')
    return jobs[job_id]


# ─────────────────────────────────────────────────────────────
# Inspection endpoints (PS Layer 2 & 3 — explicit previews)
# ─────────────────────────────────────────────────────────────

@app.post('/preprocess/preview')
def preprocess_preview(req: PreviewRequest):
    """Show exactly what preprocessing did."""
    pre = preprocessing.preprocess(req.text, req.metadata or {})
    return {
        'detected_language': pre.detected_language,
        'language_label': pre.language_label,
        'char_count': pre.char_count,
        'token_count': pre.token_count,
        'chunk_count': pre.chunk_count,
        'pii_entities': pre.pii_entities,
        'metadata': pre.metadata,
        'clean_text': pre.clean_text,
        'masked_text': pre.masked_text,
        'tokens_preview': pre.tokens[:60],
        'chunks_preview': [c[:200] for c in pre.chunks[:5]],
    }


@app.post('/features/preview')
def features_preview(req: PreviewRequest):
    """Show the inspectable feature view that the classifier 'sees'."""
    pre = preprocessing.preprocess(req.text, req.metadata or {})
    feat = feature_engineering.featurize(pre.clean_text, lang=pre.detected_language, top_k=15)
    return {
        'detected_language': pre.detected_language,
        'feature_summary': feat.to_dict(),
    }


# ─────────────────────────────────────────────────────────────
# History & document lookup
# ─────────────────────────────────────────────────────────────

def _read_audit_log(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        return []
    out = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
    return out


@app.get('/history')
def get_history(
    limit: int = 50,
    offset: int = 0,
    label: Optional[str] = None,
    only_overrides: bool = False,
):
    """Paginated audit history."""
    entries = _read_audit_log(AUDIT_LOG)
    overrides = _read_audit_log(OVERRIDE_LOG)
    override_map = {o['doc_id']: o for o in overrides if 'doc_id' in o}

    enriched = []
    for e in entries:
        if e.get('doc_id') in override_map:
            e['human_override'] = override_map[e['doc_id']]
        enriched.append(e)

    if label:
        enriched = [e for e in enriched if e.get('label') == label]
    if only_overrides:
        enriched = [e for e in enriched if 'human_override' in e]

    total = len(enriched)
    enriched = list(reversed(enriched))            # newest first
    page = enriched[offset:offset + limit]
    return {'total': total, 'offset': offset, 'limit': limit, 'entries': page}


@app.get('/document/{doc_id}')
def get_document(doc_id: str):
    entries = _read_audit_log(AUDIT_LOG)
    match = [e for e in entries if e.get('doc_id') == doc_id]
    if not match:
        raise HTTPException(404, 'Document not found in audit log.')
    overrides = _read_audit_log(OVERRIDE_LOG)
    approvals = _read_audit_log(APPROVAL_LOG)
    return {
        'audit': match[-1],
        'overrides': [o for o in overrides if o.get('doc_id') == doc_id],
        'approvals': [a for a in approvals if a.get('doc_id') == doc_id],
    }


# ─────────────────────────────────────────────────────────────
# Human-in-the-loop endpoints
# ─────────────────────────────────────────────────────────────

VALID_LABELS = ['Public', 'Internal', 'Confidential', 'Restricted']


@app.post('/override')
def submit_override(req: OverrideRequest):
    """Record a human correction (or confirmation) for a classification."""
    if req.corrected_label not in VALID_LABELS:
        raise HTTPException(400, f'corrected_label must be one of {VALID_LABELS}')
    if req.original_label not in VALID_LABELS:
        raise HTTPException(400, f'original_label must be one of {VALID_LABELS}')

    is_correction = req.corrected_label != req.original_label
    entry = {
        'doc_id': req.doc_id,
        'original_label': req.original_label,
        'corrected_label': req.corrected_label,
        'reviewer': req.reviewer,
        'reason': req.reason or '',
        'is_correction': is_correction,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    }
    with open(OVERRIDE_LOG, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, sort_keys=True) + '\n')

    return {'status': 'recorded', 'is_correction': is_correction, 'entry': entry}


@app.get('/review-queue')
def get_review_queue():
    queue = active_learning.get_review_queue()
    return {'pending_count': len(queue), 'entries': queue}


# ─────────────────────────────────────────────────────────────
# Approval workflow (Constraint C4)
# ─────────────────────────────────────────────────────────────

@app.post('/approval/sign-off')
def approval_sign_off(req: ApprovalRequest):
    if req.approver not in ('Legal', 'DataGovernance'):
        raise HTTPException(400, "approver must be 'Legal' or 'DataGovernance'")
    if req.decision not in ('approved', 'rejected'):
        raise HTTPException(400, "decision must be 'approved' or 'rejected'")

    entry = {
        'doc_id': req.doc_id,
        'approver': req.approver,
        'decision': req.decision,
        'notes': req.notes or '',
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    }
    with open(APPROVAL_LOG, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, sort_keys=True) + '\n')
    return {'status': 'recorded', 'entry': entry, 'gate_status': _gate_status_for(req.doc_id)}


@app.get('/approval/status/{doc_id}')
def approval_status(doc_id: str):
    return _gate_status_for(doc_id)


def _gate_status_for(doc_id: str) -> Dict[str, Any]:
    audit_entries = [e for e in _read_audit_log(AUDIT_LOG) if e.get('doc_id') == doc_id]
    if not audit_entries:
        return {'doc_id': doc_id, 'error': 'Document not found'}

    latest = audit_entries[-1]
    label = latest.get('label')
    required = {
        'Public': [],
        'Internal': [],
        'Confidential': ['Legal'],
        'Restricted': ['Legal', 'DataGovernance'],
    }.get(label, [])

    approvals = [a for a in _read_audit_log(APPROVAL_LOG) if a.get('doc_id') == doc_id]
    received = {}
    for a in approvals:
        received[a['approver']] = a['decision']

    pending = [r for r in required if received.get(r) != 'approved']
    rejected = any(v == 'rejected' for v in received.values())

    if not required:
        status = 'not_required'
    elif rejected:
        status = 'rejected'
    elif not pending:
        status = 'fully_approved'
    else:
        status = 'pending'

    return {
        'doc_id': doc_id,
        'label': label,
        'required_approvers': required,
        'received': received,
        'pending_approvers': pending,
        'status': status,
    }


# ─────────────────────────────────────────────────────────────
# MLOps endpoints
# ─────────────────────────────────────────────────────────────

@app.get('/mlops/registry')
def mlops_registry():
    try:
        import mlops
        return mlops.load_registry()
    except Exception as e:
        return {'error': str(e)}


@app.get('/mlops/drift')
def mlops_drift():
    """Compute fresh drift report (PSI on label distribution + confidence drop)."""
    try:
        import mlops
        return mlops.compute_drift_report()
    except Exception as e:
        return {'error': str(e)}


@app.get('/mlops/drift/report.html')
def mlops_drift_html():
    """Serve the Evidently AI HTML report, if generated. Falls back to a
    minimal HTML rendering of the JSON report when Evidently is not installed."""
    from fastapi.responses import HTMLResponse, FileResponse
    html_path = os.path.join(LOGS_DIR, 'drift_report.html')
    if os.path.exists(html_path):
        return FileResponse(html_path, media_type='text/html')

    # Fallback: render the JSON report as a tiny HTML page
    json_path = os.path.join(LOGS_DIR, 'drift_report.json')
    if not os.path.exists(json_path):
        return HTMLResponse(
            '<html><body style="font-family:Inter,system-ui;padding:24px">'
            '<h2>No drift report yet</h2>'
            '<p>Trigger one by calling <code>GET /mlops/drift</code>.</p>'
            '</body></html>',
            status_code=404,
        )
    with open(json_path) as f:
        report = json.load(f)
    return HTMLResponse(
        f'''<html><head><style>
        body{{font-family:Inter,system-ui;padding:24px;color:#1e293b;max-width:800px}}
        h2{{margin:0 0 4px 0;color:#0f172a}}
        pre{{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
            padding:16px;font-size:13px;line-height:1.5;overflow:auto}}
        .note{{background:#fef3c7;border:1px solid #fbbf24;color:#78350f;
            padding:8px 12px;border-radius:6px;font-size:13px;margin:12px 0}}
        </style></head><body>
        <h2>Drift Report (fallback view)</h2>
        <div class="note">Install <code>evidently</code> for a full HTML report. This is the raw JSON computed by the lightweight PSI calculator.</div>
        <pre>{json.dumps(report, indent=2)}</pre>
        </body></html>''',
    )


@app.get('/mlops/audit')
def mlops_audit(limit: int = 100):
    """Recent audit log entries — for the MLOps dashboard."""
    entries = _read_audit_log(AUDIT_LOG)
    return {
        'total': len(entries),
        'returned': min(limit, len(entries)),
        'entries': list(reversed(entries))[:limit],
    }


@app.get('/mlops/retraining')
def mlops_retraining():
    """Combine active-learning override summary with drift-based retraining trigger."""
    summary = active_learning.summary()
    try:
        import mlops
        trigger = mlops.check_retraining_trigger()
        summary['drift_trigger'] = trigger
    except Exception as e:
        summary['drift_trigger'] = {'error': str(e)}
    return summary


@app.post('/mlops/retrain')
def mlops_retrain():
    """Lightweight retraining stub.

    In a full deployment this would launch scripts/train_all.py as a subprocess
    or queue a background task. Here we record the intent and return the path
    to the training batch the operator should pass to `python scripts/train_all.py`.
    """
    batch_path = active_learning.export_training_batch(include_text=True)
    entry = {
        'requested_at': datetime.now(timezone.utc).isoformat(),
        'status': 'queued' if batch_path else 'skipped',
        'reason': (
            'No pending overrides — nothing new to learn from.'
            if not batch_path else
            f'Pending overrides exported to {batch_path}.'
        ),
        'batch_path': batch_path,
        'next_step': (
            'Run: python scripts/train_all.py --incremental '
            f'--corrections {batch_path}'
            if batch_path else 'Wait until human overrides accumulate.'
        ),
    }
    retrain_log = os.path.join(LOGS_DIR, 'retraining_requests.jsonl')
    with open(retrain_log, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, sort_keys=True) + '\n')
    return entry


@app.post('/mlops/export-batch')
def mlops_export_batch():
    path = active_learning.export_training_batch(include_text=True)
    if not path:
        return {'exported': False, 'reason': 'No pending overrides.'}
    return {'exported': True, 'path': path, 'pending_count': active_learning.count_pending()}


# ─────────────────────────────────────────────────────────────
# Metrics / health
# ─────────────────────────────────────────────────────────────

@app.get('/health')
def health():
    return {
        'status': 'ok',
        'pipeline_loaded': _PIPELINE is not None,
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    }


@app.get('/metrics')
def get_metrics():
    entries = _read_audit_log(AUDIT_LOG)
    overrides = _read_audit_log(OVERRIDE_LOG)

    if not entries:
        return {
            'total_classified': 0,
            'total_overrides': 0,
            'human_override_rate': 0.0,
            'override_rate_compliant': True,
            'label_distribution': {},
            'avg_confidence': 0.0,
            'target_override_rate': '< 5%',
        }

    label_counts: Dict[str, int] = {}
    confidence_sum = 0.0
    for e in entries:
        lbl = e.get('label', 'Unknown')
        label_counts[lbl] = label_counts.get(lbl, 0) + 1
        confidence_sum += float(e.get('confidence', 0) or 0)

    total = len(entries)
    real_overrides = [
        o for o in overrides
        if o.get('original_label') != o.get('corrected_label')
    ]
    override_rate = len(real_overrides) / total if total else 0.0

    return {
        'total_classified': total,
        'total_overrides': len(real_overrides),
        'total_confirmations': len(overrides) - len(real_overrides),
        'human_override_rate': round(override_rate * 100, 2),
        'override_rate_compliant': override_rate < 0.05,
        'label_distribution': label_counts,
        'avg_confidence': round(confidence_sum / total, 4) if total else 0.0,
        'target_override_rate': '< 5%',
    }


@app.get('/')
def root():
    return {
        'service': 'DataShield Sensitivity Classification Engine',
        'version': '1.1.0',
        'docs': '/docs',
        'health': '/health',
    }


# ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import uvicorn
    print('[API] Starting DataShield API on http://localhost:8000')
    print('[API] Docs at http://localhost:8000/docs')
    uvicorn.run(app, host='127.0.0.1', port=8000)
