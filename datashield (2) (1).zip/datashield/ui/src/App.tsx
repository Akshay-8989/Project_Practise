import { useEffect, useState } from 'react';
import { Routes, Route, NavLink, Navigate } from 'react-router-dom';
import {
  ShieldCheck, FileScan, ClipboardList, GitMerge, Activity,
} from 'lucide-react';
import ClassifyPage from './pages/ClassifyPage';
import HistoryPage from './pages/HistoryPage';
import ApprovalsPage from './pages/ApprovalsPage';
import MLOpsPage from './pages/MLOpsPage';
import { api } from './lib/api';

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV: NavItem[] = [
  { to: '/classify',  label: 'Classify',  icon: FileScan },
  { to: '/history',   label: 'History',   icon: ClipboardList },
  { to: '/approvals', label: 'Approvals', icon: GitMerge },
  { to: '/mlops',     label: 'MLOps',     icon: Activity },
];

export default function App() {
  const [apiOnline, setApiOnline] = useState<boolean | null>(null);

  // Poll health every 5s
  useEffect(() => {
    const check = async () => {
      try { await api.health(); setApiOnline(true); }
      catch { setApiOnline(false); }
    };
    check();
    const id = setInterval(check, 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Sidebar */}
      <aside className="w-60 bg-white border-r border-slate-200 flex flex-col">
        {/* Brand */}
        <div className="px-5 py-5 border-b border-slate-200">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-md bg-slate-900 flex items-center justify-center">
              <ShieldCheck className="w-4.5 h-4.5 text-white" strokeWidth={2} />
            </div>
            <div>
              <div className="text-[15px] font-semibold tracking-tight text-slate-900 leading-none">
                DataShield
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Sensitivity Engine</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2.5 py-4 space-y-0.5">
          {NAV.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-2.5 px-3 py-2 rounded-md text-sm transition-colors ${
                  isActive
                    ? 'bg-slate-100 text-slate-900 font-medium'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`
              }
            >
              <item.icon className="w-4 h-4 flex-shrink-0" strokeWidth={2} />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* Footer status */}
        <div className="px-4 py-3 border-t border-slate-200">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span
              className={`dot ${
                apiOnline === true ? 'dot-good' :
                apiOnline === false ? 'dot-bad' : 'dot-neutral'
              }`}
            />
            <span>
              API {apiOnline === true ? 'connected' : apiOnline === false ? 'offline' : 'checking'}
            </span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1.5 tracking-wide">v3.0.0 · local</div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-x-auto">
        {apiOnline === false && (
          <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-6 py-2.5 text-sm flex items-center gap-2">
            <span className="dot dot-warn" />
            <span>
              Backend offline. Start it with{' '}
              <code className="px-1.5 py-0.5 bg-amber-100 rounded text-[12px] font-mono">python run.py</code>.
            </span>
          </div>
        )}
        <div className="px-8 py-6 max-w-screen-2xl">
          <Routes>
            <Route path="/"          element={<Navigate to="/classify" replace />} />
            <Route path="/classify"  element={<ClassifyPage />} />
            <Route path="/history"   element={<HistoryPage />} />
            <Route path="/approvals" element={<ApprovalsPage />} />
            <Route path="/mlops"     element={<MLOpsPage />} />
            <Route path="/metrics"   element={<Navigate to="/mlops" replace />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}
