import { useEffect, useState } from 'react';
import { CheckCircle2, XCircle, Shield, AlertTriangle } from 'lucide-react';
import { PageHeader, Card, SectionTitle, LabelBadge, EmptyState, Spinner } from '../components/UI';
import { api } from '../lib/api';

export default function ApprovalsPage() {
  const [docs, setDocs] = useState<any[]>([]);
  const [gates, setGates] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const h = await api.history({ limit: 100 });
      const pending = h.entries.filter(e => e.label === 'Confidential' || e.label === 'Restricted');
      setDocs(pending);

      // Load gate status for each
      const gateMap: Record<string, any> = {};
      await Promise.all(pending.map(async d => {
        try { gateMap[d.doc_id] = await api.approvalStatus(d.doc_id); } catch {}
      }));
      setGates(gateMap);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <div>
      <PageHeader
        title="Approval Workflow"
        subtitle="Constraint C4 — Restricted documents require Legal + Data Governance dual approval. Confidential requires Legal only."
      />

      {loading ? (
        <Card><div className="flex items-center justify-center py-8"><Spinner className="w-8 h-8" /></div></Card>
      ) : !docs.length ? (
        <Card><EmptyState icon={CheckCircle2} title="All clear" hint="No Confidential or Restricted documents need attention." /></Card>
      ) : (
        <div className="space-y-3">
          <div className="text-sm font-medium text-slate-700">
            {docs.length} document(s) require approval
          </div>
          {docs.map(d => (
            <ApprovalRow key={d.doc_id} doc={d} gate={gates[d.doc_id]} onUpdate={load} />
          ))}
        </div>
      )}
    </div>
  );
}

function ApprovalRow({ doc, gate, onUpdate }: { doc: any; gate: any; onUpdate: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const [approver, setApprover] = useState<'Legal' | 'DataGovernance'>('Legal');
  const [decision, setDecision] = useState<'approved' | 'rejected'>('approved');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const status = gate?.status || 'unknown';
  const required = gate?.required_approvers || [];
  const received = gate?.received || {};
  const pending = gate?.pending_approvers || [];

  const statusColor =
    status === 'fully_approved' ? 'text-emerald-700 bg-emerald-50 border-emerald-200' :
    status === 'rejected' ? 'text-rose-700 bg-rose-50 border-rose-200' :
    status === 'pending' ? 'text-amber-700 bg-amber-50 border-amber-200' :
    'text-slate-700 bg-slate-50 border-slate-200';

  const submit = async () => {
    setSubmitting(true);
    try {
      await api.approve({ doc_id: doc.doc_id, approver, decision, notes });
      setExpanded(false);
      setNotes('');
      onUpdate();
    } catch (e: any) {
      alert('Failed: ' + e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="!p-0 overflow-hidden">
      <div className="px-5 py-4 flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3 flex-wrap">
          <LabelBadge label={doc.label} />
          <code className="text-xs font-mono text-slate-600">{doc.doc_id}</code>
          <span className={`pill ${statusColor}`}>{status}</span>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="text-xs text-slate-600">
            {Object.entries(received).length > 0
              ? `Received: ${Object.entries(received).map(([k, v]) => `${k} (${v})`).join(', ')}`
              : 'No signatures yet'}
          </div>
          {pending.length > 0 && (
            <div className="text-xs text-amber-700">Pending: {pending.join(', ')}</div>
          )}
          <button
            onClick={() => setExpanded(!expanded)}
            className={expanded ? 'btn-secondary' : 'btn-primary'}
          >
            {expanded ? 'Close' : 'Sign Off'}
          </button>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-slate-200 px-5 py-4 bg-slate-50/50 fade-in">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="label-text">Signing as</label>
              <select className="input" value={approver} onChange={e => setApprover(e.target.value as any)}>
                <option value="Legal">Legal</option>
                <option value="DataGovernance">Data Governance</option>
              </select>
            </div>
            <div>
              <label className="label-text">Decision</label>
              <select className="input" value={decision} onChange={e => setDecision(e.target.value as any)}>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
            <div>
              <label className="label-text">Notes</label>
              <input className="input" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Optional…" />
            </div>
          </div>
          <div className="mt-3 flex justify-end">
            <button onClick={submit} disabled={submitting} className={decision === 'approved' ? 'btn-primary' : 'btn-danger'}>
              {submitting ? <Spinner /> : decision === 'approved' ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
              Submit {decision === 'approved' ? 'approval' : 'rejection'}
            </button>
          </div>
        </div>
      )}
    </Card>
  );
}
