import { useState } from 'react';
import {
  Check, AlertCircle, Clock, Languages, Shield, Eye, EyeOff,
  FileSearch, Sparkles, Hash, AlignLeft, Layers, X, FileText,
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from 'recharts';
import { ClassifyResponse, api } from '../lib/api';
import { LabelBadge, ActionBadge, Spinner } from './UI';
import PolicyTraceView from './PolicyTraceView';

const LABEL_COLORS: Record<string, string> = {
  Public: '#10b981',
  Internal: '#3b82f6',
  Confidential: '#f59e0b',
  Restricted: '#ef4444',
};

const VALID_LABELS = ['Public', 'Internal', 'Confidential', 'Restricted'];

export default function ResultCard({ result, onOverride }: {
  result: ClassifyResponse;
  onOverride?: () => void;
}) {
  const [insightsOpen, setInsightsOpen] = useState(false);
  const [reviewer, setReviewer] = useState('analyst@datashield');
  const [reason, setReason] = useState('');
  const [corrected, setCorrected] = useState(result.label);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState<string | null>(null);

  const probs = result.class_probabilities || {};
  const probData = VALID_LABELS.map(l => ({ name: l, value: probs[l] || 0 }));

  const submitHitl = async (action: 'confirm' | 'correct') => {
    if (!result.doc_id) return;
    const payload = {
      doc_id: result.doc_id,
      original_label: result.label,
      corrected_label: action === 'confirm' ? result.label : corrected,
      reviewer,
      reason: reason || (action === 'confirm' ? 'confirmed correct' : '(no reason given)'),
    };
    setSubmitting(true);
    try {
      await api.override(payload);
      setSubmitted(action === 'confirm' ? 'Confirmed correct' : `Corrected to ${corrected}`);
      onOverride?.();
    } catch (e: any) {
      alert('Submit failed: ' + e.message);
    } finally {
      setSubmitting(false);
    }
  };

  const lat = result.latency_ms || { total: 0, preprocessing: 0, features: 0, classification: 0 };
  const evidence = result.evidence || [];
  const pii = result.preprocessing?.pii_entities || [];

  return (
    <div className="card overflow-hidden fade-in">
      {/* Header — label, action, latency, doc_id */}
      <div className="px-5 py-4 bg-slate-50/60 border-b border-slate-200">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3 flex-wrap">
            <LabelBadge label={result.label} />
            <span className="text-sm font-medium text-slate-700">
              {(result.confidence * 100).toFixed(1)}% confidence
            </span>
            <ActionBadge action={result.policy_action} />
          </div>
          <div className="flex items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />{lat.total?.toFixed(0)} ms</span>
            <span className="flex items-center gap-1.5"><Languages className="w-3.5 h-3.5" />{result.language?.routed_to || 'en'}</span>
            <code className="font-mono text-slate-600">{result.doc_id?.slice(0, 18)}</code>
          </div>
        </div>
        {result.source_file && (
          <div className="text-xs text-slate-500 mt-2"><FileText className="w-3.5 h-3.5 inline mr-1" />{result.source_file}</div>
        )}
      </div>

      <div className="p-5 space-y-5">
        {/* Probabilities chart */}
        <div>
          <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-2">Class Probabilities</h3>
          <div className="h-32">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={probData} layout="vertical" margin={{ left: 10, right: 30 }}>
                <XAxis type="number" domain={[0, 1]} hide />
                <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip
                  formatter={(v: any) => `${(v * 100).toFixed(1)}%`}
                  contentStyle={{ fontSize: 12, borderRadius: 6, border: '1px solid #e2e8f0' }}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {probData.map((d) => (
                    <Cell key={d.name} fill={LABEL_COLORS[d.name]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Evidence tokens */}
        <div>
          <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-2">
            Evidence Tokens
            <span className="ml-2 text-slate-400 font-normal normal-case">
              ({evidence.length} ≥ 3 {evidence.length >= 3 ? '✓' : '✗'})
            </span>
          </h3>
          <div className="space-y-1.5">
            {evidence.slice(0, 8).map((e, i) => (
              <div key={i} className="flex items-center justify-between bg-slate-50 border-l-4 border-brand-500 rounded px-3 py-1.5">
                <code className="font-mono text-sm text-slate-800">{e.token}</code>
                <span className="text-xs text-slate-500">
                  weight {e.weight?.toFixed(3)} · <span className="text-slate-400">{e.source}</span>
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* PII pills */}
        {pii.length > 0 && (
          <div>
            <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-2">
              PII Detected & Masked
            </h3>
            <div className="flex flex-wrap gap-1.5">
              {pii.map((p: string) => (
                <span key={p} className="inline-flex items-center gap-1 px-2 py-1 rounded bg-rose-50 text-rose-700 text-xs font-medium border border-rose-200">
                  <Shield className="w-3 h-3" />{p}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Latency breakdown */}
        <div className="grid grid-cols-4 gap-2 text-center text-xs">
          <LatencyChip label="Preprocess" value={lat.preprocessing} />
          <LatencyChip label="Features" value={lat.features} />
          <LatencyChip label="Classify" value={lat.classification} />
          <LatencyChip label="Total" value={lat.total} highlight />
        </div>

        {/* View Insights button */}
        <div className="flex justify-center">
          <button
            onClick={() => setInsightsOpen(true)}
            className="btn-secondary"
          >
            <Eye className="w-4 h-4" />
            View Insights
          </button>
        </div>

        {/* HITL */}
        <div className="border-t border-slate-200 pt-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">👤 Human-in-the-Loop Review</h3>
          {submitted ? (
            <div className="flex items-center gap-2 text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2 text-sm">
              <Check className="w-4 h-4" />{submitted}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="label-text">Reviewer</label>
                  <input className="input" value={reviewer} onChange={e => setReviewer(e.target.value)} />
                </div>
                <div>
                  <label className="label-text">Correct label</label>
                  <select className="input" value={corrected} onChange={e => setCorrected(e.target.value)}>
                    {VALID_LABELS.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </div>
              </div>
              <div className="mb-3">
                <label className="label-text">Reason / notes (optional)</label>
                <textarea
                  className="input"
                  rows={2}
                  value={reason}
                  onChange={e => setReason(e.target.value)}
                  placeholder="Why correct, or context for the decision…"
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => submitHitl('confirm')}
                  disabled={submitting}
                  className="btn-secondary flex-1"
                >
                  {submitting ? <Spinner /> : <Check className="w-4 h-4" />} Confirm Correct
                </button>
                <button
                  onClick={() => submitHitl('correct')}
                  disabled={submitting || corrected === result.label}
                  className="btn-primary flex-1"
                >
                  <AlertCircle className="w-4 h-4" /> Submit Correction
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Insights modal */}
      {insightsOpen && (
        <InsightsModal result={result} onClose={() => setInsightsOpen(false)} />
      )}
    </div>
  );
}

function LatencyChip({ label, value, highlight }: { label: string; value: number; highlight?: boolean }) {
  return (
    <div className={`rounded-lg px-2 py-2 ${highlight ? 'bg-brand-50 text-brand-700 border border-brand-200' : 'bg-slate-50 border border-slate-200 text-slate-700'}`}>
      <div className="font-semibold">{value?.toFixed(0)} ms</div>
      <div className="text-[10px] uppercase tracking-wide opacity-70">{label}</div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// Insights modal — readable for end users + policy as JSON
// ────────────────────────────────────────────────────────────

function InsightsModal({ result, onClose }: { result: ClassifyResponse; onClose: () => void }) {
  const pre = result.preprocessing || {};
  const feat = result.features || {};
  const meta = pre.metadata || {};
  const numFeat = feat.numeric_features || {};
  const tfidf = feat.tfidf_top || [];

  // Stop background scroll while modal is open
  useEffectStopScroll();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 fade-in" onClick={onClose}>
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Modal header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/60">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-brand-600" />
              Classification Insights
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Detailed view of how this document was processed and classified.</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100 transition-colors">
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Modal body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">

          {/* Summary strip */}
          <div className="grid grid-cols-4 gap-3">
            <InfoTile label="Final Label" value={<LabelBadge label={result.label} />} />
            <InfoTile label="Confidence" value={<span className="font-semibold">{(result.confidence * 100).toFixed(1)}%</span>} />
            <InfoTile label="Policy Action" value={<ActionBadge action={result.policy_action} />} />
            <InfoTile label="Latency" value={<span className="font-semibold">{result.latency_ms?.total?.toFixed(0)} ms</span>} />
          </div>

          {/* Document overview */}
          <Section icon={FileSearch} title="Document Overview">
            <DefList items={[
              ['Document ID', <code className="font-mono text-xs">{result.doc_id}</code>],
              ['Language detected', `${pre.language_label || pre.detected_language || 'Unknown'} (${pre.detected_language || '—'})`],
              ['Source system', meta.source_system || '—'],
              ['Department', meta.department || '—'],
              ['File type', meta.file_type || '—'],
              ['Timestamp', result.timestamp_utc?.replace('T', ' ').slice(0, 19) + ' UTC'],
            ]} />
          </Section>

          {/* Content statistics */}
          <Section icon={AlignLeft} title="Content Statistics">
            <div className="grid grid-cols-3 gap-3">
              <StatCard label="Characters" value={numFeat.num_chars?.toLocaleString() || pre.char_count?.toLocaleString() || '—'} />
              <StatCard label="Tokens" value={numFeat.num_tokens?.toLocaleString() || pre.token_count?.toLocaleString() || '—'} />
              <StatCard label="Chunks" value={pre.chunk_count?.toString() || '—'} />
              <StatCard label="Digits" value={numFeat.num_digits?.toLocaleString() || '—'} />
              <StatCard label="Digit ratio" value={numFeat.digit_ratio !== undefined ? `${(numFeat.digit_ratio * 100).toFixed(1)}%` : '—'} />
              <StatCard label="Vocabulary used" value={feat.vocab_size?.toLocaleString() || '—'} />
            </div>
          </Section>

          {/* PII findings */}
          {pre.pii_entities?.length > 0 && (
            <Section icon={Shield} title="Sensitive Data Detected">
              <p className="text-sm text-slate-700 mb-3">
                The following types of personally identifiable information were detected and <strong>masked before storage</strong>:
              </p>
              <div className="flex flex-wrap gap-2">
                {pre.pii_entities.map((p: string) => (
                  <span key={p} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 text-rose-700 text-sm font-medium border border-rose-200">
                    <Shield className="w-3.5 h-3.5" />{p}
                  </span>
                ))}
              </div>
              {pre.masked_text_preview && (
                <div className="mt-3">
                  <div className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-1.5">Masked snippet (stored in audit log)</div>
                  <pre className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs font-mono whitespace-pre-wrap text-slate-700 max-h-32 overflow-y-auto">
                    {pre.masked_text_preview}
                  </pre>
                </div>
              )}
            </Section>
          )}

          {/* Top keywords */}
          {tfidf.length > 0 && (
            <Section icon={Hash} title="Top Keywords Driving the Decision">
              <p className="text-sm text-slate-600 mb-3">
                These are the most influential terms in the document, ranked by their TF-IDF weight.
              </p>
              <div className="grid grid-cols-2 gap-2">
                {tfidf.slice(0, 10).map((t: any, i: number) => (
                  <div key={i} className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                    <code className="font-mono text-sm text-slate-800">{t.token}</code>
                    <span className="text-xs text-slate-500">weight {t.weight?.toFixed(3)}</span>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Class probabilities */}
          <Section icon={Layers} title="How Confident is the Model About Each Class">
            <div className="space-y-2">
              {VALID_LABELS.map(lbl => {
                const v = result.class_probabilities?.[lbl] || 0;
                return (
                  <div key={lbl}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="font-medium text-slate-700">{lbl}</span>
                      <span className="font-semibold text-slate-900">{(v * 100).toFixed(2)}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all"
                        style={{ width: `${v * 100}%`, backgroundColor: LABEL_COLORS[lbl] }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </Section>

          {/* Latency breakdown */}
          <Section icon={Clock} title="Latency Breakdown">
            <div className="grid grid-cols-4 gap-3">
              <StatCard label="Preprocessing" value={`${result.latency_ms?.preprocessing?.toFixed(0)} ms`} />
              <StatCard label="Feature engineering" value={`${result.latency_ms?.features?.toFixed(0)} ms`} />
              <StatCard label="Classification" value={`${result.latency_ms?.classification?.toFixed(0)} ms`} />
              <StatCard label="Total" value={`${result.latency_ms?.total?.toFixed(0)} ms`} highlight />
            </div>
          </Section>

          {/* Policy engine — human-readable */}
          <Section icon={Shield} title="Policy Engine Decision">
            <p className="text-sm text-slate-600 mb-3">
              How the policy engine evaluated this document, step by step:
            </p>
            <PolicyTraceView trace={result.policy_trace} />
          </Section>
        </div>

        {/* Modal footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button onClick={onClose} className="btn-secondary">
            <EyeOff className="w-4 h-4" /> Close insights
          </button>
        </div>
      </div>
    </div>
  );
}

// Helpers ────────────────────────────────────────────────────

function Section({ icon: Icon, title, children }: { icon: any; title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-3">
        <Icon className="w-4 h-4 text-brand-600" />
        {title}
      </h3>
      {children}
    </div>
  );
}

function InfoTile({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
      <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wide">{label}</div>
      <div className="mt-1">{value}</div>
    </div>
  );
}

function StatCard({ label, value, highlight }: { label: string; value: React.ReactNode; highlight?: boolean }) {
  return (
    <div className={`rounded-lg px-3 py-2.5 border ${highlight ? 'bg-brand-50 border-brand-200 text-brand-700' : 'bg-slate-50 border-slate-200 text-slate-700'}`}>
      <div className="text-[10px] font-semibold uppercase tracking-wide opacity-80">{label}</div>
      <div className="font-semibold mt-0.5 text-base">{value}</div>
    </div>
  );
}

function DefList({ items }: { items: [string, React.ReactNode][] }) {
  return (
    <dl className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
      {items.map(([k, v]) => (
        <div key={k} className="flex items-center gap-3 px-4 py-2.5 odd:bg-slate-50/50">
          <dt className="text-sm text-slate-600 w-44 flex-shrink-0">{k}</dt>
          <dd className="text-sm text-slate-900 font-medium">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

// Stops the page from scrolling under the modal.
import { useEffect } from 'react';
function useEffectStopScroll() {
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, []);
}
