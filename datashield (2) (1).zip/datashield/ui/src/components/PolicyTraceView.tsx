import {
  Shield, AlertCircle, CheckCircle2, ArrowRight, Scale,
  FileSearch, Lock, Info,
} from 'lucide-react';
import { LabelBadge, ActionBadge } from './UI';

interface PolicyTrace {
  pre_policy_label?: string;
  post_policy_label?: string;
  triggered_rules?: string[];
  action?: string;
  pii_hits?: Array<{ rule: string; matched: string; severity: string }>;
  note?: string;
  approval?: any;
  conflict_resolution?: { fired_rules?: any[]; winning_rule?: string | null };
  calibration_source?: any;
}

// Maps short rule keys to friendly explanations the operator can read.
const RULE_NAMES: Record<string, { title: string; description: string }> = {
  PII_REGEX_SSN: {
    title: 'US Social Security Number detected',
    description: 'A pattern matching a US SSN (XXX-XX-XXXX) was found in the content.',
  },
  PII_REGEX_CARD: {
    title: 'Payment card number detected',
    description: 'A Luhn-valid 13–16 digit credit / debit card number was found.',
  },
  PII_REGEX_IBAN: {
    title: 'IBAN bank-account number detected',
    description: 'An International Bank Account Number pattern was found.',
  },
  PII_REGEX_PAN: {
    title: 'Indian PAN number detected',
    description: 'An Indian Permanent Account Number (Income Tax ID) was found.',
  },
  PII_REGEX_AADHAAR: {
    title: 'Indian Aadhaar number detected',
    description: 'A 12-digit Aadhaar identifier was found.',
  },
  PII_REGEX_EMAIL: {
    title: 'Email address detected',
    description: 'A personal email address pattern was found.',
  },
  PII_REGEX_PHONE: {
    title: 'Phone number detected',
    description: 'A phone-number pattern was found.',
  },
  PII_REGEX_DOB: {
    title: 'Date of birth detected',
    description: 'A date format that looks like a date of birth was found.',
  },
  THRESHOLD_CONFIDENTIAL: {
    title: 'Confidential threshold crossed',
    description: 'Model probability for Confidential exceeded the calibrated cutoff.',
  },
  THRESHOLD_RESTRICTED: {
    title: 'Restricted threshold crossed',
    description: 'Model probability for Restricted exceeded the calibrated cutoff.',
  },
  THRESHOLD_INTERNAL: {
    title: 'Internal threshold crossed',
    description: 'Model probability for Internal exceeded the calibrated cutoff.',
  },
};

function ruleInfo(key: string): { title: string; description: string } {
  if (RULE_NAMES[key]) return RULE_NAMES[key];
  // Generic fallback for unknown rules — turn snake_case into Title Case.
  const title = key
    .replace(/^PII_REGEX_/, 'PII detected — ')
    .replace(/^THRESHOLD_/, 'Threshold reached — ')
    .replace(/_/g, ' ')
    .toLowerCase()
    .replace(/^./, c => c.toUpperCase());
  return { title, description: 'Configured rule fired during evaluation.' };
}

function severityBadge(sev: string) {
  if (sev === 'high') {
    return <span className="pill bg-rose-50 text-rose-700 border-rose-200">High severity</span>;
  }
  if (sev === 'medium') {
    return <span className="pill bg-amber-50 text-amber-700 border-amber-200">Medium severity</span>;
  }
  return <span className="pill bg-slate-50 text-slate-700 border-slate-200">{sev || 'severity unknown'}</span>;
}


// ───────────────────────────────────────────────────────────
// Main component
// ───────────────────────────────────────────────────────────

export default function PolicyTraceView({ trace }: { trace: PolicyTrace | null | undefined }) {
  if (!trace || typeof trace !== 'object') {
    return (
      <div className="text-sm text-slate-500 italic">No policy decisions recorded for this document.</div>
    );
  }

  const pre = trace.pre_policy_label;
  const post = trace.post_policy_label;
  const wasOverridden = pre && post && pre !== post;
  const piiHits = trace.pii_hits || [];
  const triggered = trace.triggered_rules || [];
  const approval = trace.approval || null;
  const conflict = trace.conflict_resolution || {};
  const firedRules = conflict.fired_rules || [];
  const winning = conflict.winning_rule;

  return (
    <div className="space-y-4">
      {/* Step 1: model → policy → final */}
      <div className="rounded-lg border border-slate-200 bg-slate-50/60 px-4 py-3">
        <div className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-2 flex items-center gap-1.5">
          <ArrowRight className="w-3.5 h-3.5" />
          Decision flow
        </div>
        <div className="flex items-center flex-wrap gap-3 text-sm">
          <div className="flex items-center gap-2">
            <span className="text-slate-600">Model suggested</span>
            <LabelBadge label={pre} />
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center gap-2">
            <span className="text-slate-600">Final label</span>
            <LabelBadge label={post} />
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400" />
          <div className="flex items-center gap-2">
            <span className="text-slate-600">Action</span>
            <ActionBadge action={trace.action} />
          </div>
        </div>
        {wasOverridden && (
          <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded px-3 py-1.5 mt-3 flex items-start gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
            The policy engine overrode the model's suggestion to be safe.
          </div>
        )}
        {trace.note && (
          <div className="text-xs text-slate-600 italic mt-2">Note: {trace.note}</div>
        )}
      </div>

      {/* Step 2: Sensitive patterns found */}
      {piiHits.length > 0 ? (
        <Block icon={Shield} title={`${piiHits.length} sensitive pattern${piiHits.length === 1 ? '' : 's'} found in content`}>
          <ul className="space-y-2">
            {piiHits.map((h, i) => {
              const info = ruleInfo(h.rule);
              return (
                <li key={i} className="border border-slate-200 rounded-lg px-3 py-2 bg-white">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="font-medium text-slate-900 text-sm">{info.title}</div>
                    {severityBadge(h.severity)}
                  </div>
                  <div className="text-xs text-slate-600 mt-1">{info.description}</div>
                  {h.matched && (
                    <div className="mt-2 text-xs">
                      <span className="text-slate-500">Matched (masked): </span>
                      <code className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-800">{h.matched}</code>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </Block>
      ) : (
        <Block icon={CheckCircle2} title="No sensitive patterns matched" tone="success">
          <p className="text-sm text-slate-600">
            The PII rule set did not match any high-risk content (SSN, payment card, IBAN, PAN, Aadhaar, etc.).
          </p>
        </Block>
      )}

      {/* Step 3: Rules that fired */}
      {triggered.length > 0 && (
        <Block icon={FileSearch} title={`${triggered.length} policy rule${triggered.length === 1 ? '' : 's'} fired`}>
          <ul className="space-y-2">
            {triggered.map((r, i) => {
              const info = ruleInfo(r);
              return (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-brand-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="font-medium text-slate-900">{info.title}</div>
                    <div className="text-xs text-slate-600">{info.description}</div>
                  </div>
                </li>
              );
            })}
          </ul>
        </Block>
      )}

      {/* Step 4: Conflict resolution */}
      {firedRules.length > 1 && (
        <Block icon={Scale} title="Multiple rules competed for the final decision">
          <p className="text-sm text-slate-600 mb-3">
            More than one rule fired. The engine picked the highest-priority winner:
          </p>
          <ul className="space-y-1.5">
            {firedRules.map((fr: any, i: number) => {
              const ruleName = typeof fr === 'string' ? fr : (fr.rule || fr.name || JSON.stringify(fr));
              const isWinner = winning === ruleName || (typeof fr === 'object' && fr.rule === winning);
              const info = ruleInfo(ruleName);
              return (
                <li key={i} className={`flex items-center gap-2 text-sm rounded-md px-2 py-1.5 ${isWinner ? 'bg-emerald-50 border border-emerald-200' : 'bg-slate-50'}`}>
                  {isWinner
                    ? <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                    : <Info className="w-4 h-4 text-slate-400 flex-shrink-0" />}
                  <span className={isWinner ? 'font-medium text-emerald-900' : 'text-slate-700'}>{info.title}</span>
                  {isWinner && <span className="text-xs ml-auto text-emerald-700 font-semibold">winner</span>}
                </li>
              );
            })}
          </ul>
        </Block>
      )}

      {/* Step 5: Approval gate */}
      {approval && (
        <Block icon={Lock} title="Approval gate">
          <ApprovalGateView approval={approval} />
        </Block>
      )}

      {/* Step 6: Calibration source */}
      {trace.calibration_source && (
        <Block icon={Info} title="How were the thresholds chosen?">
          <CalibrationView source={trace.calibration_source} />
        </Block>
      )}
    </div>
  );
}

// ───────────────────────────────────────────────────────────
// Sub-components
// ───────────────────────────────────────────────────────────

function Block({ icon: Icon, title, children, tone }: {
  icon: any;
  title: string;
  children: React.ReactNode;
  tone?: 'success' | 'default';
}) {
  const ring = tone === 'success'
    ? 'border-emerald-200 bg-emerald-50/40'
    : 'border-slate-200 bg-white';
  const iconColor = tone === 'success' ? 'text-emerald-600' : 'text-brand-600';
  return (
    <div className={`rounded-lg border ${ring} px-4 py-3`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className={`w-4 h-4 ${iconColor}`} />
        <h4 className="text-sm font-semibold text-slate-900">{title}</h4>
      </div>
      {children}
    </div>
  );
}

function ApprovalGateView({ approval }: { approval: any }) {
  if (!approval || typeof approval !== 'object') return null;

  const required: string[] = approval.required_approvers || approval.required || [];
  const received: Record<string, string> = approval.received || {};
  const pending: string[] = approval.pending_approvers || approval.pending || [];
  const status: string = approval.status || (required.length === 0 ? 'not_required' : 'pending');

  const statusLabel: Record<string, string> = {
    not_required: 'No approval required',
    pending: 'Pending sign-off',
    fully_approved: 'Fully approved',
    rejected: 'Rejected',
  };
  const statusClass: Record<string, string> = {
    not_required: 'bg-slate-50 text-slate-700 border-slate-200',
    pending: 'bg-amber-50 text-amber-700 border-amber-200',
    fully_approved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    rejected: 'bg-rose-50 text-rose-700 border-rose-200',
  };

  if (!required.length) {
    return (
      <p className="text-sm text-slate-600">
        This sensitivity level does not require human sign-off.{' '}
        <span className={`pill ${statusClass.not_required}`}>{statusLabel.not_required}</span>
      </p>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-sm">
        <span className="text-slate-600">Status:</span>
        <span className={`pill ${statusClass[status] || statusClass.pending}`}>
          {statusLabel[status] || status}
        </span>
      </div>

      <div>
        <div className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-1.5">
          Required approvers
        </div>
        <ul className="space-y-1">
          {required.map(role => {
            const decision = received[role];
            const isApproved = decision === 'approved';
            const isRejected = decision === 'rejected';
            const isPending = pending.includes(role) || !decision;
            return (
              <li key={role} className="flex items-center gap-2 text-sm">
                {isApproved && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                {isRejected && <AlertCircle className="w-4 h-4 text-rose-600" />}
                {isPending && <Info className="w-4 h-4 text-amber-500" />}
                <span className="font-medium text-slate-800">{role}</span>
                <span className="text-slate-500">
                  {isApproved && '— approved'}
                  {isRejected && '— rejected'}
                  {isPending && '— awaiting sign-off'}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

function CalibrationView({ source }: { source: any }) {
  if (!source || typeof source !== 'object') return null;
  const entries = Object.entries(source);
  if (!entries.length) return null;

  return (
    <div className="text-sm text-slate-700 space-y-1.5">
      <p className="text-slate-600 mb-2">
        Thresholds were tuned on a held-out validation set, not hand-picked. Source values used:
      </p>
      <dl className="border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-100">
        {entries.map(([k, v]) => (
          <div key={k} className="flex items-center px-3 py-1.5 odd:bg-slate-50/60 text-xs">
            <dt className="text-slate-600 w-48 flex-shrink-0">{k.replace(/_/g, ' ')}</dt>
            <dd className="font-mono text-slate-900">{typeof v === 'object' ? JSON.stringify(v) : String(v)}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
