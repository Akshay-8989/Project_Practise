"""
transformer_model.py
--------------------
Transformer-based classifier using HuggingFace transformers.

Role in ensemble:
  - Captures deep contextual patterns that TF-IDF misses
  - Multilingual: xlm-roberta-base handles both English and Hindi
  - Strongest on nuanced, long-form documents

Explainability: Integrated Gradients (see explainability/ig_explainer.py)

Graceful fallback:
  If torch or transformers is not installed, the pipeline skips this model
  and redistributes voting weights to LR + XGBoost (see ensemble/voting.py).
  This allows the module to run on machines without GPU / without torch.

IMPORTANT - Safe torch detection:
  torch is NOT imported at module level because on some Windows machines
  `import torch` causes a C-level access violation (not catchable by Python).
  We use subprocess to check whether torch works before importing it.

To enable:
    pip install -r requirements-transformer.txt

Why separate requirements file:
  - torch + transformers is ~2GB on disk
  - Windows DLL conflicts are common with CUDA torch on Python 3.11
  - The base module (LR + XGBoost) covers all functional requirements
  - Transformer is an accuracy BOOST, not a hard dependency
"""
import os
import subprocess
import sys
from typing import List, Dict, Any, Optional
import numpy as np
import joblib


def _check_torch_safe() -> bool:
    """
    Safely check if torch is importable by running a subprocess.
    This avoids C-level crashes (access violations) from killing the
    main process on Windows with broken CUDA DLLs.
    """
    try:
        result = subprocess.run(
            [sys.executable, '-c', 'import torch; import transformers; print("ok")'],
            capture_output=True, text=True, timeout=15,
        )
        return result.returncode == 0 and 'ok' in result.stdout
    except Exception:
        return False


TORCH_AVAILABLE = _check_torch_safe()


class TransformerModel:
    """
    Fine-tuned transformer classifier.

    Uses [CLS] pooling -> dropout -> linear for classification.
    Supports any HuggingFace model (default: distilbert-base-multilingual-cased
    for bilingual EN/HI support).

    All torch usage is guarded by lazy imports to avoid Windows DLL crashes.
    """

    def __init__(self, cfg: Dict[str, Any], classes: List[str]):
        import torch
        import torch.nn as nn
        from transformers import AutoTokenizer, AutoModel

        self.classes = classes
        self.num_classes = len(classes)
        self.model_name = cfg.get('model_name', 'distilbert-base-multilingual-cased')
        self.max_length = cfg.get('max_length', 256)
        self.batch_size = cfg.get('batch_size', 16)
        self.epochs = cfg.get('epochs', 2)
        self.lr = cfg.get('learning_rate', 5e-5)
        self.warmup_ratio = cfg.get('warmup_ratio', 0.1)
        self.weight_decay = cfg.get('weight_decay', 0.01)

        # CPU optimization: when fast_finetune is True, the encoder is FROZEN
        # and only the small classification head is trained. This is 3-5x
        # faster on CPU at the cost of ~1-2% F1 on synthetic data. Recommended
        # for office laptops without a GPU. Set to False to fully fine-tune.
        self.fast_finetune = cfg.get('fast_finetune', True)

        # CPU optimization: bigger inference batches mean fewer Python loop
        # iterations. Doesn't affect training (still uses self.batch_size).
        self.inference_batch_size = cfg.get('inference_batch_size', 32)

        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.label_to_idx = {c: i for i, c in enumerate(classes)}

        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.encoder = AutoModel.from_pretrained(self.model_name).to(self.device)
        hidden_size = self.encoder.config.hidden_size
        self.head = nn.Sequential(
            nn.Dropout(0.1),
            nn.Linear(hidden_size, self.num_classes),
        ).to(self.device)

    def _tokenize(self, texts, labels=None):
        """Tokenize texts into batches.

        Optimization: tokenize the ENTIRE list in a single tokenizer call.
        The HuggingFace tokenizer is implemented in Rust and is much faster
        when handed the whole list (it parallelizes internally) than when
        called once per document in a Python loop.
        """
        import torch
        from torch.utils.data import DataLoader, TensorDataset

        # Single batched tokenizer call — Rust internals do the heavy lifting.
        enc = self.tokenizer(
            list(texts),
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt',
        )
        ids_tensor = enc['input_ids']
        mask_tensor = enc['attention_mask']

        if labels is not None:
            label_tensor = torch.tensor(labels, dtype=torch.long)
            dataset = TensorDataset(ids_tensor, mask_tensor, label_tensor)
        else:
            dataset = TensorDataset(ids_tensor, mask_tensor)

        return DataLoader(dataset, batch_size=self.batch_size, shuffle=(labels is not None))

    def fit(self, texts: List[str], labels: List[str]):
        """Fine-tune the transformer on the given data."""
        import torch
        import torch.nn as nn
        from transformers import get_linear_schedule_with_warmup
        from collections import Counter

        label_ids = [self.label_to_idx[l] for l in labels]

        # Class imbalance: compute class weights
        counts = Counter(label_ids)
        total = len(label_ids)
        weights = torch.tensor(
            [total / (self.num_classes * counts.get(i, 1)) for i in range(self.num_classes)],
            dtype=torch.float32,
        ).to(self.device)

        loader = self._tokenize(texts, label_ids)

        # CPU optimization: in fast_finetune mode we FREEZE the encoder. The
        # encoder is still used as a fixed feature extractor (forward pass
        # only) and only the small Linear head is trained. This drops the
        # backward-pass cost from O(encoder + head) to O(head), which is
        # a 3-5x speedup on CPU since the encoder has ~66M params and the
        # head has only hidden_size * num_classes = ~3K params.
        if self.fast_finetune:
            for param in self.encoder.parameters():
                param.requires_grad = False
            self.encoder.eval()  # also disables dropout in the encoder
            optimizer = torch.optim.AdamW(
                self.head.parameters(),
                lr=self.lr,
                weight_decay=self.weight_decay,
            )
            mode_msg = "FAST mode (encoder frozen, head only)"
        else:
            optimizer = torch.optim.AdamW([
                {'params': self.encoder.parameters(), 'lr': self.lr * 0.1},
                {'params': self.head.parameters(), 'lr': self.lr},
            ], weight_decay=self.weight_decay)
            mode_msg = "FULL fine-tune (encoder + head)"

        total_steps = len(loader) * self.epochs
        warmup_steps = int(total_steps * self.warmup_ratio)
        scheduler = get_linear_schedule_with_warmup(optimizer, warmup_steps, total_steps)

        criterion = nn.CrossEntropyLoss(weight=weights)

        if not self.fast_finetune:
            self.encoder.train()
        self.head.train()
        print(f'  [transformer] training: {mode_msg}, epochs={self.epochs}, max_length={self.max_length}')

        for epoch in range(self.epochs):
            total_loss = 0
            for batch in loader:
                input_ids = batch[0].to(self.device)
                attention_mask = batch[1].to(self.device)
                targets = batch[2].to(self.device)

                # In fast mode, no grad through the encoder (saves memory + time)
                if self.fast_finetune:
                    with torch.no_grad():
                        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
                else:
                    outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
                pooled = outputs.last_hidden_state[:, 0, :]
                logits = self.head(pooled)
                loss = criterion(logits, targets)

                optimizer.zero_grad()
                loss.backward()
                if self.fast_finetune:
                    torch.nn.utils.clip_grad_norm_(self.head.parameters(), max_norm=1.0)
                else:
                    torch.nn.utils.clip_grad_norm_(
                        list(self.encoder.parameters()) + list(self.head.parameters()),
                        max_norm=1.0,
                    )
                optimizer.step()
                scheduler.step()
                total_loss += loss.item()

            avg_loss = total_loss / len(loader)
            print(f'  [transformer] epoch {epoch + 1}/{self.epochs}, loss={avg_loss:.4f}')

        return self

    def predict_proba(self, texts: List[str]) -> np.ndarray:
        """Returns (n, n_classes) probability matrix."""
        import torch
        from torch.utils.data import DataLoader, TensorDataset

        self.encoder.eval()
        self.head.eval()

        # CPU optimization: use a larger batch size for inference to reduce
        # Python-loop overhead. Doesn't affect quality, only speed.
        original_bs = self.batch_size
        self.batch_size = max(self.batch_size, self.inference_batch_size)
        try:
            loader = self._tokenize(texts)
        finally:
            self.batch_size = original_bs

        all_probs = []
        # inference_mode is faster than no_grad — also disables view tracking.
        with torch.inference_mode():
            for batch in loader:
                input_ids = batch[0].to(self.device)
                attention_mask = batch[1].to(self.device)
                outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
                pooled = outputs.last_hidden_state[:, 0, :]
                logits = self.head(pooled)
                probs = torch.softmax(logits, dim=-1).cpu().numpy()
                all_probs.append(probs)

        return np.vstack(all_probs)

    def predict(self, texts: List[str]) -> List[str]:
        probs = self.predict_proba(texts)
        idx = np.argmax(probs, axis=1)
        return [self.classes[i] for i in idx]

    def save(self, path: str):
        import torch
        os.makedirs(os.path.dirname(path), exist_ok=True)
        save_dir = path.replace('.joblib', '_dir')
        os.makedirs(save_dir, exist_ok=True)
        self.tokenizer.save_pretrained(save_dir)
        self.encoder.save_pretrained(save_dir)
        torch.save(self.head.state_dict(), os.path.join(save_dir, 'head.pt'))
        joblib.dump({
            'classes': self.classes,
            'model_name': self.model_name,
            'max_length': self.max_length,
            'batch_size': self.batch_size,
            'save_dir': save_dir,
        }, path)

    @classmethod
    def load(cls, path: str, cfg: Dict[str, Any] = None) -> 'TransformerModel':
        import torch
        import torch.nn as nn
        from transformers import AutoTokenizer, AutoModel

        meta = joblib.load(path)
        save_dir = meta['save_dir']
        inst = cls.__new__(cls)
        inst.classes = meta['classes']
        inst.num_classes = len(inst.classes)
        inst.model_name = meta['model_name']
        inst.max_length = meta['max_length']
        inst.batch_size = meta['batch_size']
        inst.label_to_idx = {c: i for i, c in enumerate(inst.classes)}
        inst.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        inst.tokenizer = AutoTokenizer.from_pretrained(save_dir)
        inst.encoder = AutoModel.from_pretrained(save_dir).to(inst.device)
        hidden_size = inst.encoder.config.hidden_size
        inst.head = nn.Sequential(
            nn.Dropout(0.1),
            nn.Linear(hidden_size, inst.num_classes),
        ).to(inst.device)
        inst.head.load_state_dict(torch.load(
            os.path.join(save_dir, 'head.pt'), map_location=inst.device
        ))
        return inst
