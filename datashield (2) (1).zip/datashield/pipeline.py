"""
pipeline.py
-----------
The main SensitivityClassifier orchestrator with language routing.

Public API (stable):
    clf = SensitivityClassifier()
    result = clf.predict(text, metadata)
    results = clf.predict_batch(texts, metadatas)

Language routing flow (new in this version):
  1. Detect language (utils.language_detector)
     - 'en' → English model set
     - 'hi' → Hindi model set
     - 'unknown' → fall back to default_language (English)
  2. Dispatch the document to the matching model set
     (LogisticModel + XGBoostModel + Stacker, all trained on that language's
     slice of the synthetic dataset)
  3. Everything downstream is the same: policy engine, explainability,
     audit log.

Why a model PER language rather than one multilingual model:
  - TF-IDF and HashingVectorizer tokenize on whitespace/word boundaries.
    Hindi (Devanagari) and English vocabularies don't share features, so a
    single bag-of-words model would waste capacity on zero-value cells.
  - Separate models are smaller, faster, and much easier to audit (each
    one's feature importances map cleanly to one vocabulary).
  - The problem statement explicitly says "route to language-specific model."

Artifact layout:
  artifacts/
    en/
      logistic.joblib
      xgboost.joblib
      stacker.joblib
    hi/
      logistic.joblib
      xgboost.joblib
      stacker.joblib
"""
import os
import uuid
from typing import List, Dict, Any, Optional
import numpy as np
import yaml

from models.logistic_model import LogisticModel
from models.xgboost_model import XGBoostModel
from ensemble.voting import SoftVotingEnsemble
from ensemble.stacking import StackingEnsemble
from explainability.shap_explainer import ShapExplainer
from explainability.lime_explainer import LimeExplainer
from policy_engine.rules import PolicyEngine
from utils.audit_logger import AuditLogger
from utils.language_detector import detect_language, language_label

# Transformer + IG: optional (graceful fallback if torch not installed).
# transformer_model.py uses subprocess to check torch (avoids Windows DLL crash).
try:
    from models.transformer_model import TORCH_AVAILABLE
    if TORCH_AVAILABLE:
        from models.transformer_model import TransformerModel
        from explainability.ig_explainer import IntegratedGradientsExplainer
    else:
        TransformerModel = None
        IntegratedGradientsExplainer = None
except Exception:
    TORCH_AVAILABLE = False
    TransformerModel = None
    IntegratedGradientsExplainer = None

MODEL_VERSION = 'v3.0.0-bilingual'


class _LanguageModelSet:
    """Bundle of models for one language."""

    def __init__(self, lang: str, artifacts_dir: str, cfg: Dict[str, Any], classes: List[str],
                 force_skip_transformer: bool = False):
        self.lang = lang
        self.classes = classes
        lang_dir = os.path.join(artifacts_dir, lang)

        # Base models
        self.logistic: Optional[LogisticModel] = None
        lr_path = os.path.join(lang_dir, 'logistic.joblib')
        if os.path.exists(lr_path):
            self.logistic = LogisticModel.load(lr_path)

        self.xgboost: Optional[XGBoostModel] = None
        xgb_path = os.path.join(lang_dir, 'xgboost.joblib')
        if os.path.exists(xgb_path):
            self.xgboost = XGBoostModel.load(xgb_path)

        # Transformer (optional). Skip entirely if force_skip_transformer is True
        # — this is what FAST mode uses to ensure the transformer isn't loaded
        # even if its artifacts exist on disk.
        self.transformer = None
        if force_skip_transformer:
            print(f'  [pipeline:{lang}] transformer skipped (force_mode=fast)')
        elif TORCH_AVAILABLE and TransformerModel is not None:
            transformer_path = os.path.join(lang_dir, 'transformer.joblib')
            fallback = cfg.get('transformer', {}).get('fallback_if_missing', True)
            if os.path.exists(transformer_path):
                try:
                    self.transformer = TransformerModel.load(transformer_path)
                    print(f'  [pipeline:{lang}] transformer loaded')
                except Exception as e:
                    print(f'  [pipeline:{lang}] transformer load failed: {e}')
            elif not fallback:
                print(f'  [pipeline:{lang}] transformer artifact missing and fallback disabled')
        else:
            print(f'  [pipeline:{lang}] transformer skipped (torch not installed)')

        # Ensemble
        self.ensemble_strategy = cfg['ensemble']['strategy']
        self.voter = SoftVotingEnsemble(
            weights=cfg['ensemble']['voting_weights'],
            classes=classes,
        )
        self.stacker: Optional[StackingEnsemble] = None
        stacker_path = os.path.join(lang_dir, 'stacker.joblib')
        if self.ensemble_strategy == 'stacking' and os.path.exists(stacker_path):
            try:
                self.stacker = StackingEnsemble.load(stacker_path)
            except Exception as e:
                print(f'  [pipeline:{lang}] stacker load failed: {e}')
                self.ensemble_strategy = 'voting'
        elif self.ensemble_strategy == 'stacking':
            self.ensemble_strategy = 'voting'

        # Explainers
        top_k = cfg['explainability']['top_k_evidence']
        self.shap_explainer = ShapExplainer(self.xgboost, top_k=top_k) if self.xgboost else None
        self.lime_explainer = LimeExplainer(
            self.logistic,
            top_k=top_k,
            num_samples=cfg['explainability']['lime_num_samples'],
        ) if self.logistic else None
        # IG explainer for transformer (only if transformer loaded)
        self.ig_explainer = None
        if self.transformer is not None and IntegratedGradientsExplainer is not None:
            ig_steps = cfg.get('explainability', {}).get('ig_steps', 32)
            self.ig_explainer = IntegratedGradientsExplainer(
                self.transformer, top_k=top_k, n_steps=ig_steps,
            )

    @property
    def is_ready(self) -> bool:
        return self.logistic is not None and self.xgboost is not None

    def run_base_models(self, texts: List[str], metadatas: List[Dict[str, Any]]) -> Dict[str, Optional[np.ndarray]]:
        probs: Dict[str, Optional[np.ndarray]] = {'logistic': None, 'xgboost': None, 'transformer': None}
        if self.logistic is not None:
            try:
                probs['logistic'] = self.logistic.predict_proba(texts)
            except Exception as e:
                print(f'  [pipeline:{self.lang}] logistic failed: {e}')
        if self.xgboost is not None:
            try:
                probs['xgboost'] = self.xgboost.predict_proba(texts, metadatas)
            except Exception as e:
                print(f'  [pipeline:{self.lang}] xgboost failed: {e}')
        if self.transformer is not None:
            try:
                probs['transformer'] = self.transformer.predict_proba(texts)
            except Exception as e:
                print(f'  [pipeline:{self.lang}] transformer failed: {e}')
        return probs


class SensitivityClassifier:
    def __init__(
        self,
        model_config: str = 'configs/model.yaml',
        policy_config: str = 'configs/policy.yaml',
        force_mode: Optional[str] = None,
    ):
        """
        Bilingual sensitivity classifier with optional transformer.

        Args:
            model_config: path to configs/model.yaml
            policy_config: path to configs/policy.yaml
            force_mode: one of None | 'fast' | 'full'
                - None (default): auto-detect — load transformer artifacts if
                  present, otherwise run with LR+XGB only.
                - 'fast': never load the transformer, even if artifacts exist.
                  Used for real-time API serving and CPU-bound environments
                  where the <200ms latency budget matters.
                - 'full': require transformer artifacts. Raises FileNotFoundError
                  if any language's transformer.joblib is missing — caller
                  should train first with `python -m scripts.train_all`.
        """
        if force_mode not in (None, 'fast', 'full'):
            raise ValueError(
                f"force_mode must be None, 'fast', or 'full' (got {force_mode!r})"
            )
        self.force_mode = force_mode

        with open(model_config, 'r', encoding='utf-8') as f:
            self.cfg = yaml.safe_load(f)
        self.classes = self.cfg['classes']
        self.artifacts_dir = self.cfg['paths']['artifacts_dir']
        self.logs_dir = self.cfg['paths']['logs_dir']
        self.languages = self.cfg.get('languages', ['en'])
        self.default_language = self.cfg.get('default_language', 'en')

        # If force_mode='full' is requested, validate that artifacts exist
        # BEFORE we start loading anything. Fail fast with a clear message.
        if force_mode == 'full':
            missing = []
            for lang in self.languages:
                path = os.path.join(self.artifacts_dir, lang, 'transformer.joblib')
                if not os.path.exists(path):
                    missing.append(path)
            if missing:
                raise FileNotFoundError(
                    "force_mode='full' requires transformer artifacts for every "
                    "language, but these are missing:\n  - "
                    + "\n  - ".join(missing)
                    + "\n\nTrain them with:\n"
                    "  python -m scripts.train_all\n"
                    "or switch to fast mode (no transformer): force_mode='fast'."
                )
            if not TORCH_AVAILABLE:
                raise RuntimeError(
                    "force_mode='full' requires torch + transformers to be "
                    "installed. Either install them:\n"
                    "  pip install -r requirements-transformer.txt\n"
                    "or switch to fast mode: force_mode='fast'."
                )

        force_skip = (force_mode == 'fast')

        # Load one model set per supported language
        print(f'[pipeline] loading model sets for languages: {self.languages}')
        if force_mode:
            print(f'[pipeline] force_mode={force_mode}')
        self.model_sets: Dict[str, _LanguageModelSet] = {}
        for lang in self.languages:
            ms = _LanguageModelSet(
                lang, self.artifacts_dir, self.cfg, self.classes,
                force_skip_transformer=force_skip,
            )
            status = 'ready' if ms.is_ready else 'INCOMPLETE'
            print(f'  [{lang}] {status}')
            self.model_sets[lang] = ms

        # Fail fast if default language isn't ready — we have to be able to
        # handle unknown-language docs.
        if not self.model_sets[self.default_language].is_ready:
            print(f'[pipeline] WARNING: default language {self.default_language} not trained.')

        # Shared across languages
        self.policy = PolicyEngine(policy_config)
        self.audit = AuditLogger(log_dir=self.logs_dir)

        # Latency fix: skip LIME perturbation for high-confidence predictions
        # (uses fast coefficient-based fallback instead, saving ~100-150ms)
        self.lime_skip_confidence = self.cfg.get('explainability', {}).get(
            'lime_skip_confidence', 0.90
        )
        print(f'[pipeline] lime_skip_confidence={self.lime_skip_confidence}')

        # Compute runtime mode for auditability and downstream consumers.
        # 'full' = LR + XGB + transformer all loaded for at least one language
        # 'fast' = LR + XGB only (no transformer artifact present anywhere)
        # 'partial' = some languages full, others fast (mixed)
        any_with_transformer = any(
            ms.transformer is not None for ms in self.model_sets.values()
        )
        all_with_transformer = all(
            ms.transformer is not None for ms in self.model_sets.values()
        )
        if all_with_transformer:
            self.runtime_mode = 'full'
        elif any_with_transformer:
            self.runtime_mode = 'partial'
        else:
            self.runtime_mode = 'fast'
        print(f'[pipeline] runtime_mode={self.runtime_mode}  (full=LR+XGB+Transformer, fast=LR+XGB)')
        print(f'[pipeline] ready. model_version={MODEL_VERSION}')

    # --------------------------------------------------------
    def _route(self, text: str) -> str:
        """Return the language code to route this document through."""
        detected = detect_language(text)
        if detected in self.model_sets and self.model_sets[detected].is_ready:
            return detected
        # Fall back to default (handles 'unknown' and languages where the
        # model isn't trained yet).
        return self.default_language

    # --------------------------------------------------------
    def predict(self, text: str, metadata: Optional[Dict[str, Any]] = None,
                doc_id: Optional[str] = None) -> Dict[str, Any]:
        return self.predict_batch([text], [metadata or {}], doc_ids=[doc_id] if doc_id else None)[0]

    def predict_batch(
        self,
        texts: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        doc_ids: Optional[List[Optional[str]]] = None,
    ) -> List[Dict[str, Any]]:
        if metadatas is None:
            metadatas = [{} for _ in texts]
        if doc_ids is None:
            doc_ids = [None] * len(texts)

        # Group texts by routed language to batch-process each set efficiently
        groups: Dict[str, List[int]] = {}
        routing_info: List[Dict[str, str]] = []
        for i, t in enumerate(texts):
            detected = detect_language(t)
            routed = self._route(t)
            groups.setdefault(routed, []).append(i)
            routing_info.append({'detected': detected, 'routed': routed})

        # Pre-allocate output
        results: List[Optional[Dict[str, Any]]] = [None] * len(texts)

        # Process each language group
        for lang, idxs in groups.items():
            ms = self.model_sets[lang]
            sub_texts = [texts[i] for i in idxs]
            sub_meta = [metadatas[i] for i in idxs]

            model_probs = ms.run_base_models(sub_texts, sub_meta)

            # Ensemble
            if ms.ensemble_strategy == 'stacking' and ms.stacker is not None:
                combined = ms.stacker.predict_proba(model_probs)
                ensemble_used = 'stacking'
            else:
                combined = ms.voter.combine(model_probs)
                ensemble_used = 'voting'

            active_models = ms.voter.active_models(model_probs)

            for j, global_i in enumerate(idxs):
                probs = combined[j]
                pre_label_idx = int(np.argmax(probs))
                pre_label = self.classes[pre_label_idx]
                max_class_prob = float(np.max(probs))
                class_probs = {c: float(round(probs[k], 4)) for k, c in enumerate(self.classes)}

                # Policy
                decision = self.policy.apply(sub_texts[j], pre_label, class_probs)
                final_label = decision.post_policy_label
                final_conf = class_probs.get(final_label, 0.0)

                # Evidence (with latency-optimized LIME skip for high-confidence predictions)
                evidence = self._gather_evidence(
                    sub_texts[j], sub_meta[j], final_label, active_models, ms, decision,
                    max_class_prob=max_class_prob,
                )

                # Per-model contributions
                model_contributions = {}
                for m_name, m_probs in model_probs.items():
                    if m_probs is None:
                        model_contributions[m_name] = None
                    else:
                        model_contributions[m_name] = round(float(m_probs[j][pre_label_idx]), 4)

                detected = routing_info[global_i]['detected']
                user_doc_id = doc_ids[global_i] if global_i < len(doc_ids) else None
                result = {
                    'doc_id': user_doc_id or str(uuid.uuid4()),
                    'label': final_label,
                    'confidence': round(final_conf, 4),
                    'class_probabilities': class_probs,
                    'evidence': evidence,
                    'model_contributions': model_contributions,
                    'policy_trace': decision.to_dict(),
                    'language': {
                        'detected': detected,
                        'routed_to': lang,
                        'detected_label': language_label(detected),
                    },
                    'audit': {
                        'model_version': MODEL_VERSION,
                        'ensemble_used': ensemble_used,
                        'active_models': active_models,
                        'runtime_mode': self.runtime_mode,
                    },
                }
                self.audit.log(texts[global_i], result, model_version=MODEL_VERSION)
                results[global_i] = result

        return results  # type: ignore

    # --------------------------------------------------------
    def _gather_evidence(
        self,
        text: str,
        metadata: Dict[str, Any],
        predicted_class: str,
        active_models: List[str],
        ms: _LanguageModelSet,
        decision,
        max_class_prob: float = 0.0,
    ) -> List[Dict[str, Any]]:
        evidence: List[Dict[str, Any]] = []

        # Policy-detected PII hits first (independently verifiable)
        for hit in decision.pii_hits:
            evidence.append({
                'token': hit.matched_value_masked,
                'weight': 1.0,
                'source': f'policy:{hit.rule_name}',
            })

        if 'xgboost' in active_models and ms.shap_explainer is not None:
            try:
                evidence.extend(ms.shap_explainer.explain(text, metadata, predicted_class))
            except Exception as e:
                print(f'  [pipeline:{ms.lang}] shap failed: {e}')

        # LATENCY FIX: Skip expensive LIME perturbation when the model is
        # highly confident (max_class_prob > lime_skip_confidence). Uses the
        # fast coefficient-based fallback (~0ms) instead of full LIME
        # perturbation (~100-150ms). This brings p95 under 200ms.
        if 'logistic' in active_models and ms.lime_explainer is not None:
            try:
                if max_class_prob > self.lime_skip_confidence:
                    # High confidence → fast coefficient fallback
                    evidence.extend(
                        ms.lime_explainer._fallback_explain(text, predicted_class)
                    )
                else:
                    # Low confidence → full LIME perturbation (more evidence needed)
                    evidence.extend(ms.lime_explainer.explain(text, predicted_class))
            except Exception as e:
                print(f'  [pipeline:{ms.lang}] lime failed: {e}')

        if 'transformer' in active_models and ms.ig_explainer is not None:
            try:
                evidence.extend(ms.ig_explainer.explain(text, predicted_class))
            except Exception as e:
                print(f'  [pipeline:{ms.lang}] IG failed: {e}')

        # Dedupe by (token, source) — keep max weight
        seen: Dict[tuple, Dict[str, Any]] = {}
        for e in evidence:
            key = (e['token'].lower(), e['source'])
            if key not in seen or e['weight'] > seen[key]['weight']:
                seen[key] = e
        deduped = sorted(seen.values(), key=lambda x: -x['weight'])

        # Compliance: ≥3 evidence tokens
        if len(deduped) < 3:
            tokens = [t for t in text.split() if len(t) > 3][:6]
            for tok in tokens:
                if any(e['token'].lower() == tok.lower() for e in deduped):
                    continue
                deduped.append({
                    'token': tok.strip('.,;:!?'),
                    'weight': 0.01,
                    'source': 'lexical_fallback',
                })
                if len(deduped) >= 3:
                    break

        top_k = self.cfg['explainability']['top_k_evidence']
        return deduped[:top_k + len(decision.pii_hits)]
